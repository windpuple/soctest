/**
 * (c) Copyright 2011, Verigy Technologies, all rights reserved.
 *
 * Modification History:
 *
 *
 */

//for testmethod framework interfaces
#include "testmethod.hpp"
//for testmethod API interfaces
#include "mapi.hpp"

#include "JitterStardustUtil.hpp"
/**
 *----------------------------------------------------------------------*
 * @testmethod Class: JitterStardust
 *
 * @Purpose: jitter measurement on the output side of a device.
 *
 *----------------------------------------------------------------------*
 * @Description:
 *   This function performs jitter test shift the spec value. 
 *   When the spec value is shifted,a function test will be runned,then
 *   we can get error count after function test.Through analyzing error
 *   count, we caculate jitter
 * @Parameters:
 *   1.string& pinlist : 
 *     Define a list of pins/pin groups the spec is shifted for.
 *     valid type :O,IO               
 *   2.string& portName:           optional {@|portName}
 *     Port name of above test pins for Multiport Setups.
 *     NOTE:only pins of one port can be selected.     
 *     default is @.
 *   3.string& specName_postfix: 
 *     A spec-variable corresponding to each test-pin should be predefined
 *     and used bu this TestMethod to do jitter measurement.
 *     For example:if Tx0 is the input pin,its corresponding spec-variables
 *     are Tx0_offset,this parameter needs to be set as "offset".
 *   4.testmethod::SpecValue UI_width:   {ns}
 *     Bit time of test pattern.
 *     For example:2.5Gb/s -> 0.4ns
 *   5.testmethod::SpecValue start:   {ns}
 *     --if autoSyncMode is "OFF":start of Data Acquisition
 *     --if autoSyncMode is "ON" or "ON_KEEP_VALUE": start of linear Pattern
 *     Alignment Search
 *   6.testmethod::SpecValue stop:    {ns}
 *     --if autoSyncMode is "OFF":stop of Data Acquisition
 *     --if autoSyncMode is "ON" or "ON_KEEP_VALUE": stop of linear Pattern 
 *     Alignment Search      
 *   7.testmethod::SpecValue dataAcquStepWidth:  {ns}
 *     Step width for Data Acquisition
 *   8.int passOnMaxErrorCount:     optional
 *     It defines the pass criteria for all following execution.That is,
 *     besides normally regarding pass as 0 error count, users can 
 *     specify the maximum edge count as the pass/fail threshold.
 *     default vaule: 0
 *   9.string& autoSyncMode: {OFF | ON | ON_KEEP_VALUE}
 *     Enabling of linear Pattern Alignment Search to find passing pattern.  
 *       With ON_KEEP_VALUE option the Sync value will be kept 
 *     after the finishing of the testsuite execution.
 *       With ON option the spec variable will be reset to its 
 *     original value after finishing the test.
 *       With OFF option linear Pattern Alignment Search to find
 *      passing pattern is disable.
 *       defalut is ON.
 *   10.testmethod::SpecValue autoSyncStepWidth: {ns} 
 *      Step width for AutoSync Search.
 *   11.string& transitionSearchMode:  {OFF | ON}
 *        With ON,Binary Search for Pass/Fail Transition of 
 *      MIN_BER poit with maximum search range of one "UI_width"
 *      and resolution of dataAcquStepWidth.
 *        With OFF,on transiton search will not be made.
 *      default is ON.
 *   12.string& transition:  {LEFT | RIGHT | BOTH}
 *      Determine which side of bit transition will be searched 
 *      if transitionSearchMode is ON and be acquired for jitter
 *      histogram calculation. If both autoSyncMode and 
 *      transitionSearchMode are OFF,this parameter is not in effect,
 *      and users have to choose proper values of start and stop for 
 *      acquisition based on the test requirement.
 *      default is LEFT.
 *   13.int errorMapStartCycle:
 *      This parameter determines the start cycle within the test pattern
 *      where the data acquisition with error map starts.
 *   14.int acquisitionDepth:
 *      this parameter determines how many samples will be acquired with
 *      the error map. The maximum recording size depends on whether the test
 *      processor error map or the large error map in the vector memory is
 *      used. Use numbers on a 2^x basis.
 *   15.string& FFTWindow:
 *      windowing option for FFT. 
 *   16.string& outputMode: {SUMMARY | DETAIL | ANALYSIS}
 *      This parameter is in effect only if output is set ReportUI.
 *      SUMMARY - a result table will be printed in the Report Window.
 *      DETAIL  - an ASCII plot of the Error Count and the histogram curve will 
 *                be printed in report window.
 *      ANALYSIS - the jitter histogram data will be transfer to signal  
 *                 analyzer tool for display and debuggine.
 *     default is SUMMARY.
 *   17.string& output:               {ReportUI | None}
 *     Print message or not. 
 *     ReportUI - for debug mode
 *     None - for production mode
 *     default is ReportUI.
 *   18.string mTestName        {frequency_MHz}
 *      test limits' names
 *
 * NOTE: this testmethod just supports PinScale.
 *----------------------------------------------------------------------*
 */


class JitterStardust: public testmethod::TestMethod
{
protected:
  string  pinlist;
  string  portName;
  string  specName_postfix;
  testmethod::SpecValue  UI_width;
  testmethod::SpecValue  start;
  testmethod::SpecValue  stop;
  testmethod::SpecValue  dataAcquStepWidth;
  int  passOnMaxErrorCount;
  string  autoSyncMode;
  testmethod::SpecValue  autoSyncStepWidth;
  string  transitionSearchMode;
  string  transition;
  int  errorMapStartCycle;
  int  acquisitionDepth;
  string  FFTWindow;
  string  outputMode;
  string  output;
  string  mTestName;
protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    addParameter("pinlist",
                 "string",
                 &pinlist)
      .setComment("setup pins");
    addParameter("portName",
                 "string",
                 &portName)
      .setComment("port name for multiport setups");
    addParameter("specName_postfix",
                 "string",
                 &specName_postfix)
      .setComment("spec-variable's postfix");
    addParameter("UI_width",
                 "SpecValue",
                 &UI_width)
      .setDefault("0[ns]")
      .setComment("bit time of test pattern,e.g. 0.4[ns]");
    addParameter("start",
                 "SpecValue",
                 &start)
      .setDefault("0[ns]")
      .setComment("start value, e.g. 0.1[ns]");
    addParameter("stop",
                 "SpecValue",
                 &stop)
      .setDefault("0[ns]")
      .setComment("stop value, e.g. 2.5[ns]");
    addParameter("dataAcquStepWidth",
                 "SpecValue",
                 &dataAcquStepWidth)
      .setDefault("0[ns]")
      .setComment("step width for data acquisition, e.g. 0.01[ns]");
    addParameter("passOnMaxErrorCount",
                 "int",
                 &passOnMaxErrorCount)
      .setDefault("0")
      .setComment("error count as the pass/fail threshold");
    addParameter("autoSync",
                 "string",
                 &autoSyncMode)
      .setDefault("ON")
      .setOptions("ON:OFF:ON_KEEP_VALUE")
      .setComment("autosync mode");
    addParameter("autoSync.stepWidth",
                 "SpecValue",
                 &autoSyncStepWidth)
      .setDefault("0[ns]")
      .setComment("setp width for autosync search, e.g. 1[ns]");
    addParameter("transitionSearch",
                 "string",
                 &transitionSearchMode)
      .setDefault("ON")
      .setOptions("ON:OFF")
      .setComment("transition search mode");
    addParameter("transitionSearch.transition",
                 "string",
                 &transition)
      .setDefault("LEFT")
      .setOptions("LEFT:RIGHT:BOTH")
      .setComment("determine data acquisition's direction");
    addParameter("errorMapStartCycle",
                 "int",
                 &errorMapStartCycle)
      .setDefault("0")
      .setComment("determine the start cycle within the test pattern \n"
                  "where the data acquisition with error map starts");
    addParameter("acquisitionDepth",
                 "int",
                 &acquisitionDepth)
      .setComment("detemine how many samples will be acquired with error map\n"
                  "Notes: the number on a 2^x basis");
    addParameter("FFTWindow",
                 "string",
                 &FFTWindow)
      .setDefault("Uniform")
      .setOptions("Uniform : Hanning: Hamming : Blackman")
      .setComment("windowing option for FFT");
    addParameter("output",
                 "string",
                 &output)
      .setDefault("ReportUI")
      .setOptions("ReportUI:NONE")
      .setComment("display result or not");
    addParameter("output.mode",
                 "string",
                 &outputMode)
      .setDefault("SUMMARY")
      .setOptions("SUMMARY:DETAIL:ANALYSIS")
      .setComment("determine output mode ");
    addParameter("testName",
                 "string",
                 &mTestName)
      .setDefault("frequency_MHz")
      .setComment("test limit's name, default is \"frequency_MHz\", no unit means 'MHz'\n"
         "if test table is used, the limit is defined in file\n"
         "if predefined limit is used, the limit name must be as same as default.");
 
    addLimit("frequency_MHz");
  }
  
  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
      static JitterStardustUtil::JitterStardustParameter parameters;
      static JitterStardustUtil::JitterStardustLimit testLimit;
      static JitterStardustUtil::JitterStardustResult results;
    /*----------------------------
    * 1. prepare for test
    *----------------------------
    */
    ON_FIRST_INVOCATION_BEGIN();
      /*process all parameters needed in test*/
      JitterStardustUtil::processParameters(
                                  pinlist,
                                  portName,
                                  specName_postfix,
                                  UI_width.getValueAsTargetUnit("ns"),
                                  start.getValueAsTargetUnit("ns"),
                                  stop.getValueAsTargetUnit("ns"),
                                  dataAcquStepWidth.getValueAsTargetUnit("ns"),
                                  passOnMaxErrorCount,
                                  autoSyncMode,
                                  autoSyncStepWidth.getValueAsTargetUnit("ns"),
                                  transitionSearchMode,
                                  transition,
                                  errorMapStartCycle,
                                  acquisitionDepth,
                                  FFTWindow,
                                  outputMode,
                                  parameters);
  
      JitterStardustUtil::processLimit(mTestName,testLimit);
    ON_FIRST_INVOCATION_END();
  
    /* do test and store the results */
    JitterStardustUtil::doMeasurement(parameters,results);
  
    /* datalog */
    JitterStardustUtil::judgeAndDatalog(parameters,results,testLimit);
  
    /* output results */
    JitterStardustUtil::reportToUI(parameters,results,output);
  
    return ;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   *
   *Note: TestMethod API should not be used in this method.
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    if(parameterIdentifier == "UI_width")
    {
      if(UI_width.getValueAsTargetUnit("ns") <= 0)
      {
        getParameter("UI_width").setValid(false);
        getParameter("UI_width").setMessage("UI_width should be greater than zero!");
      }
      else
      {
        getParameter("UI_width").setValid(true);
      }
    }
    else if(parameterIdentifier == "dataAcquStepWidth")
    {
      if(dataAcquStepWidth.getValueAsTargetUnit("ns") <= 0)
      {
        getParameter("dataAcquStepWidth").setValid(false);
        getParameter("dataAcquStepWidth").setMessage("dataAcquStepWidth should be greater than zero!");
      }
      else
      {
        getParameter("dataAcquStepWidth").setValid(true);
      }
    }
    else if(parameterIdentifier == "passOnMaxErrorCount")
    {
      if(passOnMaxErrorCount < 0)
      {
        getParameter("passOnMaxErrorCount").setValid(false);
        getParameter("passOnMaxErrorCount").setMessage("passOnMaxErrorCount should not be negative!");
      }
      else
      {
        getParameter("passOnMaxErrorCount").setValid(true);
      }
    }
    else if(parameterIdentifier == "autoSync")
    {
      if(CommonUtil::trim(autoSyncMode) == "OFF")
      {
        getParameter("autoSync.stepWidth").setEnabled(false);
      }
      else
      {
        getParameter("autoSync.stepWidth").setEnabled(true);
      }
    }
    else if(parameterIdentifier == "autoSync.stepWidth")
    {
      if(autoSyncStepWidth.getValueAsTargetUnit("ns") <= 0)
      {
        getParameter("autoSync.stepWidth").setValid(false);
        getParameter("autoSync.stepWidth").setMessage("autoSyncStepWidth should be greater than zero!");
      }
      else
      {
        getParameter("autoSync.stepWidth").setValid(true);
      }
    }
    else if(parameterIdentifier == "transitionSearch")
    {
      if(CommonUtil::trim(transitionSearchMode) == "OFF")
      {
        getParameter("transitionSearch.transition").setEnabled(false);
      }
      else
      {
        getParameter("transitionSearch.transition").setEnabled(true);
      }
    }
    else if(parameterIdentifier == "errorMapStartCycle")
    {
      if(errorMapStartCycle < 0)
      {
        getParameter("errorMapStartCycle").setValid(false);
        getParameter("errorMapStartCycle").setMessage("errorMapStartCycle should not be negative!");
      }
      else
      {
        getParameter("errorMapStartCycle").setValid(true);
      }
    }
    else if(parameterIdentifier == "acquisitionDepth")
    {
      if(acquisitionDepth <= 0)
      {
        getParameter("acquisitionDepth").setValid(false);
        getParameter("acquisitionDepth").setMessage("acquisitionDepth should be greater than zero!");
      }
      else
      {
        getParameter("acquisitionDepth").setValid(true);
      }
    }
    else if (parameterIdentifier == "testName")
    {
      getParameter(parameterIdentifier).setValid(!mTestName.empty());
    }
    else if(parameterIdentifier == "output")
    {
      if(CommonUtil::trim(output) == "NONE")
      {
        getParameter("output.mode").setEnabled(false);
      }
      else
      {
        getParameter("output.mode").setEnabled(true);
      }
    }
    return ;
  }
  
  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string  getComment() const
  {
     static string comment = _TML_VERSION;
     return comment;
  }
};

REGISTER_TESTMETHOD("AcTest.JitterStardust", JitterStardust);
