/**
 * (c) Copyright 2011, Verigy Technologies, all rights reserved.
 *
 * Modification History:
 *
 *
 */

//for testmethod framework interfaces
#include "testmethod.hpp"
//for testmethod API interfaces
#include "mapi.hpp"

#include "JitterSeparationUtil.hpp"
/**
 *----------------------------------------------------------------------*
 * @testmethod Class: JitterSeparation
 *
 * @Purpose: jitter measurement on the output side of a device.
 *
 *----------------------------------------------------------------------*
 * @Description:
 *   This function performs jitter test shift the spec value. 
 *   When the spec value is shifted,a function test will be runned,then
 *   we can get error count after function test.Through analyzing error
 *   count, we caculate jitter
 * @Parameters:
 *   1.string& pinlist : 
 *     Define a list of pins/pin groups the spec is shifted for.
 *     valid type :O,IO               
 *   2.string& portName:           optional {@|portName}
 *     Port name of above test pins for Multiport Setups.
 *     NOTE:only pins of one port can be selected.     
 *     default is @.
 *   3.string& specName_postfix: 
 *     A spec-variable corresponding to each test-pin should be predefined
 *     and used bu this TestMethod to do jitter measurement.
 *     For example:if Tx0 is the input pin,its corresponding spec-variables
 *     are Tx0_offset,this parameter needs to be set as "offset".
 *   4.testmethod::SpecValue UI_width: {ns}
 *     Bit time of test pattern.
 *     For example:2.5Gb/s -> 0.4ns
 *   5.testmethod::SpecValue start: {ns}
 *     --if autoSyncMode is "OFF":start of Data Acquisition
 *     --if autoSyncMode is "ON" or "ON_KEEP_VALUE": start of linear Pattern
 *     Alignment Search
 *   6.testmethod::SpecValue stop: {ns}
 *     --if autoSyncMode is "OFF":stop of Data Acquisition
 *     --if autoSyncMode is "ON" or "ON_KEEP_VALUE": stop of linear Pattern
 *     Alignment Search      
 *   7.testmethod::SpecValue dataAcquStepWidth: {ns}
 *     Step width for Data Acquisition
 *   8.int passOnMaxErrorCount:     optional
 *     It defines the pass criteria for all following execution.That is,besides 
 *     normally regarding pass as 0 error count, users can specify the maximum 
 *     edge count as the pass/fail threshold.
 *     default vaule: 0
 *   9.string& autoSyncMode: {OFF | ON | ON_KEEP_VALUE}
 *     Enabling of linear Pattern Alignment Search to find passing pattern.  
 *     With ON_KEEP_VALUE option the Sync value will be kept after the finishing 
 *     of the testsuite execution.
 *     With ON option the spec variable will be reset to its original value
 *     after finishing the test.
 *     default is ON.
 *     With OFF option linear Pattern Alignment Search to find passing pattern 
 *     is disable.
 *   10.testmethod::SpecValue autoSyncStepWidth: {ns} 
 *      Step width for AutoSync Search.
 *   11.string& transitionSearchMode:  {OFF | ON}
 *      With ON,Binary Search for Pass/Fail Transition of MIN_BER poit with
 *      maximum search range of one "UI_width" and 
 *      resolution of dataAcquStepWidth_ns.
 *      With OFF,on transiton search will be made.
 *      default is ON.
 * 
 *      NOTES: autoSyncMode and transitionSearchMode can't be
 *      OFF at the same time for jitter separation test, because
 *      this test need two side data to do jitter separation.
 *   12.int bitNumbers:
 *      The total bit numbers of the pattern
 *   13.double fittingRangeMax:
 *      Max BER number for fitting
 *   14.double fittingRangeMin:
 *      Min BER number for fitting
 *   15.int BERFactor,
 *      Target BER for total jitter calculation.
 *   16.string& outputMode: {SUMMARY | DETAIL | ANALYSIS}
 *      This parameter is in effect only if output is set ReportUI.
 *      SUMMARY - a result table will be printed in the Report Window.
 *      DETAIL  - an ASCII plot of the Error Count and the histogram curve will 
 *                be printed in report window.
 *      ANALYSIS - the jitter histogram data will be transfer to signal analyzer 
 *                 tool for display and debuggine.
 *     default is SUMMARY.
 *   17.string& output:               {ReportUI | None}
 *     Print message or not. 
 *     ReportUI - for debug mode
 *     None - for production mode
 *     default is ReportUI.
 *   18.string mTestName        {(random_jitter_ps,deterministic_jitter_ps,total_jitter_ps)}
 *     three test limits' names in pairs
 *
 * @NOTE: this testmethod just spports PinScale.
 *----------------------------------------------------------------------*
 */


class JitterSeparation: public testmethod::TestMethod
{
protected:
  string  pinlist;
  string  portName;
  string  specName_postfix;
  testmethod::SpecValue  UI_width;
  testmethod::SpecValue  start;
  testmethod::SpecValue  stop;
  testmethod::SpecValue  dataAcquStepWidth;
  int  passOnMaxErrorCount;
  string  autoSyncMode;
  testmethod::SpecValue  autoSyncStepWidth;
  string  transitionSearchMode;
  int  bitNumbers;
  double  fittingRangeMax;
  double  fittingRangeMin;
  int  BERFactor;
  string  outputMode;
  string  output;
  string  mTestName;
protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    addParameter("pinlist",
                 "string",
                 &pinlist)
      .setComment("setup pins");
    addParameter("portName",
                 "string",
                 &portName)
      .setComment("port name for multiport setups");
    addParameter("specName_postfix",
                 "string",
                 &specName_postfix)
      .setComment("spec-variable's postfix");
    addParameter("UI_width",
                 "SpecValue",
                 &UI_width)
      .setDefault("0[ns]")
      .setComment("bit time of test pattern,e.g. 0.4[ns]");
    addParameter("start",
                 "SpecValue",
                 &start)
      .setDefault("0[ns]")
      .setComment("start value, e.g. 0.1[ns]");
    addParameter("stop",
                 "SpecValue",
                 &stop)
      .setDefault("0[ns]")
      .setComment("stop value, e.g. 2.5[ns]");
    addParameter("dataAcquStepWidth",
                 "SpecValue",
                 &dataAcquStepWidth)
      .setDefault("0[ns]")
      .setComment("step width for data acquisition, e.g. 0.01[ns]");
    addParameter("passOnMaxErrorCount",
                 "int",
                 &passOnMaxErrorCount)
      .setDefault("0")
      .setComment("error count as the pass/fail threshold");
    addParameter("autoSync",
                 "string",
                 &autoSyncMode)
      .setDefault("ON")
      .setOptions("ON:OFF:ON_KEEP_VALUE")
      .setComment("autosync mode");
    addParameter("autoSync.stepWidth",
                 "SpecValue",
                 &autoSyncStepWidth)
      .setDefault("0[ns]")
      .setComment("setp width for autosync search, e.g. 1.0[ns]");
    addParameter("transitionSearchMode",
                 "string",
                 &transitionSearchMode)
      .setDefault("ON")
      .setOptions("ON:OFF")
      .setComment("transition search mode");
    addParameter("bitNumbers",
                 "int",
                 &bitNumbers)
      .setComment("the total bit numbers of the pattern");
    addParameter("fittingRangeMax",
                 "double",
                 &fittingRangeMax)
      .setDefault("1.0")
      .setComment("Max BER number for fitting");
    addParameter("fittingRangeMin",
                 "double",
                 &fittingRangeMin)
      .setDefault("0.0")
      .setComment("Min BER number for fitting");
    addParameter("BERFactor",
                 "int",
                 &BERFactor)
      .setDefault("-12")
      .setOptions("-6:-7:-8:-9:-10:-11:-12:-13:-14:-15")
      .setComment("Target BER for total jitter calculation");
    addParameter("output",
                 "string",
                 &output)
       .setDefault("ReportUI")
       .setOptions("ReportUI:NONE")
       .setComment("display result or not");
    addParameter("output.mode",
                 "string",
                 &outputMode)
      .setDefault("SUMMARY")
      .setOptions("SUMMARY:DETAIL:ANALYSIS")
      .setComment("determine output mode ");
    
    addParameter("testName",
                 "string",
                 &mTestName)
      .setDefault("(random_jitter_ps,deterministic_jitter_ps,total_jitter_ps)")
      .setComment("three test limits' names in pairs, "
         "like \"(randomJitter,determJitter,totalJitter\")\n"
         "pair is ordered:\n" 
         "  pair.first is for random, no unit means 'ps'\n"
         "  pair.second is for deterministic, no unit means 'ps'\n"
         "  pair.third is for total, no unit means 'ps'\n"
         "if test table is used, the limit is defined in file\n"
         "if predefined limit is used, the limit name must be as same as default.");

    addLimit("random_jitter_ps");
    addLimit("deterministic_jitter_ps");
    addLimit("total_jitter_ps");
  }
  
  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
    static JitterSeparationUtil::JitterSeparationParameter parameters;
    static JitterSeparationUtil::JitterSeparationLimit testLimit;
    static JitterSeparationUtil::JitterSeparationResult results;
    /*----------------------------
     * 1. prepare for test
     *----------------------------
     */
    ON_FIRST_INVOCATION_BEGIN();
      /*process all parameters needed in test*/
      JitterSeparationUtil::processParameters(
                                  pinlist,
                                  portName,
                                  specName_postfix,
                                  UI_width.getValueAsTargetUnit("ns"),
                                  start.getValueAsTargetUnit("ns"),
                                  stop.getValueAsTargetUnit("ns"),
                                  dataAcquStepWidth.getValueAsTargetUnit("ns"),
                                  passOnMaxErrorCount,
                                  autoSyncMode,
                                  autoSyncStepWidth.getValueAsTargetUnit("ns"),
                                  transitionSearchMode,
                                  bitNumbers,
                                  fittingRangeMax,
                                  fittingRangeMin,
                                  BERFactor,
                                  outputMode,
                                  parameters);
  
      JitterSeparationUtil::processLimit(mTestName,testLimit);
    ON_FIRST_INVOCATION_END();
  
    /* do test and store the results */
    JitterSeparationUtil::doMeasurement(parameters,results);
  
    /* datalog */
    JitterSeparationUtil::judgeAndDatalog(parameters,results,testLimit);
  
    /* output results */
    JitterSeparationUtil::reportToUI(parameters,results,output);
  
    return ;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   *
   *Note: TestMethod API should not be used in this method.
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    if(parameterIdentifier == "UI_width")
    {
      if(UI_width.getValueAsTargetUnit("ns") <= 0)
      {
        getParameter("UI_width").setValid(false);
        getParameter("UI_width").setMessage("UI_width shoult be greater than zero!");
      }
      else
      {
        getParameter("UI_width").setValid(true);
      }
    }
    else if(parameterIdentifier == "dataAcquStepWidth")
    {
      if(dataAcquStepWidth.getValueAsTargetUnit("ns") <= 0)
      {
        getParameter("dataAcquStepWidth").setValid(false);
        getParameter("dataAcquStepWidth").setMessage("dataAcquStepWidth shoult be greater than zero!");
      }
      else
      {
        getParameter("dataAcquStepWidth").setValid(true);
      }
    }
    else if(parameterIdentifier == "passOnMaxErrorCount")
    {
      if(passOnMaxErrorCount < 0)
      {
        getParameter("passOnMaxErrorCount").setValid(false);
        getParameter("passOnMaxErrorCount").setMessage("passOnMaxErrorCount shoult not be negative!");
      }
      else
      {
        getParameter("passOnMaxErrorCount").setValid(true);
      }
    }
    else if(parameterIdentifier == "autoSync")
    {
      if(CommonUtil::trim(autoSyncMode) == "OFF")
      {
        getParameter("autoSync.stepWidth").setEnabled(false);
      }
      else
      {
        getParameter("autoSync.stepWidth").setEnabled(true);
      }
    }
    else if(parameterIdentifier == "autoSync.stepWidth")
    {
      if(autoSyncStepWidth.getValueAsTargetUnit("ns") <= 0)
      {
        getParameter("autoSync.stepWidth").setValid(false);
        getParameter("autoSync.stepWidth").setMessage("autoSyncStepWidth shoult be greater than zero!");
      }
      else
      {
        getParameter("autoSync.stepWidth").setValid(true);
      }
    }
    else if(parameterIdentifier == "fittingRangeMax")
    {
      if(fittingRangeMax > 1)
      {
        getParameter("fittingRangeMax").setValid(false);
        getParameter("fittingRangeMax").setMessage("fittingRangeMax should be less than 1.");
      }
      else
      {
        getParameter("fittingRangeMax").setValid(true);
      }
    }
    else if(parameterIdentifier == "fittingRangeMin")
    {
      if(fittingRangeMin <= 0)
      {
        getParameter("fittingRangeMin").setValid(false);
        getParameter("fittingRangeMin").setMessage("fittingRangeMin should be greater than zero!");
      }
      else
      {
        getParameter("fittingRangeMin").setValid(true);
      }
    }
    else if (parameterIdentifier == "testName")
    {
      vector<string> names;
      if(JitterSeparationUtil::processTestName(mTestName,names))
      {
        getParameter(parameterIdentifier).setValid(true);
      }
      else
      {
        getParameter(parameterIdentifier).setValid(false);
        getParameter(parameterIdentifier).setMessage(
          "test name should be three names in order, like \"(randomJitter,determJitter,totalJitter)\".");
      }
    }
    else if(parameterIdentifier == "output")
    {
      if(CommonUtil::trim(output) == "NONE")
      {
        getParameter("output.mode").setEnabled(false);
      }
      else
      {
        getParameter("output.mode").setEnabled(true);
      }
    }

    return ;
  }
  
  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string  getComment() const
  {
     static string comment = _TML_VERSION;
     return comment;
  }
};

REGISTER_TESTMETHOD("AcTest.JitterSeparation", JitterSeparation);
