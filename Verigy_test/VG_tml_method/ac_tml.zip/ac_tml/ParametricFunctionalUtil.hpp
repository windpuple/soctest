#ifndef INCLUDE_PARAMETRICFUNCTIONAL_H
#define	INCLUDE_PARAMETRICFUNCTIONAL_H
#include "CommonUtil.hpp"
#include "FunctionalUtil.hpp"

#define HAS_PARAM_FUNC_VALUE(value) (fabs((value) - 9999) > 1e-16)
/*-----------------------------------------------------------------------*
 * This part contains data structure and utilities dedicated for:
 * parametric functional test
 * ----------------------------------------------------------------------*
 */
class ParamFuncTestUtil
{
public:

struct ParamFuncTestResult
{   

  /*
   * this two-layered map contains result of search test of current site.
   * <key> STRING of combination of setup pins and result pins.
   * <value> SpecSearchResultData holds search result
   * for example:
   * setup pins: s1,s2;
   * result pins: r1,r2;
   * execution mode: serial for both setup and result pins
   * =>
   * resultData["s1"]["r1"] -> {TM::TransitionPassFail,true,2.20,2.30}
   * resultData["s1"]["r2"] -> {TM::TransitionPassFail,true,2.25,2.31}
   * resultData["s2"]{"r1"] -> {TM::AllFail,false,0.0,0.0}
   * resultData["s2"]["r2"] -> {TM::AllPass,false,0.0,0.0}
   */
   map< STRING,map<STRING,SpecSearchResultData> > searchResult;

   /*these two bool vars for dataloging measured pass range*/
   Boolean isSetupPinsSerial;
   Boolean isResultPinsSerial;
   /*these two string vector for dataloging*/
   STRING_VECTOR vecSetupPins;
   STRING_VECTOR vecResultPins;
};

enum ParamFuncTestCase
{
  PURE_FUNCTIONAL_TEST,
  PASS_FAIL_TEST_MIN_AND_MAX,
  PASS_FAIL_TEST_MIN_ONLY,
  PASS_FAIL_TEST_MAX_ONLY,
  PASS_FAIL_TEST_NO_MIN_MAX,
  VALUE_TEST_MIN_AND_MAX,
  VALUE_TEST_MIN_ONLY,
  VALUE_TEST_MAX_ONLY,
  VALUE_TEST_NO_MIN_MAX,
  UNKNOWN_CASE = 0xff
};

struct ParamFuncTestParameter 
{
  ParamFuncTestCase testCase;
  /*parameter stuffs for spec search*/ 
  STRING specName;
  TM::SPEC_TYPE specType;
  Boolean isSerialForSetupPins; /*false: parallel*/
  Boolean isSerialForResultPins;/*false: parallel*/
  STRING_VECTOR setupPinVector;
  STRING_VECTOR resultPinVector; 
  STRING setupPinlist;   
  STRING resultPinlist;  
  TM::SPEC_METHOD searchMethod;
  STRING unit; 
  DOUBLE searchStart;
  DOUBLE searchStop;
  DoubleWithFlag dfStepWidth;
  DoubleWithFlag dfResolution;
  DoubleWithFlag dfPassMin;
  DoubleWithFlag dfPassMax;
  
  Boolean isValueTest;
  Boolean isPerPinEvalMode;
  Boolean isParallelSearch;/*true: support parallel multisite*/
  /*FW command string for mask mode*/
  STRING fwMaskMode;
  STRING fwRestoreMaskMode;
  /*string of setup information used by PUT_DATALOG api*/
  STRING setupStrForDatalog;
};

struct ParamFuncTestLimit
{
  bool isLimitTableUsed;
  string testname_functional;
  string testname_search;
  int testnumber_functional;
  int testnumber_search;
  string softBinNumberString_functional;
  string softBinNumberString_search;
  int hardBinNumber_functional;
  int hardBinNumber_search;
  LIMIT specSearchLimit;  
};

static void processLimits(
  const string& testname,
  ParamFuncTestParameter& pftParam, 
  ParamFuncTestLimit& limits);
 
static void processParameters(
              STRING& runTo,
              STRING& runToType,
              STRING& maskBefore,
              STRING& maskBeforeType,
              STRING& maskAfter,
              STRING& maskAfterType,
              STRING& specName,
              STRING& specType,
              STRING& setupPinlist,
              STRING& setupPinlistMode,
              STRING& resultPinlist,
              STRING& resultPinlistMode,
              STRING& searchMethod,
              STRING& unit,
              const double searchstart,
              const double searchstop,
              STRING& step,
              STRING& resolution,
              const double passMin,
              const double passMax,
              ParamFuncTestParameter& pftParam);

static void doMeasurement(
              ParamFuncTestParameter& pftParam,
              ParamFuncTestLimit& limits,
              ParamFuncTestResult& testResult);                                      

static void judgeAndDatalog(
              const ParamFuncTestParameter& pftParam,
              const ParamFuncTestLimit& limits,
              const ParamFuncTestResult& testResult,
              double _results[4]);

static void reportToUI(
              const ParamFuncTestParameter& pftParam,
              const ParamFuncTestResult& testResult,
              const STRING& output);                  
                                                 
private:

static void processSearchLimitWithParam(
               ParamFuncTestParameter& pftParam, 
               LIMIT& limit);

static void checkPinsAndExecMode(
              STRING& setupPinlist,
              STRING& setupPinlistMode,
              STRING& resultPinlist,
              STRING& resultPinlistMode,
              ParamFuncTestParameter& pftParam);

static void checkSearchStuffs(
              STRING& specName,
              STRING& specType,
              STRING& searchMethod,
              STRING& unit,
              double searchStart,
              double searchStop,
              STRING& step,
              STRING& resolution,
              double passMin,
              double passMax,
              ParamFuncTestParameter& pftParam);

static void processMaskModeForFuncTest(              
              STRING& runTo,
              STRING& runToType,
              STRING& maskBefore,
              STRING& maskBeforeType,
              STRING& maskAfter,
              STRING& maskAfterType,
              ParamFuncTestParameter& pftParam);
                                                                                  
static const STRING_VECTOR checkAndExpandPinlistToPins(
              const STRING& pinlist,
              const TM::PIN_TYPES digitalPinType,
              const Boolean isDpsPinRequired);                

static void doFuncTest(
              ParamFuncTestParameter& pftParam );

static void doValueTest(
              ParamFuncTestParameter& pftParam,
              ParamFuncTestLimit& limit,
              ParamFuncTestResult& testResult);

static void doPFTest(
              ParamFuncTestParameter& pftParam,
              ParamFuncTestResult& testResult);
              
static void datalogForValueTest(
              const ParamFuncTestLimit& limits,
              const ParamFuncTestResult& testResult,
              double _results[4]);

static void datalogForPFTest(
              const ParamFuncTestLimit& limits,
              const ParamFuncTestResult& testResult);
                                          
static void outputForValueTest(
              const STRING& specName,
              const STRING& unit,
              const ParamFuncTestResult& testResult,
              const STRING& output);

static void outputForPFTest(
              const STRING& specName,
              const ParamFuncTestResult& testResult,
              const STRING& output);
                                                                                       
};

/*
 *----------------------------------------------------------------------*
 * Routine: ParamFuncTestUtil::checkAndExpandPinlistToPins
 *
 * Purpose: validate and expand pinlist to individual pins
 *
 *----------------------------------------------------------------------*
 * Description:
 *   Use PinUtility API to validate and expand pinlist to pins.
 *   pinlist could be setupPinlist and resultPinlist.
 *   (setupPinlist can include digital and dps pins;
 *    resultPinlist can only contain O/IO digital pins.)
 * 
 *   Uage(for example: I_PIN_GROUP consists of I_PIN1,I_PIN2.)
 *   (1)pinlist: "I_PIN_GROUP,Vcc" 
 *      I_PIN1,I_PIN2,Vcc
 *   (2)pinlist: "I_PIN_GROUP,O_PIN1"
 *      I_PIN1,I_PIN2,O_PIN1
 *
 * Parameters:
 *   1)pinlist: needed be separated.
 *   2)digitalPinType: 
 *     type of digital pin(TM::I_PIN,TM::O_PIN,TM::IO_PIN,TM::DC_PIN)
 *   3)isDpsPinRequired: whether to expand dps pins from pinlist or not.
 *
 * Output: 
 *   the string vector of individual pins.
 * Note: 
 *   (1)refer to PinUtility API user manual.
 *   (2)If input is "@", here mute error on mismatched pintype.
 *      and just retrieve pins of the expected type.
 *      otherwise, error is cast if wrong type pin included
 *----------------------------------------------------------------------*
 */
inline const STRING_VECTOR 
ParamFuncTestUtil::checkAndExpandPinlistToPins(
                                     const STRING& pinlist,
                                     const TM::PIN_TYPES digitalPinType,
                                     const Boolean isDpsPinRequired)
{
  const static STRING
  funcName = "ParamFuncTestUtil::checkAndExpandPinlistToPins"; 
  
  STRING_VECTOR resultExpandedPinVector;/*vector of expanded all pins*/
  STRING_VECTOR expandedDigitalPinVector;/*vector of expanded digital pins*/
  STRING_VECTOR expandedDpsPinVector;/*vector of expanded dps pins*/
  STRING_VECTOR splitPinlist;/*vector of split pinlist,but not expanded*/ 
  /*
   * If input is "@", here skip throwing error.
   * and just retrieve pins of the expected type.
   */
  Boolean isThrowErrorForMismatchedType 
  = (CommonUtil::trim(pinlist) != "@");
  
  CommonUtil::splitStr(pinlist,',',splitPinlist);
  resultExpandedPinVector.clear();
  
  for ( STRING_VECTOR::const_iterator it = splitPinlist.begin();
        it != splitPinlist.end();
        ++it)
  {
    try
    {
      /*get digital pins*/
      expandedDigitalPinVector 
      = PinUtility.getDigitalPinNamesFromPinList(*it,
                                                 digitalPinType,
                                                 TRUE,
                                                 isThrowErrorForMismatchedType);
      resultExpandedPinVector += expandedDigitalPinVector;
    }
    catch(ErrorInfo& e)
    {
      if ( isDpsPinRequired )/*if parse possible dps pins*/
      {
        try
        {
          /*get dps pins*/
          expandedDpsPinVector = PinUtility.getDpsPinNamesFromPinList(
                                               pinlist,
                                               isThrowErrorForMismatchedType);                                         
          resultExpandedPinVector += expandedDpsPinVector;
        }
        catch(ErrorInfo& e)
        {
          throw Error(funcName,"invalide pin group/pin: "+*it,funcName);    
        } 
      }
      else
      {
        throw Error(funcName,"invalide pin group/pin: "+*it,funcName);
      }/* end for dps parse */  
    }/* end for catch error */
  }/* end for */
       
  return resultExpandedPinVector;
}

/*
 *if limit is set, nothing is changed.
 *if the limit is not set, use pass_min/max parameter as limit value.
 *if the limit and pass_min/max are set, use start,stop as limit value.
 *
 */
inline void ParamFuncTestUtil::processSearchLimitWithParam(
  ParamFuncTestParameter& pftParam, 
  LIMIT& limit)
{
  double lowValue = 0;
  double highValue = 0;
  bool isLimitLowSet = (limit.getLow(&lowValue) != TM::NA); 
  bool isLimitHighSet = (limit.getHigh(&highValue) != TM::NA);
  if (!isLimitLowSet && !isLimitHighSet)
  { //no limit specified
    switch(pftParam.testCase) 
    {
      case VALUE_TEST_MIN_AND_MAX:
      case PASS_FAIL_TEST_MIN_AND_MAX:
        /*set test limit: [passMin, passMax]*/
        limit.low(TM::GE,min(pftParam.dfPassMin.value,pftParam.dfPassMax.value));
        limit.high(TM::LE,max(pftParam.dfPassMin.value,pftParam.dfPassMax.value));
        break;

      case VALUE_TEST_MIN_ONLY:
      case PASS_FAIL_TEST_MIN_ONLY:
        /*set test limit: [passMin,stop] */
        limit.low(TM::GE,min(pftParam.dfPassMin.value,pftParam.searchStop));  
        limit.high(TM::LE,max(pftParam.dfPassMin.value,pftParam.searchStop));
        break;

      case VALUE_TEST_MAX_ONLY:
      case PASS_FAIL_TEST_MAX_ONLY:
        /*set test limit: [start,passMax] */
        limit.low(TM::GE,min(pftParam.searchStart,pftParam.dfPassMax.value));  
        limit.high(TM::LE,max(pftParam.searchStart,pftParam.dfPassMax.value));
        break;
      
      case VALUE_TEST_NO_MIN_MAX:
      case PASS_FAIL_TEST_NO_MIN_MAX:
        /*set test limit: [start,stop] */
        limit.low(TM::GE,min(pftParam.searchStart,pftParam.searchStop));  
        limit.high(TM::LE,max(pftParam.searchStart,pftParam.searchStop));     
        break;
      default:
        break;
    }
  }
  else if (isLimitLowSet && !isLimitHighSet)
  {
    switch(pftParam.testCase)
    {
      case VALUE_TEST_MIN_AND_MAX:
      case VALUE_TEST_MAX_ONLY:
      case PASS_FAIL_TEST_MIN_AND_MAX:
      case PASS_FAIL_TEST_MAX_ONLY:
        limit.high(TM::LE,pftParam.dfPassMax.value);
        break;

      case VALUE_TEST_NO_MIN_MAX:
      case VALUE_TEST_MIN_ONLY:
      case PASS_FAIL_TEST_NO_MIN_MAX:
      case PASS_FAIL_TEST_MIN_ONLY:
        limit.high(TM::LE,pftParam.searchStop);
        break;
      default:
        break;
    }
  }
  else if (isLimitHighSet && !isLimitLowSet)
  {
    switch(pftParam.testCase)
    {
      case VALUE_TEST_MIN_AND_MAX:
      case VALUE_TEST_MIN_ONLY:
      case PASS_FAIL_TEST_MIN_AND_MAX:
      case PASS_FAIL_TEST_MIN_ONLY:
        limit.low(TM::GE,pftParam.dfPassMin.value);
        break;

      case VALUE_TEST_MAX_ONLY:
      case VALUE_TEST_NO_MIN_MAX:
      case PASS_FAIL_TEST_MAX_ONLY:
      case PASS_FAIL_TEST_NO_MIN_MAX:
        limit.low(TM::GE,pftParam.searchStart);
        break;
      default:
        break;
    }
  }
  else
  {
    //input limit is used, do nothing. 
  }
}

inline void ParamFuncTestUtil::processLimits(
  const string& testname, 
  ParamFuncTestParameter& pftParam, 
  ParamFuncTestLimit& testlimit)
{
  string validName = CommonUtil::trim(testname);
  string::size_type leadPos = validName.find_first_not_of(" ()");
  string::size_type postPos = validName.find_last_not_of(" ()");
  validName = validName.substr(leadPos,postPos-leadPos +1);
  vector<string> limitNames;
  CommonUtil::splitStr(validName,',',limitNames);

  bool isTestnameLegal = true;
  if (!limitNames.empty())
  {
    //if there is only one limit name specified, search and functional test share it.
    //if two names, search use the first one, functional test use the 2nd.
    if (limitNames.size() == 1)
    {
      testlimit.testname_search = 
        testlimit.testname_functional = limitNames.at(0);
    }
    else if (limitNames.size() == 2)
    {
      testlimit.testname_search = limitNames.at(0);
      testlimit.testname_functional = limitNames.at(1);
    }
    else 
    {
      isTestnameLegal = false;
    }
  }
  else
  {
    isTestnameLegal = false;
  }

  if (!isTestnameLegal)
  {
    throw Error("ParamFuncTestUtil::processLimits()",
                "Invalid test name parameter.");
  }
  testlimit.testnumber_functional = 0;
  testlimit.testnumber_search = 0;
  //check whether limit table is used.
  TestTable* pLimitTable = TestTable::getDefaultInstance();
  pLimitTable->readCsvFile();
  testlimit.isLimitTableUsed = pLimitTable->isTmLimitsCsvFile();
 
  string testsuiteName;
  GET_TESTSUITE_NAME(testsuiteName);
  if(pftParam.testCase == PURE_FUNCTIONAL_TEST)
  {
    //in case of pure functional, testnumber is needed to 
    //be retrieved for test table way.
    if (testlimit.isLimitTableUsed)
    {
      try
      {		
        string keyInTable = testsuiteName + ":" + testlimit.testname_functional;
        V93kLimits::TMLimits::LimitInfo& limitInfo =
        V93kLimits::tmLimits.getLimit(keyInTable);
        testlimit.testnumber_functional = limitInfo.TestNumber;
        testlimit.softBinNumberString_functional = limitInfo.BinsNumString;
        testlimit.hardBinNumber_functional = limitInfo.BinhNum;
      }
      catch(Error& e)
      {
        testlimit.isLimitTableUsed = false;
      }
    }
  }
  else
  {
    if (testlimit.isLimitTableUsed)
    {
      try
      {
        string keyInTable = testsuiteName + ":" + testlimit.testname_search;
        const V93kLimits::TMLimits::LimitInfo& limitInfo =
        V93kLimits::tmLimits.getLimit(keyInTable);
          testlimit.specSearchLimit = limitInfo.TEST_API_LIMIT;
        testlimit.testnumber_search = limitInfo.TestNumber;
        testlimit.softBinNumberString_search = limitInfo.BinsNumString;
        testlimit.hardBinNumber_search = limitInfo.BinhNum;
      }
      catch(Error e)
      {
        testlimit.isLimitTableUsed = false;
      }
    }

    if(!testlimit.isLimitTableUsed)
    {
      testlimit.specSearchLimit = GET_LIMIT_OBJECT(testlimit.testname_search);
      processSearchLimitWithParam(pftParam,testlimit.specSearchLimit);
    }

    //spec search always use "ns" or "V"
    string targetUnit = (pftParam.specType == TM::LEV)?"V":"ns";
    if (testlimit.specSearchLimit.unit().empty())
    {
      testlimit.specSearchLimit.unit(targetUnit);
    }
    else if (CommonUtil::getUnitNameOfLimit(testlimit.specSearchLimit) != targetUnit)
    { 
      throw Error("ParamFuncTestUtil::processLimits()",
        "the unit of parametric spec search value must be: V or ns.",
        "ParamFuncTestUtil::processLimits()");
    }
  }
}

          
/*
 *----------------------------------------------------------------------*
 * Routine: ParamFuncTestUtil::processParameters
 *
 * Purpose: 
 *    1) parse,validate and process the parameters 
 *    2) collect setup information for datalog 
 *----------------------------------------------------------------------*
 * Description:
 *       1.parse pin list and execution mode 
 *       2.setup mask mode of functional test
 *       3.setup spec search if spec name is given 
 *       4.define test case     
 *
 * Parameters:
 *    1.runTo: string of runto number
 *    2.runToType: vector or cycle
 *    3.maskBefore: string of mask_before number
 *    4.maskBeforeType: vector or cycle
 *    5.maskAfter: string of mask_after number
 *    6.maskAfterType: vector or cycle
 *    7.resultPinlist: result pinlist contributing to test result 
 *    8.specName: spec variable name
 *    9.specType: timing or level 
 *    10.setupPinlist: setup pinlist which spec applies to
 *    11.setupPinlistMode: 
 *            parallel or serial
 *            force serial to parallel if PPF not set
 *    12.resultPinlist: result pinlist contributes to test result
 *    13.resultPinlistMode: 
 *            parallel or serial
 *            force serial to parallel if PPF not set.
 *    14.searchMethod: binary,linear,lin/bin
 *    15.unit: the unit of following 6 parameters.
 *    16.searchStart: start of search range
 *    17.searchStop:  stop of search range
 *    18.step: number of step if '#' preceded,otherwise stepwidth
 *    19.resolution: resolution involved in binary or lin/bin algorithm
 *    20.passMin: min of pass range
 *    21.passMax: max of pass range
 *    22.pftParam: holds all parameters related to parametric func test
 * Output: 
 *   None
 *
 * Note:
 *  
 *----------------------------------------------------------------------*
 */
inline void ParamFuncTestUtil::processParameters(
              STRING& runTo,
              STRING& runToType,
              STRING& maskBefore,
              STRING& maskBeforeType,
              STRING& maskAfter,
              STRING& maskAfterType,
              STRING& specName,
              STRING& specType,
              STRING& setupPinlist,
              STRING& setupPinlistMode,
              STRING& resultPinlist,
              STRING& resultPinlistMode,
              STRING& searchMethod,
              STRING& unit,
              const double searchStart,
              const double searchStop,
              STRING& step,
              STRING& resolution,
              const double passMin,
              const double passMax,
              ParamFuncTestParameter& pftParam)
{
   pftParam.testCase = UNKNOWN_CASE;
   pftParam.specName = "";
   pftParam.fwMaskMode = "";
   pftParam.fwRestoreMaskMode = "";
   pftParam.setupStrForDatalog = ""; 
  
  /*--------------------------------------------------
   * 1. check pins and execution mode 
   *--------------------------------------------------
   */
   checkPinsAndExecMode(setupPinlist,setupPinlistMode,
                        resultPinlist,resultPinlistMode,
                        pftParam);
  
  /*---------------------------------------------------
   * 2. setup mask mode for functional test.
   *--------------------------------------------------- 
   */
   processMaskModeForFuncTest(runTo,runToType,
                              maskBefore,maskBeforeType,
                              maskAfter,maskAfterType,
                              pftParam);
                          
  /*---------------------------------------------------
   * 3. check spec search stuffs if necessary
   *--------------------------------------------------- 
   */   
  if ( !specName.empty() )              
  {  
    checkSearchStuffs(specName, specType, searchMethod,
                      unit, searchStart, searchStop,
                      step, resolution, passMin, passMax,
                      pftParam);
    /* figure out search cases */
    if ( pftParam.isValueTest )
    {
      if ( pftParam.dfPassMin.hasValue && pftParam.dfPassMax.hasValue )
      {
        pftParam.testCase = VALUE_TEST_MIN_AND_MAX;
      }
      else if ( pftParam.dfPassMin.hasValue )
      {
        pftParam.testCase = VALUE_TEST_MIN_ONLY;
      }
      else if ( pftParam.dfPassMax.hasValue )
      {
        pftParam.testCase = VALUE_TEST_MAX_ONLY;
      }
      else
      {
        pftParam.testCase = VALUE_TEST_NO_MIN_MAX;
      }
    }
    else
    {
      if ( pftParam.dfPassMin.hasValue && pftParam.dfPassMax.hasValue )
      {
        pftParam.testCase = PASS_FAIL_TEST_MIN_AND_MAX;
      }
      else if ( pftParam.dfPassMin.hasValue )
      {
        pftParam.testCase = PASS_FAIL_TEST_MIN_ONLY;
      }
      else if ( pftParam.dfPassMax.hasValue )
      {
        pftParam.testCase = PASS_FAIL_TEST_MAX_ONLY;
      }
      else
      {
        pftParam.testCase = PASS_FAIL_TEST_NO_MIN_MAX;
      }
    }                                         
  }
  else/*no spec variable given => pure func test*/ 
  {                                                                     
    pftParam.testCase = PURE_FUNCTIONAL_TEST;
  }                                                                                        
}

/*
 *----------------------------------------------------------------------*
 * Routine: ParamFuncTestUtil::checkPinsAndExecMode
 *
 * Purpose: parse pins and execution mode of pins
 *
 *----------------------------------------------------------------------*
 * Description:
 *     parse input and fill in pftParam container.
 * Parameters:
 *     setupPinlist : setup pinlist
 *     setupPinlistMode: serial or parallel mode
 *     resultPinlist: result pinlist
 *     resultPinlistMode: serial or parallel mode
 *     pftParam: parameters of parametric spec search
 *        
 * Output: 
 *
 * Note: 
 *   
 *----------------------------------------------------------------------*
 */
inline void 
ParamFuncTestUtil::checkPinsAndExecMode(
              STRING& setupPinlist,
              STRING& setupPinlistMode,
              STRING& resultPinlist,
              STRING& resultPinlistMode,
              ParamFuncTestParameter& pftParam)
{
  setupPinlist = CommonUtil::trim(setupPinlist);
  setupPinlistMode = CommonUtil::trim(setupPinlistMode);
  resultPinlist = CommonUtil::trim(resultPinlist);
  resultPinlistMode = CommonUtil::trim(resultPinlistMode);
  Boolean isSetupPinlistSerial = false;
  Boolean isResultPinlistSerial = false;                  
                                

  /*--------------------------------------------------
   * get execution mode
   *--------------------------------------------------
   */
  STRING testSuiteName;
  INT valueOnPass = 0;
  INT perPinOnPass = 0;
  INT valueOnFail = 0;
  INT perPinOnFail = 0;
  GET_TESTSUITE_NAME(testSuiteName);
  GET_TESTSUITE_FLAG(testSuiteName, "value_on_pass",   &valueOnPass);
  GET_TESTSUITE_FLAG(testSuiteName, "value_on_fail",   &valueOnFail);
  GET_TESTSUITE_FLAG(testSuiteName, "per_pin_on_pass", &perPinOnPass);
  GET_TESTSUITE_FLAG(testSuiteName, "per_pin_on_fail", &perPinOnFail);
 
  if ( 1 == valueOnPass || 1 == valueOnFail )
  {
    pftParam.isValueTest = true;
  }
  else
  {
    pftParam.isValueTest = false;
  }
  
  if ( 1 == perPinOnPass || 1 == perPinOnFail )
  {
    pftParam.isPerPinEvalMode = true;
  }
  else
  {
    pftParam.isPerPinEvalMode = false;
  }
        
  /*decide result pinlist mode by pin mode and evaluation mode*/
  if ( resultPinlistMode == "serial" && pftParam.isPerPinEvalMode )
  {
    isResultPinlistSerial = true; 
  }
  else
  {
    isResultPinlistSerial = false;
  }

  /*decide setup pinlist mode by pin mode and evaluation mode*/
  if ( setupPinlistMode == "serial" && pftParam.isPerPinEvalMode )
  {
    isSetupPinlistSerial = true;
  }
  else
  {
    isSetupPinlistSerial = false;
  }
  
  pftParam.isSerialForSetupPins = isSetupPinlistSerial;
  pftParam.isSerialForResultPins = isResultPinlistSerial;
   /*process for result pinlist*/
  if ( resultPinlist.empty() )
  {
    if ( isResultPinlistSerial )    
    {     
      /* The result pins are used in serial mode and no pins are given,
       * so it is necessary to get the active pins from the SREC Query
       * (to get all active pins) and use them as result pins. 
       */
      STRING answer = "";
      STRING activeResultPinlist = "";
      FW_TASK("SREC? (@)\n",answer);
      STRING::size_type pos = 0;

      while ( (pos = answer.find_first_of("ACT",pos)) != STRING::npos )
      { 
        pos = answer.find_first_of('(',pos+3);
        STRING::size_type secondPos = answer.find_first_of(')',pos);
        activeResultPinlist += answer.substr(pos+1,secondPos-pos-1);
        pos = secondPos+1;    
      }
      
      if ( activeResultPinlist.empty() )/*no active pins are found*/
      {
        cout<<"WARNING: No active pins found with SREC Query."
            <<" All pins (@) are used as active pins."
            <<endl;
        pftParam.resultPinlist = "@";
      }
      else
      {
        pftParam.resultPinlist = activeResultPinlist;
      }
    }
    else
    { /* For performance reasons, the result pinlist is set to ALL pins
       * if the result pins are used in parallel mode because the active
       * pins are already set by a SREC command and it is not necessary
       * to know which pins are active. 
       */
      pftParam.resultPinlist = "@";     
    }   
  }
  else /*directly use input result pin names*/
  {
    pftParam.resultPinlist = resultPinlist;
  }
   
  pftParam.setupPinlist = setupPinlist.empty()?"@":setupPinlist;                

  /*--------------------------------------------------
   * collect pinlist data for logging
   *--------------------------------------------------
   */
  pftParam.setupStrForDatalog += "Result Pins("
                                 +resultPinlistMode
                                 +")    "
                                 +resultPinlist
                                 +"\n";
  pftParam.setupStrForDatalog += "Setup Pins("
                                 +setupPinlistMode
                                 +")    "
                                 +setupPinlist
                                 +"\n";  
  /*--------------------------------------------------
   * for executing performance:
   * prepare vector of expanded pins according to
   * execution mode.
   *--------------------------------------------------
   */
  pftParam.setupPinVector.clear();
  pftParam.resultPinVector.clear();
  if ( pftParam.isSerialForSetupPins )
  {
    pftParam.setupPinVector = checkAndExpandPinlistToPins(
                                         pftParam.setupPinlist,
                                         TM::I_PIN|TM::O_PIN|TM::IO_PIN,
                                         true);
  }
  else
  {
    /*check pins*/
    checkAndExpandPinlistToPins(pftParam.setupPinlist,
                                TM::I_PIN|TM::O_PIN|TM::IO_PIN,
                                true);
    pftParam.setupPinVector.push_back(pftParam.setupPinlist);
  }
  
  if ( pftParam.isSerialForResultPins )
  {                                        
    pftParam.resultPinVector = checkAndExpandPinlistToPins(
                                          pftParam.resultPinlist,
                                          TM::O_PIN|TM::IO_PIN,
                                          false);  
  }
  else
  {
    /*check pins*/
    checkAndExpandPinlistToPins(pftParam.resultPinlist,
                                TM::O_PIN|TM::IO_PIN,
                                false);
    pftParam.resultPinVector.push_back(pftParam.resultPinlist);
  }
}

/*
 *----------------------------------------------------------------------*
 * Routine: ParamFuncTestUtil::checkSearchStuffs
 *
 * Purpose: validate settings of spec search
 *
 *----------------------------------------------------------------------*
 * Description:
 *     parse setting and fill in pftParam container.
 * Parameters:
 *    specName: spec variable name
 *    specType: timing or level 
 *    searchMethod: binary,linear,lin/bin
 *    unit: the unit of following 6 parameters.
 *    searchStart: start of search range
 *    searchStop:  stop of search range
 *    step: number of step if '#' preceded,otherwise stepwidth
 *    resolution: resolution involved in binary or lin/bin algorithm
 *    passMin: min of pass range
 *    passMax: max of pass range
 *    pftParam: parameters of parametric spec search
 *        
 * Output: 
 *
 * Note: 
 *   
 *----------------------------------------------------------------------*
 */
inline void 
ParamFuncTestUtil::checkSearchStuffs(
              STRING& specName,
              STRING& specType,
              STRING& searchMethod,
              STRING& unit,
              double searchStart,
              double searchStop,
              STRING& step,
              STRING& resolution,
              double passMin,
              double passMax,
              ParamFuncTestParameter& pftParam)
{
  const static 
  STRING funcName = "ParamFuncTestUtil::checkSearchStuffs";    
  /*remove preceding and trailing space chars*/  
  specName = CommonUtil::trim(specName);
  specType = CommonUtil::trim(specType);
  searchMethod = CommonUtil::trim(searchMethod);
  unit = CommonUtil::trim(unit);
  step = CommonUtil::trim(step);
  resolution = CommonUtil::trim(resolution);
  
  /*judge parameters given or not*/
  Boolean isStepGiven = step.empty()?false:true;
  Boolean isResolutionGiven = resolution.empty()?false:true;
  Boolean isPassMinGiven = HAS_PARAM_FUNC_VALUE(passMin);
  Boolean isPassMaxGiven = HAS_PARAM_FUNC_VALUE(passMax);
  Boolean isStepWidth = false;
  DOUBLE dStart = 0.0, dStop = 0.0; /*input search range*/
  DOUBLE dSearchMin = 0.0, dSearchMax = 0.0; /*real search range*/  
  DOUBLE dPassMin = 0.0,dPassMax = 0.0;/*pass range*/
  DOUBLE dStep = 0.0, dStepWidth = 0.0, dResolution = 0.0;
  
  dStart = searchStart;
  dStop = searchStop;

  if ( isPassMinGiven )
  {
    dPassMin = passMin;
  }

  if ( isPassMaxGiven )
  {
    dPassMax = passMax;
  }
   
  /*-------------------------------------------------- 
   * check start,stop,passMin,passMax
   *-------------------------------------------------- 
   */
    dSearchMin = min(dStart,dStop);
    dSearchMax = max(dStart,dStop);
    if ( dSearchMin == dSearchMax )
    {
      throw Error(funcName,"Invalid search range of 0",funcName);
    }
    
    if ( !isPassMinGiven ) 
    { /*use start value if passMin missed*/
      dPassMin = dSearchMin;
    }
    else if ( dPassMin < dSearchMin || dPassMin > dSearchMax )
    { /*passMin out of range*/
      throw Error(funcName,
                  "A passMin is outside the [start,stop] range is not allowed",
                  funcName);    
    }

    if ( !isPassMaxGiven )
    { /*use stop value if passMax missed*/
      dPassMax = dSearchMax;
    }
    else if ( dPassMax < dSearchMin || dPassMax > dSearchMax )
    { /*passMin out of range*/
      throw Error(funcName,
                  "A passMax is outside the [start,stop] range is not allowed",
                  funcName);    
    }    

  if ( (isPassMinGiven && isPassMaxGiven)
       && (dPassMin > dPassMax) )
  {
    cout<<"swap passMin and passMax,"
        <<" because passMin is greater than passMax!"
        <<endl;
    DOUBLE tmp;
    tmp = dPassMin;
    dPassMin = dPassMax;
    dPassMax = tmp;  
  } 
   
  /*--------------------------------------------------
   * process resolution and step/stepwidth 
   *--------------------------------------------------
   */
  if ( isResolutionGiven )
  {
    dResolution = CommonUtil::string2Double(resolution,"resolution");
  }
        
  if ( isStepGiven )
  {
    if ( step.find('#',0) != STRING::npos )
    {
      /* skip the first '#' char before conversion */ 
      dStep = CommonUtil::string2Double(step.c_str()+1 ,"step");
      if ( dStep <= 0.0 )
      {
        throw Error(funcName,
                    "number of step must be positive number, but input is:"
                    +step,
                    funcName);
      }
      
      /* convert step to stepwidth */
      dStepWidth = abs(dSearchMax - dSearchMin)/dStep;
      isStepWidth = false;      
    }
    else
    {
      isStepWidth = true;
      dStepWidth = CommonUtil::string2Double(step,"step");
    }
  }

  /*--------------------------------------------------
   * initialize param struct with parsed results. 
   *--------------------------------------------------
   */
  pftParam.specName = specName;
  pftParam.specType 
  = CommonUtil::convertStringToSearchType(specType);
  
  pftParam.searchMethod 
  = CommonUtil::convertStringToMethod(searchMethod);
      
  pftParam.searchStart = dSearchMin;
  pftParam.searchStop = dSearchMax;
  pftParam.dfStepWidth.value = dStepWidth;
  pftParam.dfStepWidth.hasValue = isStepGiven;
  pftParam.dfResolution.value = dResolution;
  pftParam.dfResolution.hasValue = isResolutionGiven;
  pftParam.dfPassMin.value = dPassMin;
  pftParam.dfPassMin.hasValue = isPassMinGiven;
  pftParam.dfPassMax.value = dPassMax;
  pftParam.dfPassMax.hasValue = isPassMaxGiven;
  pftParam.unit = unit;
       
  /*--------------------------------------------------
   *collect original setup information for datalog
   *--------------------------------------------------
   */
  pftParam.setupStrForDatalog += "Spec Name: "+specName+"\n";
  pftParam.setupStrForDatalog += "Spec Type: "+specType+"\n";
  pftParam.setupStrForDatalog += "Search Method: "+searchMethod+"\n";
  
  ostringstream logStream;
  logStream << "Search Range: ["
            << searchStart << "  " << unit << ","
            << searchStop << "  " << unit << "]\n";
  pftParam.setupStrForDatalog += logStream.str();
  
  if ( isStepGiven )                               
  {
    pftParam.setupStrForDatalog += "Step:    "
                                   +step+"  "+(isStepWidth?unit:"")+"\n";
  }
  
  if (isResolutionGiven )
  {
    pftParam.setupStrForDatalog += "Resolution: "
                                   +resolution+"  "+unit+"\n";  
  }
}

/*
 *----------------------------------------------------------------------*
 * Routine: ParamFuncTestUtil::processMaskModeForFuncTest
 *
 * Purpose: setup mask mode for functional test
 *
 *----------------------------------------------------------------------*
 * Description:
 *
 * Parameters:
 *    runTo: string of runto number
 *    runToType: "vector" or "cycle"
 *    maskBefore: string of mask_before number
 *    maskBeforeType: "vector" or "cycle"
 *    maskAfter: string of mask_after number
 *    maskAfterType: "vector" or "cycle"
 *    pftParam: parameters of parametric spec search
 *        
 * Output: 
 *
 * Note: 
 *   1. xx_typpe must be: "vector" or "cycle"
 *   2. support port-based number of runto,maskbefore and maskafter,
 *      but the port name must be same!
 *      And firmware can validate these three number automatically.  
 *----------------------------------------------------------------------*
 */
inline void 
ParamFuncTestUtil::processMaskModeForFuncTest(              
              STRING& runTo,
              STRING& runToType,
              STRING& maskBefore,
              STRING& maskBeforeType,
              STRING& maskAfter,
              STRING& maskAfterType,
              ParamFuncTestParameter& pftParam)
{
  runTo = CommonUtil::trim(runTo);
  runToType = CommonUtil::trim(runToType);
  maskBefore = CommonUtil::trim(maskBefore);
  maskBeforeType = CommonUtil::trim(maskBeforeType);
  maskAfter = CommonUtil::trim(maskAfter);
  maskAfterType = CommonUtil::trim(maskAfterType);
  pftParam.fwMaskMode = "";
  pftParam.fwRestoreMaskMode = "";
  
  STRING strOfRunToNumber = "";
  STRING strOfMaskBeforeNumber = "";
  STRING strOfMaskAfterNumber = "";
  STRING portName = ""; 
  set<STRING> allPorts;/*holds all possible unique ports*/
  
 
  /*---------------------------------------------------
   * split port name and number
   *--------------------------------------------------- 
   */    
  if ( !runTo.empty() )
  {     
    pftParam.setupStrForDatalog += "run to (" 
                                   + runToType 
                                   + "):  " 
                                   + runTo
                                   + "\n";
   
    CommonUtil::splitPortDataAndPortName(runTo,
                                              strOfRunToNumber,
                                              portName,
                                              false); 
    if ( !portName.empty() )
    {
      allPorts.insert(portName);    
    }                                                                                                                                                         
  }  
  
  if ( !maskBefore.empty() )
  {
    pftParam.setupStrForDatalog += "mask before (" 
                                   + maskBeforeType 
                                   + "):  " 
                                   + maskBefore
                                   + "\n";
    CommonUtil::splitPortDataAndPortName(maskBefore,
                                              strOfMaskBeforeNumber,
                                              portName,
                                              false);
    if ( !portName.empty() )
    {
      allPorts.insert(portName);    
    }
  }
  
  if ( !maskAfter.empty() )
  {
    pftParam.setupStrForDatalog += "mask after (" 
                                   + maskAfterType 
                                   + "):  " 
                                   + maskAfter
                                   + "\n";    
    CommonUtil::splitPortDataAndPortName(maskAfter,
                                              strOfMaskAfterNumber,
                                              portName,
                                              false);
    if ( !portName.empty() )
    {
      allPorts.insert(portName);    
    }
  }
   
  /*-----------------------------------------------------------
   * check consistency of port name: only one port at one time
   *----------------------------------------------------------- 
   */
  if ( allPorts.size() == 0 )
  {
      portName = "";    
  }
  else if ( allPorts.size() == 1 )
  {
    portName = *(allPorts.begin());
  }
  else /* allPorts.size() > 1 */
  {
    throw Error("ParamFuncTestUtil::processMaskModeForFuncTest",
                "inconsistent portName of runto,maskbefore,maskafter!",
                "ParamFuncTestUtil::processMaskModeForFuncTest");     
  }
 
  /*---------------------------------------------------
   * generate mask mode fw command for functional test.
   *--------------------------------------------------- 
   */   
   FunctionalUtil::maskFunctionalTest(
                            strOfRunToNumber,
                            (runToType == "cycle"),
                            strOfMaskBeforeNumber,
                            (maskBeforeType == "cycle"),
                            strOfMaskAfterNumber,
                            (maskAfterType == "cycle"),
                            portName,
                            pftParam.fwMaskMode,
                            pftParam.fwRestoreMaskMode);
}

/*
 *----------------------------------------------------------------------*
 * Routine: ParamFuncTestUtil::doMeasurement
 *
 * Purpose: do parametric func test.
 *
 *----------------------------------------------------------------------*
 * Description:
 *   if pure functional test, 
 *      do functional test with mask mode if need.
 *   if value test,
 *      call specific spec search function depends on flag:
 *   if p/f test
 *      call specific p/f test.
 *  
 *   call default functions which invokes SEARCH_FUNC_TASK api 
 *   for double density
 * 
 * Parameters:
 *     pftParam: parameters of parametric spec search
 *     testResult: contains test result of spec search    
 * Output: 
 *
 * Note: 
 *   
 *----------------------------------------------------------------------*
 */
inline void ParamFuncTestUtil::doMeasurement(
                  ParamFuncTestParameter& pftParam,
                  ParamFuncTestLimit& limits,
                  ParamFuncTestResult& testResult)
{
  switch( pftParam.testCase ) 
  {
    case PURE_FUNCTIONAL_TEST:
      doFuncTest(pftParam);
      break;

    case PASS_FAIL_TEST_MIN_AND_MAX:
    case PASS_FAIL_TEST_MIN_ONLY:
    case PASS_FAIL_TEST_MAX_ONLY:      
    case PASS_FAIL_TEST_NO_MIN_MAX:
      {
        //reset start stop with limit for P/F test.
        limits.specSearchLimit.getLow(&pftParam.searchStart);
        limits.specSearchLimit.getHigh(&pftParam.searchStop); 
        doPFTest(pftParam,testResult);
      }
      break;
      
    case VALUE_TEST_MIN_AND_MAX:
    case VALUE_TEST_MIN_ONLY:
    case VALUE_TEST_MAX_ONLY:
    case VALUE_TEST_NO_MIN_MAX:
      doValueTest(pftParam,limits,testResult);
      break;

    default:
      throw Error("ParamFuncTestUtil::doMeasurement",
                  "unsupported test case.",
                  "ParamFuncTestUtil::doMeasurement");
      break;
  }
}

/*
 *----------------------------------------------------------------------*
 * Routine: ParamFuncTestUtil::doFuncTest
 *
 * Purpose: do functional test with mask mode 
 *
 *----------------------------------------------------------------------*
 * Description:
 *
 * Parameters:
 *    pftParam: contains mask mode of func test
 * Output:
 *     None 
 * Note: 
 *   multisite enabled with ON_FRIST_INVOCATION_BEGIN/END block     
 *----------------------------------------------------------------------*
 */              
inline void 
ParamFuncTestUtil::doFuncTest(ParamFuncTestParameter& pftParam)
{
  
  ON_FIRST_INVOCATION_BEGIN();
    if ( !pftParam.resultPinlist.empty() && pftParam.resultPinlist != "@" )
    {
      pftParam.fwMaskMode += "SREC STOR,(@)\n SREC X,(@)\n SREC ACT,(";
      pftParam.fwMaskMode += pftParam.resultPinlist;
      pftParam.fwMaskMode += ")\n";
      pftParam.fwRestoreMaskMode += "SREC RSTO,(@)\n";
    }
    
    if ( !pftParam.fwMaskMode.empty() )
    {
      FW_TASK("SQGB ACQF,0;"+pftParam.fwMaskMode);
    }
    else
    {
      Sequencer.reset();
    }
  
    FUNCTIONAL_TEST();
  ON_FIRST_INVOCATION_END();    
}

/*
 *----------------------------------------------------------------------*
 * Routine: ParamFuncTestUtil::doValueTest
 *
 * Purpose: do search spec value by SEARCH_FUNC_TASK api
 *
 *----------------------------------------------------------------------*
 * Description:
 *   set test limit according to different pass ranges.
 *   do search by SEARCH_FUNC_TASK api 
 *   retrieve, preprocess and store test result 
 * Parameters:
 *   pftParam: contains search settings.
 *   testResult: holds test result per setuppin and resultpin
 * Output:
 *     None 
 * Note: 
 *   enable multisite parallel     
 *----------------------------------------------------------------------*
 */
inline void ParamFuncTestUtil::doValueTest(
              ParamFuncTestParameter& pftParam,
              ParamFuncTestLimit& limits,
              ParamFuncTestResult& testResult)
{    

  SpecSearchResultData resultData;

  testResult.isResultPinsSerial = pftParam.isSerialForResultPins;
  testResult.isSetupPinsSerial = pftParam.isSerialForSetupPins;
  testResult.vecSetupPins = pftParam.setupPinVector;
  testResult.vecResultPins = pftParam.resultPinVector;
  
  ON_FIRST_INVOCATION_BEGIN();
    /*send FW cmd of mask mode for func test involved in spec search*/
    if ( !pftParam.fwMaskMode.empty() )
    {
      FW_TASK("SQGB ACQF,0;"+pftParam.fwMaskMode);
    }
    else
    {
      FW_TASK("SQGB ACQF,0;");
    }
  ON_FIRST_INVOCATION_END();

  /*loop execution for all searches:
   *pin execution mode (serial/parallel) is reflected by setupPinVector and resultPinVector.
   *this has been done in checkPinsAndExecMode() function.
   */
  for ( STRING_VECTOR::size_type sIndex = 0; sIndex < pftParam.setupPinVector.size(); ++sIndex )
  { 
    SEARCH_FUNC_TASK searchFuncTask;
    for ( STRING_VECTOR::size_type rIndex = 0; rIndex < pftParam.resultPinVector.size(); ++rIndex )
    {
       ON_FIRST_INVOCATION_BEGIN();
         /*setup...*/        
         SEARCH_FUNC_PIN_TASK& searchFuncPinTask = searchFuncTask.pin(pftParam.setupPinVector[sIndex]);
         searchFuncPinTask.spec(pftParam.specName,pftParam.specType)
                          .resultPins(pftParam.resultPinVector[rIndex])
                          .method(pftParam.searchMethod)
                          .start(pftParam.searchStart)
                          .stop(pftParam.searchStop);

         if ( pftParam.dfStepWidth.hasValue )
         {
           searchFuncPinTask.stepWidth(pftParam.dfStepWidth.value);
         }
         if ( pftParam.dfResolution.hasValue )
         {
           searchFuncPinTask.resolution(pftParam.dfResolution.value);
         }
         /*execute...*/
         searchFuncTask.execute();
       ON_FIRST_INVOCATION_END();

       /*retrieve result*/
       resultData.specResult = searchFuncTask.getResultSpec(pftParam.setupPinVector[sIndex]);
       if ( resultData.specResult == TM::TransitionPassFail ||
            resultData.specResult == TM::TransitionFailPass )
       {
         resultData.passVal = searchFuncTask.getPassValue(pftParam.setupPinVector[sIndex]);
         resultData.failVal = searchFuncTask.getFailValue(pftParam.setupPinVector[sIndex]);
         resultData.isTestPassed = limits.specSearchLimit.pass(resultData.passVal) &&
           limits.specSearchLimit.pass(resultData.failVal);
       }
       else if ( resultData.specResult == TM::AllPass )  
       {
         resultData.isTestPassed = false;
         resultData.passVal = MAX_DOUBLE_LOCAL;
         resultData.failVal = MAX_DOUBLE_LOCAL;
       }
       else /* ( resultData.specResult == TM::AllFail ) */ 
       {
         resultData.isTestPassed = false;
         resultData.passVal = MIN_DOUBLE_LOCAL;
         resultData.failVal = MIN_DOUBLE_LOCAL;
       }
      testResult.searchResult[pftParam.setupPinVector[sIndex]][pftParam.resultPinVector[rIndex]] = resultData;
    }/*end-for-each-result-pin*/
  }/*end-for-each-setup-pin*/ 
  
  /*send FW cmd of restoring mask mode for func test involved in spec search*/
  ON_FIRST_INVOCATION_BEGIN();
    if ( !pftParam.fwRestoreMaskMode.empty() )
    {
      FW_TASK(pftParam.fwRestoreMaskMode);
    }
  ON_FIRST_INVOCATION_END();
}  

             
/*
 *----------------------------------------------------------------------*
 * Routine: ParamFuncTestUtil::doPFTest
 *
 * Purpose: do pass/fail spec search by SEARCH_FUNC_TASK api
 *
 *----------------------------------------------------------------------*
 * Description:
 *   customize search setting into linear search with one step.
 *   do search by SEARCH_FUNC_TASK api
 *   retrieve, preprocess and store test result 
 * Parameters:
 *   pftParam: contains search settings.
 *   testResult: holds test result per setuppin and resultpin
 * Output:
 *     None 
 * Note: 
 *     
 *----------------------------------------------------------------------*
 */
inline void ParamFuncTestUtil::doPFTest(
              ParamFuncTestParameter& pftParam,
              ParamFuncTestResult& testResult)
{    

  SpecSearchResultData resultData;

  testResult.isResultPinsSerial = pftParam.isSerialForResultPins;
  testResult.isSetupPinsSerial = pftParam.isSerialForSetupPins;
  testResult.vecSetupPins = pftParam.setupPinVector;
  testResult.vecResultPins = pftParam.resultPinVector;
    
  ON_FIRST_INVOCATION_BEGIN();
    
    /*send FW cmd of mask mode for func test involved in spec search*/
    if ( !pftParam.fwMaskMode.empty() )
    {
      FW_TASK("SQGB ACQF,0;"+pftParam.fwMaskMode);
    }
    else
    {
      FW_TASK("SQGB ACQF,0;");
    }
    
    /*customize search settings for pass/fail test*/
    pftParam.dfResolution.hasValue = false;  
    pftParam.searchMethod = TM::Linear;
    pftParam.dfStepWidth.hasValue = true;
      /* if start equals stop, only one functional test needed.
       * therefore make next step bigger than search stop 
       * by increasing stepwidth rudely.
       * here plus 0.1 to do it.
       * otherwise, set number of step to one!
       */
    pftParam.dfStepWidth.value = (pftParam.searchStart != pftParam.searchStop)? 
                                 (abs(pftParam.searchStop - pftParam.searchStart))
                                 :1.0;
  ON_FIRST_INVOCATION_END();

  /*loop execution for all searches:
   *pin execution mode (serial/parallel) is reflected by setupPinVector and resultPinVector.
   *this has been done in checkPinsAndExecMode() function.
   */
  for ( STRING_VECTOR::size_type sIndex = 0; sIndex < pftParam.setupPinVector.size(); ++sIndex )
  { 
    SEARCH_FUNC_TASK searchFuncTask;
    for ( STRING_VECTOR::size_type rIndex = 0; rIndex < pftParam.resultPinVector.size(); ++rIndex )
    {
       ON_FIRST_INVOCATION_BEGIN();
         /*setup...*/        
         SEARCH_FUNC_PIN_TASK& searchFuncPinTask = searchFuncTask.pin(pftParam.setupPinVector[sIndex]);
         searchFuncPinTask.spec(pftParam.specName,pftParam.specType)
                          .resultPins(pftParam.resultPinVector[rIndex])
                          .method(pftParam.searchMethod)
                          .start(pftParam.searchStart)
                          .stop(pftParam.searchStop);

         if ( pftParam.dfStepWidth.hasValue )
         {
           searchFuncPinTask.stepWidth(pftParam.dfStepWidth.value);
         }
         if ( pftParam.dfResolution.hasValue )
         {
           searchFuncPinTask.resolution(pftParam.dfResolution.value);
         }
         /*execute...*/
         searchFuncTask.execute();
       ON_FIRST_INVOCATION_END();

       /*retrieve result*/
       resultData.specResult = searchFuncTask.getResultSpec(pftParam.setupPinVector[sIndex]);
       if ( resultData.specResult == TM::TransitionPassFail ||
            resultData.specResult == TM::TransitionFailPass )
       {
         resultData.isTestPassed = true;
       }
       else
       {
         resultData.isTestPassed = false;
       }
       testResult.searchResult[pftParam.setupPinVector[sIndex]][pftParam.resultPinVector[rIndex]] = resultData;
    }/*end-for-each-result-pin*/
  }/*end-for-each-setup-pin*/ 
  
  /*send FW cmd of restoring mask mode for func test involved in spec search*/
  ON_FIRST_INVOCATION_BEGIN();
    if ( !pftParam.fwRestoreMaskMode.empty() )
    {
      FW_TASK(pftParam.fwRestoreMaskMode);
    }
  ON_FIRST_INVOCATION_END();
}
  

/*
 *----------------------------------------------------------------------*
 * Routine: ParamFuncTestUtil::judgeAndDatalog
 *
 * Purpose: datalog for test
 *
 *----------------------------------------------------------------------*
 * Description:
 *    1) Use PUT_DATALOG to log setup information
 *    2) log result for search result and functional test result
 *
 * Parameters: 
 *    pftParam: contains setup information which will be logged.
 *    limits: test limit.
 *    testResult: holds search result.
 *    _results[4]: four results used by testflow, only for value test.
 * Output: 
 *
 * Note: 
 *
 *----------------------------------------------------------------------*
 */
inline void ParamFuncTestUtil::judgeAndDatalog(
                 const ParamFuncTestParameter& pftParam,
                 const ParamFuncTestLimit& limits,
                 const ParamFuncTestResult& testResult,
                 double _results[4])
{  
  /*1. log setup information*/   
  if ( !pftParam.setupStrForDatalog.empty() )
  {
    PUT_DATALOG("\n"+pftParam.setupStrForDatalog);
  }
    
  /*2. log test result*/
  switch(pftParam.testCase) 
  {
    case PURE_FUNCTIONAL_TEST:
      {
        if (limits.isLimitTableUsed)
        {
          bool pass = TESTSET().cont(TM::CONTINUE)
                               .testnumber(limits.testnumber_functional)
                               .testname(limits.testname_functional)
                               .judgeAndLog_FunctionalTest();
          if(!pass && limits.softBinNumberString_functional.size() > 0)
          {
            SET_MULTIBIN(limits.softBinNumberString_functional,limits.hardBinNumber_functional);
          }
        }
        else
        {
          TESTSET().cont(TM::CONTINUE)
                   .testnumber(limits.testname_functional,true)
                   .judgeAndLog_FunctionalTest();
        }
      }
      break;

    case PASS_FAIL_TEST_MIN_AND_MAX:
    case PASS_FAIL_TEST_MIN_ONLY:
    case PASS_FAIL_TEST_MAX_ONLY:
    case PASS_FAIL_TEST_NO_MIN_MAX:
      datalogForPFTest(limits,testResult);
      break;

    case VALUE_TEST_MIN_AND_MAX:
    case VALUE_TEST_MIN_ONLY:
    case VALUE_TEST_MAX_ONLY:    
    case VALUE_TEST_NO_MIN_MAX:
      datalogForValueTest(limits,testResult,_results);     
      break;

    default:
      throw Error("ParamFuncTestUtil::judgeAndDatalog",
                  "unsupported test case.",
                  "ParamFuncTestUtil::judgeAndDatalog");
      break;
  }
}

/*
 *----------------------------------------------------------------------*
 * Routine: ParamFuncTestUtil::datalogForValueTest
 *
 * Purpose: datalog spec value test
 *
 *----------------------------------------------------------------------*
 * Description:
 *    log result for search result
 *
 * Parameters:
 *    limits: test limit. 
 *    testResult: holds search result.
 *    _results[4]: four limits used by testflow
 * Output: 
 *
 * Note: support MPR logging 
 *
 *----------------------------------------------------------------------*
 */
inline void 
ParamFuncTestUtil::datalogForValueTest(const ParamFuncTestLimit& limits, 
  const ParamFuncTestResult& testResult,
  double _results[4])                  
{
  /*init _results*/
  _results[0]=_results[2]= DBL_MAX; 
  _results[1]=_results[3]= -DBL_MAX;

  map< STRING,map<STRING,SpecSearchResultData> > resultMap = testResult.searchResult;
  SpecSearchResultData  searchResultData;

  DOUBLE dPassValue = 0.0;
  DOUBLE dFailValue = 0.0;
  DOUBLE minPassValue,minFailValue;
  DOUBLE maxPassValue,maxFailValue;
  minPassValue = minFailValue = MAX_DOUBLE_LOCAL;
  maxPassValue = maxFailValue = MIN_DOUBLE_LOCAL;

  if ( resultMap.empty() ) 
  {
    throw Error("ParamFuncTestUtil::datalogForValueTest",
                "no result is recorded!",
                "ParamFuncTestUtil::datalogForValueTest");
  }
  size_t sizeOfValue = testResult.vecSetupPins.size()*testResult.vecResultPins.size();
  STRING_VECTOR logPinVector;
  ARRAY_D passValueArray(sizeOfValue);
  ARRAY_D failValueArray(sizeOfValue);

  for ( STRING_VECTOR::size_type sIndex = 0; sIndex < testResult.vecSetupPins.size(); ++sIndex )
  { 
    for ( STRING_VECTOR::size_type rIndex = 0; rIndex < testResult.vecResultPins.size(); ++rIndex )      
    {
      STRING sPin = testResult.vecSetupPins[sIndex];
      STRING rPin = testResult.vecResultPins[rIndex];
      searchResultData = resultMap[sPin][rPin];
      /*collect measused range for per setup pin and result pin*/
      dPassValue = searchResultData.passVal;
      dFailValue = searchResultData.failVal;

      logPinVector.push_back(sPin);
      passValueArray[sIndex*testResult.vecSetupPins.size()+rIndex] = dPassValue;
      failValueArray[sIndex*testResult.vecSetupPins.size()+rIndex] = dFailValue;

      minPassValue = min( dPassValue, minPassValue );
      maxPassValue = max( dPassValue, maxPassValue );
      minFailValue = min( dFailValue, minFailValue );
      maxFailValue = max( dFailValue, maxFailValue );        

    }/*end-of-for-rPins*/
  } /*end-of-for-sPins*/

  if (limits.isLimitTableUsed)
  {
    /*log pass value*/
    TestSet.cont(TM::CONTINUE)
           .judgeAndLog_ParametricTest(
                         logPinVector,
                         limits.testname_search,
                         V93kLimits::tmLimits,
                         passValueArray);
    /*log fail value*/                                   
    TestSet.cont(TM::CONTINUE)
           .judgeAndLog_ParametricTest(
                         logPinVector,
                         limits.testname_search,
                         V93kLimits::tmLimits,
                         failValueArray);
   }   
   else
   {     
     /*log pass value*/
     TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                           logPinVector,
                           limits.testname_search,
                           limits.specSearchLimit,
                           passValueArray);
     /*log fail value*/                                   
     TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                           logPinVector,
                           limits.testname_search,
                           limits.specSearchLimit,
                           failValueArray);  
  }  

  if ( testResult.isResultPinsSerial )
  {           
    /*log pass range and fail range*/
    STRING measuredRange = "\nMeasured Pass Range: [" 
                           + CommonUtil::double2String(minPassValue) 
                           + ","
                           + CommonUtil::double2String(maxPassValue)
                           +"]\n"
                           + "Measured Fail Range: [" 
                           + CommonUtil::double2String(minFailValue) 
                           + ","
                           + CommonUtil::double2String(maxFailValue)
                           +"]\n"; 
    PUT_DATALOG( measuredRange );                           
  }
  //prepare for _results[4]
  _results[0] = minPassValue;
  _results[1] = maxPassValue;
  _results[2] = minFailValue;
  _results[3] = maxFailValue;
}

/*
 *----------------------------------------------------------------------*
 * Routine: ParamFuncTestUtil::datalogForPFTest
 *
 * Purpose: datalog pass/fail test
 *
 *----------------------------------------------------------------------*
 * Description:
 *    log result for search result
 *
 * Parameters: 
 *    testResult: holds search result.
 *
 * Output: 
 *
 * Note: support MPR logging: 
 *   for PF test, the value is dummy 0.0.
 *----------------------------------------------------------------------*
 */ 
inline void 
ParamFuncTestUtil::datalogForPFTest(
  const ParamFuncTestLimit& limits,
  const ParamFuncTestResult& testResult)                  
{
  map< STRING,map<STRING,SpecSearchResultData> > resultMap = testResult.searchResult;
  
  if ( resultMap.empty() ) 
  {
    throw Error("ParamFuncTestUtil::datalogForPFTest",
                "no result is recorded!",
                "ParamFuncTestUtil::datalogForPFTest");
  }
  
  size_t sizeOfValue = testResult.vecSetupPins.size()*testResult.vecResultPins.size();
  STRING_VECTOR logPinVector;
  ARRAY_D dummyPFValueArray(sizeOfValue);

  bool isTestPassed = true;
  for ( STRING_VECTOR::size_type sIndex = 0; sIndex < testResult.vecSetupPins.size(); ++sIndex )
  { 
    for ( STRING_VECTOR::size_type rIndex = 0; rIndex < testResult.vecResultPins.size(); ++rIndex )      
    {
      STRING sPin = testResult.vecSetupPins[sIndex];
      STRING rPin = testResult.vecResultPins[rIndex];
      isTestPassed = isTestPassed && resultMap[sPin][rPin].isTestPassed;
      logPinVector.push_back(sPin);
      if(resultMap[sPin][rPin].isTestPassed)
      {
        dummyPFValueArray[sIndex*testResult.vecSetupPins.size()+rIndex] = 0.0;
      }
      else
      {
        dummyPFValueArray[sIndex*testResult.vecSetupPins.size()+rIndex] = 1.0;
      }
   }/*end-for*/
  }/*end-for*/
  
  if (limits.isLimitTableUsed)
  {
    TESTSET().cont(TM::CONTINUE)
             .testnumber(limits.testnumber_search)
             .judgeAndLog_ParametricTest(
                logPinVector,
                limits.testname_search,
                isTestPassed?TM::Pass : TM::Fail,
                dummyPFValueArray);
    if(!isTestPassed && limits.softBinNumberString_search.size() > 0)
    {
      SET_MULTIBIN(limits.softBinNumberString_search,limits.hardBinNumber_search);
    }
  }
  else
  {
    TESTSET().cont(TM::CONTINUE)
             .judgeAndLog_ParametricTest(
                logPinVector,
                limits.testname_search,
                isTestPassed?TM::Pass : TM::Fail,
                dummyPFValueArray);        
  } 
  
}

/*
 *----------------------------------------------------------------------*
 * Routine: ParamFuncTestUtil::reportToUI
 *
 * Purpose: print result to reportUI Window
 *
 *----------------------------------------------------------------------*
 * Description:
 *   
 * Parameters:
 *   pftParam: some parameters of pftParam need be printed
 *   testResult: test result
 *   output: string to indicate if print result to window.
 *
 * Output:
 *   
 * Note:
 *
 *----------------------------------------------------------------------*
 */
inline void 
ParamFuncTestUtil::reportToUI(const ParamFuncTestParameter& pftParam,
                              const ParamFuncTestResult& testResult,
                              const STRING& output)                  
{
  if ( output == "None" )
  {
    return;  
  }
  
  switch(pftParam.testCase) 
  {
    case PURE_FUNCTIONAL_TEST:
      /*functional test*/
      {
        Boolean isGlobalPass = GET_FUNCTIONAL_RESULT();           
        if ( pftParam.isPerPinEvalMode )
        {
          /*expand pinlist into vector of pins*/
          STRING_VECTOR vecPinList = PinUtility.getDigitalPinNamesFromPinList(
                                     pftParam.resultPinlist,
                                     TM::O_PIN|TM::IO_PIN,
                                     TRUE,
                                     (pftParam.resultPinlist=="@")?FALSE:TRUE);
          STRING_VECTOR::size_type index;
          for ( index = 0; index < vecPinList.size(); ++index )
          {
            Boolean isPass = isGlobalPass?true:GET_FUNCTIONAL_RESULT(vecPinList[index]);
            CommonUtil::datalogToWindow( output, vecPinList[index], isPass );
          }
        }
        else
        {
          CommonUtil::datalogToWindow( output, pftParam.resultPinlist, isGlobalPass );
        }
      }  
      break;

    case PASS_FAIL_TEST_MIN_AND_MAX:
    case PASS_FAIL_TEST_MIN_ONLY:
    case PASS_FAIL_TEST_MAX_ONLY:
    case PASS_FAIL_TEST_NO_MIN_MAX:
      outputForPFTest(pftParam.specName,testResult,output);
      break;

    case VALUE_TEST_MIN_AND_MAX:
    case VALUE_TEST_MIN_ONLY:
    case VALUE_TEST_MAX_ONLY:    
    case VALUE_TEST_NO_MIN_MAX:
      outputForValueTest(pftParam.specName,
                         pftParam.unit,
                         testResult,
                         output);     
      break;

    default:
      throw Error("ParamFuncTestUtil::reportToUI",
                  "unsupported test case.",
                  "ParamFuncTestUtil::reportToUI");
      break;
  }
}

/*
 *----------------------------------------------------------------------*
 * Routine: ParamFuncTestUtil::outputForPFTest
 *
 * Purpose: print pass/fail test result to reportUI Window
 *
 *----------------------------------------------------------------------*
 * Description:
 *   
 * Parameters:
 *   specName: spec variable name to be printed
 *   testResult: test result
 *   output: string to indicate if print result to window.
 *
 * Output:
 *   
 * Note:
 *
 *----------------------------------------------------------------------*
 */
inline void 
ParamFuncTestUtil::outputForPFTest(const STRING& specName,
                                   const ParamFuncTestResult& testResult,
                                   const STRING& output)                  
{

  if ( output == "None" ) 
  {
    return;
  }
  STRING preamble = "(spec name)"+specName; 
  map< STRING,map<STRING,SpecSearchResultData> > resultMap = testResult.searchResult;
  SpecSearchResultData  searchResultData;
  
   if ( resultMap.empty() ) 
  {
    throw Error("ParamFuncTestUtil::outputForPFTest",
                "no result is recorded!",
                "ParamFuncTestUtil::outputForPFTest");
  } 
    
  for ( STRING_VECTOR::size_type sIndex = 0; sIndex < testResult.vecSetupPins.size(); ++sIndex )
  { 
    for ( STRING_VECTOR::size_type rIndex = 0; rIndex < testResult.vecResultPins.size(); ++rIndex )      
    {
        STRING sPin = testResult.vecSetupPins[sIndex];
        STRING rPin = testResult.vecResultPins[rIndex];
        searchResultData = resultMap[sPin][rPin];
               
        /*for better output*/
        cout<<"setup pins:["<<sPin<<"]  result pins:["<<rPin<<"]"<<endl;
        
        /*print to UI report*/
         
        switch ( searchResultData.specResult )
        {
          case TM::TransitionPassFail :      
            cout<<"Spec Search Result is TransitionPassFail :"<<endl;           
            break;   
          
          case TM::TransitionFailPass :      
            cout<<"Spec Search Result is TransitionFailPass :"<<endl;
            break; 
            
          case TM::AllPass :     
            cout<<"Spec Search Result is AllPass :"<<endl;
            break;  
           
          case TM::AllFail :
            cout<<"Spec Search Result is AllFail :"<<endl;
            break;
          default:
            throw Error("ParamFuncTestUtil::outputForPFTest",
                       "Unknown spec result",
                       "ParamFuncTestUtil::outputForPFTest");
            break;        
        }/*end-of-switch*/
        
        if ( searchResultData.isTestPassed )
        { 
          cout<<preamble<<"                          = "
              << setiosflags(ios_base::left)<<setw(OUTPUT_WIDTH) 
              << "passed"<<"                P"<<endl;
       
          cout<<preamble<<"                          = "
              << setiosflags(ios_base::left)<<setw(OUTPUT_WIDTH) 
              << "passed"<<"                P"<<endl;                 
        }
        else
        {
          cout<<preamble<<"                          = "
              << setiosflags(ios_base::left)<<setw(OUTPUT_WIDTH) 
              << "failed"<<"                F"<<endl;
       
          cout<<preamble<<"                          = "
              << setiosflags(ios_base::left)<<setw(OUTPUT_WIDTH) 
              << "failed"<<"                F"<<endl;          
        }
                
    }/*end-of-for*/
  }/*end-of-for*/
}

/*
 *----------------------------------------------------------------------*
 * Routine: ParamFuncTestUtil::outputForValueTest
 *
 * Purpose: print result to reportUI Window
 *
 *----------------------------------------------------------------------*
 * Description:
 *   
 * Parameters:
 *   specName: spec variable name to be printed
 *   unit: unit of value
 *   testResult: test result
 *   output: string to indicate if print result to window.
 *
 * Output:
 *   
 * Note:
 *
 *----------------------------------------------------------------------*
 */
inline void 
ParamFuncTestUtil::outputForValueTest( const STRING& specName,
                                       const STRING& unit,
                                       const ParamFuncTestResult& testResult,
                                       const STRING& output)                  
{

  if ( output == "None" ) 
  {
    return;
  }
  
  STRING preamble = "(spec name)"+specName;
  STRING passFail = "FAIL";  
  map< STRING,map<STRING,SpecSearchResultData> > resultMap = testResult.searchResult;
  SpecSearchResultData  searchResultData;
  
  if ( resultMap.empty() ) 
  {
    throw Error("ParamFuncTestUtil::outputForValueTest",
                "no result is recorded!",
                "ParamFuncTestUtil::outputForValueTest");
  } 
    
  for ( STRING_VECTOR::size_type sIndex = 0; sIndex < testResult.vecSetupPins.size(); ++sIndex )
  { 
    for ( STRING_VECTOR::size_type rIndex = 0; rIndex < testResult.vecResultPins.size(); ++rIndex )      
    {
        STRING sPin = testResult.vecSetupPins[sIndex];
        STRING rPin = testResult.vecResultPins[rIndex];
        searchResultData = resultMap[sPin][rPin];
               
        /*for better output*/
        cout<<"setup pins:["<<sPin<<"]  result pins:["<<rPin<<"]"<<endl;
        
        /*print to UI report*/
        if ( searchResultData.isTestPassed )
        { 
          passFail = "P";      
        }
        else
        {
          passFail = "F";
        }
         
        switch ( searchResultData.specResult )
        {
          case TM::TransitionPassFail :      
            cout<<"Spec Search Result is TransitionPassFail :\n"
                <<preamble<<"                          P = "
                << setiosflags(ios_base::left)<<setw(OUTPUT_WIDTH) 
                << searchResultData.passVal
                <<"   "<<unit<<"             "<<passFail<<endl;
       
            cout<<preamble<<"                          F = "
                << setiosflags(ios_base::left)<<setw(OUTPUT_WIDTH) 
                << searchResultData.failVal
                <<"   "<<unit<<"             "<<passFail<<endl;            
            break;   
          
          case TM::TransitionFailPass :      
            cout<<"Spec Search Result is TransitionFailPass :\n"
                <<preamble<<"                          P = "
                <<setiosflags(ios_base::left)<<setw(OUTPUT_WIDTH) 
                <<searchResultData.passVal
                <<"   "<<unit<<"             "<<passFail<<endl;
            
            cout<<preamble<<"                          F = "
                <<setiosflags(ios_base::left)<<setw(OUTPUT_WIDTH) 
                <<searchResultData.failVal
                <<"   "<<unit<<"             "<<passFail<<endl; 
            break; 
            
          case TM::AllPass :     
            cout<<"Spec Search Result is AllPass :\n"
                <<preamble<<"                          F = ******"
                <<"             FAIL"<<endl;
            cout<<preamble<<"                          p = ******"
                <<"             FAIL"<<endl;
            break;  
           
          case TM::AllFail :
            cout<<"Spec Search Result is AllFail :\n"
                <<preamble<<"                          F = ******"
                <<"             FAIL"<<endl;
            cout<<preamble<<"                          p = ******"
                <<"             FAIL"<<endl;
            break;
          default:
            throw Error("ParamFuncTestUtil::outputForValueTest",
                       "Unknown spec result",
                       "ParamFuncTestUtil::outputForValueTest");
            break;        
      }/*end-of-switch*/
    }/*end-of-for*/
  }/*end-of-for*/
}
#endif
