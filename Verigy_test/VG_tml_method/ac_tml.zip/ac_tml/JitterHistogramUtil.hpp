#ifndef INCLUDE_JITTERHISTOGRAM_H
#define INCLUDE_JITTERHISTOGRAM_H
#include <algorithm>
#include "CommonUtil.hpp"
#include "JitterUtil.hpp"

/******************************************************************************
 *                    jitter histogram test utility class 
 ******************************************************************************
 *Description:
 * By setting up different parameters,users can make the jitter histogram
 * measurement in different conditions.
 *    pattern synchronization: find a passing pattern
 *    transtioon search on specified side(s): optimize the start of jitter data
 *                                           acquisition.
 *    data acquisition on specified side(s): sample the jitter data
 *    jitter histogram calculation on specified side(s).
 * according the description,the whole process steps:
 * |----------------|     |------------|       |-------------|       |---------|
 * |    pattern     |     | transition |       |             |       |         |
 * |synchronization |---->|  search    |------>|     data    |------>|  post   |
 * |   (optional)   |     | (optional) |       | acquisition |       | process |
 * |----------------|     |------------|       |-------------|       |---------|
 *
 ******************************************************************************
 */ 
class JitterHistogramUtil
{
  public:
  /**
   *---------------------------------------------------------------------------
   *         test parameters containe
   *---------------------------------------------------------------------------
   */
  struct  JitterHistogramParameter
  {
    //common parameter for jitter histogram, separation and stardust
    JitterUtil::JitterParameter commonParameter;
  };
 /**
  *----------------------------------------------------------------------------
  *         test limits container                                    
  *----------------------------------------------------------------------------
  */
  struct JitterHistogramLimit
  {
    bool isLimitTableUsed;
    string ppTestname;
    string rmsTestname;
    LIMIT ppJitterLimit;
    LIMIT rmsJitterLimit;
  } ;
  /**
   *---------------------------------------------------------------------------
   *         test results container
   *---------------------------------------------------------------------------
   */
  struct ResultData
  {
    // histogram data vector of left transition
    vector<INT> leftHistogramData;

    // histogram data vector of right transiton
    vector<INT> rightHistogramData;

    // the result of jitter on the left transition side
    JitterHistogramType leftSideJitter;

    // the result of jitter on the right transition side
    JitterHistogramType rightSideJitter;

    // initialize all stuffs to some defaults.
    void init()
    {
      leftHistogramData.clear();
      rightHistogramData.clear();
      leftSideJitter.mean = 0.0;
      leftSideJitter.rms = 0.0;
      leftSideJitter.peak2peak = 0.0;
      leftSideJitter.median = 0.0;
      leftSideJitter.medist = 0.0;
      rightSideJitter.mean = 0.0;
      rightSideJitter.rms = 0.0;
      rightSideJitter.peak2peak = 0.0;
      rightSideJitter.median = 0.0;
      rightSideJitter.medist = 0.0;
    }
    ResultData()
    {
      init();
    }
  };
  /**
   *---------------------------------------------------------------------------
   * Struct: JitterHistogramResult
   * Purpose: container to store jitter measurement results
   *---------------------------------------------------------------------------
   * Decription:
   *   This two-layered map contains result of test.The outside map contains
   *   every site's result.The inside map contains every pin's result.
   *   The outside map's key: INT is the index of site number
   *   The outside map's value:map<STRING,ResultData> is the result of the
   *   site which is indexed by key.
   *   The inside map's key: STRING is the pin's name.
   *   The inside map's value: ResultData is the result of the pin which is
   *   indexed by key.
   * Note:
   *---------------------------------------------------------------------------
   */
  struct JitterHistogramResult
  {
    map<INT,map<STRING, ResultData> > resultMap;
    JitterUtil::JitterResult jitterResult;
    void init()
    {
      jitterResult.init();
      resultMap.clear();
    }
  } ;
  /**
   *---------------------------------------------------------------------------
   *         public interfaces of jitter historgram  test
   *---------------------------------------------------------------------------
   */  
  
  static void processParameters(
    const STRING& pinlist,
    const STRING& portName,
    const STRING& specName_postfix,
    const double UI_width_ns,
    const double start_ns,
    const double stop_ns,
    const double dataAcquStepWidth_ns,
    const int passOnMaxErrorCount,
    const STRING& autoSyncMode,
    const double autoSyncStepWidth_ns,
    const STRING& transitionSearchMode,
    const STRING& transition,
    const STRING& outputMode,
    JitterHistogramParameter& parameters);
  static void processLimit(
    const string& testname,
    JitterHistogramLimit& testlimit);
  static void doMeasurement(
    const JitterHistogramParameter& parameters,
    JitterHistogramResult& results);
  static void judgeAndDatalog(
    const JitterHistogramParameter& parameters,
    const JitterHistogramResult& results,
    const JitterHistogramLimit & testlimit);
  static void reportToUI(
    const JitterHistogramParameter& parameters,
    const JitterHistogramResult& results,
    const STRING& output);
  static bool processTestName(
    const string& testname,vector<string>& names);

  private:
  static void histogramCalculation(
    const JitterHistogramParameter& parameters,
    JitterHistogramResult& results);
  static void applyPatternSyncValue(
    const JitterHistogramParameter& parameters,
    JitterHistogramResult& results);
  static void printHistogram(const vector<INT> &);
  static void printJitterValue(const DOUBLE,const DOUBLE);
  static void prepareDataForAnalyzer(
    const STRING&,
    const vector<INT>&,
    WAVE_LOG &);
};
  
/**
 *-----------------------------------------------------------------------------
 * Routine: processParameter
 *
 * Purpose: parse input parameters and setup internal parameters
 *
 *-----------------------------------------------------------------------------
 * Description:
 *   according user's input to fill out interal parameters
 * Parameters:
 *   1.STRING& pinlist:
 *     Define a list of pins/pin groups the spec is shifted for.
 *     valid type :O,IO
 *   2.STRING& portName:           optional {@|portName}
 *     Port name of above test pins for Multiport Setups.
 *     NOTE:only pins of one port can be selected.
 *     default is @.
 *   3.STRING& specName_postfix:
 *     A spec-variable corresponding to each test-pin should be predefined
 *     and used by this TestMethod to do jitter measurement.
 *     For example:if Tx0 is the input pin,its corresponding
 *     spec-variables are Tx0_offset,this parameter needs to be
 *     set as "offset".
 *   4.double UI_width_ns:
 *     Bit time of test pattern.
 *     For example:2.5Gb/s -> 0.4ns
 *   5.double start_ns:
 *     --if autoSyncMode is "OFF":start of Data Acquisition
 *     --if autoSyncMode is "ON" or "ON_KEEP_VALUE": start of linear Pattern
 *     Alignment Search
 *   6.double stop_ns:
 *     --if autoSyncMode is "OFF":stop of Data Acquisition
 *     --if autoSyncMode is "ON" or "ON_KEEP_VALUE": stop of linear Pattern
 *     Alignment Search
 *   7.double dataAcquStepWidth_ns:
 *     Step width for Data Acquisition
 *   8.int passOnMaxErrorCount:     optional
 *     It defines the pass criteria for all following execution.That is,
 *     besides normally regarding pass as 0 error count, users
 *     can specify the maximum edge count as the pass/fail
 *     threshold. default vaule: 0
 *   9.STRING& autoSyncMode: {OFF | ON | ON_KEEP_VALUE}
 *     Enabling of linear Pattern Alignment Search to find passing pattern.
 *       With ON_KEEP_VALUE option the Sync value will be kept
 *     after the finishing of the testsuite execution.
 *       With ON option the spec variable will be reset to its
 *     original value after finishing the test.
 *       With OFF option linear Pattern Alignment Search to find
 *     passing pattern is disable.
 *       default is ON.
 *   10.double autoSyncStepWidth_ns:
 *      Step width for AutoSync Search.
 *   11.STRING& transitionSearchMode:  {OFF | ON}
 *        With ON,Binary Search for Pass/Fail Transition of
 *      MIN_BER poit with maximum search range of one "UI_width"
 *      and resolution of dataAcquStepWidth_ns.
 *        With OFF,transiton search will not be made.
 *      default is ON.
 *   12.STRING& transition:  {LEFT | RIGHT | BOTH}
 *      Determine which side of bit transition will be searched
 *      if transitionSearchMode is ON and be acquired for jitter
 *      histogram calculation. If both autoSyncMode and
 *      transitionSearchMode are OFF,this parameter is not in
 *      effect,and users have to choose proper values of start
 *      and stop for acquisition based on the test requirement.
 *      default is LEFT.
 *   13.STRING& outputMode: {SUMMARY | DETAIL | ANALYSIS}
 *      This parameter is in effect only if output is set ReportUI.
 *      SUMMARY - a result table will be printed in the Report Window.
 *      DETAIL  - an ASCII plot of the Error Count and the histogram curve
 *                will be printed in report window.
 *      ANALYSIS - the jitter histogram data will be transfer to signal
 *                analyzer tool for display and debuggine.
 *      default is SUMMARY.
 *   14.JitterHistogramParameter& parameters
 *      this parameter's type is output,we use user's input to
 *      fill out this parameter.
 *   Note:
 *-----------------------------------------------------------------------------
 */
void JitterHistogramUtil::processParameters(
  const STRING& pinlist,
  const STRING& portName,
  const STRING& specName_postfix,
  const double UI_width_ns,
  const double start_ns,
  const double stop_ns,
  const double dataAcquStepWidth_ns,
  const int passOnMaxErrorCount,
  const STRING& autoSyncMode,
  const double autoSyncStepWidth_ns,
  const STRING& transitionSearchMode,
  const STRING& transition,
  const STRING& outputMode,
  JitterHistogramParameter& parameters)
{
  JitterUtil::JitterParameter& commonParameter = parameters.commonParameter;
  STRING tempString = CommonUtil::trim(pinlist);
  JitterUtil::checkSetupPinlist(tempString);
  commonParameter.PinVector = JitterUtil::expandPinlistToPins(tempString);

  commonParameter.portName = CommonUtil::trim(portName);

  tempString = CommonUtil::trim(specName_postfix);
  if( tempString.empty())
  {
    STRING api = "Check specName_postfix: ";
    STRING msg = "There is no specName_postfix! Please input specName_postfix.";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }
  commonParameter.specName_postfix = tempString;

  if(UI_width_ns <= 0)
  { 
    STRING api = "Check parameter UI_width_ns: ";
    STRING msg = "UI_width_ns should be greater than zero!";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }
  commonParameter.UI_width_ns = UI_width_ns;
  commonParameter.start_ns = start_ns;
  commonParameter.stop_ns = stop_ns;
  if(dataAcquStepWidth_ns <= 0)
  { 
    STRING api = "Check parameter dataAcquStepWidth_ns: ";
    STRING msg = "dataAcquStepWidth_ns should be greater than zero!";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }
  commonParameter.dataAcquStepWidth_ns = dataAcquStepWidth_ns;

  if(passOnMaxErrorCount < 0)
  { 
    STRING api = "Check parameter passOnMaxErrorCount: ";
    STRING msg = "passOnMaxErrorCount shoult not be negative!";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }
  commonParameter.passOnMaxErrorCount = passOnMaxErrorCount;

  tempString = CommonUtil::trim(autoSyncMode);
  if(tempString == "OFF")
  {
    commonParameter.autoSyncMode = JitterUtil::AUTOSYNC_OFF;
  }
  else if (tempString == "ON")
  {
    commonParameter.autoSyncMode = JitterUtil::AUTOSYNC_ON;
  } 
  else if (tempString == "ON_KEEP_VALUE")
  {
    commonParameter.autoSyncMode = JitterUtil::AUTOSYNC_ON_KEEP_VALUE;
  }
  else
  {
    STRING api = "Check AUTOSYNC_MODE: ";
    STRING msg = "These is an unknow AUTOSYNC_MODE type.";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }

  if(autoSyncStepWidth_ns <= 0)
  { 
    STRING api = "Check parameter autoSyncStepWidth_ns: ";
    STRING msg = "autoSyncStepWidth_ns should be greater than zero!";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }
  commonParameter.autoSyncStepWidth_ns = autoSyncStepWidth_ns;

  tempString = CommonUtil::trim(transitionSearchMode); 
  if(tempString == "OFF")
  {
    commonParameter.transitionSearchMode = JitterUtil::TRANSITIONSEARCH_OFF;
  }
  else if(tempString == "ON")
  {
    commonParameter.transitionSearchMode = JitterUtil::TRANSITIONSEARCH_ON;
  }
  else
  {
    STRING api = "Check TRANSITIONSEARCH_MODE: ";
    STRING msg = "These is an unknow TRANSITIONSEARCH_MODE type.";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }

  tempString = CommonUtil::trim(transition);
  if(tempString == "LEFT")
  {
    commonParameter.transition = JitterUtil::LEFT;
  } 
  else if(tempString == "RIGHT")
  {
    commonParameter.transition = JitterUtil::RIGHT;
  }
  else if(tempString == "BOTH")
  {
    commonParameter.transition = JitterUtil::BOTH;
  }
  else
  {
    STRING api = "Check TRANSITION: ";
    STRING msg = "These is an unknow TRANSITION type.";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }

  tempString = CommonUtil::trim(outputMode);
  if (tempString == "SUMMARY")
  {
    commonParameter.outputMode = JitterUtil::OUTPUT_SUMMARY;
  }
  else if(tempString == "DETAIL")
  {
    commonParameter.outputMode = JitterUtil::OUTPUT_DETAIL;
  }
  else if(tempString == "ANALYSIS")
  {
    commonParameter.outputMode = JitterUtil::OUTPUT_ANALYSIS;
  }
  else
  {
    STRING api = "Check OUTPUT_MODE: ";
    STRING msg = "These is an unknow OUTPUT_MODE type.";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }
}

/**
 *-----------------------------------------------------------------------------
 * Routine: processTestName
 *
 * Purpose: process names of test limits
 *
 *-----------------------------------------------------------------------------
 * Description:
 *   the input testname is in the format as "(ppJitter,rmsJitter)"
 *   the output names is in vector of "ppJitter" and "rmsJitter"
 *   return value: true if the test name is valid, otherwise, false is returned.
 * Note:
 *-----------------------------------------------------------------------------
 */
bool JitterHistogramUtil::processTestName(const string& testname,vector<string>& names)
{
  bool isValid = false;
  string validName = CommonUtil::trim(testname);
  string::size_type leadPos = validName.find("(");
  string::size_type postPos = validName.find(")");

  names.clear();
  if (leadPos != string::npos && postPos != string::npos && leadPos < postPos)
  {
    validName = validName.substr(leadPos+1,postPos-leadPos-1);
    CommonUtil::splitStr(validName,',',names);
    isValid = true;
  }
  return isValid;
}

/**
 *-----------------------------------------------------------------------------
 * Routine: processLimit
 *
 * Purpose: process Limit(s)
 *
 *-----------------------------------------------------------------------------
 * Description:
 *   
 * Note:
 *-----------------------------------------------------------------------------
 */
void JitterHistogramUtil::processLimit(
  const string& testname,
  JitterHistogramLimit& testlimit)
{
  const string funcName = "JitterHistogramUtil::processLimit()";
  vector<string> names;
  if (processTestName(testname,names) && names.size() == 2)
  {
    testlimit.ppTestname = names[0];
    testlimit.rmsTestname = names[1];  
  }
  else
  {
    throw Error(funcName,
      "two test names are needed for peak-to-peak and rms jitter testing.",
      funcName);
  }

  //first, try to get limit from test table 
  string testsuiteName;
  GET_TESTSUITE_NAME(testsuiteName);
  TesttableLimitHelper ttlHelper(testsuiteName);
  if (ttlHelper.isLimitCsvFileLoad())
  {
    ttlHelper.getLimit(testlimit.ppTestname, testlimit.ppJitterLimit);
    ttlHelper.getLimit(testlimit.rmsTestname, testlimit.rmsJitterLimit);
  }
      
  testlimit.isLimitTableUsed = ttlHelper.isAllInTable(); 

  //if not defined in test table, use testflow limit
  if(!testlimit.isLimitTableUsed)
  {
    testlimit.ppJitterLimit = GET_LIMIT_OBJECT(testlimit.ppTestname);
    testlimit.rmsJitterLimit = GET_LIMIT_OBJECT(testlimit.rmsTestname);
  } 
 
  //default is 'ps' as same as parameter definition
  if (testlimit.ppJitterLimit.unit().empty())
  {
  testlimit.ppJitterLimit.unit("ps");
  }
  if (testlimit.rmsJitterLimit.unit().empty())
  {
  testlimit.rmsJitterLimit.unit("ps");
  }
}
/**
 *-----------------------------------------------------------------------------
 * Routine: doMeasurement
 *
 * Purpose: execute measurement and store results
 *
 *-----------------------------------------------------------------------------
 * Description:
 *
 *INPUT:
 *        parameters--------------test parameters
 *        result------------------test result container
 *
 *RETURN:
 *NOTE:
 * process steps:
 * |----------------|     |------------|       |-------------|       |---------|
 * |    pattern     |     | transition |       |             |       |         |
 * |synchronization |---->|  search    |------>|     data    |------>|  post   |
 * |   (optional)   |     | (optional) |       | acquisition |       | process |
 * |----------------|     |------------|       |-------------|       |---------|
 *-----------------------------------------------------------------------------
 */
void JitterHistogramUtil::doMeasurement(
  const JitterHistogramParameter & parameters,
  JitterHistogramResult& results)
{
  ON_FIRST_INVOCATION_BEGIN();
    results.init();
    CONNECT();
    FW_TASK("SQGB ACQF,0;");
  ON_FIRST_INVOCATION_END();

  const JitterUtil::JitterParameter& commonParameter = parameters.commonParameter;
  // autoSync
  if(commonParameter.autoSyncMode == JitterUtil::AUTOSYNC_ON || 
     commonParameter.autoSyncMode == JitterUtil::AUTOSYNC_ON_KEEP_VALUE)
  { 
    bool isEveryPinOfAllSitesFail = false;
    JitterUtil::autoSync(parameters.commonParameter,
                         results.jitterResult,
                         isEveryPinOfAllSitesFail);
    if(isEveryPinOfAllSitesFail)
    {
      return;
    }
  }
  // transition search
  if(commonParameter.transitionSearchMode == JitterUtil::TRANSITIONSEARCH_ON)
  {
    bool isEveryPinOfAllSitesFail = false;
    JitterUtil::transitionSearch(parameters.commonParameter,
                                 results.jitterResult,
                                 isEveryPinOfAllSitesFail);
    if(isEveryPinOfAllSitesFail)
    {
      return;
    }
  }
  //data acquisition
  JitterUtil::dataAcquire(parameters.commonParameter,results.jitterResult);
  
  //post process: calculation and apply pattern synchronization value
  ON_FIRST_INVOCATION_BEGIN();
    histogramCalculation(parameters,results);
    if(commonParameter.autoSyncMode == JitterUtil::AUTOSYNC_ON_KEEP_VALUE)
    {
      applyPatternSyncValue(parameters,results);
    }
  ON_FIRST_INVOCATION_END();
}

/**
 *-----------------------------------------------------------------------------
 *Routing: histogramCalculation
 *
 *Purpose: calculate jitter value of every pin of every site
 *
 *-----------------------------------------------------------------------------
 *Description:
 *  the function calculate the jitter value according to the testing
 *  result(error count).
 *INPUT:
 *      parameters---------test parameters
 *      results------------test result container
 *Return:
 *-----------------------------------------------------------------------------
 */
void JitterHistogramUtil::histogramCalculation(
  const JitterHistogramParameter& parameters,
  JitterHistogramResult& results)
{
  const JitterUtil::JitterParameter& commonParameter = parameters.commonParameter;
  JitterUtil::JitterResult& commonResult = results.jitterResult;

  map<INT, map<STRING,JitterUtil::CommonResultData> >::const_iterator site_it;
  map<STRING,JitterUtil::CommonResultData>::const_iterator pin_it;
  
  //left side
  if(commonParameter.transition == JitterUtil::LEFT || 
     commonParameter.transition == JitterUtil::BOTH)
  {
    for(site_it = commonResult.commonResultMap.begin();
        site_it != commonResult.commonResultMap.end();
        ++site_it)//for every site
    {
      for(pin_it = site_it->second.begin();
          pin_it != site_it->second.end();++pin_it)//for every pin
      {
        if(pin_it->second.lastStatus == JitterUtil::LEFT_JITTER || 
           pin_it->second.lastStatus == JitterUtil::BOTH_JITTER)
        {
          DOUBLE startValue = 0.0;
          if(commonParameter.transitionSearchMode == JitterUtil::TRANSITIONSEARCH_ON)
          {
            startValue = 
              commonResult.commonResultMap[site_it->first][pin_it->first].leftTransitionVal;
          }
          else if(commonParameter.autoSyncMode == JitterUtil::AUTOSYNC_ON || 
                  commonParameter.autoSyncMode == JitterUtil::AUTOSYNC_ON_KEEP_VALUE)
          {
            startValue = 
              commonResult.commonResultMap[site_it->first][pin_it->first].autoSyncVal;
          }
          else
          {
            startValue = commonParameter.start_ns;
          }
          DSP_JITTER_HISTOGRAM(
            pin_it->second.leftErrorCount,
            startValue,
            -commonParameter.dataAcquStepWidth_ns,
            results.resultMap[site_it->first][pin_it->first].leftHistogramData,
            results.resultMap[site_it->first][pin_it->first].leftSideJitter,
            true);
        }//end if for jitter calculation
      }//end for every pin
    }//end for every site
  }//end if for left

  //right side
  if(commonParameter.transition == JitterUtil::RIGHT || 
     commonParameter.transition == JitterUtil::BOTH)
  {
    for(site_it = commonResult.commonResultMap.begin();
        site_it != commonResult.commonResultMap.end();
        ++site_it)//for every site
    {
      for(pin_it = site_it->second.begin();
          pin_it != site_it->second.end();++pin_it)//for every pin
      {
        if(pin_it->second.lastStatus == JitterUtil::RIGHT_JITTER || 
           pin_it->second.lastStatus == JitterUtil::BOTH_JITTER)
        {
          DOUBLE startValue = 0.0;
          if(commonParameter.transitionSearchMode == JitterUtil::TRANSITIONSEARCH_ON)
          {
            startValue = 
              commonResult.commonResultMap[site_it->first][pin_it->first].rightTransitionVal;
          }
          else if(commonParameter.autoSyncMode == JitterUtil::AUTOSYNC_ON || 
                  commonParameter.autoSyncMode == JitterUtil::AUTOSYNC_ON_KEEP_VALUE)
          {
            startValue = 
              commonResult.commonResultMap[site_it->first][pin_it->first].autoSyncVal;
          }
          else
          {
            startValue = commonParameter.start_ns;
          }
          DSP_JITTER_HISTOGRAM(
            pin_it->second.rightErrorCount,
            startValue,
            commonParameter.dataAcquStepWidth_ns,
            results.resultMap[site_it->first][pin_it->first].rightHistogramData,
            results.resultMap[site_it->first][pin_it->first].rightSideJitter,
            true);
        }//end if for jitter calculation
      }//end for every pin
    }//end for every site
  }//end if for right side
}

/**
 *-----------------------------------------------------------------------------
 *Routine: applyPatternSyncValue
 *
 *Purpose: keep synchronization value
 *
 *-----------------------------------------------------------------------------
 *Description:
 * if user sets the autoSyncMode parameter to ON_KEEP_VALUE, then the
 * synchronization value of the test pin will be keeped for the following
 * test suites.
 *
 *INPUT:
 *       Parameters------------test parameters
 *       results---------------result container
 *RETURN:
 *-----------------------------------------------------------------------------
 */
void JitterHistogramUtil::applyPatternSyncValue(
  const JitterHistogramParameter& parameters,
  JitterHistogramResult& results)
{
  JitterUtil::JitterParameter commonParameter = parameters.commonParameter;
  JitterUtil::JitterResult commonResult = results.jitterResult;

  // firmware stream
  ostringstream fsString;
  Boolean isEveryPinOfAllSitesFail = true;
  FOR_EACH_SITE_BEGIN();
    INT siteNumber = CURRENT_SITE_NUMBER();
    Boolean isFirst = true;
    STRING_VECTOR::const_iterator it = commonParameter.PinVector.begin();
    STRING_VECTOR::const_iterator it_end = commonParameter.PinVector.end();
    for(;it != it_end;++it)
    {
      // autoSync pass, so we can apply the synchronization value to the
      // followig test suites.
      if(commonResult.commonResultMap[siteNumber][*it].lastStatus != JitterUtil::AUTOSYNC_FAIL)
      {
        if(isFirst)
        {
          isFirst = false;
          fsString << "PSFC " << siteNumber << ";";
        }
        isEveryPinOfAllSitesFail = false;
        fsString << "SHSP TIM," << "\"" << *it << "_" 
                 << commonParameter.specName_postfix;
        if((!commonParameter.portName.empty()) && commonParameter.portName != "@")
        {
          fsString << "@" << commonParameter.portName;
        }
        fsString << "\",(" << *it << "),,,;SHVL ";
        if(commonParameter.transition == JitterUtil::LEFT)
        {
          fsString << results.resultMap[siteNumber][*it].leftSideJitter.mean +
                      0.5 * commonParameter.UI_width_ns << ",;";
        }
        else // for right or both sides
        {
          fsString << results.resultMap[siteNumber][*it].rightSideJitter.mean -
                      0.5 * commonParameter.UI_width_ns << ",;"; 
		}
      }
    }//end for every pin of one site
  FOR_EACH_SITE_END();
  if(!isEveryPinOfAllSitesFail)
  {
    fsString << "PSFC ALL\n";
    //download and execute firmware command
    FW_TASK(fsString.str());
  }
}

/**
 *-----------------------------------------------------------------------------
 * Routine: judgeAndDatalog
 *
 * Purpose: judge and put result into event datalog stream
 *
 *-----------------------------------------------------------------------------
 * Description:
 *    judge result of 'results' with pass limit form 'testlimit'
 *
 *   INPUT:  param       - test parameters
 *           testLimit   - test limit container
 *           result      - result container
 *
 *   RETURN:
 *-----------------------------------------------------------------------------
 */
void JitterHistogramUtil::judgeAndDatalog(
  const JitterHistogramParameter& parameters,
  const JitterHistogramResult& results,
  const JitterHistogramLimit & testlimit)
{
  JitterUtil::JitterParameter commonParameter = parameters.commonParameter;
  INT siteNumber = CURRENT_SITE_NUMBER();
  //user's input unit is ns,translate ns to ps
  double factorPP = 1000.0;
  double factorRMS = 1000.0;

  STRING_VECTOR::const_iterator it = commonParameter.PinVector.begin();
  STRING_VECTOR::const_iterator it_end = commonParameter.PinVector.end();

  ARRAY_D leftSidePPJitter(commonParameter.PinVector.size());
  ARRAY_D leftSideRMSJitter(commonParameter.PinVector.size());
  ARRAY_D rightSidePPJitter(commonParameter.PinVector.size());
  ARRAY_D rightSideRMSJitter(commonParameter.PinVector.size());

  int pinIndex = 0;
  for(;it != it_end; ++it,pinIndex++)
  {
    map<INT,map<STRING,ResultData> > ::const_iterator site_it;
    map<STRING,ResultData>::const_iterator pin_it;
    site_it = results.resultMap.find(siteNumber);
    // because setup error or other error, there is no result for this site.
    if(site_it == results.resultMap.end())
    {
      STRING api = "JitterHistogramUtil::judgeAndDatalog: ";
      STRING msg = "These is no result for this site.";
      throw Error(api.c_str(),msg.c_str(),api.c_str());
    }
    pin_it = site_it->second.find(*it);
    // because setup error or other error, there is no result for this site.
    if(pin_it == site_it->second.end())
    {
      STRING api = "JitterHistogramUtil::judgeAndDatalog: ";
      STRING msg = "These is no result for this pin.";
      throw Error(api.c_str(),msg.c_str(),api.c_str());
    }    

    JitterUtil::JitterResult commonResult = 
      const_cast<JitterUtil::JitterResult&>(results.jitterResult);   
    switch(commonResult.commonResultMap[siteNumber][*it].lastStatus)
    {
      case JitterUtil::LEFT_JITTER:
        leftSidePPJitter[pinIndex] = pin_it->second.leftSideJitter.peak2peak * factorPP;
        leftSideRMSJitter[pinIndex] = pin_it->second.leftSideJitter.rms * factorRMS;
        break;
      case JitterUtil::RIGHT_JITTER:
        rightSidePPJitter[pinIndex] = pin_it->second.rightSideJitter.peak2peak * factorPP;
        rightSideRMSJitter[pinIndex] = pin_it->second.rightSideJitter.rms * factorRMS;
        break;
      case JitterUtil::BOTH_JITTER:
        leftSidePPJitter[pinIndex] = pin_it->second.leftSideJitter.peak2peak * factorPP;
        leftSideRMSJitter[pinIndex] = pin_it->second.leftSideJitter.rms * factorRMS;
        rightSidePPJitter[pinIndex] = pin_it->second.rightSideJitter.peak2peak * factorPP;
        rightSideRMSJitter[pinIndex] = pin_it->second.rightSideJitter.rms * factorRMS;
        break;
      case JitterUtil::AUTOSYNC_FAIL:
      case JitterUtil::LEFT_TRANSITION_FAIL:
      case JitterUtil::RIGHT_TRANSITION_FAIL:
      case JitterUtil::BOTH_TRANSITION_FAIL:
        leftSidePPJitter[pinIndex] = NAN;
        leftSideRMSJitter[pinIndex] = NAN;
        rightSidePPJitter[pinIndex] = NAN;
        rightSideRMSJitter[pinIndex] = NAN;
        break;
      default:
        break;
    }//end for switch
  }//end for pinlist

  //MPR log
  if (testlimit.isLimitTableUsed) //limit table way
  {
    switch(commonParameter.transition)
    {
      case JitterUtil::LEFT:
        TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
          testlimit.ppTestname, V93kLimits::tmLimits, leftSidePPJitter);
        TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
          testlimit.rmsTestname, V93kLimits::tmLimits, leftSideRMSJitter);
        break;
      case JitterUtil::RIGHT:
        TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
          testlimit.ppTestname, V93kLimits::tmLimits, rightSidePPJitter);
        TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
          testlimit.rmsTestname, V93kLimits::tmLimits, rightSideRMSJitter);
        break;
      case JitterUtil::BOTH:
        TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
          testlimit.ppTestname, V93kLimits::tmLimits, leftSidePPJitter);
        TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
          testlimit.rmsTestname, V93kLimits::tmLimits, leftSideRMSJitter);
        TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
          testlimit.ppTestname, V93kLimits::tmLimits, rightSidePPJitter);
        TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
          testlimit.rmsTestname, V93kLimits::tmLimits, rightSideRMSJitter);
        break;
      default:
        break;
    }
  }
  else // testflow limit way
  {
    switch(commonParameter.transition)
    {
      case JitterUtil::LEFT:
        TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
          testlimit.ppTestname, testlimit.ppJitterLimit, leftSidePPJitter);
        TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
          testlimit.rmsTestname, testlimit.rmsJitterLimit, leftSideRMSJitter);
        break;
      case JitterUtil::RIGHT:
        TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
          testlimit.ppTestname, testlimit.ppJitterLimit, rightSidePPJitter);
        TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
          testlimit.rmsTestname, testlimit.rmsJitterLimit, rightSideRMSJitter);
        break;
      case JitterUtil::BOTH:
        TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
          testlimit.ppTestname, testlimit.ppJitterLimit, leftSidePPJitter);
        TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
          testlimit.rmsTestname, testlimit.rmsJitterLimit, leftSideRMSJitter);
        TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
          testlimit.ppTestname, testlimit.ppJitterLimit, rightSidePPJitter);
        TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
          testlimit.rmsTestname, testlimit.rmsJitterLimit, rightSideRMSJitter);
        break;
      default:
        break;
    }
  } 
}

/**
 *-----------------------------------------------------------------------------
 * Routine: reportToUI
 *
 * Purpose: output result to ui_report window
 *
 *-----------------------------------------------------------------------------
 * Description:
 *   display:
 *       a) summary,just give the summary test result in ui_report
 *       b) detail,will give error count plot and histogram curve
 *       c) analysis,you can get histogram curve in signal analyzer
 *   INPUT:  parameters          - test parameters
 *           results             - result container
 *           output             - "NONE" or "ReportUI"
 *   RETURN:
 * Note:
 *  In every mode of the three display modes, you can get peak_to_peak
 *  and rms value in ui_report window.
 *-----------------------------------------------------------------------------
 */ 
void JitterHistogramUtil::reportToUI(
  const JitterHistogramParameter& parameters,
  const JitterHistogramResult& results,
  const STRING & output)
{
  if(output == "NONE")
  {
    return;
  }

  JitterUtil::JitterParameter commonParameter = parameters.commonParameter;

  STRING_VECTOR::const_iterator it = commonParameter.PinVector.begin();
  STRING_VECTOR::const_iterator it_end = commonParameter.PinVector.end();
  INT siteNumber = CURRENT_SITE_NUMBER();

  map<INT,map<STRING,ResultData > > ::const_iterator site_it;
  map<STRING,ResultData >::const_iterator pin_it;

  if (commonParameter.outputMode == JitterUtil::OUTPUT_SUMMARY)// summary mode
  {
    cout << "Jitter Test Summary:   " <<endl;
    cout << "site:                  " << siteNumber << endl;
    for(;it != it_end; ++it)
    {
      site_it = results.resultMap.find(siteNumber);
      // because setup error or other error, there is no result for this site.
      if(site_it == results.resultMap.end())
      {
        cout<<"Warning::There is no result fot this site: " 
            << siteNumber <<endl;
        continue;
      }      
      pin_it = site_it->second.find(*it);
      //because setup error or other errors,thers is no result for this pin.
      if(pin_it == site_it->second.end())
      {
        cout<<"Warning::There is no result for this pin: " << *it
            <<"in site: " << siteNumber <<endl;
        continue;
      }            
      // normal case
      JitterUtil::JitterResult commonResult = 
        const_cast<JitterUtil::JitterResult&>(results.jitterResult);
      switch(commonResult.commonResultMap[siteNumber][*it].lastStatus)
      {
        case JitterUtil::LEFT_JITTER:
          cout << "Pins:                    " << *it <<endl
               << "Left Jitter Result:      " << endl;
          printJitterValue(pin_it->second.leftSideJitter.peak2peak,
                           pin_it->second.leftSideJitter.rms);
          break;
        case JitterUtil::RIGHT_JITTER:
          cout << "Pins:                    " << *it <<endl
               << "Right Jitter Result:     " << endl;
          printJitterValue(pin_it->second.rightSideJitter.peak2peak,
                           pin_it->second.rightSideJitter.rms);
          break;
        case JitterUtil::BOTH_JITTER:
          cout << "Pins:                    " << *it <<endl
               << "Left Jitter Result:      " << endl;
          printJitterValue(pin_it->second.leftSideJitter.peak2peak,
                           pin_it->second.leftSideJitter.rms);
          cout << "Right Jitter Result:     " << endl;
          printJitterValue(pin_it->second.rightSideJitter.peak2peak,
                           pin_it->second.rightSideJitter.rms);
          break;
        case JitterUtil::AUTOSYNC_FAIL:
          JitterUtil::printWaringMessage(siteNumber,*it);
          cout << "There is no pass pattern!" << endl;
          break;
        case JitterUtil::LEFT_TRANSITION_FAIL:
          JitterUtil::printWaringMessage(siteNumber,*it);
          cout << "There is no transition on left!" << endl;
          break;
        case JitterUtil::RIGHT_TRANSITION_FAIL:
          JitterUtil::printWaringMessage(siteNumber,*it);
          cout << "There is no transition on right!" << endl;
          break;
        case JitterUtil::BOTH_TRANSITION_FAIL:
          JitterUtil::printWaringMessage(siteNumber,*it);
          cout << "There is no transition for both sides!" << endl;
          break;
        default:
          throw Error("JitterHistogramUtil::reportToUI",
                      "There is an unknown status for reportToUI!",
                      "JitterHistogramUtil::reportToUI");
      }//end for switch
    }//end for pinlist
  }//end for summary mode
  else if (commonParameter.outputMode == JitterUtil::OUTPUT_DETAIL)//detail mode
  {
    cout << "JItter Test Detail:  " << endl;
    cout << "site:                " << siteNumber <<endl;
    for(;it != it_end; ++it)
    {
      site_it = results.resultMap.find(siteNumber);
      // because setup error or other error, there is no result for this site.
      if(site_it == results.resultMap.end())
      {
        cout<<"Warning::There is no result fot this site: " 
            << siteNumber <<endl;
        continue;
      }    
      pin_it = site_it->second.find(*it);
      // because setup error or other error, there is no result for this pin.
      if(pin_it == site_it->second.end())
      {
        cout<<"Warning::There is no result for this pin: " << *it
            <<"in site: " << siteNumber <<endl;
        continue;
      }      
      // normal case 
      JitterUtil::JitterResult commonResult = 
        const_cast<JitterUtil::JitterResult&>(results.jitterResult);
      switch(commonResult.commonResultMap[siteNumber][*it].lastStatus)
      {
        case JitterUtil::LEFT_JITTER:
          cout << "Pins:                           " << *it << endl
               << "Left Jitter Error Count Plot:   " <<endl;
          printHistogram(commonResult.commonResultMap[siteNumber][*it].leftErrorCount);

          cout << "Left Jitter Histogram Curve:   " << endl;
          printHistogram(pin_it->second.leftHistogramData);
          printJitterValue(pin_it->second.leftSideJitter.peak2peak,
                           pin_it->second.leftSideJitter.rms);
          break;
        case JitterUtil::RIGHT_JITTER:
          cout << "Pins:                            " << *it << endl
               << "Right Jitter Error Count Plot:   " <<endl;
          printHistogram(commonResult.commonResultMap[siteNumber][*it].rightErrorCount);

          cout << "Right Jitter Histogram Curve:   " << endl;
          printHistogram(pin_it->second.rightHistogramData);
          printJitterValue(pin_it->second.rightSideJitter.peak2peak,
                           pin_it->second.rightSideJitter.rms);
          break;
        case JitterUtil::BOTH_JITTER:
          cout << "Pins:                            " << *it << endl
               << "Left Jitter Error Count Plot:   " <<endl;
          printHistogram(commonResult.commonResultMap[siteNumber][*it].leftErrorCount);

          cout << "Left Jitter Histogram Curve:   " << endl;
          printHistogram(pin_it->second.leftHistogramData);
          printJitterValue(pin_it->second.leftSideJitter.peak2peak,
                           pin_it->second.leftSideJitter.rms);

          cout << "Right Jitter Error Count Plot:   " <<endl;
          printHistogram(commonResult.commonResultMap[siteNumber][*it].rightErrorCount);

          cout << "Right Jitter Histogram Curve:   " << endl;
          printHistogram(pin_it->second.rightHistogramData);
          printJitterValue(pin_it->second.rightSideJitter.peak2peak,
                           pin_it->second.rightSideJitter.rms);
          break;	  	  	  
        case JitterUtil::AUTOSYNC_FAIL:
          JitterUtil::printWaringMessage(siteNumber,*it);
          cout << "There is no pass pattern!" << endl;
          break;
        case JitterUtil::LEFT_TRANSITION_FAIL:
          JitterUtil::printWaringMessage(siteNumber,*it);
          cout << "There is no transition on left!" << endl;
          break;
        case JitterUtil::RIGHT_TRANSITION_FAIL:
          JitterUtil::printWaringMessage(siteNumber,*it);
          cout << "There is no transition on right!" << endl;
          break;
        case JitterUtil::BOTH_TRANSITION_FAIL:
          JitterUtil::printWaringMessage(siteNumber,*it);
          cout << "There is no transition for both sides!" << endl;
          break;
        default:
          throw Error("JitterHistogramUtil::reportToUI",
                      "There is an unknown status for reportToUI!",
                      "JitterHistogramUtil::reportToUI");
      }
    }
  }
  else // analysis mode
  {
    cout << "Jitter Test Analysis:    " << endl;
    cout << "site       :             " << siteNumber << endl;
    for(;it != it_end; ++it)
    {
      site_it = results.resultMap.find(siteNumber);
      // because setup error or other error, there is no result for this site.
      if(site_it == results.resultMap.end())
      {
        cout<<"Warning::There is no result fot this site: " << siteNumber <<endl;
        continue;
      }      
      pin_it = site_it->second.find(*it);
      // because setup error or other error, there is no result for this pin.
      if(pin_it == site_it->second.end())
      {
        cout<<"Warning::There is no result for this pin: " << *it
            <<"in site: " << siteNumber <<endl;
        continue;
      }      

      // normal case
      JitterUtil::JitterResult commonResult = 
        const_cast<JitterUtil::JitterResult&>(results.jitterResult);
      switch(commonResult.commonResultMap[siteNumber][*it].lastStatus)
      {
        case JitterUtil::LEFT_JITTER:
          {
            WAVE_LOG histogramWaveLeft;
            prepareDataForAnalyzer(pin_it->first,
                                   pin_it->second.leftHistogramData,
                                   histogramWaveLeft);
            PUT_DEBUG(*it,"LEFT HISTOGRAM",histogramWaveLeft);
          }
          cout << "Pins:                    " << *it <<endl;
          cout << "Left Jitter Result:      " << endl;
          printJitterValue(pin_it->second.leftSideJitter.peak2peak,
                           pin_it->second.leftSideJitter.rms);
          break;
        case JitterUtil::RIGHT_JITTER:
          {
            WAVE_LOG histogramWaveRight;
            prepareDataForAnalyzer(pin_it->first,
                                   pin_it->second.rightHistogramData,
                                   histogramWaveRight);
            PUT_DEBUG(*it,"RIGHT HISTOGRAM",histogramWaveRight);
          }
          cout << "Pins:                    " << *it <<endl;
          cout << "Right Jitter Result:     " << endl;
          printJitterValue(pin_it->second.rightSideJitter.peak2peak,
                           pin_it->second.rightSideJitter.rms);
          break;
        case JitterUtil::BOTH_JITTER:
          {
            WAVE_LOG histogramWaveLeft;
            prepareDataForAnalyzer(pin_it->first,
                                   pin_it->second.leftHistogramData,
                                   histogramWaveLeft);
            PUT_DEBUG(*it,"LEFT HISTOGRAM",histogramWaveLeft);

            WAVE_LOG histogramWaveRight;
            prepareDataForAnalyzer(pin_it->first,
                                   pin_it->second.rightHistogramData,
                                   histogramWaveRight);
            PUT_DEBUG(*it,"RIGHT HISTOGRAM",histogramWaveRight);
          }
          cout << "Pins:                    " << *it <<endl;
          cout << "Left Jitter Result:      " << endl;
          printJitterValue(pin_it->second.leftSideJitter.peak2peak,
                           pin_it->second.leftSideJitter.rms);
          cout << "Right Jitter Result:     " << endl;
          printJitterValue(pin_it->second.rightSideJitter.peak2peak,
                           pin_it->second.rightSideJitter.rms);
          break;
        case JitterUtil::AUTOSYNC_FAIL:
          JitterUtil::printWaringMessage(siteNumber,*it);
          cout << ", there is no pass pattern!" << endl;
          break;
        case JitterUtil::LEFT_TRANSITION_FAIL:    
          JitterUtil::printWaringMessage(siteNumber,*it);
          cout << "There is no transition on left!" << endl;
          break;
        case JitterUtil::RIGHT_TRANSITION_FAIL:
          JitterUtil::printWaringMessage(siteNumber,*it);
          cout << "Tthere is no transition on right!" << endl;
          break;
        case JitterUtil::BOTH_TRANSITION_FAIL:
          JitterUtil::printWaringMessage(siteNumber,*it);
          cout << "There is no transition for both sides!" << endl;
          break;
        default:
          throw Error("JitterHistogramUtil::reportToUI",
                      "There is an unknown status for reportToUI!",
                      "JitterHistogramUtil::reportToUI");
      }
    }
  }
}

/**
 *-----------------------------------------------------------------------------
 *Routine: JitterHistogramUtil::printHistogram
 *
 *Purpose: print histogram to ui_report window
 *-----------------------------------------------------------------------------
 *Parameters:
 * 1)histogramData: histogram data 
 *-----------------------------------------------------------------------------
 */

void JitterHistogramUtil::printHistogram(const vector<INT> & histogramData)
{
  INT length = histogramData.size();
  // use function max_element get the max value of the ErrorCount Array
  INT maxValue = *(max_element(histogramData.begin(),histogramData.end()));
  //because the error count number offen is very big, so we adjust the number
  //every line can out put 80 "*" most
  for(INT index = 0;index < length; ++index)
  {
    double refence = 0.0;
    if(maxValue != 0)
    {
      refence = static_cast<double>(histogramData[index])/maxValue;
    }
    INT bar = static_cast<INT>(refence *80);
    for(INT i=0;i < bar;++i)
    {
      cout << "*";
    }
    cout << endl;
  }
}


void JitterHistogramUtil::printJitterValue(const DOUBLE peak2peak,
                                                const DOUBLE rms)
{
  //user's input unit is ns,translate ns to ps
  const INT factor = 1000;
  cout << "       peak_to_peak[ps]:     " << peak2peak * factor << endl; 
  cout << "                rms[ps]:     " << rms * factor << endl; 
}

void JitterHistogramUtil::prepareDataForAnalyzer(
  const STRING & pinName,
  const vector<INT>& histogramData,
  WAVE_LOG& dataForAnalyzer)
{
  INT sizeOfArray = histogramData.size();
  ARRAY_I histogramDataArray(sizeOfArray);
  for(INT loop =0;loop < sizeOfArray;loop++)
  {
    histogramDataArray[loop] = histogramData[loop];
  }
  dataForAnalyzer.xTitle("Time");
  dataForAnalyzer.xUnit("ns");
  dataForAnalyzer.yAxis(histogramDataArray);
  dataForAnalyzer.yTitle(pinName + "Histogram Data");
  dataForAnalyzer.yUnit("Number");
}
#endif /*INCLUDE_JITTERHISTOGRAM_H*/
