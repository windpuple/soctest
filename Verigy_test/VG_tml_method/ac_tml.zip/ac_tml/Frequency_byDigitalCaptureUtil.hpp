#ifndef INCLUDE_FREQUENCY_BYDIGITALCAPTUPE_H
#define INCLUDE_FREQUENCY_BYDIGITALCAPTUPE_H
#include "CommonUtil.hpp"
class FrequencyUtil
{
public:
  /*
   *--------------------------------------------------------------------------------------* 
   * Struct: FrequencyParam
   * Purpose: container to store frequency measurement parameters
   *--------------------------------------------------------------------------------------*
   * Decription:
   *  const STRING vectorVariableName: 
   *     Vector Variable name for digital capture.
   *  const STRING algorithm.     { FFT | Linear Fit }:
   *     Indicate the frequncy measurement algorithm.
   *  DOUBLE samplePeriod_us:
   *     value of sample rate period, the unit is us.
   *  DOUBLE targetFrequency_MHz:
   *     this is the expected signal frequency in [MHz],the default value is 0.
   * Note:
   *--------------------------------------------------------------------------------------*
   */
  struct FrequencyParam
  {
    // Parameters
    STRING vectorVariableName;
    STRING algorithm;
    DOUBLE samplePeriod_us;
    DOUBLE targetFrequency_MHz;
    STRING testsuiteName;
  };
  /*
   *--------------------------------------------------------------------------------------* 
   * Struct: FrequencyResult
   * Purpose: container to store frequency measurement results
   *--------------------------------------------------------------------------------------*
   * Decription:
   *  const STRING testName;
   *     Name of the test limit.
   *  const LIMIT limit
   *     Idicate the frequncy limitation.
   *  map <STRING,DOUBLE> mapPinFrequency:
   *     record the frequency of every pin.
   * Note:
   *--------------------------------------------------------------------------------------*
   */
  struct FrequencyResult
  {
    // Parameters
    STRING testName;
    bool isLimitTableUsed;
    LIMIT limit;
    map <STRING,DOUBLE> mapPinFrequency;
  };
  static void processParameters (const STRING &vectorVariableName,
                                 const STRING &algorithm,                      
                                 DOUBLE samplePeriod_ns,
                                 DOUBLE targetFrequency_MHz,
                                 FrequencyUtil::FrequencyParam &params);
  static void doMeasurement (const FrequencyParam& params, FrequencyResult& results);
  static void judgeAndDatalog (const FrequencyResult& results);
  static void reportToUI (const FrequencyResult& results,const STRING& output);
  static double calculateFrequency_byFFT (ARRAY_I &time_data, double sample_period_us);
  static double calculateFrequency_byLinearFit (ARRAY_I &time_data, double sample_period_us);
};

/*
 *----------------------------------------------------------------------*
 * Routine: FrequencyUtil::processParameters
 *
 * Purpose: process the parameters of frequency test
 *
 *----------------------------------------------------------------------*
 * Description:
 * 
 *   
 * Parameters:
 *   vectorVariableName: vector variable name of digital capture.
 *   algorithm: frequency calculate algorithm. (FFT/Linear Fit)
 *   samplePeriod_ns: sample period value, the unit is ns.
 *   targetFrequency_MHz: this is the expected  signal frequency in [MHz],
 *                        the default value is 0.
 *   params: the struct which store all parameters for frequency test.
 *
 * Output:
 * 
 * Note:
 *
 *----------------------------------------------------------------------*
 */
inline void FrequencyUtil::processParameters (const STRING &vectorVariableName,
                                              const STRING &algorithm,
                                              DOUBLE samplePeriod_ns,
                                              DOUBLE targetFrequency_MHz,   
                                              FrequencyUtil::FrequencyParam &params)
{
  params.algorithm = CommonUtil::trim(algorithm);
  params.samplePeriod_us = fabs(samplePeriod_ns / 1000);
  params.vectorVariableName = CommonUtil::trim(vectorVariableName);
  params.targetFrequency_MHz = fabs(targetFrequency_MHz);
  GET_TESTSUITE_NAME(params.testsuiteName);
}                                                   

/*
 *----------------------------------------------------------------------*
 * Routine: FrequencyUtil::doMeasurement
 *
 * Purpose: do frequency test
 *
 *----------------------------------------------------------------------*
 * Description:
 *   Do digital capture test, then calculate the frequency according to 
 * the capture data , sample period value and the algorithm(FFT/Linear Fit).
 *   
 * Parameters:
 *   params: parameters of frequency tset.
 *   results: contains test results of frequency test.
 *
 * Output:
 * 
 * Note:
 *
 *----------------------------------------------------------------------*
 */
inline void FrequencyUtil::doMeasurement (const FrequencyParam& params, FrequencyResult& results)
{
 
  ON_FIRST_INVOCATION_BEGIN();
    
    CONNECT();

    // digital capture test
    DIGITAL_CAPTURE_TEST(1 s);
  ON_FIRST_INVOCATION_END();
 
  results.mapPinFrequency.clear();
   
  /* get the vector data */
  VECTOR vectors ( params.vectorVariableName );
  ARRAY_I vector_data = vectors.getVectors();
  
  /* get the pin list */
  const STRING_VECTOR pinList = vectors.getVariablePinList();
  const int pinAmount = pinList.size();

  /* get the vector size of per pin */
  const int transferType = vectors.getVariableTransferType();
  const int codeWidth = vectors.getVectorNumberPerSample();
  int pinDataSize;
  if ( transferType == 0)  //Parallel mode
  {
    pinDataSize = vector_data.size();
  }
  else //Serial mode
  {
    pinDataSize = vector_data.size()*codeWidth;
  }

  /* Calculate and datalog Frequency for every pin */
  ARRAY_I perPin_data (pinDataSize);
  map <STRING,DOUBLE> mapPinFrequency;
  for (int pinIndex = 0; pinIndex < pinAmount; pinIndex++)
  {
     /* get perPin_Data from the vector_data */
    if (transferType == 0)  //Parallel mode
    {
      for (int i=0;i<pinDataSize;i++)
      {
        perPin_data[i] = 
          ( (vector_data[i] & (1<<(pinAmount-pinIndex-1))) == 0 ) ? 0 : 1;
      }
    }
    else //Serial mode
    {
      for (int i=0;i<vector_data.size();i++)
      {
        for (int j=0;j<codeWidth;j++)
        {
          perPin_data[i*codeWidth+codeWidth-j-1] = 
            ( (vector_data[i] & (1<<j)) == 0 ) ? 0 : 1;
        }
      }
    }
    double factor = 1;
    if (results.limit.unit() != "MHz")
    {
      //if unit is NOT 'MHz' (empty or in format of "kHz;3;kHz;3")
      //factor for converting from 'MHz' to the unit of limit 
      string unitName = CommonUtil::getUnitNameOfLimit(results.limit);
      if (unitName.empty()) // empty means standard unit, i.e. 'Hz'
      {
        unitName = "Hz";
      }
      factor = SI_Value::getDiffValue("MHz",unitName);
    }

    /* calculate the frequency according to the algorithm */
    if (params.algorithm == "FFT")
    {
      mapPinFrequency[pinList[pinIndex]] = factor* 
          FrequencyUtil::calculateFrequency_byFFT(perPin_data,params.samplePeriod_us);
    }
    else //Linear Fit
    {
      mapPinFrequency[pinList[pinIndex]] = factor*
          FrequencyUtil::calculateFrequency_byLinearFit(perPin_data,params.samplePeriod_us);
    }
    /*code added for undersampling support*/
    if (params.targetFrequency_MHz > 1e-6)
    {
      double m = round (params.targetFrequency_MHz * params.samplePeriod_us);
      double tempValue = m / params.samplePeriod_us * factor;
      if(tempValue > params.targetFrequency_MHz)
      { 
        mapPinFrequency[pinList[pinIndex]] = 
          tempValue - mapPinFrequency[pinList[pinIndex]];
      }
      else
      {
        mapPinFrequency[pinList[pinIndex]] = 
          tempValue + mapPinFrequency[pinList[pinIndex]];
      }
    }
  }

  // Record the results
  results.mapPinFrequency = mapPinFrequency;
}

/*
 *----------------------------------------------------------------------*
 * Routine: FrequencyUtil::judgeAndDatalog
 *
 * Purpose: datalog for frequency test.
 *
 *----------------------------------------------------------------------*
 * Description:
 *   use judgeAndLog_ParametricTest to log the test result of frequency
 * test.
 *   
 * Parameters:
 *   results: test results of frequency test.
 * Output:
 * 
 * Note:
 *
 *----------------------------------------------------------------------*
 */
inline void FrequencyUtil::judgeAndDatalog (const FrequencyResult& results)
{
  map<STRING,DOUBLE>::iterator it;
  map<STRING,DOUBLE> mapPinFrequency = results.mapPinFrequency;
  vector<string> logPins;
  ARRAY_D logValues(mapPinFrequency.size());
  //prepare result for MPR logging
  int index = 0;
  for (it = mapPinFrequency.begin();it != mapPinFrequency.end(); it++)
  {
    logPins.push_back(it->first);
    logValues[index++] = it->second;
  }
  //do datalog
  if (results.isLimitTableUsed)
  {  
    TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(
            logPins,
            results.testName,
            V93kLimits::tmLimits,
            logValues);
  }
  else
  {
    TESTSET().cont(TM::CONTINUE)
             .judgeAndLog_ParametricTest(
                logPins,
                results.testName,
                logValues);
  }
}
/*
 *----------------------------------------------------------------------*
 * Routine: FrequencyUtil::reportToUI
 *
 * Purpose: print result to ui_report window
 *
 *----------------------------------------------------------------------*
 * Description:
 * *   
 * Parameters:
 *   results: test results of frequency test.
 *   output: string to indicate if print the results to window.(None/ReportUI)
 * 
 * Output:
 * 
 * Note:
 *
 *----------------------------------------------------------------------*
 */
inline void FrequencyUtil::reportToUI (const FrequencyResult& results,const STRING& output)
{
  if (output == "None")
  {
      return;
  }
  else  // Report to ui_report window.
  {
    map<STRING,DOUBLE>::iterator it;
    map<STRING,DOUBLE> mapPinFrequency = results.mapPinFrequency;
    Boolean isPass;
    
    /* output site infomation */
    cout << " Site: " << CURRENT_SITE_NUMBER() << endl;
    /* for each pin, output the results */
    for (it = mapPinFrequency.begin();it != mapPinFrequency.end(); it++)
    {
      isPass = results.limit.pass(it->second);
      cout <<"Frequency("<<it->first<<"):          f="
           <<setiosflags(ios_base::left)<<setw(OUTPUT_WIDTH)
           <<it->second<<CommonUtil::getUnitNameOfLimit(results.limit)<<"            ";
      if (isPass)
      {
        cout << "P" <<endl;
      }
      else
      {
        cout << "F" <<endl;
      }
    }
  }
}

/*
 *----------------------------------------------------------------------*
 * Routine: FrequencyUtil::calculateFrequency_byFFT
 *
 * Purpose: Use FFT algorithm to calculate the frequncy.
 *
 *----------------------------------------------------------------------*
 * Description:
 * *   
 * Parameters:
 *   time_data: the vector data array for calculate frequency.
 *   sample_period_us: sample period value, the unit is us.
 * 
 * Output:
 * 
 * Note:
 *
 *----------------------------------------------------------------------*
 */
inline double FrequencyUtil::calculateFrequency_byFFT(ARRAY_I &time_data, double sample_period_us)
{
  // performs interpolation of max bin in spectrum, according to Tabei/Ueda
  // will work on both digitally captured clock signals and analog signals

  ARRAY_D spect ;
  int min_index , max_index ;
  double min , max , dR , interpol_index , frequency_MHz ;

  DSP_SPECTRUM ( time_data , spect , VOLT , 1.0 , HANNING , 0 ) ;  // Tabei-Ueda algorithm needs power spectrum (no log!) with Hanning filter applied

  //cancel out the potential max bin at DC
  if (spect.size() > 2)
  {
    spect[0] = 0;
    spect[1] = 0;
  }
  else
  {
    cerr<<"WARN: spectrum data is too small."<<endl;
  }
  DSP_MINMAX  ( spect , &min , &max , &min_index , &max_index ) ;  // look for max bin

  // interpolating equations
  int max_index_plus_one = max_index + 1;
  max_index_plus_one = (max_index_plus_one < spect.size())?
                       max_index_plus_one : max_index_plus_one-1;

  if ( ( max_index > 0 ) && ( spect[ max_index - 1 ] > spect[ max_index_plus_one ] ) )
  {
    dR = spect[ max_index - 1 ] / spect[ max_index ] ;
    interpol_index = max_index + ( 1.0 - 2.0 * dR ) / ( 1.0 + dR ) ;
  }
  else
  {
    dR = spect[ max_index_plus_one ] / spect[ max_index ] ;
    interpol_index = max_index - ( 1.0 - 2.0 * dR ) / ( 1.0 + dR ) ;
  }
  
  frequency_MHz = interpol_index / ( sample_period_us * time_data.size() ) ;
  return frequency_MHz ;
}

/*
 *----------------------------------------------------------------------*
 * Routine: FrequencyUtil::calculateFrequency_byLinearFit
 *
 * Purpose: Use Linear Fit algorithm to calculate the frequncy.
 *
 *----------------------------------------------------------------------*
 * Description:
 * *   
 * Parameters:
 *   time_data: the vector data array for calculate frequency.
 *   sample_period_us: sample period value, the unit is us.
 * 
 * Output:
 * 
 * Note:
 *
 *----------------------------------------------------------------------*
 */
inline double FrequencyUtil::calculateFrequency_byLinearFit(ARRAY_I &time_data, double sample_period_us)
{
  int i , j ;
  double frequency_MHz , slope , offset ;
  ARRAY_I rising_edge ( time_data.size());

  // detect position of rising edges and store it in array rising_edge
  for ( i = 0 , j = 0 ; i < time_data.size() - 1 ; i++ )
  {
    if ( time_data [ i ] < time_data [ i + 1 ] )
    {
      rising_edge [ j++ ] = i ;
    }
  }

  // perform linear fit on positions of rising edges; slope contains frequency information
  DSP_REG1 ( rising_edge , &slope , &offset , 0 , j ) ;
  frequency_MHz = 1 / ( sample_period_us * slope ) ;

  return frequency_MHz ;
}
#endif
