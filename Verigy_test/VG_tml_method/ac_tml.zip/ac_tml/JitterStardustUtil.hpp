#ifndef INCLUDE_JITTERHISTOGRAM_H
#define INCLUDE_JITTERHISTOGRAM_H
#include <algorithm>
#include "CommonUtil.hpp"
#include "JitterUtil.hpp"

/******************************************************************************
 *                    jitter stardust test utility class 
 ******************************************************************************
 *@Description:
 * By setting up different parameters,users can make the jitter stardust
 * measurement in different conditions.
 *  pattern synchronization: find a passing pattern
 *  transtioon search on specified side(s): optimize the start of jitter data
 *                                          acquisition.
 *  data acquisition on specified side(s): sample the jitter data
 *  jitter histogram calculation on specified side(s): get the mean value of jitter
 *  data acquisiton on specified side(s): run function test to get
 *                                        pass/fail sequence
 *  calculate the frequency component of jitter.
 *
 * according the description,the whole process steps:
 * |----------------|     |------------|       |-------------|
 * |    pattern     |     | transition |       |     data    |
 * |synchronization |---->|  search    |------>| acquisition |
 * |   (optional)   |     | (optional) |       |    (must)   |
 * |----------------|     |------------|       |-------------|
 *                                                    |
 *         -------------------------------------------|
 *         |
 * |----------------|     |---------------|       |-------------|
 * |      data      |     |      data     |       |     post    |
 * |     process    |---->|  acquisition  |------>|   process   |
 * |(mean of jitter)|     |(function test)|       | (frequency) |
 * |----------------|     |---------------|       |-------------|
 * 
 ******************************************************************************
 */ 
class JitterStardustUtil
{
  public:
  /**
   *---------------------------------------------------------------------------
   *         test parameters containe
   *---------------------------------------------------------------------------
   */
  struct  JitterStardustParameter
  {
    //common parameter for jitter stardust, separation and stardust
    JitterUtil::JitterParameter commonParameter;
    //special parameters for jitter stardust
    INT errorMapStartCycle;
    INT  acquisitionDepth;
    INT  FFTWindow;
  };
 /**
  *----------------------------------------------------------------------------
  *         test limits container                                    
  *----------------------------------------------------------------------------
  */
  struct JitterStardustLimit
  {
    bool isLimitTableUsed;
    string testname;
    LIMIT frequencyLimit;
  } ;
  /**
   *---------------------------------------------------------------------------
   *         test results container
   *---------------------------------------------------------------------------
   */
  struct ResultData
  {
    // histogram data vector of left transition
    vector<INT> leftHistogramData;

    // histogram data vector of right transiton
    vector<INT> rightHistogramData;

    // the result of histogram on the left transition side
    JitterHistogramType leftHistogram;

    // the result of histogram on the right transition side
    JitterHistogramType rightHistogram;

    // pass/fail sequence data of left transition
    vector<INT> leftPFData;

    // pass/fail sequence data of right transition
    vector<INT> rightPFData;

    // the result of spectrum amplitude on the left transition side
    vector<DOUBLE> leftSpectrumAmplitude;
   
    // the result of frequency on the left transition side
    vector<DOUBLE> leftFrequency;

    // the result of spectrum amplitude on the right transition side
    vector<DOUBLE> rightSpectrumAmplitude;
   
    // the result of frequency on the right transition side
    vector<DOUBLE> rightFrequency;

    // initialize all stuffs to some defaults.
    void init()
    {
      leftHistogramData.clear();
      rightHistogramData.clear();
      leftHistogram.mean = 0.0;
      leftHistogram.rms = 0.0;
      leftHistogram.peak2peak = 0.0;
      leftHistogram.median = 0.0;
      leftHistogram.medist = 0.0;
      rightHistogram.mean = 0.0;
      rightHistogram.rms = 0.0;
      rightHistogram.peak2peak = 0.0;
      rightHistogram.median = 0.0;
      rightHistogram.medist = 0.0;
      leftSpectrumAmplitude.clear();
      leftFrequency.clear();
      rightSpectrumAmplitude.clear();
      rightFrequency.clear();
    }
    ResultData()
    {
      init();
    }
  };
  /**
   *---------------------------------------------------------------------------
   * @Struct: JitterStardustResult
   * 
   * @Purpose: container to store jitter measurement results
   *---------------------------------------------------------------------------
   * @Decription:
   *   This two-layered map contains result of test.The outside map contains
   *   every site's result.The inside map contains every pin's result.
   *   The outside map's key: INT is the index of site number
   *   The outside map's value:map<STRING,ResultData> is the result of the
   *   site which is indexed by key.
   *   The inside map's key: STRING is the pin's name.
   *   The inside map's value: ResultData is the result of the pin which is
   *   indexed by key.
   * @Note:
   *---------------------------------------------------------------------------
   */
  struct JitterStardustResult
  {
    map<INT,map<STRING, ResultData> > resultMap;
    JitterUtil::JitterResult jitterResult;
    void init()
    {
      jitterResult.init();
      resultMap.clear();
    }
  } ;
  /**
   *---------------------------------------------------------------------------
   *         public interfaces of jitter stardust  test
   *---------------------------------------------------------------------------
   */  
  
  static void processParameters(
    const STRING& pinlist,
    const STRING& portName,
    const STRING& specName_postfix,
    const DOUBLE UI_width_ns,
    const DOUBLE start_ns,
    const DOUBLE stop_ns,
    const DOUBLE dataAcquStepWidth_ns,
    const INT passOnMaxErrorCount,
    const STRING& autoSyncMode,
    const DOUBLE autoSyncStepWidth_ns,
    const STRING& transitionSearchMode,
    const STRING& transition,
    const INT errorMapStartCycle,
    const INT acquisitionDepth,
    const STRING& FFTWindow,
    const STRING& outputMode,
    JitterStardustParameter& parameters);
  static void processLimit(const string& testname, 
    JitterStardustLimit& testlimit);
  static void doMeasurement(
    const JitterStardustParameter& parameters,
    JitterStardustResult& results);
  static void judgeAndDatalog(
    const JitterStardustParameter& parameters,
    const JitterStardustResult& results,
    const JitterStardustLimit & testlimit);
  static void reportToUI(
    const JitterStardustParameter& parameters,
    const JitterStardustResult& results,
    const STRING& output);

  private:
  static void getErrorDensitySignalData(
    const JitterStardustParameter& parameters,
    JitterStardustResult& results);
  static void updateErrorDensityResult(
    const JitterStardustParameter& parameters,
    const Boolean isLeft,
    JitterStardustResult& results);
  static void histogramCalculation(
    const JitterStardustParameter& parameters,
    JitterStardustResult& results);
  static void stardustCalculation(
    const JitterStardustParameter& parameters,
    JitterStardustResult& results);
  static void applyCrossoverOffset(
    const JitterStardustParameter& parameters,
    const Boolean isLeft,
    JitterStardustResult& results,
    ostringstream& fwStream);
  static void applyPatternSyncValue(
    const JitterStardustParameter& parameters,
    JitterStardustResult& results);
  static void applyErrorMapSetupAndRunFuncTest(
    const JitterStardustParameter& parameters,
    ostringstream& restoreString);
  static void printStardustCurve(const vector<DOUBLE>&,
                                 const vector<DOUBLE>&);
  static void printStardustValue(const vector<DOUBLE>&,
                                 const vector<DOUBLE>&);
  static void prepareDataForAnalyzer(const STRING&,
                                     const vector<DOUBLE>&,
                                     const vector<DOUBLE>&,
                                     SCATTER_LOG &);
};
  
/**
 *-----------------------------------------------------------------------------
 * @Routine: processParameter
 *
 * @Purpose: parse input parameters and setup internal parameters
 *
 *-----------------------------------------------------------------------------
 * @Description:
 *   according user's input to fill out interal parameters
 * @Parameters:
 *   1.STRING& pinlist:
 *     Define a list of pins/pin groups the spec is shifted for.
 *     valid type :O,IO
 *   2.STRING& portName:           optional {@|portName}
 *     Port name of above test pins for Multiport Setups.
 *     NOTE:only pins of one port can be selected.
 *     default is @.
 *   3.STRING& specName_postfix:
 *     A spec-variable corresponding to each test-pin should be predefined
 *     and used by this TestMethod to do jitter measurement.
 *     For example:if Tx0 is the input pin,its corresponding
 *     spec-variables are Tx0_offset,this parameter needs to be
 *     set as "offset".
 *   4.DOUBLE UI_width_ns:
 *     Bit time of test pattern.
 *     For example:2.5Gb/s -> 0.4ns
 *   5.DOUBLE start_ns:
 *     --if autoSyncMode is "OFF":start of Data Acquisition
 *     --if autoSyncMode is "ON" or "ON_KEEP_VALUE": start of linear Pattern
 *     Alignment Search
 *   6.DOUBLE stop_ns:
 *     --if autoSyncMode is "OFF":stop of Data Acquisition
 *     --if autoSyncMode is "ON" or "ON_KEEP_VALUE": stop of linear Pattern
 *     Alignment Search
 *   7.DOUBLE dataAcquStepWidth_ns:
 *     Step width for Data Acquisition
 *   8.INT passOnMaxErrorCount:     optional
 *     It defines the pass criteria for all following execution.That is,
 *     besides normally regarding pass as 0 error count, users
 *     can specify the maximum edge count as the pass/fail threshold. 
 *     default vaule: 0
 *   9.STRING& autoSyncMode: {OFF | ON | ON_KEEP_VALUE}
 *     Enabling of linear Pattern Alignment Search to find passing pattern.
 *       With ON_KEEP_VALUE option the Sync value will be kept
 *     after the finishing of the testsuite execution.
 *       With ON option the spec variable will be reset to its
 *     original value after finishing the test.
 *       With OFF option linear Pattern Alignment Search to find
 *     passing pattern is disable.
 *       default is ON.
 *   10.DOUBLE autoSyncStepWidth_ns:
 *      Step width for AutoSync Search.
 *   11.STRING& transitionSearchMode:  {OFF | ON}
 *        With ON,Binary Search for Pass/Fail Transition of
 *      MIN_BER poit with maximum search range of one "UI_width"
 *      and resolution of dataAcquStepWidth_ns.
 *        With OFF,transiton search will not be made.
 *      default is ON.
 *   12.STRING& transition:  {LEFT | RIGHT | BOTH}
 *      Determine which side of bit transition will be searched
 *      if transitionSearchMode is ON and be acquired for jitter
 *      stardust calculation. If both autoSyncMode and
 *      transitionSearchMode are OFF,this parameter is not in
 *      effect,and users have to choose proper values of start
 *      and stop for acquisition based on the test requirement.
 *      default is LEFT.
 *   13.INT errorMapStartCycle:
 *      This parameter determines the start cycle within the test pattern
 *      where the data acquisition with error map starts.
 *   14.INT acquisitionDepth:
 *      this parameter determines how many samples will be acquired with
 *      the error map. The maximum recording size depends on whether the test
 *      processor error map or the large error map in the vector memory is
 *      used. Use numbers on a 2^x basis.
 *   15.STRING& FFTWindow: {Uniform,Hanning,Hamming,Blackman}
 *      windowing option for FFT.
 *   16.STRING& outputMode: {SUMMARY | DETAIL | ANALYSIS}
 *      This parameter is in effect only if output is set ReportUI.
 *      SUMMARY - a result table will be printed in the Report Window.
 *      DETAIL  - an ASCII plot of the Error Count and the stardust curve
 *                will be printed in report window.
 *      ANALYSIS - the jitter stardust data will be transfer to signal
 *                analyzer tool for display and debuggine.
 *      default is SUMMARY.
 *   17.JitterStardustParameter& parameters
 *      this parameter's type is output,we use user's input to
 *      fill out this parameter.
 * @Note:
 *-----------------------------------------------------------------------------
 */
void
JitterStardustUtil::processParameters(
  const STRING& pinlist,
  const STRING& portName,
  const STRING& specName_postfix,
  const DOUBLE  UI_width_ns,
  const DOUBLE  start_ns,
  const DOUBLE  stop_ns,
  const DOUBLE  dataAcquStepWidth_ns,
  const INT passOnMaxErrorCount,
  const STRING& autoSyncMode,
  const DOUBLE  autoSyncStepWidth_ns,
  const STRING& transitionSearchMode,
  const STRING& transition,
  const INT     errorMapStartCycle,
  const INT     acquisitionDepth,
  const STRING& FFTWindow,
  const STRING& outputMode,
  JitterStardustParameter& parameters)
{
  JitterUtil::JitterParameter& commonParameter = parameters.commonParameter;
  STRING tempString = CommonUtil::trim(pinlist);
  JitterUtil::checkSetupPinlist(tempString);
  commonParameter.PinVector = JitterUtil::expandPinlistToPins(tempString);

  commonParameter.portName = CommonUtil::trim(portName);

  tempString = CommonUtil::trim(specName_postfix);
  if( tempString.empty())
  {
    STRING api = "Check specName_postfix: ";
    STRING msg = "There is no specName_postfix! Please input specName_postfix.";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }
  commonParameter.specName_postfix = tempString;

  if(UI_width_ns <= 0)
  { 
    STRING api = "Check parameter UI_width_ns: ";
    STRING msg = "UI_width_ns should be greater than zero!";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }
  commonParameter.UI_width_ns = UI_width_ns; 
  commonParameter.start_ns = start_ns;
  commonParameter.stop_ns = stop_ns;
  if(dataAcquStepWidth_ns <= 0)
  { 
    STRING api = "Check parameter dataAcquStepWidth_ns: ";
    STRING msg = "dataAcquStepWidth_ns should be greater than zero!";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }
  commonParameter.dataAcquStepWidth_ns = dataAcquStepWidth_ns;

  if(passOnMaxErrorCount < 0)
  { 
    STRING api = "Check parameter passOnMaxErrorCount: ";
    STRING msg = "passOnMaxErrorCount shoult not be negative!";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }
  commonParameter.passOnMaxErrorCount = passOnMaxErrorCount;

  tempString = CommonUtil::trim(autoSyncMode);
  if(tempString == "OFF")
  {
    commonParameter.autoSyncMode = JitterUtil::AUTOSYNC_OFF;
  }
  else if (tempString == "ON")
  {
    commonParameter.autoSyncMode = JitterUtil::AUTOSYNC_ON;
  } 
  else if (tempString == "ON_KEEP_VALUE")
  {
    commonParameter.autoSyncMode = JitterUtil::AUTOSYNC_ON_KEEP_VALUE;
  }
  else
  {
    STRING api = "Check AUTOSYNC_MODE: ";
    STRING msg = "These is an unknow AUTOSYNC_MODE type.";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }

  if(autoSyncStepWidth_ns <= 0)
  { 
    STRING api = "Check parameter autoSyncStepWidth_ns: ";
    STRING msg = "autoSyncStepWidth_ns should be greater than zero!";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }
  commonParameter.autoSyncStepWidth_ns = autoSyncStepWidth_ns;

  tempString = CommonUtil::trim(transitionSearchMode); 
  if(tempString == "OFF")
  {
    commonParameter.transitionSearchMode = JitterUtil::TRANSITIONSEARCH_OFF;
  }
  else if(tempString == "ON")
  {
    commonParameter.transitionSearchMode = JitterUtil::TRANSITIONSEARCH_ON;
  }
  else
  {
    STRING api = "Check TRANSITIONSEARCH_MODE: ";
    STRING msg = "These is an unknow TRANSITIONSEARCH_MODE type.";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }

  tempString = CommonUtil::trim(transition);
  if(tempString == "LEFT")
  {
    commonParameter.transition = JitterUtil::LEFT;
  } 
  else if(tempString == "RIGHT")
  {
    commonParameter.transition = JitterUtil::RIGHT;
  }
  else if(tempString == "BOTH")
  {
    commonParameter.transition = JitterUtil::BOTH;
  }
  else
  {
    STRING api = "Check TRANSITION: ";
    STRING msg = "These is an unknow TRANSITION type.";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }

  if(errorMapStartCycle <= 0)
  { 
    STRING api = "Check parameter errorMapStartCycle: ";
    STRING msg = "errorMapStartCycle should be greater than zero!";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }
  parameters.errorMapStartCycle = errorMapStartCycle;
  if(acquisitionDepth <= 0)
  { 
    STRING api = "Check parameter acquisitionDepth: ";
    STRING msg = "acquisitionDepth should be greater than zero!";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }
  parameters.acquisitionDepth = acquisitionDepth;
 
  tempString = CommonUtil::trim(FFTWindow); 
  if(tempString == "Uniform")
  {
    parameters.FFTWindow = RECT;
  }
  else if(tempString == "Hanning")
  {
    parameters.FFTWindow = HANNING;
  }
  else if(tempString == "Hamming")
  {
    parameters.FFTWindow = HAMMING;
  }
  else if(tempString == "Blackman")
  {
    parameters.FFTWindow = FBLACKMAN;
  }
  else 
  {
    STRING api = "Check parameter FFTWindow: ";
    STRING msg = "There is no FFTWindow type!";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }
  
  tempString = CommonUtil::trim(outputMode);
  if (tempString == "SUMMARY")
  {
    commonParameter.outputMode = JitterUtil::OUTPUT_SUMMARY;
  }
  else if(tempString == "DETAIL")
  {
    commonParameter.outputMode = JitterUtil::OUTPUT_DETAIL;
  }
  else if(tempString == "ANALYSIS")
  {
    commonParameter.outputMode = JitterUtil::OUTPUT_ANALYSIS;
  }
  else
  {
    STRING api = "Check OUTPUT_MODE: ";
    STRING msg = "These is an unknow OUTPUT_MODE type.";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }
}

/**
 *-----------------------------------------------------------------------------
 * @Routine: processLimit
 *
 * @Purpose: process Limit(s)
 *
 *-----------------------------------------------------------------------------
 * @Description:
 *   
 * @Note:
 *-----------------------------------------------------------------------------
 */
void
JitterStardustUtil::processLimit(const string& testname, JitterStardustLimit& testlimit)
{
  testlimit.testname = testname;
  //first, try to get limit from test table 
  string testsuiteName;
  GET_TESTSUITE_NAME(testsuiteName);
  TesttableLimitHelper ttlHelper(testsuiteName);
  if (ttlHelper.isLimitCsvFileLoad())
  {
    ttlHelper.getLimit(testlimit.testname, testlimit.frequencyLimit);
  }
      
  testlimit.isLimitTableUsed = ttlHelper.isAllInTable(); 

  //if not defined in test table, use testflow limit
  if(!testlimit.isLimitTableUsed)
  {
    testlimit.frequencyLimit = GET_LIMIT_OBJECT(testlimit.testname);
  } 
    
  //default is 'MHz' as same as parameter definition
  if (testlimit.frequencyLimit.unit().empty())
  {
    testlimit.frequencyLimit.unit("MHz");
  }
}
/**
 *-----------------------------------------------------------------------------
 * @Routine: doMeasurement
 *
 * @Purpose: execute measurement and store results
 *
 *-----------------------------------------------------------------------------
 * @Description:
 * 
 * @Parameters:
 *   INPUT:
 *        parameters--------------test parameters
 *   OUTPUT
 *        result------------------test result container
 *
 * @RETURN:
 * @NOTE:
 *  process steps:
 * |----------------|     |------------|       |-------------|
 * |    pattern     |     | transition |       |     data    |
 * |synchronization |---->|  search    |------>| acquisition |
 * |   (optional)   |     | (optional) |       |    (must)   |
 * |----------------|     |------------|       |-------------|
 *                                                    |
 *         -------------------------------------------|
 *         |
 * |----------------|     |---------------|       |-------------|
 * |      data      |     |      data     |       |     post    |
 * |     process    |---->|  acquisition  |------>|   process   |
 * |(mean of jitter)|     |(function test)|       | (frequency) |
 * |----------------|     |---------------|       |-------------|
 * 
 *-----------------------------------------------------------------------------
 */
void
JitterStardustUtil::doMeasurement(
  const JitterStardustParameter & parameters,
  JitterStardustResult& results)
{
  ON_FIRST_INVOCATION_BEGIN();
    results.init();
    CONNECT();
    FW_TASK("SQGB ACQF,0;");
  ON_FIRST_INVOCATION_END();

  const JitterUtil::JitterParameter& commonParameter = parameters.commonParameter;
  // autoSync
  if(commonParameter.autoSyncMode == JitterUtil::AUTOSYNC_ON || 
     commonParameter.autoSyncMode == JitterUtil::AUTOSYNC_ON_KEEP_VALUE)
  { 
    bool isEveryPinOfAllSitesFail = false;
    JitterUtil::autoSync(parameters.commonParameter,
                         results.jitterResult,
                         isEveryPinOfAllSitesFail);
    if(isEveryPinOfAllSitesFail)
    {
      return;
    }
  }
  // transition search
  if(commonParameter.transitionSearchMode == JitterUtil::TRANSITIONSEARCH_ON)
  {
    bool isEveryPinOfAllSitesFail = false;
    JitterUtil::transitionSearch(parameters.commonParameter,
                                 results.jitterResult,
                                 isEveryPinOfAllSitesFail);
    if(isEveryPinOfAllSitesFail)
    {
      return;
    }
  }
  //data acquisition
  JitterUtil::dataAcquire(parameters.commonParameter,results.jitterResult);
 
  // pre-process data and get error density signal data.
  ON_FIRST_INVOCATION_BEGIN();
    histogramCalculation(parameters,results);
    
    getErrorDensitySignalData(parameters,results);
  ON_FIRST_INVOCATION_END();
  
  //post process: calculation 
  if(parameters.commonParameter.transition == JitterUtil::LEFT ||
     parameters.commonParameter.transition == JitterUtil::BOTH)
  {
    updateErrorDensityResult(parameters,true,results);
  }
  if(parameters.commonParameter.transition == JitterUtil::RIGHT ||
     parameters.commonParameter.transition == JitterUtil::BOTH)
  {
    updateErrorDensityResult(parameters,false,results);
  }
  stardustCalculation(parameters,results);

  // apply pattern synchronization value 
  ON_FIRST_INVOCATION_BEGIN();
    if(commonParameter.autoSyncMode == JitterUtil::AUTOSYNC_ON_KEEP_VALUE)
    {
      applyPatternSyncValue(parameters,results);
    }
  ON_FIRST_INVOCATION_END();
}

/**
 *-----------------------------------------------------------------------------
 *@Routing: getErrorDensitySignalData
 *
 *@Purpose: get the pass and fail sequence
 *
 *-----------------------------------------------------------------------------
 *@Description:
 *  The idea behind stardust measurement is to place the strobe in the center 
 *  of a signal transition.
 *  The center of the signal transition corresponds to the mean value of the 
 *  histogram over the signal transition. 
 *  So the compare strobe will be placed at the mean value and one functional
 *  test will be executed using the Global Sequencer in the Edge origented mode.
 *  After the functional test, the detail error map will be evaluated, thus
 *  we can get pass/fail sequence.
 * 
 *@Parameters:
 *  INPUT:
 *      parameters---------test parameters
 *  INPUT and OUTPUT:
 *      results------------test result container
 *Return:
 *-----------------------------------------------------------------------------
 */
void
JitterStardustUtil::getErrorDensitySignalData(
  const JitterStardustParameter& parameters,
  JitterStardustResult& results)
{
  const JitterUtil::JitterParameter& commonParameter = 
                                                    parameters.commonParameter;
  if(commonParameter.transition == JitterUtil::LEFT ||
     commonParameter.transition == JitterUtil::BOTH)
  {
    ostringstream fwStream;
    applyCrossoverOffset(parameters,true,results,fwStream);
    applyErrorMapSetupAndRunFuncTest(parameters,fwStream);
  } 
  
     
  if(commonParameter.transition == JitterUtil::RIGHT ||
     commonParameter.transition == JitterUtil::BOTH)
  {
    ostringstream fwStream;
    applyCrossoverOffset(parameters,false,results,fwStream);
    applyErrorMapSetupAndRunFuncTest(parameters,fwStream);
  } 
}

/**
 *-----------------------------------------------------------------------------
 *@Routing: applyErrorMapSetupAndRunFuncTest
 *
 *@Purpose: apply error map setup and run functional test
 *
 *-----------------------------------------------------------------------------
 *@Description:
 *  apply startCycle and maxCycles for error map setup 
 *@Parameters: 
 *    INPUT:
 *       parameters-------test parameters
 *       fwStream---------firmware stream include: 1.set crossover offset value
 *                                                 2.set up error map mode 
 *
 *@Return:
 *-----------------------------------------------------------------------------
 */
void
JitterStardustUtil::applyErrorMapSetupAndRunFuncTest
  (const JitterStardustParameter& parameters,
   ostringstream& fwStream)
{
  //set up error map mode
  STRING restoredString;
  STRING portName = parameters.commonParameter.portName;
  if(parameters.commonParameter.portName.empty())
  {
    portName = "@";
  }
  fwStream << "CYRM EDGE,,(@);";
  fwStream << "DCRM? EMAP, (@@);";
  fwStream << "DCRM EMAP,8,PF,(" << portName << ");";
  fwStream << "DCGM FAIL,STRT,NONE;";
  fwStream << "DCRP " << parameters.errorMapStartCycle <<",("
           << portName << ");";

  FW_TASK(fwStream.str(), restoredString);

  //run functional test and resotre error map mode
  ostringstream funcTestAndErrorMapRestoreFW;
  funcTestAndErrorMapRestoreFW << "FTST?;" << restoredString.c_str();
  FW_TASK(funcTestAndErrorMapRestoreFW.str());
}

/**
 *-----------------------------------------------------------------------------
 *@Routing: updateErrorDensityResult
 *
 *@Purpose: update result data for get error density signal
 *
 *-----------------------------------------------------------------------------
 *@Description:
 *  get detail error map data after function test 
 *@Parameters: 
 *    INPUT:
 *       parameters----------------------------test parameters
 *       isLeft--------------------------------is left side?
 *    INPUT and OUTPUT:
 *       results-------------------------------test result container
 *
 *@Return:
 *-----------------------------------------------------------------------------
 */
void
JitterStardustUtil::updateErrorDensityResult(
  const JitterStardustParameter& parameters,
  const Boolean isLeft,
  JitterStardustResult& results)
{
  const INT BLOCK_FIRST_CYCLE = 8;
  const INT BLOCK_HEAD_LENGTH = 12;
  const INT BITS_PER_CYCLE = 8;
  const JitterUtil::JitterParameter& commonParameter = parameters.commonParameter;
  JitterUtil::JitterResult& commonResult = results.jitterResult;
 
  ostringstream fsString;
  STRING pinlist,answer;
  pinlist.clear();
  answer.clear();
  Boolean isFirst = true;
  INT siteNum = CURRENT_SITE_NUMBER();
  STRING_VECTOR::const_iterator it = commonParameter.PinVector.begin();
  STRING_VECTOR::const_iterator it_end = commonParameter.PinVector.end();
  for(; it != it_end; ++it) 
  {
    if(commonResult.commonResultMap[siteNum][*it].lastStatus == JitterUtil::LEFT_JITTER ||
       commonResult.commonResultMap[siteNum][*it].lastStatus == JitterUtil::BOTH_JITTER ||
       commonResult.commonResultMap[siteNum][*it].lastStatus == JitterUtil::RIGHT_JITTER)
    {
      if(isFirst)
      {
        pinlist += *it;
        isFirst = false;
      }
      else
      {
        pinlist = pinlist + "," + *it;
      }
    }
  }
  fsString << "EMAP? PPIN," << parameters.errorMapStartCycle
           << "," << parameters.acquisitionDepth << ",EDGE,8,PF,ALL,BYTE,,("
           << pinlist << ")";
  FW_TASK(fsString.str(),answer);

  /*
   *the firmware answer like:
   * EMAP PPIN,2000,1024,EDGE,8,PF,ALL,BYTE,,(TX_1P),#9000001036$@!%
   * EMAP PPIN,2000,1024,EDGE,8,PF,ALL,BYTE,,(TX_2P),#9000001056$@!%
   *                                                            ----
   *that means binary data for data stream.
   */
  string::size_type oldPos = 0, newPos = 0;
  while((oldPos = answer.find('(',oldPos)) != STRING::npos)
  {
    newPos = answer.find(')',oldPos);
    STRING pinName = answer.substr(oldPos + 1,newPos - oldPos - 1);
    oldPos = answer.find('#',oldPos);
    char* pPos = const_cast<char*>(answer.c_str()) + oldPos;
    INT digitalN = *(++pPos) - '0'; 
    pPos = pPos + digitalN + 1 + BLOCK_FIRST_CYCLE;
    /**
     *the data stream block size is 4 bytes. because Linux is litter-endian
     *encoded. so we change the byte sequence to get the data stream block
     *size. 
     */
    for(int i = 0; i < 2; i++)
    {
      char cSwap = *(pPos + i);
      *(pPos + i) = *(pPos + (4 -i -1));
      *(pPos + (4 -i -1)) = cSwap;
    } 
    /**
     *char type data accounts 1 byte in memory, but integer type data 
     *accouts 4 bytes in memory, so we can using the following trick
     *to get data stream block size.
     */ 
    INT *dataCount = reinterpret_cast<INT *>(pPos);

    //process result block
    size_t dataBlockIndex = oldPos + 2 + digitalN + BLOCK_HEAD_LENGTH;
    for(INT loop = 0; loop < *dataCount; ++loop)
    {
      unsigned char chEdge = 
             static_cast<unsigned char>(answer[dataBlockIndex + loop]);
      for(INT bit = 0; bit < BITS_PER_CYCLE; ++bit)
      {
        if(isLeft)
        {
          if(chEdge & 0x80)
          {
            results.resultMap[siteNum][pinName].leftPFData.push_back(1);
          }
          else
          {
            results.resultMap[siteNum][pinName].leftPFData.push_back(-1);
          }
        }//for left
        else
        {
          if(chEdge & 0x80)
          {
            results.resultMap[siteNum][pinName].rightPFData.push_back(1);
          }
          else
          {
            results.resultMap[siteNum][pinName].rightPFData.push_back(-1);
          }
        }// for right
        chEdge <<=1;
      }//for every cycle
    }// for every pin
  }
}

/**
 *-----------------------------------------------------------------------------
 *@Routing: stardustCalculation
 *
 *@Purpose: calculate stardust value of every pin of every site
 *
 *-----------------------------------------------------------------------------
 *@Description:
 *  the function calculate the stardust value according to the testing
 *  result(pass/fail sequence data).
 *@Parameters: 
 *    INPUT:
 *      parameters---------test parameters
 *    INPUT and OUTPUT
 *      results------------test result container
 *@Return:
 *-----------------------------------------------------------------------------
 */
void
JitterStardustUtil::stardustCalculation(
  const JitterStardustParameter& parameters,
  JitterStardustResult& results)
{
  const JitterUtil::JitterParameter& commonParameter = parameters.commonParameter;
  JitterUtil::JitterResult& commonResult = results.jitterResult;
  INT siteNum = CURRENT_SITE_NUMBER();

  map<INT, map<STRING,JitterUtil::CommonResultData> >::const_iterator site_it;
  map<STRING,JitterUtil::CommonResultData>::const_iterator pin_it;
  
  //left side
  if(commonParameter.transition == JitterUtil::LEFT || 
     commonParameter.transition == JitterUtil::BOTH)
  {
    site_it = commonResult.commonResultMap.find(siteNum);
    if(site_it != commonResult.commonResultMap.end())
    {
      for(pin_it = site_it->second.begin();
          pin_it != site_it->second.end();++pin_it)//for every pin
      {
        if(pin_it->second.lastStatus == JitterUtil::LEFT_JITTER || 
           pin_it->second.lastStatus == JitterUtil::BOTH_JITTER)
        {
          DSP_JITTER_STARDUST(
            results.resultMap[site_it->first][pin_it->first].leftPFData,
            commonParameter.UI_width_ns,
            results.resultMap[site_it->first][pin_it->first].leftSpectrumAmplitude,
            results.resultMap[site_it->first][pin_it->first].leftFrequency,
            parameters.FFTWindow);
        }//end if for separation calculation
      }//end for every pin
    }//end for every site
  }//end if for left

  //right side
  if(commonParameter.transition == JitterUtil::RIGHT || 
     commonParameter.transition == JitterUtil::BOTH)
  {
    site_it = commonResult.commonResultMap.find(siteNum);
    if(site_it != commonResult.commonResultMap.end())
    {
      for(pin_it = site_it->second.begin();
          pin_it != site_it->second.end();++pin_it)//for every pin
      {
        if(pin_it->second.lastStatus == JitterUtil::RIGHT_JITTER || 
           pin_it->second.lastStatus == JitterUtil::BOTH_JITTER)
        {
          DSP_JITTER_STARDUST(
            results.resultMap[site_it->first][pin_it->first].rightPFData,
            commonParameter.UI_width_ns,
            results.resultMap[site_it->first][pin_it->first].rightSpectrumAmplitude,
            results.resultMap[site_it->first][pin_it->first].rightFrequency,
            parameters.FFTWindow);
        }//end if for separation calculation
      }//end for every pin
    }//end for every site
  }//end if for right side
}

/**
 *-----------------------------------------------------------------------------
 *@Routing: histogramCalculation
 *
 *@Purpose: calculate histogram value of every pin of every site
 *
 *-----------------------------------------------------------------------------
 *@Description:
 *  the function calculate the histogram value according to the testing
 *  result(error count).
 *@Parameters: 
 *    INPUT:
 *      parameters---------test parameters
 *    INPUT and OUTPUT:
 *      results------------test result container
 *@Return:
 *-----------------------------------------------------------------------------
 */
void
JitterStardustUtil::histogramCalculation(
  const JitterStardustParameter& parameters,
  JitterStardustResult& results)
{
  const JitterUtil::JitterParameter& commonParameter = parameters.commonParameter;
  JitterUtil::JitterResult& commonResult = results.jitterResult;

  map<INT, map<STRING,JitterUtil::CommonResultData> >::const_iterator site_it;
  map<STRING,JitterUtil::CommonResultData>::const_iterator pin_it;
  
  //left side
  if(commonParameter.transition == JitterUtil::LEFT || 
     commonParameter.transition == JitterUtil::BOTH)
  {
    for(site_it = commonResult.commonResultMap.begin();
        site_it != commonResult.commonResultMap.end();
        ++site_it)//for every site
    {
      for(pin_it = site_it->second.begin();
          pin_it != site_it->second.end();++pin_it)//for every pin
      {
        if(pin_it->second.lastStatus == JitterUtil::LEFT_JITTER || 
           pin_it->second.lastStatus == JitterUtil::BOTH_JITTER)
        {
          DOUBLE startValue = 0.0;
          if(commonParameter.transitionSearchMode == JitterUtil::TRANSITIONSEARCH_ON)
          {
            startValue = 
              commonResult.commonResultMap[site_it->first][pin_it->first].leftTransitionVal;
          }
          else if(commonParameter.autoSyncMode == JitterUtil::AUTOSYNC_ON || 
                  commonParameter.autoSyncMode == JitterUtil::AUTOSYNC_ON_KEEP_VALUE)
          {
            startValue = 
              commonResult.commonResultMap[site_it->first][pin_it->first].autoSyncVal;
          }
          else
          {
            startValue = commonParameter.start_ns;
          }
          DSP_JITTER_HISTOGRAM(
            pin_it->second.leftErrorCount,
            startValue,
            -commonParameter.dataAcquStepWidth_ns,
            results.resultMap[site_it->first][pin_it->first].leftHistogramData,
            results.resultMap[site_it->first][pin_it->first].leftHistogram,true);
        }//end if for jitter calculation
      }//end for every pin
    }//end for every site
  }//end if for left

  //right side
  if(commonParameter.transition == JitterUtil::RIGHT || 
     commonParameter.transition == JitterUtil::BOTH)
  {
    for(site_it = commonResult.commonResultMap.begin();
        site_it != commonResult.commonResultMap.end();
        ++site_it)//for every site
    {
      for(pin_it = site_it->second.begin();
          pin_it != site_it->second.end();++pin_it)//for every pin
      {
        if(pin_it->second.lastStatus == JitterUtil::RIGHT_JITTER || 
           pin_it->second.lastStatus == JitterUtil::BOTH_JITTER)
        {
          DOUBLE startValue = 0.0;
          if(commonParameter.transitionSearchMode == JitterUtil::TRANSITIONSEARCH_ON)
          {
            startValue = 
              commonResult.commonResultMap[site_it->first][pin_it->first].rightTransitionVal;
          }
          else if(commonParameter.autoSyncMode == JitterUtil::AUTOSYNC_ON || 
                  commonParameter.autoSyncMode == JitterUtil::AUTOSYNC_ON_KEEP_VALUE)
          {
            startValue = 
              commonResult.commonResultMap[site_it->first][pin_it->first].autoSyncVal;
          }
          else
          {
            startValue = commonParameter.start_ns;
          }
          DSP_JITTER_HISTOGRAM(
            pin_it->second.rightErrorCount,
            startValue,
            commonParameter.dataAcquStepWidth_ns,
            results.resultMap[site_it->first][pin_it->first].rightHistogramData,
            results.resultMap[site_it->first][pin_it->first].rightHistogram,true);
        }//end if for jitter calculation
      }//end for every pin
    }//end for every site
  }//end if for right side
}

/**
 *-----------------------------------------------------------------------------
 *@Routine: applyCrossoverOffset
 *
 *@Purpose: place the strobe in the center of a signal transition 
 *
 *-----------------------------------------------------------------------------
 *@Description:
 *  The center of the signal transition corresponds to the mean value of the 
 *  histogram over the signal transition. 
 *  This function will place the compare strobe at the mean of the histogram. 
 *@Parameters:
 *     INPUT:
 *       parameters-----test parameters
 *       isLeft---------lest side? or right side
 *       results--------result container
 *     OUTPUT:
 *       fwStream-------firmware stream includes: set crossover offset value
 *@RETURN:
 *-----------------------------------------------------------------------------
 */
void
JitterStardustUtil::applyCrossoverOffset(
  const JitterStardustParameter& parameters,
  const Boolean isLeft,
  JitterStardustResult& results,
  ostringstream& fwStream)
{
  const JitterUtil::JitterParameter& commonParameter = parameters.commonParameter;
  JitterUtil::JitterResult& commonResult = results.jitterResult;

  // firmware stream
  Boolean isEveryPinOfAllSitesFail = true;
  FOR_EACH_SITE_BEGIN();
    INT siteNum = CURRENT_SITE_NUMBER();
    Boolean isFirst = true;
    STRING_VECTOR::const_iterator it = commonParameter.PinVector.begin();
    STRING_VECTOR::const_iterator it_end = commonParameter.PinVector.end();
    for(;it != it_end;++it)
    {
      /**
       * if the last status of this pin indicate that this pin has done jitter histogrom,
       * which means this pin can do stardust test.
       */  
      if(commonResult.commonResultMap[siteNum][*it].lastStatus == JitterUtil::LEFT_JITTER ||
         commonResult.commonResultMap[siteNum][*it].lastStatus == JitterUtil::BOTH_JITTER ||
         commonResult.commonResultMap[siteNum][*it].lastStatus == JitterUtil::RIGHT_JITTER)
      {
        if(isFirst)
        {
          isFirst = false;
          fwStream << "PSFC " << siteNum << ";";
        }
        isEveryPinOfAllSitesFail = false;
        fwStream << "SHSP TIM," << "\"" << *it << "_" 
                 << commonParameter.specName_postfix;
        if((!commonParameter.portName.empty()) && commonParameter.portName != "@")
        {
          fwStream << "@" << commonParameter.portName;
        }
        fwStream << "\",(" << *it << "),,,;SHVL ";
        if(isLeft)
        {
          fwStream << results.resultMap[siteNum][*it].leftHistogram.mean << ",;";
        }
        else
        {
          fwStream << results.resultMap[siteNum][*it].rightHistogram.mean <<",;";
        }
      }
    }//end for every pin of one site
  FOR_EACH_SITE_END();
  if(!isEveryPinOfAllSitesFail)
  {
    fwStream << "PSFC ALL\n";
  }
}

/**
 *-----------------------------------------------------------------------------
 *@Routine: applyPatternSyncValue
 *
 *@Purpose: keep synchronization value
 *
 *-----------------------------------------------------------------------------
 *@Description:
 * if user sets the autoSyncMode parameter to ON_KEEP_VALUE, then the
 * synchronization value of the test pin will be keeped for the following
 * test suites.
 *
 *@Parameters:
 *    INPUT:
 *       Parameters------------test parameters
 *       results---------------result container
 *@RETURN:
 *-----------------------------------------------------------------------------
 */
void
JitterStardustUtil::applyPatternSyncValue(
  const JitterStardustParameter& parameters,
  JitterStardustResult& results)
{
  const JitterUtil::JitterParameter& commonParameter = parameters.commonParameter;
  JitterUtil::JitterResult commonResult = results.jitterResult;

  // firmware stream
  ostringstream fsString;
  Boolean isEveryPinOfAllSitesFail = true;
  FOR_EACH_SITE_BEGIN();
    INT siteNum = CURRENT_SITE_NUMBER();
    Boolean isFirst = true;
    STRING_VECTOR::const_iterator it = commonParameter.PinVector.begin();
    STRING_VECTOR::const_iterator it_end = commonParameter.PinVector.end();
    for(;it != it_end;++it)
    {
      // autoSync pass, so we can apply the synchronization value to the
      // followig test suites.
      if(commonResult.commonResultMap[siteNum][*it].lastStatus != JitterUtil::AUTOSYNC_FAIL)
      {
        if(isFirst)
        {
          isFirst = false;
          fsString << "PSFC " << siteNum << ";";
        }
        isEveryPinOfAllSitesFail = false;
        fsString << "SHSP TIM," << "\"" << *it << "_" 
                 << commonParameter.specName_postfix;
        if((!commonParameter.portName.empty()) && commonParameter.portName != "@")
        {
          fsString << "@" << commonParameter.portName;
        }
        fsString << "\",(" << *it << "),,,;SHVL ";
        if(commonParameter.transition == JitterUtil::LEFT)
        {
          fsString << results.resultMap[siteNum][*it].leftHistogram.mean +
                      0.5 * commonParameter.UI_width_ns << ",;";
        }
        else // for right or both sides
        {
          fsString << results.resultMap[siteNum][*it].rightHistogram.mean -
                      0.5 * commonParameter.UI_width_ns << ",;"; 
        }
      }
    }//end for every pin of one site
  FOR_EACH_SITE_END();
  if(!isEveryPinOfAllSitesFail)
  {
    fsString << "PSFC ALL\n";
    //download and execute firmware command
    FW_TASK(fsString.str());
  }
}

/**
 *-----------------------------------------------------------------------------
 * @Routine: judgeAndDatalog
 *
 * @Purpose: judge and put result into event datalog stream
 *
 *-----------------------------------------------------------------------------
 * @Description:
 *    judge result of 'results' with pass limit form 'testlimit'
 *
 * @Parameters:
 *   INPUT:  param---------------test parameters
 *           testLimit-----------test limit container
 *           result--------------result container
 *
 * @RETURN:
 *-----------------------------------------------------------------------------
 */
void
JitterStardustUtil::judgeAndDatalog(
  const JitterStardustParameter& parameters,
  const JitterStardustResult& results,
  const JitterStardustLimit & testlimit)
{
  const JitterUtil::JitterParameter& 
    commonParameter = parameters.commonParameter;
  INT siteNum = CURRENT_SITE_NUMBER();

  double factor = 1.0; 

  ARRAY_D leftFrequencyValues(commonParameter.PinVector.size());
  ARRAY_D rightFrequencyValues(commonParameter.PinVector.size());

  STRING_VECTOR::const_iterator it = commonParameter.PinVector.begin();
  STRING_VECTOR::const_iterator it_end = commonParameter.PinVector.end();
  int pinIndex = 0;
  for(;it != it_end; ++it, ++pinIndex)
  {
    map<INT,map<STRING,ResultData> > ::const_iterator site_it;
    map<STRING,ResultData>::const_iterator pin_it;
    site_it = results.resultMap.find(siteNum);
    // because setup error or other error, there is no result for this site.
    if(site_it == results.resultMap.end())
    {
      STRING api = "JitterStardustUtil::judgeAndDatalog: ";
      STRING msg = "These is no result for this site.";
      throw Error(api.c_str(),msg.c_str(),api.c_str());
    }
    pin_it = site_it->second.find(*it);
    // because setup error or other error, there is no result for this site.
    if(pin_it == site_it->second.end())
    {
      STRING api = "JitterStardustUtil::judgeAndDatalog: ";
      STRING msg = "These is no result for this pin.";
      throw Error(api.c_str(),msg.c_str(),api.c_str());
    }

    JitterUtil::JitterResult commonResult = 
      const_cast<JitterUtil::JitterResult&>(results.jitterResult);   
    switch(commonResult.commonResultMap[siteNum][*it].lastStatus)
    {
      case JitterUtil::LEFT_JITTER:
        leftFrequencyValues[pinIndex] = pin_it->second.leftFrequency[0] * factor;
        break;
      case JitterUtil::RIGHT_JITTER:
        rightFrequencyValues[pinIndex] = pin_it->second.rightFrequency[0] * factor;
        break;
      case JitterUtil::BOTH_JITTER:
        leftFrequencyValues[pinIndex] = pin_it->second.leftFrequency[0] * factor;
        rightFrequencyValues[pinIndex] = pin_it->second.rightFrequency[0] * factor;
        break;
      case JitterUtil::AUTOSYNC_FAIL:
      case JitterUtil::LEFT_TRANSITION_FAIL:
      case JitterUtil::RIGHT_TRANSITION_FAIL:
      case JitterUtil::BOTH_TRANSITION_FAIL:
      default:
        leftFrequencyValues[pinIndex] = NAN;
        rightFrequencyValues[pinIndex] = NAN;
        break;
    }//end for switch
  }//end for pinlist

  //MPR log
  if (testlimit.isLimitTableUsed) //limit table way
  {
    switch(commonParameter.transition)
    {
      case JitterUtil::LEFT:
        TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
          testlimit.testname, V93kLimits::tmLimits, leftFrequencyValues);
        break;
      case JitterUtil::RIGHT:
        TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
          testlimit.testname, V93kLimits::tmLimits, rightFrequencyValues);
        break;
      case JitterUtil::BOTH:
        TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
          testlimit.testname, V93kLimits::tmLimits, leftFrequencyValues);
        TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
          testlimit.testname, V93kLimits::tmLimits, rightFrequencyValues);
        break;
      default:
        break;
    }
  }
  else // testflow limit way
  {
    switch(commonParameter.transition)
    {
      case JitterUtil::LEFT:
        TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
          testlimit.testname, testlimit.frequencyLimit, leftFrequencyValues);
        break;
      case JitterUtil::RIGHT:
        TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
          testlimit.testname, testlimit.frequencyLimit, rightFrequencyValues);
        break;
      case JitterUtil::BOTH:
        TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
          testlimit.testname, testlimit.frequencyLimit, leftFrequencyValues);
        TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
          testlimit.testname, testlimit.frequencyLimit, rightFrequencyValues);
        break;
      default:
        break;
    }
  }
}

/**
 *-----------------------------------------------------------------------------
 * @Routine: reportToUI
 *
 * @Purpose: output result to ui_report window
 *
 *-----------------------------------------------------------------------------
 * @Description:
 *   display:
 *       a) summary,just give the summary test result in ui_report
 *       b) detail,will give error count plot and stardust curve
 *       c) analysis,you can get stardust curve in signal analyzer
 *  @Parameters:
 *     INPUT:
 *        parameters---------------test parameters
 *        results------------------result container
 *        output-------------------"NONE" or "ReportUI"
 *  @RETURN:
 * 
 *  @Note:
 *   In every mode of the three display modes, you can get spectrum amplitude
 *   and frequency value in ui_report window.
 *-----------------------------------------------------------------------------
 */ 
void
JitterStardustUtil::reportToUI(
  const JitterStardustParameter& parameters,
  const JitterStardustResult& results,
  const STRING & output)
{
  if(output == "NONE")
  {
    return;
  }

  const JitterUtil::JitterParameter& commonParameter = 
                                                   parameters.commonParameter;

  STRING_VECTOR::const_iterator it = commonParameter.PinVector.begin();
  STRING_VECTOR::const_iterator it_end = commonParameter.PinVector.end();
  INT siteNum = CURRENT_SITE_NUMBER();

  map<INT,map<STRING,ResultData > > ::const_iterator site_it;
  map<STRING,ResultData >::const_iterator pin_it;

  if (commonParameter.outputMode == JitterUtil::OUTPUT_SUMMARY)// summary mode
  {
    cout << "Jitter Test Summary:   " <<endl;
    cout << "site:                  " << siteNum << endl;
    for(;it != it_end; ++it)
    {
      site_it = results.resultMap.find(siteNum);
      // because setup error or other error, there is no result for this site.
      if(site_it == results.resultMap.end())
      {
        cout<<"Warning::There is no result fot this site: " 
            << siteNum <<endl;
        continue;
      }      
      pin_it = site_it->second.find(*it);
      //because setup error or other errors,thers is no result for this pin.
      if(pin_it == site_it->second.end())
      {
        cout<<"Warning::There is no result for this pin: " << *it
            <<"in site: " << siteNum <<endl;
        continue;
      }            
      // normal case
      JitterUtil::JitterResult commonResult = 
        const_cast<JitterUtil::JitterResult&>(results.jitterResult);
      switch(commonResult.commonResultMap[siteNum][*it].lastStatus)
      {
        case JitterUtil::LEFT_JITTER:
          cout << "Pins:                    " << *it <<endl
               << "Left Stardust Result:    " << endl;
          printStardustValue(pin_it->second.leftSpectrumAmplitude,
                             pin_it->second.leftFrequency);
          break;
        case JitterUtil::RIGHT_JITTER:
          cout << "Pins:                    " << *it <<endl
               << "Right Stardust Result:   " << endl;
          printStardustValue(pin_it->second.rightSpectrumAmplitude,
                             pin_it->second.rightFrequency);
          break;
        case JitterUtil::BOTH_JITTER:
          cout << "Pins:                    " << *it <<endl
               << "Left Stardust Result:    " << endl;
          printStardustValue(pin_it->second.leftSpectrumAmplitude,
                             pin_it->second.leftFrequency);
          cout << "Right Stardust Result:   " << endl;
          printStardustValue(pin_it->second.rightSpectrumAmplitude,
                             pin_it->second.rightFrequency);
          break;
        case JitterUtil::AUTOSYNC_FAIL:
          JitterUtil::printWaringMessage(siteNum,*it);
          cout << "There is no pass pattern!" << endl;
          break;
        case JitterUtil::LEFT_TRANSITION_FAIL:
          JitterUtil::printWaringMessage(siteNum,*it);
          cout << "There is no transition on left!" << endl;
          break;
        case JitterUtil::RIGHT_TRANSITION_FAIL:
          JitterUtil::printWaringMessage(siteNum,*it);
          cout << "There is no transition on right!" << endl;
          break;
        case JitterUtil::BOTH_TRANSITION_FAIL:
          JitterUtil::printWaringMessage(siteNum,*it);
          cout << "There is no transition for both sides!" << endl;
          break;
        default:
          throw Error("JitterStardustUtil::reportToUI",
                      "There is an unknown status for reportToUI!",
                      "JitterStardustUtil::reportToUI");
      }//end for switch
    }//end for pinlist
  }//end for summary mode
  else if (commonParameter.outputMode == JitterUtil::OUTPUT_DETAIL)//detail mode
  {
    cout << "JItter Test Detail:  " << endl;
    cout << "site:                " << siteNum <<endl;
    for(;it != it_end; ++it)
    {
      site_it = results.resultMap.find(siteNum);
      // because setup error or other error, there is no result for this site.
      if(site_it == results.resultMap.end())
      {
        cout<<"Warning::There is no result fot this site: " 
            << siteNum <<endl;
        continue;
      }    
      pin_it = site_it->second.find(*it);
      // because setup error or other error, there is no result for this pin.
      if(pin_it == site_it->second.end())
      {
        cout<<"Warning::There is no result for this pin: " << *it
            <<"in site: " << siteNum <<endl;
        continue;
      }      
      // normal case 
      JitterUtil::JitterResult commonResult = 
        const_cast<JitterUtil::JitterResult&>(results.jitterResult);
      switch(commonResult.commonResultMap[siteNum][*it].lastStatus)
      {
        case JitterUtil::LEFT_JITTER:
          cout << "Pins:                   " << *it << endl
               << "Left Stardust Result:   " <<endl;
          printStardustValue(pin_it->second.leftSpectrumAmplitude,
                             pin_it->second.leftFrequency);

          cout << "Left Stardust Curve:    " << endl;
          printStardustCurve(pin_it->second.leftSpectrumAmplitude,
                             pin_it->second.leftFrequency);
          break;
        case JitterUtil::RIGHT_JITTER:
          cout << "Pins:                   " << *it << endl
               << "Right Stardust Result:  " <<endl;
          printStardustValue(pin_it->second.rightSpectrumAmplitude,
                             pin_it->second.rightFrequency);

          cout << "Right Sardust Curve:    " << endl;
          printStardustCurve(pin_it->second.rightSpectrumAmplitude,
                             pin_it->second.rightFrequency);
          break;
        case JitterUtil::BOTH_JITTER:
          cout << "Pins:                            " << *it << endl
               << "Left Stardust Result:   " <<endl;
          printStardustValue(pin_it->second.leftSpectrumAmplitude,
                             pin_it->second.leftFrequency);

          cout << "Left Stardust Curve:    " << endl;
          printStardustCurve(pin_it->second.leftSpectrumAmplitude,
                             pin_it->second.leftFrequency);

          cout << "Right Stardust Result:  " <<endl;
          printStardustValue(pin_it->second.rightSpectrumAmplitude,
                             pin_it->second.rightFrequency);

          cout << "Right Sardust Curve:    " << endl;
          printStardustCurve(pin_it->second.rightSpectrumAmplitude,
                             pin_it->second.rightFrequency);
          break;	  	  	  
        case JitterUtil::AUTOSYNC_FAIL:
          JitterUtil::printWaringMessage(siteNum,*it);
          cout << "There is no pass pattern!" << endl;
          break;
        case JitterUtil::LEFT_TRANSITION_FAIL:
          JitterUtil::printWaringMessage(siteNum,*it);
          cout << "There is no transition on left!" << endl;
          break;
        case JitterUtil::RIGHT_TRANSITION_FAIL:
          JitterUtil::printWaringMessage(siteNum,*it);
          cout << "There is no transition on right!" << endl;
          break;
        case JitterUtil::BOTH_TRANSITION_FAIL:
          JitterUtil::printWaringMessage(siteNum,*it);
          cout << "There is no transition for both sides!" << endl;
          break;
        default:
          throw Error("JitterStardustUtil::reportToUI",
                      "There is an unknown status for reportToUI!",
                      "JitterStardustUtil::reportToUI");
      }
    }
  }
  else // analysis mode
  {
    cout << "Jitter Test Analysis:    " << endl;
    cout << "site       :             " << siteNum << endl;
    for(;it != it_end; ++it)
    {
      site_it = results.resultMap.find(siteNum);
      // because setup error or other error, there is no result for this site.
      if(site_it == results.resultMap.end())
      {
        cout<<"Warning::There is no result fot this site: " << siteNum <<endl;
        continue;
      }      
      pin_it = site_it->second.find(*it);
      // because setup error or other error, there is no result for this pin.
      if(pin_it == site_it->second.end())
      {
        cout<<"Warning::There is no result for this pin: " << *it
            <<"in site: " << siteNum <<endl;
        continue;
      }      

      // normal case
      JitterUtil::JitterResult commonResult = 
        const_cast<JitterUtil::JitterResult&>(results.jitterResult);
      switch(commonResult.commonResultMap[siteNum][*it].lastStatus)
      {
        case JitterUtil::LEFT_JITTER:
          {
            SCATTER_LOG stardustWaveLeft;
            prepareDataForAnalyzer(pin_it->first,
                                   pin_it->second.leftSpectrumAmplitude,
                                   pin_it->second.leftFrequency,
                                   stardustWaveLeft);
            PUT_DEBUG(*it,"LEFT STARDUST",stardustWaveLeft);
          }
          cout << "Pins:                   " << *it <<endl;
          cout << "Left Stardust Result:   " << endl;
          printStardustValue(pin_it->second.leftSpectrumAmplitude,
                             pin_it->second.leftFrequency);
          break;
        case JitterUtil::RIGHT_JITTER:
          {
            SCATTER_LOG stardustWaveRight;
            prepareDataForAnalyzer(pin_it->first,
                                   pin_it->second.rightSpectrumAmplitude,
                                   pin_it->second.rightFrequency,
                                   stardustWaveRight);
            PUT_DEBUG(*it,"RIGHT STARDUST",stardustWaveRight);
          }
          cout << "Pins:                   " << *it <<endl;
          cout << "Right Stardust Result:  " << endl;
          printStardustValue(pin_it->second.rightSpectrumAmplitude,
                             pin_it->second.rightFrequency);
          break;
        case JitterUtil::BOTH_JITTER:
          {
            SCATTER_LOG stardustWaveLeft;
            prepareDataForAnalyzer(pin_it->first,
                                   pin_it->second.leftSpectrumAmplitude,
                                   pin_it->second.leftFrequency,
                                   stardustWaveLeft);
            PUT_DEBUG(*it,"LEFT STARDUST",stardustWaveLeft);

            SCATTER_LOG stardustWaveRight;
            prepareDataForAnalyzer(pin_it->first,
                                   pin_it->second.rightSpectrumAmplitude,
                                   pin_it->second.rightFrequency,
                                   stardustWaveRight);
            PUT_DEBUG(*it,"RIGHT STARDUST",stardustWaveRight);
          }
          cout << "Pins:                   " << *it <<endl;
          cout << "Left Stardust Result:   " << endl;
          printStardustValue(pin_it->second.leftSpectrumAmplitude,
                             pin_it->second.leftFrequency);
          cout << "Right Stardust Result:  " << endl;
          printStardustValue(pin_it->second.rightSpectrumAmplitude,
                             pin_it->second.rightFrequency);
          break;
        case JitterUtil::AUTOSYNC_FAIL:
          JitterUtil::printWaringMessage(siteNum,*it);
          cout << ", there is no pass pattern!" << endl;
          break;
        case JitterUtil::LEFT_TRANSITION_FAIL:    
          JitterUtil::printWaringMessage(siteNum,*it);
          cout << "There is no transition on left!" << endl;
          break;
        case JitterUtil::RIGHT_TRANSITION_FAIL:
          JitterUtil::printWaringMessage(siteNum,*it);
          cout << "Tthere is no transition on right!" << endl;
          break;
        case JitterUtil::BOTH_TRANSITION_FAIL:
          JitterUtil::printWaringMessage(siteNum,*it);
          cout << "There is no transition for both sides!" << endl;
          break;
        default:
          throw Error("JitterStardustUtil::reportToUI",
                      "There is an unknown status for reportToUI!",
                      "JitterStardustUtil::reportToUI");
      }
    }
  }
}

/**
 *-----------------------------------------------------------------------------
 *@Routine: JitterStardustUtil::printStardustCurve
 *
 *@Purpose: print stardust curve to ui_report window
 *-----------------------------------------------------------------------------
 *@Parameters:
 *  spectrumAmp--------------spectrum amplitude
 *  frequency----------------frequency sequence
 * 
 *@Return:
 *-----------------------------------------------------------------------------
 */
void
JitterStardustUtil::printStardustCurve(const vector<DOUBLE>& spectrumAmp,
                                       const vector<DOUBLE>& frequency)
{
  unsigned int row = 32;
  if(row > spectrumAmp.size())
  {
    row = spectrumAmp.size();
  }

  //every line can out put 80 "*" most
  for(unsigned int index = 0;index < row; ++index)
  {
    DOUBLE reference = 0.0;
    if(spectrumAmp[0] != 0)
    {
      reference = spectrumAmp[index]/spectrumAmp[0];
    }
    INT bar = static_cast<INT>(reference *80);
    for(INT i=0;i < bar;++i)
    {
      cout << "*";
    }
    cout << endl;
  }
}

/**
 *-----------------------------------------------------------------------------
 *@Routine: JitterStardustUtil::printStardustValue
 *
 *@Purpose: print stardust value result to ui_report window
 *-----------------------------------------------------------------------------
 *@Parameters:
 *  spectrumAmp---------------spectrum amplitude
 *  frequency-----------------frequency sequence
 * 
 *@Return:
 *-----------------------------------------------------------------------------
 */
void
JitterStardustUtil::printStardustValue(const vector<DOUBLE>& spectrumAmp,
                                       const vector<DOUBLE>& frequency)
{
  unsigned int rowCounts = 20;
  if(rowCounts > spectrumAmp.size())
  {
    rowCounts = spectrumAmp.size();
  }
  cout << "The top " << rowCounts 
       << " spectrum amplitude and relevant frequency:"
       << endl;
  cout << setw(10) << "Number"
       << setw(25) << "spectrum amplitude"
       << setw(25) << "frequency[MHz]"
       << endl;
  for (unsigned int loop = 0; loop < rowCounts ; ++loop)
  {
    cout << setw(10) << loop
         << setw(25) << spectrumAmp[loop]
         << setw(20) << frequency[loop] * 1000 <<"[MHz]"
         << endl;
  }
}

/**
 *-----------------------------------------------------------------------------
 *@Routine: JitterStardustUtil::prepareDataForAnalyzer
 *
 *@Purpose: parepare specturm amplitude and frequency 
 *          sequence data for outputing to signal analyzer
 *-----------------------------------------------------------------------------
 *@Parameters:
 *  INPUT:
 *    pinName-------------------pin name
 *    spectrumAmp---------------spectrum amplitude
 *    frequency-----------------frequency sequence
 *  OUTPUT:
 *    dataForAnalyzer-----------specturm amplitude and frequency sequence data
 *                              for outputing to signal analyzer
 *@Return:
 *-----------------------------------------------------------------------------
 */

void
JitterStardustUtil::prepareDataForAnalyzer(
  const STRING & pinName,
  const vector<DOUBLE>& spectrumAmp,
  const vector<DOUBLE>& frequency,
  SCATTER_LOG& dataForAnalyzer)
{
  unsigned int sizeOfArray = 32;
  if( sizeOfArray > spectrumAmp.size())
  {
    sizeOfArray = spectrumAmp.size();
  }
  ARRAY_D spectrumArray(sizeOfArray);
  ARRAY_D frequencyArray(sizeOfArray);
  for(unsigned int loop =0;loop < sizeOfArray;loop++)
  {
    spectrumArray[loop] = spectrumAmp[loop];
    frequencyArray[loop] = frequency[loop];
  }
  dataForAnalyzer.xAxis(frequencyArray);
  dataForAnalyzer.xTitle("Frequency");
  dataForAnalyzer.xUnit("GHz");
  dataForAnalyzer.yAxis(spectrumArray);
  dataForAnalyzer.yTitle(pinName + " Stardust Data");
  dataForAnalyzer.yUnit("amplitude");
}
#endif /*INCLUDE_JITTERHISTOGRAM_H*/
