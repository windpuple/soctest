/**
 * (c) Copyright 2011, Verigy Technologies, all rights reserved.
 *
 * Modification History:
 *
 *
 */

//for testmethod framework interfaces
#include "testmethod.hpp"
//for testmethod API interfaces
#include "mapi.hpp"

#include "SpecSearchUtil.hpp"
/**
 *----------------------------------------------------------------------*
 * @Testmethod Class: SpecSearch
 *
 * @Purpose: spec search function                                                               
 *
 *----------------------------------------------------------------------*
 * @Description:                                          
 *
 * @Parameters:  1. testmethod::SpecVariable& spec :
 *                  specifies the spec's name, unit and type{TIM:LEV} 
 *                  this parameter's format like:
 *                          "LEV.1.fooSpec[mV]", or "TIM.3.barSpec@port1[A]"
 *                  type             "LEV"     ,       "TIM"
 *                  equationSetId    "1"       ,       "3"
 *                  name             "fooSpec" ,       "barSpec@port1"
 *                  unit             "mV"      ,       "A"
 *               2. string setupPinlist : optional {@|pinlist}
 *                  Define a list of pins/pin groups the spec is shifted for.
 *                  valid type : I,O,IO,DPS                                 
 *                  default : all applicable pins(@)                       
 *               3. string method : {bineary | linear | lin/bin}
 *                  spec search method
 *               4. double min : optional
 *                  start(minimum) value to do spec search
 *                  deafult : the minimum value of the varible in the specset
 *               5. double max : optional
 *                  stop(maximum) value to do spec search
 *                  deafult : the maximum value of the varible in the specset
 *               6. string step : optional
 *                  if started by "#" means step number ,or else means step width
 *                  only used when method = lin or lin/bin,
 *               7. string resolution : optional
 *                  the resolution of binary test
 *                  default : maximum resolution of the test system is used
 *               8. string resultPinlist
 *                  Defines a list of pins/pin groups that contribute to the pass/fail result
 *                  valid type : O,IO
 *               9. string output
 *                  Message to be printed to selected report media
 *----------------------------------------------------------------------*
 */

class SpecSearch: public testmethod::TestMethod
{
protected:
  double _results[4];
  testmethod::SpecVariable spec;
  string  setupPinlist;
  string  method;
  double min;
  double max;
  string  step;
  string  resolution;
  string  resultPinlist;
  string  output;
  string  mTestName;
protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    addParameter("result0",
                 "double",
                 &_results[0],
                 testmethod::TM_PARAMETER_OUTPUT)
      .setDefault("0.0");
    addParameter("result1",
                 "double",
                 &_results[1],
                 testmethod::TM_PARAMETER_OUTPUT)
      .setDefault("0.0");
    addParameter("result2",
                 "double",
                 &_results[2],
                 testmethod::TM_PARAMETER_OUTPUT)
      .setDefault("0.0");
    addParameter("result3",
                 "double",
                 &_results[3],
                 testmethod::TM_PARAMETER_OUTPUT)
      .setDefault("0.0");
    addParameter("spec",
                 "SpecVariable",
                 &spec)
      .setComment("this parameter's format like:\n"
                  "LEV.1.fooSpec[V]\n"
                  "type is LEV, equationSetId is 1\n"
                  "name is fooSpec, unit is V");
    addParameter("setupPinlist",
                 "PinString",
                 &setupPinlist)
      .setComment("pins which spec variable apply to");
    addParameter("method",
                 "string",
                 &method)
      .setDefault("linear")
      .setOptions("linear:binary:lin/bin");
    addParameter("min",
                 "double",
                 &min)
      .setDefault("9999")
      .setComment("the minimum search point.\n"
         "default is '9999' and it means the minimum value of spec variable is used.");
    addParameter("max",
                 "double",
                 &max)
      .setDefault("9999")
      .setComment("the maximum search point.\n"
         "default is '9999' and it means the maximum value of spec variable is used.");
    addParameter("step",
                 "string",
                 &step);
    addParameter("resolution",
                 "string",
                 &resolution);
    addParameter("resultPinlist",
                 "PinString",
                 &resultPinlist)
      .setComment("pins contributing to result");
    addParameter("output",
                 "string",
                 &output)
      .setDefault("None")
      .setOptions("ReportUI:None")
      .setComment("print result to UI report window");
    
    addParameter("testName",
                 "string",
                 &mTestName)
      .setDefault("SpecSearch_Test")
      .setComment("test limit's name, default is \"SpecSearch_Test\"\n"
         "if test table is used, the limit is defined in file\n"
         "if predefined limit is used, the limit name must be as same as default.");

    addLimit(getParameter("testName").getDefault());
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
    static SpecSearchUtil::SpecSearchUtilParam param;
    static SpecSearchUtil::SpecSearchUtilLimit limit;
    SpecSearchUtil::SpecSearchUtilResult result;
    
    /*----------------------------
     * 1. prepare for test
     *----------------------------
     */
    ON_FIRST_INVOCATION_BEGIN();
      /*process all parameters needed in test*/
      SpecSearchUtil::processParameters(spec.mName,
                                        spec.mType,
                                        setupPinlist,
                                        spec.mUnit,
                                        method,
                                        min,
                                        max,
                                        step,
                                        resolution,
                                        resultPinlist,
                                        param);
      SpecSearchUtil::processLimits(mTestName,
                                    param,
                                    limit);

    ON_FIRST_INVOCATION_END();
    
    /*----------------------------
     * 2. do test
     *----------------------------
     */
    SpecSearchUtil::doMeasurement(param,limit,result);
    
    /*----------------------------
     * 3. datalog
     *----------------------------
     */
    SpecSearchUtil::judgeAndDatalog(param,result,mTestName,limit,_results);
    
    /*----------------------------
     * 4. output result
     *----------------------------
     */
    SpecSearchUtil::reportToUI(param,result,output);
  
    return ;
  }
  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   *
   *Note: TestMethod API should not be used in this method.
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    if(parameterIdentifier == "method")
    {
      if(CommonUtil::trim(method) == "linear")
      {
        getParameter("resolution").setEnabled(false);
        getParameter("step").setEnabled(true);
      }
      else if(CommonUtil::trim(method) == "binary")
      {
        getParameter("resolution").setEnabled(true);
        getParameter("step").setEnabled(false);
      }
      else
      {
        getParameter("resolution").setEnabled(true);
        getParameter("step").setEnabled(true);
      }
    }

    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string  getComment() const
  {
     static string comment = _TML_VERSION;
     return comment;
  }  
};

REGISTER_TESTMETHOD("AcTest.SpecSearch", SpecSearch);
