#ifndef INCLUDE_ABSTRACT_SHMOO_HPP
#define INCLUDE_ABSTRACT_SHMOO_HPP
//for testmethod framework interfaces
#include "testmethod.hpp"
//for testmethod API interfaces
#include "mapi.hpp"
#include "ShmooUtil.hpp"
#include "CommonUtil.hpp"
using namespace std;

class AbstractShmoo: public testmethod::TestMethod
{

protected:
  /*used as the title on the Shmoo Plot.*/
  string title;

  /*X Axis*/
  double startX;
  double stopX;
  string stepX;
  string scaleX;

  /*Y Axis*/
  double startY;
  double stopY;
  string stepY;
  string scaleY;
  string mTestName;
protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   *
   *Note: TestMethod API should not be used in this method.
   */
  virtual void initialize()
  {
    addParameter("title", "string", &title, testmethod::TM_PARAMETER_INPUT)
      .setDefault("Example");

    addParameter("x.start",
                 "double", 
                 &startX, 
                 testmethod::TM_PARAMETER_INPUT);
    addParameter("x.stop",
                 "double",
                 &stopX,
                 testmethod::TM_PARAMETER_INPUT);
    addParameter("x.step",
                 "string",
                 &stepX,
                 testmethod::TM_PARAMETER_INPUT)
      .setComment("defines the resolution of the resource on X axis. It can be expressed as:\n"
                    "\"0.1\"  the step width is 0.1.\n"
                    "\"#10\"  the totalStep are 10 and thus linearStep is 1 (linear mode).\n"
                    "\"f#10\" the totalStep are 10 and linearStep is 4(fast mode).\n"
                    "\"#<20>/<2>\" the totalStep is 10 and linearStep is 2(binary mode).");
    addParameter("x.scale",
                 "string",
                 &scaleX, 
                 testmethod::TM_PARAMETER_INPUT)
      .setOptions("Linear:Logarithmic")
      .setDefault("Linear");

    addParameter("y.start",
                 "double", 
                 &startY, 
                 testmethod::TM_PARAMETER_INPUT);
    addParameter("y.stop",
                 "double",
                 &stopY,
                 testmethod::TM_PARAMETER_INPUT);
    addParameter("y.step",
                 "string",
                 &stepY,
                 testmethod::TM_PARAMETER_INPUT)
      .setComment("defines the resolution of the resource on Y axis. It can be expressed as:\n"
                     "\"0.1\"  the step width is 0.1.\n"
                     "\"#10\"  the totalStep are 10 and thus linearStep is 1 (linear mode).\n"
                     "\"f#10\" the totalStep are 10 and linearStep is 4(fast mode).\n"
                     "\"#<20>/<2>\" the totalStep is 10 and linearStep is 2(binary mode).");
    addParameter("y.scale",
                 "string",
                 &scaleY, 
                 testmethod::TM_PARAMETER_INPUT)
      .setOptions("Linear:Logarithmic")
      .setDefault("Linear");

    addParameter("testName",
                 "string",
                 &mTestName,
                 testmethod::TM_PARAMETER_INPUT)
      .setDefault("Shmoo")
      .setComment("test limit's name, default is \"Shmoo\"\n"
         "if test table is used, the limit is defined in file\n"
         "if predefined limit is used, the limit name must be as same as default.");

    addLimit(getParameter("testName").getDefault());
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
    /*process parameters*/
    StepParser stepParserX(stepX, stopX - startX);

    StepParser stepParserY(stepY, stopY - startY);

    ShmooResult shmooResult(getResultResolution());
    ShmooCoordinator coordinator(
      stepParserX.getTotalStep(),
      stepParserY.getTotalStep(),
      stepParserX.getLinearStep(),
      stepParserY.getLinearStep());
    CONNECT();

    /*save before shmoo run*/
    saveBeforeShmooRun();
  
    /*For shmoo plot */
    TpiShmooViewer viewer(
      startX,
      stopX, 
      stepParserX.getTotalStep(), 
      getShortNameForXAxis(), 
      getUnitForXAxis(), 
      startY, 
      stopY, 
      stepParserY.getTotalStep(),
      getShortNameForYAxis(), 
      getUnitForYAxis(),
      &shmooResult, 
      title, 
      getResultResolution(),
      getTpiViewerMode(),
      getXSetupPins(),
      getYSetupPins(),
      getResultPins());
    
   ShmooCellResult cellResult;
   viewer.onStart();

   /* reset sequencer mode before running pattern*/
   FW_TASK("SQGB ACQF,0;");

   /* run shmoo and save result*/
   for ( coordinator.start(); !coordinator.isEnd(); coordinator.next(shmooResult) )
   {
     unsigned int relativeX = coordinator.getRelativeX();
     unsigned int relativeY = coordinator.getRelativeY();
     double realValueX = getValueByRelativeCoordinate(
       startX, 
       stopX, 
       stepParserX.getTotalStep(), 
       relativeX, 
       scaleX == "Linear");
     double realValueY = getValueByRelativeCoordinate(
       startY, 
       stopY, 
       stepParserY.getTotalStep(), 
       relativeY, 
       scaleY == "Linear");
     /*run at every point*/
     cellResult = runAtPoint(realValueX, realValueY);
     shmooResult.setResult(relativeX, relativeY, cellResult);
     viewer.onValue(relativeX, relativeY, cellResult);
   }
   viewer.onStop();
   restoreAfterShmooRun();

   /*datalog*/
    ShmooData shmooData;
    const map<pair<unsigned int, unsigned int>, ShmooCellResult >& allResults
      = shmooResult.getAllResults();
    map<pair<unsigned int, unsigned int>, ShmooCellResult>::const_iterator it;
    for(it = allResults.begin();
        it != allResults.end();
        ++it)
    {
     
      shmooData.setResult(it->first.first, it->first.second, it->second);
    }
    
    shmooData.setTitle(title);
    shmooData.setTestMode(getTestMode());
    shmooData.setResultPins(getResultPins());
    shmooData.setResultResolution(getResultResolution());
    shmooData.setDescription(getDescription());

    shmooData.setXStart(startX);
    shmooData.setXStop(stopX);
    shmooData.setXTotalSteps(stepParserX.getTotalStep());
    shmooData.setXLinearSteps(stepParserX.getLinearStep());
    shmooData.setXUnit(getUnitForXAxis());
    shmooData.setXScale(scaleX);
    shmooData.setXAxisDescription(getXAxisDescription());
    shmooData.setYStart(startY);
    shmooData.setYStop(stopY);
    shmooData.setYTotalSteps(stepParserY.getTotalStep());
    shmooData.setYLinearSteps(stepParserY.getLinearStep());
    shmooData.setYUnit(getUnitForYAxis());
    shmooData.setYScale(scaleY);
    shmooData.setYAxisDescription(getYAxisDescription());
    //datalog
    TestTable* pLimitTable = TestTable::getDefaultInstance();
    pLimitTable->readCsvFile();
    bool isLimitTableUsed = false;
    if (pLimitTable->isTmLimitsCsvFile())
    {
      try
      {
        string testsuiteName;
        GET_TESTSUITE_NAME(testsuiteName);
        string keyInTable = testsuiteName + ":" + mTestName;
        V93kLimits::TMLimits::LimitInfo limitInfo =
          V93kLimits::tmLimits.getLimit(keyInTable);
        TESTSET().testnumber(limitInfo.TestNumber).doLog_ShmooTest(mTestName,shmooData);
        isLimitTableUsed = true;
      }
      catch(Error& e)
      {
        isLimitTableUsed = false;
      }		
    }
    
    if (!isLimitTableUsed)
    {
      TESTSET().doLog_ShmooTest(mTestName, shmooData);
    }

    return ;
  }
    	


  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   *
   *Note: TestMethod API should not be used in this method.
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    postParameterChangeForXAxis(parameterIdentifier);
    postParameterChangeForYAxis(parameterIdentifier);
    return;
  }

private:

  void postParameterChangeForXAxis(const string& parameterIdentifier)
  {
    /*"x.scale" is set after "x.start", "x.stop",
      "x.step". So when "x.scale" is set, "x.start", "x.stop",
      "x.step" have already been set.*/
    if(parameterIdentifier == "x.scale")
    {
      /* set all parameters to valid first*/
      getParameter("x.start").setValid(true);
      getParameter("x.stop").setValid(true);
      getParameter("x.step").setValid(true);
      getParameter("x.scale").setValid(true);
      getParameter("x.start").setMessage("");
      getParameter("x.stop").setMessage("");
      getParameter("x.step").setMessage("");
      getParameter("x.scale").setMessage("");
   
      /*then do then checking.*/
      if(scaleX != "Linear" && scaleX != "Logarithmic")
      {
        getParameter("x.scale").setValid(false);
        getParameter("x.scale").setMessage("x.scale should be Linear or Logarithmic!");
      }
      if(abs(stopX- startX) < 1e-38)
      {
        getParameter("x.start").setValid(false);
        getParameter("x.stop").setValid(false);
        getParameter("x.start").setMessage("x.start cannot be equal to x.stop !");
        getParameter("x.stop").setMessage("x.start cannot be equal to x.stop !");
      }
      StepParser stepParser(stepX, stopX - startX);
      getParameter("x.step").setValid(stepParser.isValid());
      getParameter("x.step").setMessage(stepParser.getMessage());

      if(scaleX == "Logarithmic")
      {
        if(!stepParser.isStepNumberSpecified())
        {
          getParameter("x.step").setValid(false);
          getParameter("x.step").setMessage("when x.scale is logarithmic, step"
            "number should be used instead of step width !");
        }
        if(startX * stopX <= 0)
        {
          getParameter("x.start").setValid(false);
          getParameter("x.stop").setValid(false);
          getParameter("x.scale").setValid(false);
          getParameter("x.start").setMessage("x.start and x.stop should be both positive"
             "or both negative when x.scale is logarithmic!");
          getParameter("x.stop").setMessage("x.start and x.stop should be both positive"
             "or both negative when x.scale is logarithmic!");
          getParameter("x.scale").setMessage("x.start and x.stop should be both positive"
             "or both negative when x.scale is logarithmic!");
        }
      }
    }
  }

  void postParameterChangeForYAxis(const string& parameterIdentifier)
  {
    /* please see postParameterChangeForXAxis() for comments*/
    if(parameterIdentifier == "y.scale")
    {
      getParameter("y.start").setValid(true);
      getParameter("y.stop").setValid(true);
      getParameter("y.step").setValid(true);
      getParameter("y.scale").setValid(true);
      getParameter("y.start").setMessage("");
      getParameter("y.stop").setMessage("");
      getParameter("y.step").setMessage("");
      getParameter("y.scale").setMessage("");
      if(scaleY != "Linear" && scaleY != "Logarithmic")
      {
        getParameter("y.scale").setValid(false);
        getParameter("y.scale").setMessage("y.scale should be Linear or Logarithmic!");
      }
      if(abs(stopY- startY) < 1e-38)
      {
        getParameter("y.start").setValid(false);
        getParameter("y.stop").setValid(false);
        getParameter("y.start").setMessage("y.start cannot be equal to y.stop !");
        getParameter("y.stop").setMessage("y.start cannot be equal to y.stop !");
      }

      StepParser stepParser(stepY, stopY - startY);
      getParameter("y.step").setValid(stepParser.isValid());
      getParameter("y.step").setMessage(stepParser.getMessage());

      if(scaleY == "Logarithmic")
      {
        if(!stepParser.isStepNumberSpecified())
        {
          getParameter("y.step").setValid(false);
          getParameter("y.step").setMessage("when y.scale is logarithmic, step"
            "number should be used instead of step width !");
        }
        if(startY * stopY <= 0)
        {
          getParameter("y.start").setValid(false);
          getParameter("y.stop").setValid(false);
          getParameter("y.scale").setValid(false);
          getParameter("y.start").setMessage("y.start and y.stop should be both positive"
             "or both negative when y.scale is logarithmic!");
          getParameter("y.stop").setMessage("y.start and y.stop should be both positive"
             "or both negative when y.scale is logarithmic!");
          getParameter("y.scale").setMessage("y.start and y.stop should be both positive"
             "or both negative when y.scale is logarithmic!");
        }
      }
    }
  }
protected:
 	
  virtual ShmooCellResult runAtPoint(double realValueX, double realValueY) = 0;
  
  virtual void saveBeforeShmooRun() = 0;
  
  virtual void restoreAfterShmooRun() = 0;
  
  virtual string getShortNameForXAxis() = 0;
  
  virtual string getShortNameForYAxis() = 0;
  
  virtual string getUnitForXAxis() = 0;
  
  virtual string getUnitForYAxis() = 0;

  virtual double getResultResolution() = 0;
 
  /*for datalog. Default implementation is provided. Subclass can override.*/
  virtual string getDescription()
  {
    return "";
  } 

  /*for datalog. Default implementation is provided. Subclass can override.*/
  virtual string getXAxisDescription()
  {
    return "";
  }

  /*for datalog. Default implementation is provided. Subclass can override.*/
  virtual string getYAxisDescription()
  {
    return "";
  }

  /*for datalog. Default implementation is provided. Subclass can override.*/
  virtual string getTestMode()
  {
    return "";
  }
 
  /*for datalog. Default implementation is provided. Subclass can override.*/
  virtual string getResultPins()
  {
    return "";
  }

  /*for the messages sent to shmoo plot. Default implementation is provided. Subclass can override.*/
  virtual string getXSetupPins()
  {
    return "";
  }
  
  /*for the messages sent to shmoo plot. Default implementation is provided. Subclass can override.*/
  virtual string getYSetupPins()
  {
    return "";
  }

  /*for the messages sent to shmoo plot. Default implementation is provided. Subclass can override.*/
  virtual int getTpiViewerMode()
  {
    return TpiShmooViewer::OTHER_MODE;
  }
  
private:
  double getValueByRelativeCoordinate(double start, double stop, unsigned int totalSteps, unsigned int relativeCoordinate, bool isLinear)
  {
    if ( isLinear )
    {
      return start + (stop - start)/totalSteps * relativeCoordinate;
    }
    else
    {
      return pow((stop/start), static_cast<double>(relativeCoordinate)
        /totalSteps) * start;
    }

  }
};
#endif
