#ifndef INCLUDE_JITTERHISTOGRAMHX_H
#define INCLUDE_JITTERHISTOGRAMHX_H
#include <algorithm>
#include "CommonUtil.hpp"
#include "JitterUtilHX.hpp"

/******************************************************************************
 *                    jitter histogram test utility class 
 ******************************************************************************
 *Description:
 * By setting up different parameters,users can make the jitter histogram
 * measurement in different conditions.
 *    pattern synchronization: find a passing pattern
 *    transtioon search on specified side(s): optimize the start of jitter data
 *                                           acquisition.
 *    data acquisition on specified side(s): sample the jitter data
 *    jitter histogram calculation on specified side(s).
 * according the description,the whole process steps:
 * |----------------|     |------------|       |-------------|       |---------|
 * |    pattern     |     | transition |       |             |       |         |
 * |synchronization |---->|  search    |------>|     data    |------>|  post   |
 * |   (optional)   |     | (optional) |       | acquisition |       | process |
 * |----------------|     |------------|       |-------------|       |---------|
 *
 ******************************************************************************
 */ 
class JitterHistogramUtilHX
{
public:
  /**
   *---------------------------------------------------------------------------
   *         test parameters containe
   *---------------------------------------------------------------------------
   */
  struct  JitterHistogramParameter
  {
    //common parameter for jitter histogram, separation and stardust
    JitterUtilHX::JitterParameter commonParameter;
  };
  /**
   *----------------------------------------------------------------------------
   *         test limits container                                    
   *----------------------------------------------------------------------------
   */
  struct JitterHistogramLimit
  {
    bool isLimitTableUsed;
    string ppTestname;
    string rmsTestname;
    LIMIT ppJitterLimit;
    LIMIT rmsJitterLimit;
  };

  /**
   *---------------------------------------------------------------------------
   *         test results container
   *---------------------------------------------------------------------------
   */
  struct ResultData
  {
    // histogram data vector of left transition
    vector<INT> leftHistogramData;

    // histogram data vector of right transiton
    vector<INT> rightHistogramData;

    // the result of jitter on the left transition side
    JitterHistogramType leftSideJitter;

    // the result of jitter on the right transition side
    JitterHistogramType rightSideJitter;

    // initialize all stuffs to some defaults.
    void init()
    {
      leftHistogramData.clear();
      rightHistogramData.clear();

      leftSideJitter.mean = 0.0;
      leftSideJitter.rms = 0.0;
      leftSideJitter.peak2peak = 0.0;
      leftSideJitter.median = 0.0;
      leftSideJitter.medist = 0.0;

      rightSideJitter.mean = 0.0;
      rightSideJitter.rms = 0.0;
      rightSideJitter.peak2peak = 0.0;
      rightSideJitter.median = 0.0;
      rightSideJitter.medist = 0.0;
    }
    ResultData()
    {
      init();
    }
  };
  /**
   *---------------------------------------------------------------------------
   * Struct: JitterHistogramResult
   * Purpose: container to store jitter measurement results
   *---------------------------------------------------------------------------
   * Decription:
   *   This two-layered map contains result of test.The outside map contains
   *   every site's result.The inside map contains every pin's result.
   *   The outside map's key: INT is the index of site number
   *   The outside map's value:map<STRING,ResultData> is the result of the
   *   site which is indexed by key.
   *   The inside map's key: STRING is the pin's name.
   *   The inside map's value: ResultData is the result of the pin which is
   *   indexed by key.
   * Note:
   *---------------------------------------------------------------------------
   */
  struct JitterHistogramResultHX
  {
    map<INT,map<STRING, map<INT, ResultData> > > resultMap;

    JitterUtilHX::JitterDataHX jitterDataHX;

    void init()
    {
      jitterDataHX.init();
      resultMap.clear();
    }
  };
  /**
   *---------------------------------------------------------------------------
   *         public interfaces of jitter historgram  test
   *---------------------------------------------------------------------------
   */  

  static void processParameters(
                               const STRING& pinlist,
                               const double UI_width_ns,
                               const double start_ns,
                               const double stop_ns,
                               const double dataAcquStepWidth_ns,    
                               const STRING& autoSyncMode,
                               const double autoSyncStepWidth_ns,
                               const STRING& transitionSearchMode,
                               const STRING& transition,
                               const STRING& outputMode,
                               JitterHistogramParameter& parameters,
                               JitterUtilHX::JitterDataHX& jitter_data_hx
                               );

  static void processLimit(const string& testname,
                           JitterHistogramLimit& testlimit);


  static void doMeasurement(const JitterHistogramParameter& parameters,
                            JitterHistogramResultHX& results_hx);

  //---------------------------------------------
  static void judgeAndDatalog(const JitterHistogramParameter& parameters,
                              const JitterHistogramResultHX& results_hx,
                              const JitterHistogramLimit& testlimit);

  static void reportToUI(const JitterHistogramParameter& parameters,
                         const JitterHistogramResultHX& results_hx,
                         const STRING& output);

  static bool processTestName(const string& testname,vector<string>& names);
private:

  static void histogramCalculation(const JitterHistogramParameter& parameters,
                                   JitterHistogramResultHX& results_hx); 

  static void histogramCalculation_qk(const JitterHistogramParameter& parameters,
                                      JitterHistogramResultHX& results_hx,
                                      JitterUtilHX::TRANSITION active);

  //---------------------------------------------
  static void applyPatternSyncValue(const JitterHistogramParameter& parameters,
                                    JitterHistogramResultHX& results_hx);

  static void printHistogram(const vector<INT> &);
  static void printJitterValue(const DOUBLE,const DOUBLE);

  static void prepareDataForAnalyzer(const STRING&,
                                     const INT & lane,
                                     const vector<INT>&,
                                     WAVE_LOG &);
};

/**
 *-----------------------------------------------------------------------------
 * Routine: processParameter
 *
 * Purpose: parse input parameters and setup internal parameters
 *
 *-----------------------------------------------------------------------------
 * Description:
 *   according user's input to fill out interal parameters
 * Parameters:
 *   1.STRING& pinlist:
 *     Define a list of pins/pin groups the spec is shifted for.
 *     valid type :O,IO
 *   4.double UI_width_ns:
 *     Bit time of test pattern.
 *     For example:2.5Gb/s -> 0.4ns
 *   5.double start_ns:
 *     --if autoSyncMode is "OFF":start of Data Acquisition
 *     --if autoSyncMode is "ON" : start of linear Pattern
 *     Alignment Search
 *   6.double stop_ns:
 *     --if autoSyncMode is "OFF":stop of Data Acquisition
 *     --if autoSyncMode is "ON" : stop of linear Pattern
 *     Alignment Search
 *   7.double dataAcquStepWidth_ns:
 *     Step width for Data Acquisition
 *   9.STRING& autoSyncMode: {OFF | ON }
 *     Enabling of linear Pattern Alignment Search to find passing pattern.
 *       With ON option the spec variable will be reset to its
 *     original value after finishing the test.
 *       With OFF option linear Pattern Alignment Search to find
 *     passing pattern is disable.
 *       default is ON.
 *   10.double autoSyncStepWidth_ns:
 *      Step width for AutoSync Search.
 *   11.STRING& transitionSearchMode:  {OFF | ON}
 *        With ON,Binary Search for Pass/Fail Transition of
 *      MIN_BER poit with maximum search range of one "UI_width"
 *      and resolution of dataAcquStepWidth_ns.
 *        With OFF,transiton search will not be made.
 *      default is ON.
 *   12.STRING& transition:  {LEFT | RIGHT | BOTH}
 *      Determine which side of bit transition will be searched
 *      if transitionSearchMode is ON and be acquired for jitter
 *      histogram calculation. If both autoSyncMode and
 *      transitionSearchMode are OFF,this parameter is not in
 *      effect,and users have to choose proper values of start
 *      and stop for acquisition based on the test requirement.
 *      default is LEFT.
 *   13.STRING& outputMode: {SUMMARY | DETAIL | ANALYSIS}
 *      This parameter is in effect only if output is set ReportUI.
 *      SUMMARY - a result table will be printed in the Report Window.
 *      DETAIL  - an ASCII plot of the Error Count and the histogram curve
 *                will be printed in report window.
 *      ANALYSIS - the jitter histogram data will be transfer to signal
 *                analyzer tool for display and debuggine.
 *      default is SUMMARY.
 *   14.JitterHistogramParameter& parameters
 *      this parameter's type is output,we use user's input to
 *      fill out this parameter.
 *   Note:
 *-----------------------------------------------------------------------------
 */
void JitterHistogramUtilHX::processParameters(
                                             const STRING& pinlist,
                                             const double UI_width_ns,
                                             const double start_ns,
                                             const double stop_ns,
                                             const double dataAcquStepWidth_ns,  
                                             const STRING& autoSyncMode,
                                             const double autoSyncStepWidth_ns,
                                             const STRING& transitionSearchMode,
                                             const STRING& transition,
                                             const STRING& outputMode,
                                             JitterHistogramParameter& parameters,
                                             JitterUtilHX::JitterDataHX& jitter_data_hx  
                                             )
{

  JitterUtilHX::JitterParameter& commonParameter = parameters.commonParameter;
  STRING tempString = CommonUtil::trim(pinlist);
  //JitterUtilHX::checkSetupPinlist(tempString);  
  commonParameter.PinVector = JitterUtilHX::expandPinlistToPins(tempString);

  //--------------------------------------------  
  JitterUtilHX::HXPins_Parsing(commonParameter, jitter_data_hx);

  //--------------------------------------------


  if (UI_width_ns <= 0)
  {
    STRING api = "Check parameter UI_width_ns: ";
    STRING msg = "UI_width_ns should be greater than zero!";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }
  commonParameter.UI_width_ns = UI_width_ns;

  //
  commonParameter.start_ns = start_ns;
  commonParameter.stop_ns = stop_ns;


  if (dataAcquStepWidth_ns <= 0)
  {
    STRING api = "Check parameter dataAcquStepWidth_ns: ";
    STRING msg = "dataAcquStepWidth_ns should be greater than zero!";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }
  commonParameter.dataAcquStepWidth_ns = dataAcquStepWidth_ns;


  //
  tempString = CommonUtil::trim(autoSyncMode);
  if (tempString == "OFF")
  {
    commonParameter.autoSyncMode = JitterUtilHX::AUTOSYNC_OFF;
  }
  else if (tempString == "ON")
  {
    commonParameter.autoSyncMode = JitterUtilHX::AUTOSYNC_ON;
  }
  else
  {
    STRING api = "Check AUTOSYNC_MODE: ";
    STRING msg = "These is an unknow AUTOSYNC_MODE type.";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }

  //
  if (autoSyncStepWidth_ns <= 0)
  {
    STRING api = "Check parameter autoSyncStepWidth_ns: ";
    STRING msg = "autoSyncStepWidth_ns should be greater than zero!";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }
  commonParameter.autoSyncStepWidth_ns = autoSyncStepWidth_ns;

  //
  tempString = CommonUtil::trim(transitionSearchMode); 
  if (tempString == "OFF")
  {
    commonParameter.transitionSearchMode = JitterUtilHX::TRANSITIONSEARCH_OFF;
  }
  else if (tempString == "ON")
  {
    commonParameter.transitionSearchMode = JitterUtilHX::TRANSITIONSEARCH_ON;
  }
  else
  {
    STRING api = "Check TRANSITIONSEARCH_MODE: ";
    STRING msg = "These is an unknow TRANSITIONSEARCH_MODE type.";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }

  //
  tempString = CommonUtil::trim(transition);
  if (tempString == "LEFT")
  {
    commonParameter.transition = JitterUtilHX::LEFT;
  }
  else if (tempString == "RIGHT")
  {
    commonParameter.transition = JitterUtilHX::RIGHT;
  }
  else if (tempString == "BOTH")
  {
    commonParameter.transition = JitterUtilHX::BOTH;
  }
  else
  {
    STRING api = "Check TRANSITION: ";
    STRING msg = "These is an unknow TRANSITION type.";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }


  //to do
  tempString = CommonUtil::trim(outputMode);
  if (tempString == "SUMMARY")
  {
    commonParameter.outputMode = JitterUtilHX::OUTPUT_SUMMARY;
  }
  else if (tempString == "DETAIL")
  {
    commonParameter.outputMode = JitterUtilHX::OUTPUT_DETAIL;
  }
  else if (tempString == "ANALYSIS")
  {
    commonParameter.outputMode = JitterUtilHX::OUTPUT_ANALYSIS;
  }
  else
  {
    STRING api = "Check OUTPUT_MODE: ";
    STRING msg = "These is an unknow OUTPUT_MODE type.";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }
}

/**
 *-----------------------------------------------------------------------------
 * Routine: processTestName
 *
 * Purpose: process names of test limits
 *
 *-----------------------------------------------------------------------------
 * Description:
 *   the input testname is in the format as "(ppJitter,rmsJitter)"
 *   the output names is in vector of "ppJitter" and "rmsJitter"
 *   return value: true if the test name is valid, otherwise, false is returned.
 * Note:
 *-----------------------------------------------------------------------------
 */
bool JitterHistogramUtilHX::processTestName(const string& testname,vector<string>& names)
{
  bool isValid = false;
  string validName = CommonUtil::trim(testname);
  string::size_type leadPos = validName.find("(");
  string::size_type postPos = validName.find(")");
  names.clear();
  if (leadPos != string::npos && postPos != string::npos && leadPos < postPos)
  {
    validName = validName.substr(leadPos+1,postPos-leadPos-1);
    CommonUtil::splitStr(validName,',',names);
    isValid = true;
  }
  return isValid;
}
/**
 *-----------------------------------------------------------------------------
 * Routine: processLimit
 *
 * Purpose: process Limit(s)
 *
 *-----------------------------------------------------------------------------
 * Description:
 *   
 * Note:
 *-----------------------------------------------------------------------------
 */
void JitterHistogramUtilHX::processLimit(
                                        const string& testname,
                                        JitterHistogramLimit& testlimit)
{
  const string funcName = "JitterHistogramUtil::processLimit()";
  vector<string> names;
  if (processTestName(testname,names) && names.size() == 2)
  {
    testlimit.ppTestname = names[0];
    testlimit.rmsTestname = names[1];
  }
  else
  {
    throw Error(funcName,
                "two test names are needed for peak-to-peak and rms jitter testing.",
                funcName);
  }

  //first, try to get limit from test table 
  string testsuiteName;
  GET_TESTSUITE_NAME(testsuiteName);
  TesttableLimitHelper ttlHelper(testsuiteName);
  if (ttlHelper.isLimitCsvFileLoad())
  {
    ttlHelper.getLimit(testlimit.ppTestname, testlimit.ppJitterLimit);
    ttlHelper.getLimit(testlimit.rmsTestname, testlimit.rmsJitterLimit);
  }

  testlimit.isLimitTableUsed = ttlHelper.isAllInTable(); 

  //if not defined in test table, use testflow limit	
  if (!testlimit.isLimitTableUsed)
  {
    testlimit.ppJitterLimit = GET_LIMIT_OBJECT(testlimit.ppTestname);
    testlimit.rmsJitterLimit = GET_LIMIT_OBJECT(testlimit.rmsTestname);
  }

  //default is 'ps' as same as parameter definition
  if (testlimit.ppJitterLimit.unit().empty())
  {
    testlimit.ppJitterLimit.unit("ps");
  }
  if (testlimit.rmsJitterLimit.unit().empty())
  {
    testlimit.rmsJitterLimit.unit("ps");
  }
}
/**
 *-----------------------------------------------------------------------------
 * Routine: doMeasurement
 *
 * Purpose: execute measurement and store results
 *
 *-----------------------------------------------------------------------------
 * Description:
 *
 *INPUT:
 *        parameters--------------test parameters
 *        result------------------test result container
 *
 *RETURN:
 *NOTE:
 * process steps:
 * |----------------|     |------------|       |-------------|       |---------|
 * |    pattern     |     | transition |       |             |       |         |
 * |synchronization |---->|  search    |------>|     data    |------>|  post   |
 * |   (optional)   |     | (optional) |       | acquisition |       | process |
 * |----------------|     |------------|       |-------------|       |---------|
 *-----------------------------------------------------------------------------
 */
void JitterHistogramUtilHX::doMeasurement(
                                         const JitterHistogramParameter & parameters,  
                                         JitterHistogramResultHX& results_hx)
{
  ON_FIRST_INVOCATION_BEGIN();
  results_hx.init();
  CONNECT();
  FW_TASK("SQGB ACQF,0;");//to do
  ON_FIRST_INVOCATION_END();

  const JitterUtilHX::JitterParameter& commonParameter = parameters.commonParameter;

  //=========================================================================
  // Quick way
  //=========================================================================
  /*if((commonParameter.autoSyncMode == JitterUtilHX::AUTOSYNC_OFF)      
    &&(commonParameter.transitionSearchMode == JitterUtilHX::TRANSITIONSEARCH_OFF)
    &&(0 == commonParameter.start_ns && 0 == commonParameter.stop_ns ))
  {		  
    //First coarse search to find Rising/Falling edge of clock signal
    JitterUtilHX::Coarse_Sync(
      parameters.commonParameter,
      results_hx.jitterDataHX,
      0.5);

    JitterUtilHX::HX_Error_Count_Acquire(
      parameters.commonParameter,
      results_hx.jitterDataHX,
      JitterUtilHX::RIGHT);

    ON_FIRST_INVOCATION_BEGIN();

    histogramCalculation_qk(parameters,results_hx,JitterUtilHX::RIGHT);

    ON_FIRST_INVOCATION_END();

    return;
  } 
  */
  //===================================================================================

  // autoSync
  if (commonParameter.autoSyncMode == JitterUtilHX::AUTOSYNC_ON || 
      commonParameter.autoSyncMode == JitterUtilHX::AUTOSYNC_ON_KEEP_VALUE)
  {
    bool isEveryPinOfAllSitesFail = false;
    JitterUtilHX::hx_autoSync(parameters.commonParameter,
                              results_hx.jitterDataHX,
                              isEveryPinOfAllSitesFail);

    if (isEveryPinOfAllSitesFail)
    {
      return;
    }
  }
  // transition search
  if (commonParameter.transitionSearchMode == JitterUtilHX::TRANSITIONSEARCH_ON)
  {
    bool isEveryPinOfAllSitesFail = false;
    JitterUtilHX::hx_transitionSearch(parameters.commonParameter,
                                      results_hx.jitterDataHX,
                                      isEveryPinOfAllSitesFail);

    if (isEveryPinOfAllSitesFail)
    {
      return;
    }
  }

  //data acquisition
  JitterUtilHX::hx_dataAcquire(parameters.commonParameter,results_hx.jitterDataHX);


  //post process: calculation and apply pattern synchronization value
  ON_FIRST_INVOCATION_BEGIN();
  histogramCalculation(parameters,results_hx);
  if (commonParameter.autoSyncMode == JitterUtilHX::AUTOSYNC_ON_KEEP_VALUE)
  {
    //  applyPatternSyncValue(parameters,results);
  }
  ON_FIRST_INVOCATION_END();
}

/**
 *-----------------------------------------------------------------------------
 *Routing: histogramCalculation
 *
 *Purpose: calculate jitter value of every pin of every site
 *
 *-----------------------------------------------------------------------------
 *Description:
 *  the function calculate the jitter value according to the testing
 *  result(error count).
 *INPUT:
 *      parameters---------test parameters
 *      results------------test result container
 *Return:
 *-----------------------------------------------------------------------------
 */
void JitterHistogramUtilHX::histogramCalculation(
                                                const JitterHistogramParameter& parameters,
                                                JitterHistogramResultHX& results_hx)
{
  const JitterUtilHX::JitterParameter& commonParameter = parameters.commonParameter;
  JitterUtilHX::JitterDataHX& commonResult = results_hx.jitterDataHX;

  map<INT, map<STRING, map<INT, JitterUtilHX::SYNC_EDGE> > >::const_iterator site_it;
  map<STRING, map<INT, JitterUtilHX::SYNC_EDGE> >::const_iterator pin_it;
  map<INT, JitterUtilHX::SYNC_EDGE>::const_iterator lane_it;


  //left side
  if (commonParameter.transition == JitterUtilHX::LEFT || 
      commonParameter.transition == JitterUtilHX::BOTH)
  {
    for (site_it = commonResult.Sync_Result.begin();
        site_it != commonResult.Sync_Result.end();
        ++site_it)//for every site
    {
      for (pin_it = site_it->second.begin();
          pin_it != site_it->second.end();++pin_it)//for every pin		  
      {
        for (lane_it = pin_it->second.begin();
            lane_it != pin_it->second.end();++lane_it)//for every lane
        {
          if (lane_it->second.lastStatus == JitterUtilHX::LEFT_JITTER || 
              lane_it->second.lastStatus == JitterUtilHX::BOTH_JITTER)
          {
            DOUBLE startValue = 0.0;
            if (commonParameter.transitionSearchMode == JitterUtilHX::TRANSITIONSEARCH_ON)
            {
              startValue = 
              commonResult.Sync_Result[site_it->first][pin_it->first][lane_it->first].leftTransitionVal;
            }
            else if (commonParameter.autoSyncMode == JitterUtilHX::AUTOSYNC_ON || 
                     commonParameter.autoSyncMode == JitterUtilHX::AUTOSYNC_ON_KEEP_VALUE)
            {
              startValue = 
              commonResult.Sync_Result[site_it->first][pin_it->first][lane_it->first].autoSyncVal;
            }
            else
            {
              startValue = commonParameter.start_ns;
            }
            DSP_JITTER_HISTOGRAM(
                                lane_it->second.leftErrorCount,
                                startValue,
                                -commonParameter.dataAcquStepWidth_ns,

                                results_hx.resultMap[site_it->first][pin_it->first][lane_it->first].leftHistogramData,
                                results_hx.resultMap[site_it->first][pin_it->first][lane_it->first].leftSideJitter,
                                true);

          }//end if for jitter calculation
        }//end for every lane
      }//end for every pin
    }//end for every site
  }//end if for left

  //right side
  if (commonParameter.transition == JitterUtilHX::RIGHT || 
      commonParameter.transition == JitterUtilHX::BOTH)
  {
    for (site_it = commonResult.Sync_Result.begin();
        site_it != commonResult.Sync_Result.end();
        ++site_it)//for every site
    {
      for (pin_it = site_it->second.begin();
          pin_it != site_it->second.end();++pin_it)//for every pin
      {
        for (lane_it = pin_it->second.begin();
            lane_it != pin_it->second.end();++lane_it)//for every lane
        {
          if (lane_it->second.lastStatus == JitterUtilHX::RIGHT_JITTER || 
              lane_it->second.lastStatus == JitterUtilHX::BOTH_JITTER)
          {


            DOUBLE startValue = 0.0;
            if (commonParameter.transitionSearchMode == JitterUtilHX::TRANSITIONSEARCH_ON)
            {
              startValue = 
              commonResult.Sync_Result[site_it->first][pin_it->first][lane_it->first].rightTransitionVal;
            }
            else if (commonParameter.autoSyncMode == JitterUtilHX::AUTOSYNC_ON || 
                     commonParameter.autoSyncMode == JitterUtilHX::AUTOSYNC_ON_KEEP_VALUE)
            {
              startValue = 
              commonResult.Sync_Result[site_it->first][pin_it->first][lane_it->first].autoSyncVal;
            }
            else
            {
              startValue = commonParameter.start_ns;
            }
            DSP_JITTER_HISTOGRAM(
                                lane_it->second.rightErrorCount,
                                startValue,
                                commonParameter.dataAcquStepWidth_ns,
                                results_hx.resultMap[site_it->first][pin_it->first][lane_it->first].rightHistogramData,
                                results_hx.resultMap[site_it->first][pin_it->first][lane_it->first].rightSideJitter,
                                true);

          }//end if for jitter calculation
        }//end for every lane
      }//end for every pin
    }//end for every site
  }//end if for right side
}



void JitterHistogramUtilHX::histogramCalculation_qk(
                                                   const JitterHistogramParameter& parameters,
                                                   JitterHistogramResultHX& results_hx,
                                                   JitterUtilHX::TRANSITION active)
{
  const JitterUtilHX::JitterParameter& commonParameter = parameters.commonParameter;
  JitterUtilHX::JitterDataHX& commonResult = results_hx.jitterDataHX;

  map<INT, map<STRING, map<INT, JitterUtilHX::SYNC_EDGE> > >::const_iterator site_it;
  map<STRING, map<INT, JitterUtilHX::SYNC_EDGE> >::const_iterator pin_it;
  map<INT, JitterUtilHX::SYNC_EDGE>::const_iterator lane_it;

  for (site_it = commonResult.Sync_Result.begin();
      site_it != commonResult.Sync_Result.end();
      ++site_it)//for every site
  {
    for (pin_it = site_it->second.begin();
        pin_it != site_it->second.end();++pin_it)//for every pin
    {
      for (lane_it = pin_it->second.begin();
          lane_it != pin_it->second.end();++lane_it)//for every lane
      {
        if (JitterUtilHX::LEFT == active || JitterUtilHX::BOTH == active)
        {

          if (( lane_it->second.LeftSide_Stop - lane_it->second.LeftSide_Start ) > 1)
          {

            DSP_JITTER_HISTOGRAM(
                                lane_it->second.leftErrorCount,
                                0,
                                commonParameter.dataAcquStepWidth_ns,
                                results_hx.resultMap[site_it->first][pin_it->first][lane_it->first].leftHistogramData,
                                results_hx.resultMap[site_it->first][pin_it->first][lane_it->first].leftSideJitter);
          }
        }
        if (JitterUtilHX::RIGHT == active || JitterUtilHX::BOTH == active)
        {

          if (( lane_it->second.RightSide_Stop - lane_it->second.RightSide_Start ) > 1)
          {

            DSP_JITTER_HISTOGRAM(
                                lane_it->second.rightErrorCount,
                                0,
                                commonParameter.dataAcquStepWidth_ns,
                                results_hx.resultMap[site_it->first][pin_it->first][lane_it->first].rightHistogramData,
                                results_hx.resultMap[site_it->first][pin_it->first][lane_it->first].rightSideJitter);
          }
        }

      }//end for every lane
    }//end for every pin
  }//end for every site

}



/**
 *-----------------------------------------------------------------------------
 *Routine: applyPatternSyncValue
 *
 *Purpose: keep synchronization value
 *
 *-----------------------------------------------------------------------------
 *Description:
 * if user sets the autoSyncMode parameter to ON_KEEP_VALUE, then the
 * synchronization value of the test pin will be keeped for the following
 * test suites.
 *
 *INPUT:
 *       Parameters------------test parameters
 *       results---------------result container
 *RETURN:
 *-----------------------------------------------------------------------------
 */
void JitterHistogramUtilHX::applyPatternSyncValue(
                                                 const JitterHistogramParameter& parameters,
                                                 JitterHistogramResultHX& results_hx)
{
  return;
}

/**
 *-----------------------------------------------------------------------------
 * Routine: judgeAndDatalog
 *
 * Purpose: judge and put result into event datalog stream
 *
 *-----------------------------------------------------------------------------
 * Description:
 *    judge result of 'results' with pass limit form 'testlimit'
 *
 *   INPUT:  param       - test parameters
 *           testLimit   - test limit container
 *           result      - result container
 *
 *   RETURN:
 *-----------------------------------------------------------------------------
 */

void JitterHistogramUtilHX::judgeAndDatalog(
                                           const JitterHistogramParameter& parameters,
                                           const JitterHistogramResultHX& results_hx,
                                           const JitterHistogramLimit & testlimit)
{
  JitterUtilHX::JitterParameter commonParameter = parameters.commonParameter;
  INT siteNumber = CURRENT_SITE_NUMBER();

  //user's input unit is ns,translate ns to ps
  double factorPP = 1000.0;
  double factorRMS = 1000.0;

  STRING_VECTOR::const_iterator it = commonParameter.PinVector.begin();
  STRING_VECTOR::const_iterator it_end = commonParameter.PinVector.end();

  ARRAY_D leftSidePPJitter(commonParameter.PinVector.size());
  ARRAY_D leftSideRMSJitter(commonParameter.PinVector.size());
  ARRAY_D rightSidePPJitter(commonParameter.PinVector.size());
  ARRAY_D rightSideRMSJitter(commonParameter.PinVector.size());
  map<INT,map<STRING, map<INT, ResultData> > > ::const_iterator site_it;
  map<STRING, map<INT, ResultData> >::const_iterator pin_it;
  map<INT, ResultData>::const_iterator lane_it;

  int pinIndex = 0;
  for (;it != it_end; ++it,pinIndex++)
  {
    site_it = results_hx.resultMap.find(siteNumber);
    // because setup error or other error, there is no result for this site.
    if (site_it == results_hx.resultMap.end())
    {
      STRING api = "JitterHistogramUtil::judgeAndDatalog: ";
      STRING msg = "These is no result for this site.";
      throw Error(api.c_str(),msg.c_str(),api.c_str());
    }
    pin_it = site_it->second.find(*it);
    // because setup error or other error, there is no result for this pin.
    if (pin_it == site_it->second.end())
    {
      STRING api = "JitterHistogramUtil::judgeAndDatalog: ";
      STRING msg = "These is no result for this pin.";
      throw Error(api.c_str(),msg.c_str(),api.c_str());
    }

    //(results.   jitterResult.Sync_Result.    find(siteNumber)->second.find(*it)->second.find(lane)->second.lastStatus
    //(results_hx.JitterDataHX.commonResultMap.find(siteNumber)->second.find(*it)                   ->second.lastStatus
    JitterUtilHX::JitterDataHX jitterData_HX = 
    const_cast<JitterUtilHX::JitterDataHX&>(results_hx.jitterDataHX);

    for (int lane=0; lane<jitterData_HX.HXPIN_Resource[siteNumber][*it].Lanes_Number; lane++)
    {

      switch (jitterData_HX.Sync_Result[siteNumber][*it][lane].lastStatus)
      {
      case JitterUtilHX::LEFT_JITTER:
        leftSidePPJitter[pinIndex] = pin_it->second.find(lane)->second.leftSideJitter.peak2peak * factorPP ;
        leftSideRMSJitter[pinIndex] = pin_it->second.find(lane)->second.leftSideJitter.rms * factorRMS;
        break;
      case JitterUtilHX::RIGHT_JITTER:
        rightSidePPJitter[pinIndex] = pin_it->second.find(lane)->second.rightSideJitter.peak2peak * factorPP;
        rightSideRMSJitter[pinIndex] = pin_it->second.find(lane)->second.rightSideJitter.rms * factorRMS;
        break;
      case JitterUtilHX::BOTH_JITTER:
        leftSidePPJitter[pinIndex] = pin_it->second.find(lane)->second.leftSideJitter.peak2peak * factorPP;
        leftSideRMSJitter[pinIndex] = pin_it->second.find(lane)->second.leftSideJitter.rms * factorRMS;
        rightSidePPJitter[pinIndex] = pin_it->second.find(lane)->second.rightSideJitter.peak2peak * factorPP;
        rightSideRMSJitter[pinIndex] = pin_it->second.find(lane)->second.rightSideJitter.rms * factorRMS;
        break;
      case JitterUtilHX::AUTOSYNC_FAIL:
      case JitterUtilHX::LEFT_TRANSITION_FAIL:
      case JitterUtilHX::RIGHT_TRANSITION_FAIL:
      case JitterUtilHX::BOTH_TRANSITION_FAIL:
        leftSidePPJitter[pinIndex] = NAN;
        leftSideRMSJitter[pinIndex] = NAN;
        rightSidePPJitter[pinIndex] = NAN;
        rightSideRMSJitter[pinIndex] = NAN;
        break;
      default:
        break;
      }//end for switch
    }//end for lane
  }//end for pinlist

  //MPR log
  if (testlimit.isLimitTableUsed) //limit table way
  {
    switch (commonParameter.transition)
    {
    case JitterUtilHX::LEFT:
      TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
                                                            testlimit.ppTestname, V93kLimits::tmLimits, leftSidePPJitter);
      TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
                                                            testlimit.rmsTestname, V93kLimits::tmLimits, leftSideRMSJitter);
      break;
    case JitterUtilHX::RIGHT:
      TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
                                                            testlimit.ppTestname, V93kLimits::tmLimits, rightSidePPJitter);
      TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
                                                            testlimit.rmsTestname, V93kLimits::tmLimits, rightSideRMSJitter);
      break;
    case JitterUtilHX::BOTH:
      TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
                                                            testlimit.ppTestname, V93kLimits::tmLimits, leftSidePPJitter);
      TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
                                                            testlimit.rmsTestname, V93kLimits::tmLimits, leftSideRMSJitter);
      TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
                                                            testlimit.ppTestname, V93kLimits::tmLimits, rightSidePPJitter);
      TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
                                                            testlimit.rmsTestname, V93kLimits::tmLimits, rightSideRMSJitter);
      break;
    default:
      break;
    }
  }
  else // testflow limit way
  {
    switch (commonParameter.transition)
    {
    case JitterUtilHX::LEFT:
      TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
                                                              testlimit.ppTestname, testlimit.ppJitterLimit, leftSidePPJitter);
      TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
                                                              testlimit.rmsTestname, testlimit.rmsJitterLimit, leftSideRMSJitter);
      break;
    case JitterUtilHX::RIGHT:
      TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
                                                              testlimit.ppTestname, testlimit.ppJitterLimit, rightSidePPJitter);
      TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
                                                              testlimit.rmsTestname, testlimit.rmsJitterLimit, rightSideRMSJitter);

      break;
    case JitterUtilHX::BOTH:
      TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
                                                              testlimit.ppTestname, testlimit.ppJitterLimit, leftSidePPJitter);
      TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
                                                              testlimit.rmsTestname, testlimit.rmsJitterLimit, leftSideRMSJitter);
      TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
                                                              testlimit.ppTestname, testlimit.ppJitterLimit, rightSidePPJitter);
      TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
                                                              testlimit.rmsTestname, testlimit.rmsJitterLimit, rightSideRMSJitter);
      break;
    default:
      break;
    }//end for switch


  }//end for lane

}

/**
 *-----------------------------------------------------------------------------
 * Routine: reportToUI
 *
 * Purpose: output result to ui_report window
 *
 *-----------------------------------------------------------------------------
 * Description:
 *   display:
 *       a) summary,just give the summary test result in ui_report
 *       b) detail,will give error count plot and histogram curve
 *       c) analysis,you can get histogram curve in signal analyzer
 *   INPUT:  parameters          - test parameters
 *           results             - result container
 *           output             - "NONE" or "ReportUI"
 *   RETURN:
 * Note:
 *  In every mode of the three display modes, you can get peak_to_peak
 *  and rms value in ui_report window.
 *-----------------------------------------------------------------------------
 */ 
void JitterHistogramUtilHX::reportToUI(
                                      const JitterHistogramParameter& parameters,
                                      const JitterHistogramResultHX& results_hx,
                                      const STRING & output)
{
  if (output == "NONE")
  {
    return;
  }

  JitterUtilHX::JitterParameter commonParameter = parameters.commonParameter;

  STRING_VECTOR::const_iterator it = commonParameter.PinVector.begin();
  STRING_VECTOR::const_iterator it_end = commonParameter.PinVector.end();
  INT siteNumber = CURRENT_SITE_NUMBER();

  map<INT,map<STRING, map<INT, ResultData> > > ::const_iterator site_it;
  map<STRING, map<INT, ResultData> >::const_iterator pin_it;
  map<INT, ResultData>::const_iterator lane_it;

  if (commonParameter.outputMode == JitterUtilHX::OUTPUT_SUMMARY)// summary mode
  {
    cout << "Jitter Test Summary:   " <<endl;
    cout << "site:                  " << siteNumber << endl;
    for (;it != it_end; ++it)
    {
      site_it = results_hx.resultMap.find(siteNumber);
      // because setup error or other error, there is no result for this site.
      if (site_it == results_hx.resultMap.end())
      {
        cout<<"Warning::There is no result fot this site: " 
        << siteNumber <<endl;
        continue;
      }
      pin_it = site_it->second.find(*it);
      //because setup error or other errors,thers is no result for this pin.
      if (pin_it == site_it->second.end())
      {
        cout<<"Warning::There is no result for this pin: " << *it
        <<"in site: " << siteNumber <<endl;
        continue;
      }


      // normal case
      JitterUtilHX::JitterDataHX jitterData_HX = 
      const_cast<JitterUtilHX::JitterDataHX&>(results_hx.jitterDataHX);

      for (int lane=0; lane<jitterData_HX.HXPIN_Resource[siteNumber][*it].Lanes_Number; lane++)
      {

        switch (jitterData_HX.Sync_Result[siteNumber][*it][lane].lastStatus)
        {
        case JitterUtilHX::LEFT_JITTER:
          cout << "Pins:                    " << *it <<endl
          //<< "lanes:                   " << lane <<endl
          << "Left Jitter Result:      " << endl;
          printJitterValue(pin_it->second.find(lane)->second.leftSideJitter.peak2peak,
                           pin_it->second.find(lane)->second.leftSideJitter.rms);
          break;
        case JitterUtilHX::RIGHT_JITTER:
          cout << "Pins:                    " << *it <<endl
          //<< "lanes:                   " << lane <<endl
          << "Right Jitter Result:     " << endl;
          printJitterValue(pin_it->second.find(lane)->second.rightSideJitter.peak2peak,
                           pin_it->second.find(lane)->second.rightSideJitter.rms);
          break;
        case JitterUtilHX::BOTH_JITTER:
          cout << "Pins:                    " << *it <<endl
          //<< "lanes:                   " << lane <<endl
          << "Left Jitter Result:      " << endl;
          printJitterValue(pin_it->second.find(lane)->second.leftSideJitter.peak2peak,
                           pin_it->second.find(lane)->second.leftSideJitter.rms);
          cout << "Right Jitter Result:     " << endl;
          printJitterValue(pin_it->second.find(lane)->second.rightSideJitter.peak2peak,
                           pin_it->second.find(lane)->second.rightSideJitter.rms);
          break;
        case JitterUtilHX::AUTOSYNC_FAIL:
          JitterUtilHX::printWaringMessage(siteNumber,*it,lane);
          cout << "There is no pass pattern!" << endl;
          break;
        case JitterUtilHX::LEFT_TRANSITION_FAIL:
          JitterUtilHX::printWaringMessage(siteNumber,*it,lane);
          cout << "There is no transition on left!" << endl;
          break;
        case JitterUtilHX::RIGHT_TRANSITION_FAIL:
          JitterUtilHX::printWaringMessage(siteNumber,*it,lane);
          cout << "There is no transition on right!" << endl;
          break;
        case JitterUtilHX::BOTH_TRANSITION_FAIL:
          JitterUtilHX::printWaringMessage(siteNumber,*it,lane);
          cout << "There is no transition for both sides!" << endl;
          break;
        default:
          throw Error("JitterHistogramUtil::reportToUI",
                      "There is an unknown status for reportToUI!",
                      "JitterHistogramUtil::reportToUI");
        }//end for switch
      }
    }//end for pinlist
  }//end for summary mode
  else if (commonParameter.outputMode == JitterUtilHX::OUTPUT_DETAIL)//detail mode
  {
    cout << "JItter Test Detail:  " << endl;
    cout << "site:                " << siteNumber <<endl;
    for (;it != it_end; ++it)
    {
      site_it = results_hx.resultMap.find(siteNumber);
      // because setup error or other error, there is no result for this site.
      if (site_it == results_hx.resultMap.end())
      {
        cout<<"Warning::There is no result fot this site: " 
        << siteNumber <<endl;
        continue;
      }
      pin_it = site_it->second.find(*it);
      // because setup error or other error, there is no result for this pin.
      if (pin_it == site_it->second.end())
      {
        cout<<"Warning::There is no result for this pin: " << *it
        <<"in site: " << siteNumber <<endl;
        continue;
      }

      // normal case 
      JitterUtilHX::JitterDataHX jitterData_HX = 
      const_cast<JitterUtilHX::JitterDataHX&>(results_hx.jitterDataHX);

      for (int lane=0; lane<jitterData_HX.HXPIN_Resource[siteNumber][*it].Lanes_Number; lane++)
      {

        switch (jitterData_HX.Sync_Result[siteNumber][*it][lane].lastStatus)
        {
        case JitterUtilHX::LEFT_JITTER:
          cout << "Pins:                           " << *it << endl
          //<< "lanes:                   " << lane <<endl
          << "Left Jitter Error Count Plot:   " <<endl;
          printHistogram(jitterData_HX.Sync_Result[siteNumber][*it][lane].leftErrorCount);

          cout << "Left Jitter Histogram Curve:   " << endl;
          printHistogram(pin_it->second.find(lane)->second.leftHistogramData);
          printJitterValue(pin_it->second.find(lane)->second.leftSideJitter.peak2peak,
                           pin_it->second.find(lane)->second.leftSideJitter.rms);
          break;
        case JitterUtilHX::RIGHT_JITTER:
          cout << "Pins:                            " << *it << endl
          //<< "lanes:                   " << lane <<endl
          << "Right Jitter Error Count Plot:   " <<endl;
          printHistogram(jitterData_HX.Sync_Result[siteNumber][*it][lane].rightErrorCount);

          cout << "Right Jitter Histogram Curve:   " << endl;
          printHistogram(pin_it->second.find(lane)->second.rightHistogramData);
          printJitterValue(pin_it->second.find(lane)->second.rightSideJitter.peak2peak,
                           pin_it->second.find(lane)->second.rightSideJitter.rms);
          break;
        case JitterUtilHX::BOTH_JITTER:
          cout << "Pins:                            " << *it << endl
          //<< "lanes:                   " << lane <<endl
          << "Left Jitter Error Count Plot:   " <<endl;
          printHistogram(jitterData_HX.Sync_Result[siteNumber][*it][lane].leftErrorCount);

          cout << "Left Jitter Histogram Curve:   " << endl;
          printHistogram(pin_it->second.find(lane)->second.leftHistogramData);
          printJitterValue(pin_it->second.find(lane)->second.leftSideJitter.peak2peak,
                           pin_it->second.find(lane)->second.leftSideJitter.rms);

          cout << "Right Jitter Error Count Plot:   " <<endl;
          printHistogram(jitterData_HX.Sync_Result[siteNumber][*it][lane].rightErrorCount);

          cout << "Right Jitter Histogram Curve:   " << endl;
          printHistogram(pin_it->second.find(lane)->second.rightHistogramData);
          printJitterValue(pin_it->second.find(lane)->second.rightSideJitter.peak2peak,
                           pin_it->second.find(lane)->second.rightSideJitter.rms);
          break;            
        case JitterUtilHX::AUTOSYNC_FAIL:
          JitterUtilHX::printWaringMessage(siteNumber,*it,lane);
          cout << "There is no pass pattern!" << endl;
          break;
        case JitterUtilHX::LEFT_TRANSITION_FAIL:
          JitterUtilHX::printWaringMessage(siteNumber,*it,lane);
          cout << "There is no transition on left!" << endl;
          break;
        case JitterUtilHX::RIGHT_TRANSITION_FAIL:
          JitterUtilHX::printWaringMessage(siteNumber,*it,lane);
          cout << "There is no transition on right!" << endl;
          break;
        case JitterUtilHX::BOTH_TRANSITION_FAIL:
          JitterUtilHX::printWaringMessage(siteNumber,*it,lane);
          cout << "There is no transition for both sides!" << endl;
          break;
        default:
          throw Error("JitterHistogramUtil::reportToUI",
                      "There is an unknown status for reportToUI!",
                      "JitterHistogramUtil::reportToUI");
        }
      }
    }
  }
  else // analysis mode
  {
    cout << "Jitter Test Analysis:    " << endl;
    cout << "site       :             " << siteNumber << endl;
    for (;it != it_end; ++it)
    {
      site_it = results_hx.resultMap.find(siteNumber);
      // because setup error or other error, there is no result for this site.
      if (site_it == results_hx.resultMap.end())
      {
        cout<<"Warning::There is no result fot this site: " << siteNumber <<endl;
        continue;
      }
      pin_it = site_it->second.find(*it);
      // because setup error or other error, there is no result for this pin.
      if (pin_it == site_it->second.end())
      {
        cout<<"Warning::There is no result for this pin: " << *it
        <<"in site: " << siteNumber <<endl;
        continue;
      }

      // normal case
      JitterUtilHX::JitterDataHX jitterData_HX = 
      const_cast<JitterUtilHX::JitterDataHX&>(results_hx.jitterDataHX);


      for (int lane=0; lane<jitterData_HX.HXPIN_Resource[siteNumber][*it].Lanes_Number; lane++)
      {

        switch (jitterData_HX.Sync_Result[siteNumber][*it][lane].lastStatus)
        {
        case JitterUtilHX::LEFT_JITTER:
          {
            WAVE_LOG histogramWaveLeft;
            prepareDataForAnalyzer(pin_it->first,lane,
                                   pin_it->second.find(lane)->second.leftHistogramData,
                                   histogramWaveLeft);
            PUT_DEBUG(*it,"LEFT HISTOGRAM",histogramWaveLeft);
          }
          cout << "Pins:                    " << *it <<endl;
          //cout << "lanes:                    " << lane <<endl;
          cout << "Left Jitter Result:      " << endl;
          printJitterValue(pin_it->second.find(lane)->second.leftSideJitter.peak2peak,
                           pin_it->second.find(lane)->second.leftSideJitter.rms);
          break;
        case JitterUtilHX::RIGHT_JITTER:
          {
            WAVE_LOG histogramWaveRight;
            prepareDataForAnalyzer(pin_it->first,lane,
                                   pin_it->second.find(lane)->second.rightHistogramData,
                                   histogramWaveRight);
            PUT_DEBUG(*it,"RIGHT HISTOGRAM",histogramWaveRight);
          }
          cout << "Pins:                    " << *it <<endl;
          //cout << "lanes:                    " << lane <<endl;
          cout << "Right Jitter Result:     " << endl;
          printJitterValue(pin_it->second.find(lane)->second.rightSideJitter.peak2peak,
                           pin_it->second.find(lane)->second.rightSideJitter.rms);
          break;
        case JitterUtilHX::BOTH_JITTER:
          {
            WAVE_LOG histogramWaveLeft;
            prepareDataForAnalyzer(pin_it->first,lane,
                                   pin_it->second.find(lane)->second.leftHistogramData,
                                   histogramWaveLeft);
            PUT_DEBUG(*it,"LEFT HISTOGRAM",histogramWaveLeft);

            WAVE_LOG histogramWaveRight;
            prepareDataForAnalyzer(pin_it->first,lane,
                                   pin_it->second.find(lane)->second.rightHistogramData,
                                   histogramWaveRight);
            PUT_DEBUG(*it,"RIGHT HISTOGRAM",histogramWaveRight);
          }
          cout << "Pins:                    " << *it <<endl;
          //cout << "lanes:                    " << lane <<endl;
          cout << "Left Jitter Result:      " << endl;
          printJitterValue(pin_it->second.find(lane)->second.leftSideJitter.peak2peak,
                           pin_it->second.find(lane)->second.leftSideJitter.rms);
          cout << "Right Jitter Result:     " << endl;
          printJitterValue(pin_it->second.find(lane)->second.rightSideJitter.peak2peak,
                           pin_it->second.find(lane)->second.rightSideJitter.rms);
          break;
        case JitterUtilHX::AUTOSYNC_FAIL:
          JitterUtilHX::printWaringMessage(siteNumber,*it,lane);
          cout << ", there is no pass pattern!" << endl;
          break;
        case JitterUtilHX::LEFT_TRANSITION_FAIL:    
          JitterUtilHX::printWaringMessage(siteNumber,*it,lane);
          cout << "There is no transition on left!" << endl;
          break;
        case JitterUtilHX::RIGHT_TRANSITION_FAIL:
          JitterUtilHX::printWaringMessage(siteNumber,*it,lane);
          cout << "Tthere is no transition on right!" << endl;
          break;
        case JitterUtilHX::BOTH_TRANSITION_FAIL:
          JitterUtilHX::printWaringMessage(siteNumber,*it,lane);
          cout << "There is no transition for both sides!" << endl;
          break;
        default:
          throw Error("JitterHistogramUtil::reportToUI",
                      "There is an unknown status for reportToUI!",
                      "JitterHistogramUtil::reportToUI");
        }
      }
    }
  }
}

/**
 *-----------------------------------------------------------------------------
 *Routine: JitterHistogramUtil::printHistogram
 *
 *Purpose: print histogram to ui_report window
 *-----------------------------------------------------------------------------
 *Parameters:
 * 1)histogramData: histogram data 
 *-----------------------------------------------------------------------------
 */

void JitterHistogramUtilHX::printHistogram(const vector<INT> & histogramData)
{
  INT length = histogramData.size();
  // use function max_element get the max value of the ErrorCount Array
  INT maxValue = *(max_element(histogramData.begin(),histogramData.end()));
  //because the error count number offen is very big, so we adjust the number
  //every line can out put 80 "*" most
  for (INT index = 0;index < length; ++index)
  {
    double refence = 0.0;
    if (maxValue != 0)
    {
      refence = static_cast<double>(histogramData[index])/maxValue;
    }
    INT bar = static_cast<INT>(refence *80);
    for (INT i=0;i < bar;++i)
    {
      cout << "*";
    }
    cout << endl;
  }
}


void JitterHistogramUtilHX::printJitterValue(const DOUBLE peak2peak,
                                             const DOUBLE rms)
{
  //user's input unit is ns,translate ns to ps
  const INT factor = 1000;
  cout << "       peak_to_peak[ps]:     " << peak2peak * factor << endl; 
  cout << "                rms[ps]:     " << rms * factor << endl; 
}


void JitterHistogramUtilHX::prepareDataForAnalyzer(
                                                  const STRING & pinName,
                                                  const INT & lane,
                                                  const vector<INT>& histogramData,
                                                  WAVE_LOG& dataForAnalyzer)
{
  INT sizeOfArray = histogramData.size();
  ARRAY_I histogramDataArray(sizeOfArray);
  for (INT loop =0;loop < sizeOfArray;loop++)
  {
    histogramDataArray[loop] = histogramData[loop];
  }

  char buffer [33];
  sprintf(buffer, "%d", lane);

  dataForAnalyzer.xTitle("Time");
  dataForAnalyzer.xUnit("ns");
  dataForAnalyzer.yAxis(histogramDataArray);  
  //dataForAnalyzer.yTitle(pinName + itoa(lane, buffer, 10) + " Histogram Data");
  dataForAnalyzer.yTitle(pinName + buffer + " Histogram Data");
  dataForAnalyzer.yUnit("Number");
}
#endif /*INCLUDE_JITTERHISTOGRAMHX_H*/
