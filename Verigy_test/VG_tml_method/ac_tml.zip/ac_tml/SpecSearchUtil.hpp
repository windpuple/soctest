#ifndef INCLUDE_SPECSPEARCH_HPP
#define INCLUDE_SPECSPEARCH_HPP
#include "CommonUtil.hpp"
#include <cmath>
/*----------------------------------------------------
 * This file contains utilities for
 * (1)standard spec search 
 * (2)parametric functional test
 *---------------------------------------------------- 
 */
#define SPEC_SEARCH_NO_VALUE 9999
class SpecSearchUtil
{
public:

/*
 *----------------------------------------------------------------------*
 *         test parameters container                                    *
 *----------------------------------------------------------------------*
 */
  struct SpecSearchUtilParam
  {
    /*original input parameters*/
    STRING specName;    
    STRING setupPinlist;
    STRING unit;
    STRING resultPinlist;
    
    /*new generated parameter for convenience*/
    
    /* the min, max ,step, resolution are convert result of min,max,step 
     * and resolution parameters in processParameters() in order*/
    DOUBLE minValue;               
    DOUBLE maxValue;
    DOUBLE stepValue;
    DOUBLE resolutionValue;
    DOUBLE passMaxValue; /*if has limit setting, set judgement range for final result analysis*/
    DOUBLE passMinValue;
    
    bool hasMinValue;         /* if the min, max, step, resolution &limitis valid*/
    bool hasMaxValue;
    bool hasStepValue;
    bool hasResolutionValue;
    bool hasLimit;
    
    TM::SPEC_TYPE type;      /* Timing or level spec search?*/
    TM::SPEC_METHOD method;  /* Linear, binary or linbin?*/
    
    STRING testSuiteName;    /*current testsuite name*/
   
    /*initialize stuff to some defaults.*/ 
    void init()
    {
      specName = "";
      setupPinlist = "";
      unit = "";
      resultPinlist = "";
      minValue = 0.0;
      maxValue = 0.0;
      passMaxValue = 0.0;
      passMinValue = 0.0;
      stepValue = 0.0;
      resolutionValue = 0.0;  
      hasMinValue = false;
      hasMaxValue = false;
      hasStepValue = false;
      hasResolutionValue = false;
      hasLimit = false;
      type = TM::TIM;
      method = TM::Linear;
    }
    
    /*default constructor for intializing parameters*/ 
    SpecSearchUtilParam()
    {
      init();
    }
  };
  
  /*
   *----------------------------------------------------------------------*
   *         test results container                                       *
   *----------------------------------------------------------------------*
   */
  struct SpecSearchUtilResult
  {
    /*TM::TransitionPassFail, TM::TransitionFailPass, TM::AllPass or TM::AllFail */
    TM::SPEC_RESULT specResult;  
    bool isPassed;       
    DOUBLE p_value;
    DOUBLE f_value;
    /*In case of single density platform,
     *need keep this search object for datalog.
     */
    SPEC_SEARCH *pLegacySearchInstance; 

    /*initialize all stuffs to some defaults.*/
    void init()
    {
      specResult = TM::AllFail;
      isPassed = false;
      p_value = NAN;
      f_value = NAN;
      if (pLegacySearchInstance != 0)
      {
        delete pLegacySearchInstance;
        pLegacySearchInstance = 0;
      }
    }
    
    SpecSearchUtilResult():pLegacySearchInstance(0)
    {
      init();
    }

    ~SpecSearchUtilResult()
    {
      if (pLegacySearchInstance != 0)
      {
        delete pLegacySearchInstance;
        pLegacySearchInstance = 0;
      }
    }
  };


  struct SpecSearchUtilLimit
  {
    bool isLimitTableUsed;
    string testname;
    int testnumber;
    string softBinNumberString;
    int hardBinNumber;
    LIMIT specSearchLimit;  
  };

  static void processLimits(
  const string& testname,
  SpecSearchUtilParam& pftParam, 
  SpecSearchUtilLimit& limits);
/*
 *----------------------------------------------------------------------*
 *         public interfaces of spec search  test                       *
 *----------------------------------------------------------------------*
 */

/*
 *----------------------------------------------------------------------*
 * Routine: processParameter
 *
 * Purpose: parse input parameters and setup internal parameters
 *
 *----------------------------------------------------------------------*
 * Description:
 *   
 * Note:
 *----------------------------------------------------------------------*
 */
  static void processParameters(
                const STRING& specName,
                const STRING& type,
                const STRING& setupPinlist,
                const STRING& unit,
                const STRING& method,
                const double min,
                const double max,
                const STRING& step,
                const STRING& resolution,
                const STRING& resultPinlist,
                SpecSearchUtilParam& param)
  {
    param.init();
    param.setupPinlist = CommonUtil::trim(setupPinlist);
    param.resultPinlist = CommonUtil::trim(resultPinlist); 
    param.specName = CommonUtil::trim(specName);   
    param.unit = CommonUtil::trim(unit);
    if (param.setupPinlist.empty())
    {    
      param.setupPinlist  = "@";
    }   
    checkSetupAndResultPinListType(param.setupPinlist,param.resultPinlist);
    
    param.type = convertStringToSearchType(type);
    param.method = convertStringToMethod(method);

    setMinMaxStepResolution(min, 
                            max, 
                            step, 
                            resolution, 
                            param); 
                                   
    GET_TESTSUITE_NAME(param.testSuiteName);    
  }
  
  /*
   *----------------------------------------------------------------------*
   * Routine: doMeasurement
   *
   * Purpose: execute measurement and store results
   *
   *----------------------------------------------------------------------*
   * Description:
   *   INPUT:  param       - test parameters
   *           result      - result container
   *
   *   OUTPUT: 
   *   RETURN: 
   *----------------------------------------------------------------------*
   */
  static void doMeasurement(const SpecSearchUtilParam& param,SpecSearchUtilLimit& limit, SpecSearchUtilResult& result)
  {
    SEARCH_FUNC_TASK task;

    ON_FIRST_INVOCATION_BEGIN();
          
      CONNECT();   
      FW_TASK("SQGB ACQF,0;");
      SEARCH_FUNC_PIN_TASK& pin_task = task.pin(param.setupPinlist);    
      pin_task.spec(param.specName,param.type).method(param.method);
      if (!param.resultPinlist.empty())
      {
        pin_task.resultPins(param.resultPinlist);
      }
        
      if(param.hasMinValue)
      {
        pin_task.start(param.minValue);       
      }
         
      if(param.hasMaxValue) 
      {
        pin_task.stop(param.maxValue);
      }
         
      if(param.hasStepValue)
      {
        pin_task.stepWidth(param.stepValue);
      }
         
      if(param.hasResolutionValue)
      {
        pin_task.resolution(param.resolutionValue);
      }
         
      task.execute();
         
    ON_FIRST_INVOCATION_END(); 
    result.specResult = task.getResultSpec(param.setupPinlist); 
    result.isPassed = task.getPassFail(param.setupPinlist);//initialize by real spec search result

    if(result.isPassed)
    {
      result.p_value = task.getPassValue(param.setupPinlist);
      result.f_value = task.getFailValue(param.setupPinlist);    
      if(param.hasLimit)
      { 
        double dResultMin = min(result.p_value,result.f_value);   
        double dResultMax = max(result.p_value,result.f_value);
        if(!( dResultMin > param.passMinValue & 
              dResultMax < param.passMaxValue))
          {
            result.isPassed =  false;
          }
      }
    }
  }
  
  /*
   *----------------------------------------------------------------------*
   * Routine: judgeAndDatalog
   *
   * Purpose: judge and put result into event datalog stream.
   *
   *----------------------------------------------------------------------*
   * Description:
   *   judge results of 'result' with pass limits from 'param'
   * 
   *   INPUT:  param       - test parameters
   *           result      - result container
   *           testname    - test limit name
   *   OUTPUT: 
   *           _results[4] - four results used by tf_result in testflow.
   *   RETURN: 
   * Note:
   *----------------------------------------------------------------------*
   */
  static void judgeAndDatalog(const SpecSearchUtilParam& param,
                              const SpecSearchUtilResult& result,
                              const string& testname,
                              SpecSearchUtilLimit& limit,
                              double _results[4])
  {   
    if(limit.isLimitTableUsed)
    {
      //pass value
      TESTSET().cont(TM::CONTINUE).testnumber(limit.testnumber)
               .judgeAndLog_ParametricTest(param.setupPinlist,
                                           testname,
                                           result.isPassed?TM::Pass : TM::Fail,
                                           result.p_value);
      //fail value
      TESTSET().cont(TM::CONTINUE).testnumber(limit.testnumber)
               .judgeAndLog_ParametricTest(param.setupPinlist,
                                           testname,
                                           result.isPassed?TM::Pass : TM::Fail,
                                           result.f_value);
      if (!result.isPassed && !limit.softBinNumberString.empty())
      {
        SET_MULTIBIN(limit.softBinNumberString,limit.hardBinNumber);
      }
    }
    else //limit in testflow is used
    {  
      TESTSET().cont(TM::CONTINUE)
               .judgeAndLog_ParametricTest(param.setupPinlist,
                                           testname,
                                           result.isPassed?TM::Pass : TM::Fail,
                                           result.p_value);

      TESTSET().cont(TM::CONTINUE)
               .judgeAndLog_ParametricTest(param.setupPinlist,
                                           testname,
                                           result.isPassed?TM::Pass : TM::Fail,
                                           result.f_value); 
    }    

    //set values for _results[4]
    if (result.specResult == TM::TransitionPassFail ||
        result.specResult == TM::TransitionFailPass)
    {
      _results[0] = _results[1] = result.p_value;
      _results[2] = _results[3] = result.f_value;
    }
    else if (result.specResult == TM::AllPass)
    {
      _results[0] = _results[1] = _results[2] = _results[3] = 0;
    }
    else //TM::AllFail
    {
      _results[0] = _results[1] = _results[2] = _results[3] = 1;
    }

  }
  
  /*
   *----------------------------------------------------------------------*
   * Routine: reportToUI
   *
   * Purpose: output result to UIWindow 
   *
   *----------------------------------------------------------------------*
   * Description:
   *   display: 
   *       a) pass or fail,
   *       b) pass and fail value.
   * 
   *   INPUT:  param              - test parameters
   *           result             - result container
   *           output             - "None" or "ReportUI" 
   *   OUTPUT: 
   *   RETURN:  
   * Note:
   *----------------------------------------------------------------------*
   */  
  static void reportToUI(const SpecSearchUtilParam& param, 
                         const SpecSearchUtilResult& result,
                         const STRING& output)
  {
    if (output != "ReportUI")
    {
      return;
    }
    const static INT OUTPUT_WIDTH = 10;
    if(result.isPassed == TRUE)
    { 
      cout<<"Spec Search Success :"<<endl;
      cout<<param.specName<<"                          P = "
          <<setiosflags(ios_base::left)<<setw(OUTPUT_WIDTH) <<result.p_value
          <<"   "<<param.unit<<"             P"<<endl;
          
      cout<<param.specName<<"                          F = "
          <<setiosflags(ios_base::left)<<setw(OUTPUT_WIDTH) <<result.f_value
          <<"   "<<param.unit<<"             P"<<endl;  
    }
    else
    {
      cout<<"Spec Search Fail :"<<endl;
      cout<<output<<"                          P = ******             F"<<endl;
      cout<<output<<"                          F = ******             F"<<endl;
    }
  }
 
 private: 
   static void processSearchLimitWithParam(
               SpecSearchUtilParam& pftParam, 
               LIMIT& limit);

   static bool checkSetupPinList(const STRING& pins);
   
   static TM::SPEC_METHOD convertStringToMethod(const STRING& methodString);
   
   static TM::SPEC_TYPE convertStringToSearchType(const STRING& typeString);
    
   static bool checkSetupAndResultPinListType(
                                 const STRING& setupPinlist,
                                 const STRING& resultPinlist);                                
    
   static void setMinMaxStepResolution(
                                 const    double min, 
                                 const    double max,
                                 const    STRING& step, 
                                 const    STRING& resolution,
                                 SpecSearchUtilParam& param );
                               
    static DOUBLE convertStringToStepWidth(
                                 const STRING& step_value,
                                 const DOUBLE min, 
                                 const DOUBLE max);                                       
};

/*
 *----------------------------------------------------------------------*
 * Routine: SpecSearchUtil::checkSetupPinList
 *
 * Purpose: judge whether the spec spec is I,O,IO,DPS pin
 *
 *----------------------------------------------------------------------*
 * Description:                                          
 *
 * Note:         
 *
 * Parameters:  STRING& pins : pinlist name                        
 *
 * Return Value: if not I or O or IO or DPS pin throw error, or else 
 *               return whether the pinlist include DPS pin       
 *               use which API will based on whether it has DPS pin 
 *----------------------------------------------------------------------*
 */
inline bool SpecSearchUtil::checkSetupPinList(const STRING& pins)
{
  bool hasDpsPin = false;

  /*Default value,handled by the Firmware*/
  if(pins == "") return false; 
  string::size_type first = 0;
  string::size_type end;
  for(;;)
  {
    end = pins.find_first_of(",",first);
    STRING one_pin = pins.substr(first,end-first);
    try
    {
      /*throw an exception if not O,IO,I pin*/
      PinUtility.getDigitalPinNamesFromPinList(one_pin,
                                               TM::O_PIN|TM::IO_PIN|TM::I_PIN,
                                               TRUE,
                                               TRUE);
    }
    catch (ErrorInfo& e)
    {
      /*throw an exception if not I,O,IO,DPS pins*/
      try
      {
        PinUtility.getDpsPinNamesFromPinList(one_pin,TRUE);
        hasDpsPin = true;
      }
      catch (ErrorInfo& e)
      {
        STRING api = "Check setup pin : ";
        STRING msg = "There is a pin["+one_pin
                     +"] is not any kind of I,O,IO,DPS pin!";
        throw Error(api.c_str(),msg.c_str(),api.c_str());
      }
    }
               
    if(end == string::npos) {break;}
    first = end + 1;       
  }
    
  return hasDpsPin;
}

/*
 *----------------------------------------------------------------------*
 * Routine: SpecSearchUtil::convertStringToMethod
 *
 * Purpose: convert a string to spec_method
 *
 *----------------------------------------------------------------------*
 * Description:
 *
 * Note:        SPEC_SEARCH can't support input string in method() directly, 
 *              but SEARCH_FUNC_TASK can support it
 *
 * Parameters:  STRING input:  (linear |binary |lin/bin only) 
 *
 * Return Value: output SPEC_METHOD
 *
 *----------------------------------------------------------------------*
 */
inline TM::SPEC_METHOD 
SpecSearchUtil::convertStringToMethod(const STRING& methodString) 
{
  STRING trimMethodString = CommonUtil::trim(methodString);
  if(trimMethodString == "linear") 
  {
    return TM::Linear;
  }
  if(trimMethodString == "binary") return TM::Binary;
  if(trimMethodString == "lin/bin") return TM::LinBin;
  
  STRING api = "Spec_search: convertStringToMethod : ";
  STRING msg = "SearchType must be linear | binary | lin/bin ! " 
               + trimMethodString + "is illegal!";
  throw Error(api.c_str(),msg.c_str(),api.c_str()); 
}

/*
 *----------------------------------------------------------------------*
 * Routine: SpecSearchUtil::convertStringToSearchType
 *
 * Purpose: convert a string to spec_type
 *
 *----------------------------------------------------------------------*
 * Description:
 *
 * Note:        SPEC_SEARCH can't support input string in type() 
 *              directly, but SEARCH_FUNC_TASK can support it                                                                                                           
 *
 * Parameters:  STRING input:  (timing/level only) 
 *
 * Return Value: output SPEC_TYPE
 *
 *----------------------------------------------------------------------*
 */
inline TM::SPEC_TYPE 
SpecSearchUtil::convertStringToSearchType(const STRING& searchTypeString) 
{
  STRING trimSearchTypeString = CommonUtil::trim(searchTypeString);
  if(trimSearchTypeString == "TIM") return TM::TIM;
  if(trimSearchTypeString == "LEV") return TM::LEV;
  
  STRING api = "Spec_search: convertStringToSearchType : ";
  STRING msg = "SearchType must be timing | level ! " + trimSearchTypeString + " is illegal!";
  throw Error(api.c_str(),msg.c_str(),api.c_str()); 
}

/*
 *----------------------------------------------------------------------*
 * Routine: SpecSearchUtil::checkSetupAndResultPinListType
 *
 * Purpose: judge whether the spec spec is I,O,IO,DPS pin  and whether the 
 *          result pin is O,IO pin
 *
 *----------------------------------------------------------------------*
 * Description:                                          
 *
 * Note:         
 *
 * Parameters:  1. STRING& setupPinlist :                                                                                   
 *                 spec pinlist name                                                                                  
 *              2. STRING& resultPinlist :                                                                                   
 *                 result pinlist name                         
 *
 * Return Value: if not I or O or IO or DPS pin throw error, or else 
 *               return true if the pinlist include DPS pin ,false if not
 *
 *----------------------------------------------------------------------*
 */
inline bool SpecSearchUtil::checkSetupAndResultPinListType(
                                    const STRING& setupPinlist,
                                    const STRING& resultPinlist)
{    
  /*judge the result pin is 0,IO
    if not,it will throw an exception */
  
  if ( resultPinlist!= "@" )
  { /*if "@", skip checking ... */ 
    PinUtility.getDigitalPinNamesFromPinList(resultPinlist,
                                             TM::O_PIN|TM::IO_PIN,
                                             TRUE,
                                             TRUE);
  }  
  /*judge the spec pin is I,O,IO,DPS */
  return (checkSetupPinList(setupPinlist));
}

/*
 *----------------------------------------------------------------------*
 * Routine: SpecSearchUtil::setMinMaxStepResolution
 *
 * Purpose: check the validation of parameters.
 *
 *----------------------------------------------------------------------*
 * Description:
 *
 * Note:
 *
 * Parameters:  1. double min : 
 *              2. double max : 
 *              3. STRING& step : optional                                                                            
 *              4. STRING& resolution : optional
 *              5. SpecSearchUtilParam& param: parameter container                                                                        
 *
 * Return Value: none
 *
 *----------------------------------------------------------------------*
 */
inline void SpecSearchUtil::setMinMaxStepResolution(
  const double min,
  const double max,
  const STRING& step, 
  const STRING& resolution, 
  SpecSearchUtilParam& param )
{
  STRING api,msg; 
    
  /*check specName*/  
  if(param.specName == "")
  { 
    api = "Spec_search: checkParameters-specName : ";
    msg = "spec name can't be empty!";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }

  if(fabs(min - SPEC_SEARCH_NO_VALUE) <= 1e-16) //no valid min value is input
  {
    param.minValue = 0;
    param.hasMinValue = false;
  }
  else
  {
    param.minValue = min;
    param.hasMinValue = true;
  }

  if(fabs(max - SPEC_SEARCH_NO_VALUE) <= 1e-16) //no valid max value is input
  {
    param.maxValue = 0;
    param.hasMaxValue = false;
  }
  else
  {
    param.maxValue = max;
    param.hasMaxValue = true;
  }
   
  /*check min & max*/
  if(param.hasMinValue && param.hasMaxValue && 
     (param.minValue - param.maxValue >= -1e-9 && 
      param.minValue - param.maxValue <= 1e-9))
    /*if the difference between min and max is enough small, 
     * they are considered to be equal*/
  {
    api = "Spec_search: checkParameters-min&max : ";
    msg = "min can't equal to max!";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }
   
  /*check step*/
  if(CommonUtil::trim(step) != "")
  {
    if(!param.hasMinValue || !param.hasMaxValue)
    {
      api = "Spec_search: checkParameters-step:";
      STRING msg = "min & max can't be empty when step = " + step + " is not empty!";
      throw Error(api.c_str(),msg.c_str(),api.c_str());
    }
    else
    {
      param.stepValue = convertStringToStepWidth(step,param.minValue,param.maxValue);
      param.hasStepValue = true;
      if(param.stepValue <= 0)
      {
        api = "Spec_search: checkParameters-step["+step+"] : ";
        msg = "step can't less or equal to 0!";
        throw Error(api.c_str(),msg.c_str(),api.c_str());            
      }
    }
  }
  else if(param.method == TM::Linear || param.method == TM::LinBin)
  {
    api = "Spec_search: checkParameters-step["+step+"] : ";
    msg = "step can't be empty when using linear | lin/bin method!";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }
  else
  {
    param.hasStepValue = false;
  }
   
  /*check resolution*/
  if(CommonUtil::trim(resolution) != "")
  {
    param.resolutionValue = CommonUtil::string2Double(resolution,"resolution");
    param.hasResolutionValue = true;
    if(param.resolutionValue <= 0)
    {
      api = "Spec_search: checkParameters-resolution["+resolution+"] : ";
      msg = "resolution can't less or equal to 0!";
      throw Error(api.c_str(),msg.c_str(),api.c_str());        
    }
  }
  else 
  {
    /*SPEC_SEARCH API need set resolution before excute, but 
      SEAR_FUNC_TASK API need not.Delay this judgement after 
      choosing searial way or parallel way to do spec search*/
    param.hasResolutionValue = false;
  }   
}

/*
 *----------------------------------------------------------------------*
 * Routine: SpecSearchUtil::convertStringToStepWidth
 *
 * Purpose: convert a string to step width
 *
 *----------------------------------------------------------------------*
 * Description:
 *
 * Note:        if input string start with "#" means step number,
 *              or else means step width
 *
 * Parameters:  1. STRING step_value :                                                                                
 *                 a string content step info                                                                                                                       
 *              2. DOUBLE min :                                                                                       
 *                 start value                                                                                        
 *              3. DOUBLE max :                                                                                       
 *                 stop value   
 *
 * Return Value: output step width value
 *
 *----------------------------------------------------------------------*
 */
inline DOUBLE SpecSearchUtil::convertStringToStepWidth(
                                         const STRING& step_value,
                                         const DOUBLE min, 
                                         const DOUBLE max)
{
  DOUBLE result;
  STRING first = step_value.substr(0,1);
  if(first == "#")
  {
    DOUBLE number = CommonUtil::string2Double(
                        step_value.substr(1,step_value.length()-1),
                        "stepNum");
    result = (max-min)/number;
  }
  else
  {
    result = CommonUtil::string2Double(step_value,"stepWidth");
  }
  return result;
}




/*
 *----------------------------------------------------------------------*
 * Routine: SpecSearchUtil::processSearchLimitWithParam
 *
 * Purpose: prepare limit 
 *
 *
 *----------------------------------------------------------------------*
 *if limit is set, nothing is changed.
 *if the limit is not set, use pass_min/max parameter as limit value.
 *if the limit and pass_min/max are set, use start,stop as limit value.
 *
 */
inline void SpecSearchUtil::processSearchLimitWithParam(
  SpecSearchUtilParam& pftParam, 
  LIMIT& limit)
{
  double lowValue = 0;
  double highValue = 0;
  bool isLimitLowSet = (limit.getLow(&lowValue) != TM::NA); 
  bool isLimitHighSet = (limit.getHigh(&highValue) != TM::NA);

  if (!isLimitLowSet && !isLimitHighSet)
  { //no limit specified
    pftParam.hasLimit = false;
  }
  else
  {
    pftParam.hasLimit = true;
  }

  //start to check range and limit
  double limitMin = min(lowValue,highValue);
  double limitMax = max(lowValue,highValue);
  double rangMin = min(pftParam.minValue,pftParam.maxValue);
  double rangMax = max(pftParam.minValue,pftParam.maxValue);
  STRING functionName = "SpecSearchUtil::processSearchLimitWithParam";
  double dPassMin = limitMin;
  double dPassMax = limitMax;


  if ( rangMin == rangMax )
  {
    throw Error(functionName,"Invalid search range of 0");
  }
  
  if(!isLimitLowSet)
  {
    dPassMin = rangMin;
  }
  else if(limitMin < rangMin || limitMin > rangMax)
  {   
    throw Error(functionName,
                "A passMin is outside the [start,stop] range is not allowed",
                functionName);    
  }

  if(!isLimitHighSet)
  {
    dPassMax = rangMax;
  }
  else if(limitMax < rangMin || limitMax > rangMax)
  {
    throw Error(functionName,
                "A passMax is outside the [start,stop] range is not allowed",
                functionName);    
  }

  //set back to structure
  pftParam.passMaxValue = dPassMax;
  pftParam.passMinValue = dPassMin;
}


/*
 *----------------------------------------------------------------------*
 * Routine: SpecSearchUtil::processLimits
 *
 * Purpose: prepare limit 
 *
 *
 *----------------------------------------------------------------------*
 */
inline void SpecSearchUtil::processLimits(
  const string& testname, 
  SpecSearchUtilParam& pftParam, 
  SpecSearchUtilLimit& testlimit)
{
  string validName = CommonUtil::trim(testname);
  string::size_type leadPos = validName.find_first_not_of(" ()");
  string::size_type postPos = validName.find_last_not_of(" ()");
  validName = validName.substr(leadPos,postPos-leadPos +1);
  vector<string> limitNames;
  CommonUtil::splitStr(validName,',',limitNames);


  if (limitNames.empty() || limitNames.size() >1)
  {
    throw Error("SpecSearchUtil::processLimits()",
                "Invalid test name parameter.");
  }
  testlimit.testname = limitNames.at(0);

  //check whether limit table is used.
  TestTable* pLimitTable = TestTable::getDefaultInstance();
  pLimitTable->readCsvFile();
  testlimit.isLimitTableUsed = pLimitTable->isTmLimitsCsvFile();
 
  string testsuiteName;
  GET_TESTSUITE_NAME(testsuiteName);

  if (testlimit.isLimitTableUsed)
  {
    try
    {
      string keyInTable = testsuiteName + ":" + testlimit.testname;
      const V93kLimits::TMLimits::LimitInfo& limitInfo = V93kLimits::tmLimits.getLimit(keyInTable);
      testlimit.specSearchLimit = limitInfo.TEST_API_LIMIT;
      testlimit.testnumber = limitInfo.TestNumber;
      testlimit.softBinNumberString = limitInfo.BinsNumString;
      testlimit.hardBinNumber = limitInfo.BinhNum;
    }
    catch(Error e)
    {
      testlimit.isLimitTableUsed = false;
    }
  }
  else //use testflow limit
  {
    testlimit.specSearchLimit = GET_LIMIT_OBJECT(testlimit.testname);
  }

  processSearchLimitWithParam(pftParam,testlimit.specSearchLimit);

  //spec search always use "ns" or "V"
  string targetUnit = (pftParam.type == TM::LEV)?"V":"ns";
  if (testlimit.specSearchLimit.unit().empty())
  {
    testlimit.specSearchLimit.unit(targetUnit);
  }
  else if (CommonUtil::getUnitNameOfLimit(testlimit.specSearchLimit) != targetUnit)
  { 
    throw Error("SpecSearchUtil::processLimits()",
                "the unit of parametric spec search value must be: V or ns.",
                "ParamFuncTestUtil::processLimits()");
  }
}


#endif /*SPECSEARCHTEST_H_*/

