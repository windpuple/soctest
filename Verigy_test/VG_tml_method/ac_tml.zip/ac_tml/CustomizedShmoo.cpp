/**
 * (c) Copyright 2011, Verigy Technologies, all rights reserved.
 *
 * Modification History:
 *
 *
 */

//for testmethod framework interfaces
#include "testmethod.hpp"

//for testmethod API interfaces
#include "mapi.hpp"
#include "AbstractShmoo.hpp"
using namespace std;

/**
 * Testmethod class.
 *
 * For each testsuite using this testmethod, one object of this
 * class is created.
 */

/* This class is used to customize shmoo. In general, it is only
 * needed to modify this file. Other files such as Shmoo.cpp, 
 * AbstractShmoo.hpp are not needed to be modified.
 */ 
class CustomizedShmoo : public AbstractShmoo
{
protected:
  string testMode;
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   *
   *Note: TestMethod API should not be used in this method.
   */
  virtual void initialize() {
    /*First call the initialize() in class AbstractShmoo to add parameters
     *common to all Shmoo.i.e. title, x.start, x.stop, x.step, x.scale, y.start, y.stop
     *y.step, and y.scale. So this line CANNOT be removed.
     */
    AbstractShmoo::initialize();

    /*add your customized test method parameters here.
     *In this example, we add a parameter "testMode".
     */
    addParameter("testMode",
                 "string",
                 &testMode,
                 testmethod::TM_PARAMETER_INPUT)
      .setOptions("PassFail:Value");

  }

  /**
   *This method is called before shmoo runs. In general, it is used to save the
   *Software/HardWare status which may be changed by the method runAtPoint().
   */
  virtual void saveBeforeShmooRun() 
  {

  }

  /**
   *This method is called after shmoo runs. In general, it is used to restore the
   *Software/HardWare status which may have been changed by the method runAtPoint().
   */
  virtual void restoreAfterShmooRun() 
  {
  }

  /**
   *This function is invoked at every Shmoo Point. In this method, you should:
   * 1. change the resource at x axis to 'valueX'.
   * 2. change the resource at y axis to 'valueY'.
   * 3. do a Pass/Fail or Value measurement.
   */
  virtual ShmooCellResult runAtPoint(double valueX, double valueY) 
  {

    ShmooCellResult cellResult;
    cellResult.value = 0;
    if(testMode == "PassFail")
    {
      bool isPass;
      /*If your test is a Pass/Fail Test. Customized here.
       *Customization begin.
       */
      FUNCTIONAL_TEST();
      isPass = GET_FUNCTIONAL_RESULT();
      /*Customization end.*/

      if (isPass) 
      {
        cellResult.resultType = ShmooCellResult::SHMOO_CELL_PASS;
      } 
      else 
      {
        cellResult.resultType = ShmooCellResult::SHMOO_CELL_FAIL;
      }
      
    }
    else
    {
      double value;
      /*If your test is a Value Test. Cusomized here.
       *Customization begin.
       */
      value = valueX + valueY;
      /*Customization end.*/

      cellResult.resultType = ShmooCellResult::SHMOO_CELL_VALUE;
      cellResult.value = value;
    }
    return cellResult;
  }

  /**
   *This method is used to differentiate the values if the testMode is Value.
   *If the difference between the results of two Points is larger than or equal
   *to getResultResolution(), then these two points' results are considered to 
   *be different. Otherwise, their results are considered to be the same.
   *E.g. Suppose the result of Point A is 2 and the result of Point B is 5.
   *     If the getResultResolution() is 2.5. Then the results of A and B
   *     are different, since 5 -2 > 2.5. However, if the getResultResolution() 
   *     is 4. Then the results of A and B are the same, since 5 - 2 < 4.
   */
  double getResultResolution()
  {
    return 1;
  }

  /**
   *This method is used in Shmoo Plot. See Online Document.
   */
  virtual string getShortNameForXAxis() 
  {
    return "CustomizedX";
  }

  /**
   *This method is used in Shmoo Plot. See Online Document.
   */
  virtual string getShortNameForYAxis() 
  {
    return "customizedY";
  }

  /**
   *This method is used in Shmoo Plot. See Online Document.
   */
  virtual string getUnitForXAxis() 
  {
    return "V";
  }

  /**
   *This method is used in Shmoo Plot. See Online Document.
   */
  virtual string getUnitForYAxis() 
  {
    return "V";
  }


  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   *
   *Note: TestMethod API should not be used in this method.
   */
  virtual void postParameterChange(const string& parameterIdentifier) 
  {
    /*First call the postParmeterchange() in class AbstractShmoo. 
     *DON'T remove this line.
     */
    AbstractShmoo::postParameterChange(parameterIdentifier);
    /*add your postParameterChange() here.
     *In this example, we make testMode can be either PassFail or Value.
     *Otherwise, it is invalid.
     */
    if(parameterIdentifier == "testMode")
    {
      getParameter("testMode").setValid(true);
      getParameter("testMode").setMessage("");
      if(testMode != "PassFail" && testMode != "Value")
      {
         getParameter("testMode").setValid(false);
         getParameter("testMode").setMessage("testMode should be PassFail or Value!");
      }
    }
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string  getComment() const
  {
     static string comment = _TML_VERSION;
     return comment;
  }

};
REGISTER_TESTMETHOD("AcTest.CustomizedShmoo", CustomizedShmoo);
