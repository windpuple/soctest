/**
 * (c) Copyright 2011, Verigy Technologies, all rights reserved.
 *
 * Modification History:
 *
 *
 */

//for testmethod framework interfaces
#include "testmethod.hpp"
//for testmethod API interfaces
#include "mapi.hpp"

#include "ParametricFunctionalUtil.hpp"
/**
 *----------------------------------------------------------------------*
 * @testmethod Class: ParametricFunctionalTest
 *
 * @Purpose: parametric functional and spec search test
 *
 *----------------------------------------------------------------------*
 * @Description:
 *   Basically,the parametric functional test is a combination of two
 *   test methods: functionalt test and spec search 
 *   Both tests can be executed separately or together in a combined test.
 *   If executed together, the spec search uses the customized functional
 *   test. 
 * @Parameters:
 *   1.string runTo:              
 *     (Optional) the pattern is executed up to this cycle or vector
 *     including the vector(cycle) specified. 
 *     In multi-port setup, you must input <cycle_no>@<port_name>, 
 *     in this case, the runToType must be cycle only.
 *   2.string runToType:              {cycle|vector}
 *     default is cycle.
 *   3.string maskBefore:
 *     (Optional) All the cycles(vectors) before the specified one are
 *     masked out. But they are still executed without impacting result.
 *     In multi-port setup, you must input <cycle_no>@<port_name>,
 *     in this case, the maskBeforeType must be cycle only.      
 *   4.string maskBeforeType          {cycle|vector}    
 *     default is cycle.
 *   5.string maskAfter:
 *     (Optional) All the cycles(vectors) after the specified one are
 *     masked out. But they are still executed without impacting result.
 *     In multi-port setup, you must input <cycle_no>@<port_name>,
 *     in this case, the maskAfterType must be cycle only.      
 *   6.string maskAfterType          {cycle|vector}    
 *     default is cycle.
 *   7.string resultPinlist
 *     (Optional)List of pins/pin groups that contribute to the result. 
 *   8.string resultPinlistMode      {parallel|serial}
 *     If parallel mode,all result pins at a time contribute to the result.
 *     If serial mode,one pin after the other contributes to the result.
 *   9.testmethod::SpecVariable& spec 
 *     (Optional)Spec resource to be shifted.
 *     specifies the spec's name,unit and type{TIM:LEV}
 *     this parameter's format like:
 *                  "LEV.1.fooSpec[mV]", or "TIM.3.barSpec@port1[A]"
 *          type             "LEV"     ,       "TIM"
 *          equationSetId    "1"       ,       "3"
 *          name             "fooSpec" ,       "barSpec@port1"
 *          unit             "mV"      ,       "A"
 *     If omit this parameter,no spec search will be executed.
 *   10.string setupPinlist
 *      (Optional)List of pins/pin groups for which the resource specified 
 *      is shifted.Pins/pin groups are separated by commas.
 *   11.string setupPinlistMode       {parallel|serial} 
 *      If parallel mode,the resource is shifted for all pins at a time.
 *      If serial mode,the resource is shifted for a single setup pin only,
 *      this is done for all setup pins, one setup pin after the other. 
 *   12.string method                 {linear|binary|lin/bin} 
 *      The search method used to find the pass/fail or fail/pass transition:
 *      a linear search,a binary search,or a linear search followed by a binary
 *      search(lin/bin search).
 *   13.start
 *      The beginning of the search interval.
 *   14.stop
 *      The stop of the search interval.
 *   15.step
 *      (Optional)Needed by a linear or lin/bin search.
 *      if '#' preceded, it means number of steps
 *      else means stepwidth.
 *   16.string resolution
 *      (Optional)Needed by a binary or lin/bin search.
 *   17.passMin
 *      (Optional)Minimum pass threshold.   
 *   18.passMax
 *      (Optional)Maximum pass threshold.
 *   19.string output:               {ReportUI | None}
 *     Print message or not. 
 *     ReportUI - for debug mode
 *     None - for production mode
 *   20.string mTestName        {(Parametric_SpecSearch,Parametric_Functional)}
 *     two test limits' names in pairs
 *   
 * Note:
 *   execution mode closely depends on: 
 *   evaluation mode,execution mode of resultpinlist and setuppinlist.
 *   please refer to user manual for detail description.
 *----------------------------------------------------------------------*
 */

class ParametricFunctionalTest: public testmethod::TestMethod
{
protected:
  double _results[4];
  string  runTo;
  string  runToType;
  string  maskBefore;
  string  maskBeforeType;
  string  maskAfter;
  string  maskAfterType;
  string  resultPinlist;
  string  resultPinlistMode;
  testmethod::SpecVariable spec;
  string  setupPinlist;
  string  setupPinlistMode;
  string  method;
  double start;
  double  stop;
  string  step;
  string  resolution;
  double  passMin;
  double  passMax;
  string  output;
  string  mTestName;
  
  protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    addParameter("result0",
                 "double",
                 &_results[0],
                 testmethod::TM_PARAMETER_OUTPUT)
      .setDefault("0.0");
    addParameter("result1",
                 "double",
                 &_results[1],
                 testmethod::TM_PARAMETER_OUTPUT)
      .setDefault("0.0");
    addParameter("result2",
                 "double",
                 &_results[2],
                 testmethod::TM_PARAMETER_OUTPUT)
      .setDefault("0.0");
    addParameter("result3",
                 "double",
                 &_results[3],
                 testmethod::TM_PARAMETER_OUTPUT)
      .setDefault("0.0");
   addParameter("runTo.type",
                 "string",
                 &runToType)
      .setDefault("cycle")
      .setOptions("cycle:vector")
      .setComment("cycle or vector");
   addParameter("runTo.number",
                 "string",
                 &runTo)
      .setComment("cycle or vector number which run to");
    addParameter("maskBefore.type",
                 "string",
                 &maskBeforeType)
      .setDefault("cycle")
      .setOptions("cycle:vector")
      .setComment("cycle or vector");
    addParameter("maskBefore.number",
                 "string",
                 &maskBefore)
      .setComment("cycle or vector number which mask before");
    addParameter("maskAfter.type",
                 "string",
                 &maskAfterType)
      .setDefault("cycle")
      .setOptions("cycle:vector")
      .setComment("cycle or vector");
    addParameter("maskAfter.number",
                 "string",
                 &maskAfter)
      .setComment("cycle or vector number which mask after");
    addParameter("resultPinlist",
                 "PinString",
                 &resultPinlist)
      .setComment("pins contributing to result");
    addParameter("resultPinlistMode",
                 "string",
                 &resultPinlistMode)
      .setDefault("parallel")
      .setOptions("parallel:serial")
      .setComment("parallel/serial mode(contribute result)");
    addParameter("spec",
                 "SpecVariable",
                 &spec)
      .setComment("this parameter's format like:\n"
                  "LEV.1.fooSpec[mV]\n"
                  "type is LEV, equationSetId is 1\n"
                  "name is fooSpec, unit is mV");
    addParameter("setupPinlist",
                 "PinString",
                 &setupPinlist)
      .setComment("pins which spec variable apply to");
    addParameter("setupPinlistMode",
                 "string",
                 &setupPinlistMode)
      .setDefault("parallel")
      .setOptions("parallel:serial")
      .setComment("parallel/serial mode(apply spec to setup pinlist)");
    addParameter("method",
                 "string",
                 &method)
      .setDefault("lin/bin")
      .setOptions("lin/bin:binary:linear")
      .setComment("search method");
    addParameter("start",
                 "double",
                 &start)
      .setComment("start value of search range");
    addParameter("stop",
                 "double",
                 &stop)
      .setComment("stop value of search range");
    addParameter("step",
                 "string",
                 &step)
      .setComment("numOfStep(# preceding) or stepWidth");
    addParameter("resolution",
                 "string",
                 &resolution)
      .setComment("resolution value");
    addParameter("passMin",
                 "double",
                 &passMin)
      .setVisible(false)  //this value is transfered to limit
      .setDefault("9999")
      .setComment("min value of pass range, default is 9999 for no input.");
    addParameter("passMax",
                 "double",
                 &passMax)
      .setVisible(false)  //this value is transfered to limit
      .setDefault("9999")
      .setComment("max value of pass range, default is 9999 for no input.");
    addParameter("output",
                 "string",
                 &output)
      .setDefault("None")
      .setOptions("None:ReportUI")
      .setComment("print result to UI report window");
    
    addParameter("testName",
                 "string",
                 &mTestName)
      .setDefault("(Parametric_SpecSearch,Parametric_Functional)")
      .setComment("test limit's name, default is \"(Parametric_SpecSearch,Parametric_Functional)\"\n"
         "\"Parametric_SpecSearch\" is for parametric search test\n"
         "\"Parametric_Functional\" is for parametric functional test\n"
         "if test table is used, the limit is defined in file\n"
         "if predefined limit is used, the limit name must be as same as default.");

      addLimit("Parametric_SpecSearch");
      addLimit("Parametric_Functional");
  }
   
  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
    static ParamFuncTestUtil::ParamFuncTestParameter pftParam;
    static ParamFuncTestUtil::ParamFuncTestLimit pftLimit;
    ParamFuncTestUtil::ParamFuncTestResult testResult;
  
    /*----------------------------
     * 1. prepare for test
     *----------------------------
     */
    ON_FIRST_INVOCATION_BEGIN();
      /*process all parameters needed in test*/
      ParamFuncTestUtil::processParameters(runTo,runToType,
                                           maskBefore,maskBeforeType,
                                           maskAfter,maskAfterType,
                                           spec.mName,
                                           spec.mType,
                                           setupPinlist,setupPinlistMode,
                                           resultPinlist,resultPinlistMode,
                                           method,spec.mUnit,
                                           start,stop,step,resolution,
                                           passMin,passMax,
                                           pftParam);
      
      ParamFuncTestUtil::processLimits(mTestName,
                                       pftParam,
                                       pftLimit);
      /*connect tester*/
      CONNECT();
    ON_FIRST_INVOCATION_END();
    
    /*----------------------------
     * 2. do test
     *----------------------------
     */
    ParamFuncTestUtil::doMeasurement(pftParam,pftLimit,testResult);
  
    /*----------------------------
     * 3. datalog
     *----------------------------
     */
    ParamFuncTestUtil::judgeAndDatalog(pftParam,pftLimit,testResult,_results);
  
    /*----------------------------
     * 4. output result
     *----------------------------
     */
    ParamFuncTestUtil::reportToUI(pftParam,testResult,output);

    /*restore mask mode for functional test at the end of test*/
    ON_FIRST_INVOCATION_BEGIN();
      if (pftParam.testCase == ParamFuncTestUtil::PURE_FUNCTIONAL_TEST &&
         !pftParam.fwRestoreMaskMode.empty() )
      {
        FW_TASK(pftParam.fwRestoreMaskMode);
      }
    ON_FIRST_INVOCATION_END(); 
    return ;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   *
   *Note: TestMethod API should not be used in this method.
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    if(parameterIdentifier == "method")
    {
      if(CommonUtil::trim(method) == "linear")
      {
        getParameter("resolution").setEnabled(false);
        getParameter("step").setEnabled(true);
      }
      else if(CommonUtil::trim(method) == "binary")
      {
        getParameter("resolution").setEnabled(true);
        getParameter("step").setEnabled(false);
      }
      else
      {
        getParameter("resolution").setEnabled(true);
        getParameter("step").setEnabled(true);
      }
    }
    else if(parameterIdentifier == "runTo")
    {
       if(CommonUtil::trim(runTo).empty())
       {
         getParameter("runToType").setEnabled(false);
       }
       else
       {
         getParameter("runToType").setEnabled(true);
       }
    }
    else if(parameterIdentifier == "maskBefore")
    {
       if(CommonUtil::trim(maskBefore).empty())
       {
         getParameter("maskBeforeType").setEnabled(false);
       }
       else
       {
         getParameter("maskBeforeType").setEnabled(true);
       }
    }
    else if(parameterIdentifier == "maskAfter")
    {
       if(CommonUtil::trim(maskAfter).empty())
       {
         getParameter("maskAfterType").setEnabled(false);
       }
       else
       {
         getParameter("maskAfterType").setEnabled(true);
       }
    }

    return;
  }
  
  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string  getComment() const
  {
     static string comment = _TML_VERSION;
     return comment;
  }
};

REGISTER_TESTMETHOD("AcTest.ParametricFunctionalTest", ParametricFunctionalTest);
