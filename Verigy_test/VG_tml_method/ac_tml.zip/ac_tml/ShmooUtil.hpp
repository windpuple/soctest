#ifndef INCLUDE_SHMOO_UTIL_HPP
#define INCLUDE_SHMOO_UTIL_HPP
#include "mapi.hpp"
#include "CommonUtil.hpp"
#include <cassert>
#include <string>
#include <map>
#include <utility>
#include <sys/time.h>
using namespace std;

/**
 * a StepParser is used to parse the step expression and
 * get the totalStep and linearStep.
 */
class StepParser
{
public:

  /**
   *----------------------------------------------------------------------*
   * Routine: constructor
   *
   * Parameters:
   *   1. stepExpression: supported expression examples are:
   *        "0.1"  the step width is 0.1.
   *        "#10"  the totalStep are 10 and thus linearStep is 1 (linear mode).
   *        "f#10" the totalStep are 10 and linearStep is 4(fast mode).
   *        "#<20>/<2>" the totalStep is 10 and linearStep is 2(binary mode).
   *   2. totalStepDifference: the difference between start and stop.
   *        totalStepDifference = stop - start = totalStep * stepWidth.
   *
   *----------------------------------------------------------------------*
   */
  StepParser(const string& stepExpression, double totalDifference = 0):
    mExpression(stepExpression),
    mTotalDifference(totalDifference), 
    mIsParsed(false),
    mTotalStep(0),
    mLinearStep(0),
    mIsStepNumberSpecified(false)
  {
  }

  /**
   *----------------------------------------------------------------------*
   * Routine: getTotaStep()
   *
   * Return: totalStep. If the stepExpression in the constructor has error(s),
   *           it will throw an Error.
   *----------------------------------------------------------------------*
   */
  unsigned int getTotalStep();

  /**
   *----------------------------------------------------------------------*
   * Routine: getLinearStep()
   *
   * Return: linear Step. If the stepExpression in the constructor has error(s),
   *           it will throw an Error.
   *----------------------------------------------------------------------*
   */
  unsigned int getLinearStep();


  bool isStepNumberSpecified();
  bool isValid()
  {
    return getMessage().empty();
  }
    
  string getMessage()
  {
    if(!mIsParsed)
    {
      parse();
      mIsParsed = true;
    }
    return mMessage;
  }
private:

  /**
   *----------------------------------------------------------------------*
   * Routine: parse()
   * Purpose: parse the total step and linear step from mExpression.  
   *
   *----------------------------------------------------------------------*
   */
  void parse();

  /**
   *----------------------------------------------------------------------*
   * Routine: parseBinary()
   * Purpose: parse the mExpression as a binary expression.
   *   An binary expression example is : #<20>/<2>
   *
   *----------------------------------------------------------------------*
   */
  void parseBinary();

  /**
   *----------------------------------------------------------------------*
   * Routine: setErrorMessage()
   * Purpose: set the error message. It is called when a syntax error 
   *   is detected when parsing.
   *
   *----------------------------------------------------------------------*
   */
  void setErrorMessage();

  /**
   *----------------------------------------------------------------------*
   * Routine: stepWidthStringToTotalStep()
   * Purpose: parse stepWidthString and calculate totalStep.
   *
   * Parameters: 
   *   1. stepWidthString: e.g "0.1"
   *
   *  Return: totalStep.
   *    totalStep * stepWidth = stop - value = mTotalDifference
   *
   *----------------------------------------------------------------------*
   */
  unsigned int stepWidthStringToTotalStep(const string& stepWidthString);

  /**
   *----------------------------------------------------------------------*
   * Routine: stringToUnsignedInt()
   * Purpose: convert string to a unsigned int number.
   *
   * Parameters:
   *   1. unsignedIntString
   *
   *  Return: unsigned int number.
   *   An Error will be thrown if the number is less than or equal to 0, or
   *   a syntax error is detected. 
   *
   *----------------------------------------------------------------------*
   */
  unsigned int stringToUnsignedInt(const string& unsignedIntString);

  /* the expression*/
  string mExpression;

  /*total difference, equal to stop - start */
  double mTotalDifference;

  /*indication whether mExpression has been parsed. mExpression should be 
   *parsed only once.*/
  bool mIsParsed;
  unsigned int mTotalStep;
  unsigned int mLinearStep;
 
  /*indication whether mExpression specifies step number or step width.
   * expression like "#40", "f#40" or "#<20>/<4>" specifies step number
   * while expression like "0.1" doesn't.
   */
  bool mIsStepNumberSpecified;

  string mMessage;
};

/**
 * ShmooResult stores the result of every measured point.
 */
class ShmooResult
{
public:
  /**
   *----------------------------------------------------------------------*
   * Routine: constructor
   *
   * Parameters:
   *   1. resultResolution: If the difference of two points' results are
   *        larger than or equal to resultResolution, their results are
   *        considered different. Otherwise, their results are considered
   *        the same.
   *----------------------------------------------------------------------*
   */
  ShmooResult(double resolution = 1)
  :mResolution(resolution)
  {
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: ShmooResult::clear
   *
   * Purpose: clear the results of all the points
   *
   *----------------------------------------------------------------------*
   */
  ShmooResult& clear()
  {
    mPointResults.clear();
    return *this;
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: ShmooResult::setResult
   *
   * Purpose: stores the result of a point
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note:        
   *
   * Parameters:  1. relativeCoordinateX :
   *                 x relative coordinate of the point. 
   *              2. relativeCoordinateY :
   *                 y relatvive coordinate of the point.
   *              3. cellResult:
   *                 the result of the point.
   *----------------------------------------------------------------------*
   */
  ShmooResult& setResult(
    unsigned int relativeCoordinateX, 
    unsigned int relativeCoordinateY, 
    const ShmooCellResult& cellResult)
  {
    mPointResults[make_pair(relativeCoordinateX, relativeCoordinateY)] = cellResult;
    return *this;
  }
 

  /*
   *----------------------------------------------------------------------*
   * Routine: ShmooResult:: isPointTested
   *
   * Purpose: check whether a point has been tested/measured. 
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note:        
   *
   * Parameters:  1. relativeCoordinateX :
   *                 x relative coordinate of the point. 
   *              2. relativeCoordinateY :
   *                 y relatvive coordinate of the point.
   * Return Value: true if the point has been tested. false otherwise.
   *----------------------------------------------------------------------*
   */
  bool isPointTested(
    unsigned int relativeCoordinateX, 
    unsigned int relativeCoordinateY) const
  {
    return mPointResults.find(
             make_pair(relativeCoordinateX, relativeCoordinateY)) != mPointResults.end();
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: ShmooResult:: isPointDifferent
   *
   * Purpose: check whether two points (x1, y1) and (x2, y2) 
   *            has different results.
   *
   *----------------------------------------------------------------------*
   * Note: If the difference of two points' results are
   *         larger than or equal to resolution, their results are
   *         considered different. Otherwise, their results are considered
   *         the same.
   *
   * Return Value: true if the two points has different results. 
   *                 false otherwise.
   *----------------------------------------------------------------------*
   */
  bool isPointDifferent(unsigned x1, unsigned y1, unsigned x2, unsigned y2) const;
  
  /*
   *----------------------------------------------------------------------*
   * Routine: ShmooResult:: getResult
   *
   * Purpose: get the result of a point.  
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note: The point should have been measured.       
   *
   * Parameters:  1. relativeCoordinateX :
   *                 x relative coordinate of the point. 
   *              2. relativeCoordinateY :
   *                 y relatvive coordinate of the point.
   * Return Value: the result of the point.
   *----------------------------------------------------------------------*
   */
  ShmooCellResult getResult(
    unsigned int relativeCoordinateX, 
    unsigned int relativeCoordinateY) const
  {
    return mPointResults.find(make_pair(
             relativeCoordinateX, relativeCoordinateY))->second;
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: ShmooResult:: getAllResults
   *
   * Purpose: get all the results.
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   *----------------------------------------------------------------------*
   */
  const map<pair<unsigned int, unsigned int>, ShmooCellResult>& getAllResults() const
  {
    return mPointResults;
  }

private:
  map<pair<unsigned int, unsigned int>, ShmooCellResult> mPointResults;
  double mResolution;
};

/**
 * ShmooParameter is an abstract class. It represents a moving resource
 * on the X or Y axis. 
 */
class ShmooParameter
{
public:
  /*
   *----------------------------------------------------------------------*
   * Routine: constructor
   *
   * Purpose:  
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note:        
   *
   * Parameters: 
   *   1. start: the start value.
   *   2. stop:  the stop value.
   *   3. totalSteps: the total step.  
   *        totalStep * stepWidth = stop - start 
   *----------------------------------------------------------------------*
   */
  ShmooParameter(const string& unit):
    mUnit(unit)
  {}

  virtual ~ShmooParameter() {}

  /*
   *----------------------------------------------------------------------*
   * Routine: saveValue
   *
   * Purpose: save the original value. 
   *
   * Note:  It should be called before the whole shmoo
   *   starts. Should be implemented by concrete subclass.      
   *
   * Return Value: the reference to itself.
   *----------------------------------------------------------------------*
   */
  virtual ShmooParameter& saveValue() = 0;

  /*
   *----------------------------------------------------------------------*
   * Routine: restoreValue
   *
   * Purpose: restore the original value. 
   *
   * Note:  It should be called after the whole shmoo
   *   stops. Should be implemented by concrete subclass.      
   *
   * Return Value: the reference to itself.
   *----------------------------------------------------------------------*
   */
  virtual ShmooParameter& restoreValue() = 0;

  /*
   *----------------------------------------------------------------------*
   * Routine: moveTo
   *
   * Purpose: Move to the position specified by relativeCoordinate  
   *
   * Note:   Should be implemented by concrete subclass.
   *
   * Return Value: the reference to itself.
   *----------------------------------------------------------------------*
   */
  virtual ShmooParameter& moveTo(double value) = 0;

  /*
   *----------------------------------------------------------------------*
   * Routine: getShortName
   *
   * Purpose: get the short name of the ShmooParameter
   *
   * Note:   Should be implemented by concrete subclass.
   *
   * Return Value: a short name that describes the ShmooParameter, it is 
   *   used for display.
   *----------------------------------------------------------------------*
   */
  virtual string getShortName() const = 0;
 
  /*
   *----------------------------------------------------------------------*
   * Routine: getDescription
   *
   * Purpose: get the description of the ShmooParameter
   *
   * Note:   Should be implemented by concrete subclass.
   *
   * Return Value: description of the ShmooParameter, it is
   *   used for datalog.
   *----------------------------------------------------------------------*
   */
  virtual string getDescription() const = 0;

  /*
   *----------------------------------------------------------------------*
   * Routine: getUnit
   *
   * Purpose: get the unit
   *
   *----------------------------------------------------------------------*
   */
  const string& getUnit() const
  {
    return mUnit;
  }

private:
  string mUnit;

public:
  static const string SPEC_VARIABLE;
  static const string BIST_RESOURCE;
  static const string HX_INSTRUMENT;
  static const string HX_RESOURCE;
};

/**
 * SpecShmooParameter represents SpecVariable resource that can be changed
 * on the X or Y axis.
 */
class SpecShmooParameter : public ShmooParameter
{
public:

  /*
   *----------------------------------------------------------------------*
   * Routine: constructor
   *
   * Purpose:
   *
   *----------------------------------------------------------------------*
   * Parameters:
   *   1. start: the start value.
   *   2. stop:  the stop value.
   *   3. totalSteps: the total step.
   *        totalStep * stepWidth = stop - start
   *   4. specName: the spec variable name.
   *   5. setupPins: the pinlist that the changed spec variable value 
   *        will apply to. 
   *
   *----------------------------------------------------------------------*
   */
  SpecShmooParameter(
    const string& unit,
    const string &specName, 
    const string &setupPins, 
    TM::SPEC_TYPE specType) :
    ShmooParameter(unit), 
    mSpecName(specName),
    mSetupPins(setupPins),
    mSpecType(specType)
  {
    
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: getSpecName
   *
   * Purpose: get the spec variable's name.
   *
   *----------------------------------------------------------------------*
   */
  const string& getSpecName() const
  {
    return mSpecName;
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: getSetupPins
   *
   * Purpose: get the setup pins
   *
   *----------------------------------------------------------------------*
   */
  const string& getSetupPins() const
  {
    return mSetupPins;
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: getSpecType
   *
   * Purpose: get the spec type: TM::LEV or TM::TIM
   *
   *----------------------------------------------------------------------*
   */
  TM::SPEC_TYPE getSpecType() const
  {
    return mSpecType;
  }

  virtual ShmooParameter& saveValue()  
  { 
    mShmooSpec.setX(mSpecName, mSpecType, mSetupPins);
    mShmooSpec.setup();
    return *this;
  }

  virtual ShmooParameter& restoreValue() 
  {
    mShmooSpec.restore();
    return *this;
  }

  virtual ShmooParameter& moveTo(double value) 
  {
    mShmooSpec.setValue(value, 0.0);
    return *this;
  }

  virtual string getParameterType () const
  {
    return SPEC_VARIABLE;
  }
  
  virtual string getShortName() const 
  {
    return mSpecName;
  }

  virtual string getDescription() const;
 
  /*
   *----------------------------------------------------------------------*
   * Routine: destructor
   *
   *----------------------------------------------------------------------*
   */
  virtual ~SpecShmooParameter()
  {
  }

private:
  ShmooSpec mShmooSpec;
  string mSpecName;
  string mSetupPins;
  TM::SPEC_TYPE mSpecType;
};

/**
 * A Utility class. It is a singleton.
 */
class BistHxUtility
{
public:
  /*
   *----------------------------------------------------------------------*
   * Routine: lookupProperty
   *
   * Purpose: return the property's full name.
   *----------------------------------------------------------------------*
   * Parameters:
   *   1. property: an abbreviated property.
   *
   *----------------------------------------------------------------------*
   */
  string lookupProperty(const string& property) const;

  /*
   *----------------------------------------------------------------------*
   * Routine: lookupUnit
   *
   * Purpose: return the factor correspondent to the unit. 
   *          e.g. 1.0e-3 for "mv"       
   *----------------------------------------------------------------------*
   * Parameters:
   *   1. property: a valid unit.
   *
   *----------------------------------------------------------------------*
   */
  double lookupUnit(const string& unit) const;
  
  /*
   *----------------------------------------------------------------------*
   * Routine: isValidProperty
   *
   * Purpose: return true if the property is a valid property. 
   *          false otherwise.       
   *----------------------------------------------------------------------*
   */
  bool isValidProperty(const string& property) const;
  
  /*
   *----------------------------------------------------------------------*
   * Routine: isValidUnit
   *
   * Purpose: return true if the unit is a valid property. 
   *          false otherwise.       
   *----------------------------------------------------------------------*
   */
  bool isValidUnit(const string& unit) const;

  bool isValidUnit(const string& property, const string& unit) const;

  /*
   *----------------------------------------------------------------------*
   * Routine: getAllValidUnitString
   *
   * Purpose: return all the valid units' string, such as "V, mV".       
   *----------------------------------------------------------------------*
   */
  string getAllValidUnitString() const;

  /*
   *----------------------------------------------------------------------*
   * Routine: getAllValidUnitString
   *
   * Purpose: return all the valid units' option, such as "V:mV".       
   *----------------------------------------------------------------------*
   */
  string getUnitOptions() const;

  string getUnitOptions(const string& property) const;

  /*
   *----------------------------------------------------------------------*
   * Routine: getPropertyOptions
   *
   * Purpose: return all the valid properties' option.       
   *----------------------------------------------------------------------*
   */
  string getPropertyOptions() const;
 
  /*
   *----------------------------------------------------------------------*
   * Routine: getPropertyDefault
   *
   * Purpose: return the default property       
   *----------------------------------------------------------------------*
   */
  string getPropertyDefault() const;

  /*
   *----------------------------------------------------------------------*
   * Routine: getShortProperty
   *
   * Purpose: return the property's abbreviation. e.g."Vil" for "DriverLow"       
   *----------------------------------------------------------------------*
   */
  string getShortProperty(const string& property) const;

  string getBaseUnit(const string& property) const;
 
  string getTargetUnit(const string& property) const;

  /*
   *----------------------------------------------------------------------*
   * Routine: getInstance
   *
   * Purpose: return the singleton instance.       
   *----------------------------------------------------------------------*
   */
  static BistHxUtility& getInstance()
  {
    static BistHxUtility bistHXUtility;
    return bistHXUtility;
  } 

  /*
   *----------------------------------------------------------------------*
   * Routine: getProperty
   *
   * Purpose: return the BIST/HX instrument/resource property's value.       
   *----------------------------------------------------------------------*
   * Parameters:
   *   1. t: BIST/HX instrument/resource.
   *   2. propertyName: the propertyName.e.g. "DriverLow"
   */
  template <class T>
  double getProperty(const T& t, const string& propertyName) const;
  
  /*
   *----------------------------------------------------------------------*
   * Routine: getProperty
   *
   * Purpose: return the HX instrument/resource property's value.       
   *----------------------------------------------------------------------*
   * Parameters:
   *   1. t: HX instrument/resource.
   *   2. propertyName: a propertyName that is specicial to HX 
   *        instrument/resource.i.e there is no such properties for BIST 
   *        resource.e.g. "DriverFineDelay"
   */
  template <class T>
  double getHighSpeedProperty(const T&t, const string& propertyName) const;

  /*
   *----------------------------------------------------------------------*
   * Routine: isHighSpeedProperty
   *
   * Purpose: whether the property is special to HX instrument/resource        
   *----------------------------------------------------------------------*
   * Parameters:
   *   1. propertyName: a propertyName may be specicial to HX 
   *        instrument/resource.i.e there is no such properties for BIST 
   *        resource.e.g. "DriverFineDelay"
   */
  bool isHighSpeedProperty(const string& propertyName) const;
 
  /*
   *----------------------------------------------------------------------*
   * Routine: setProperty
   *
   * Purpose: SET the BIST/HX instrument/resource property' to 
   *            the specified value.       
   *----------------------------------------------------------------------*
   * Parameters:
   *   1. t: BIST/HX instrument/resource.
   *   2. propertyName: the propertyName.e.g. "DriverLow"
   *   3. value: the specified value.  
   */
  template <class T>
  void setProperty(T& t, const string& propertyName, double value) const;

  /*
   *----------------------------------------------------------------------*
   * Routine: setProperty
   *
   * Purpose: set the HX instrument/resource property' to the specified
   *            value.       
   *----------------------------------------------------------------------*
   * Parameters:
   *   1. t: HX instrument/resource.
   *   2. propertyName: a propertyName that is specicial to HX 
   *        instrument/resource.i.e there is no such properties for BIST 
   *        resource.e.g. "DriverFineDelay"
   *   3. value: the specified value.  
   */
  template <class T>
  void setHighSpeedProperty(T& t, const string& propertyName, double value) const;

private:
  BistHxUtility()
  {
    mPropertyMap[SWING]    = SWING;
    mPropertyMap[OFFSET]   = OFFSET;
    mPropertyMap["Vil"]    = DRIVER_LOW;
    mPropertyMap["Vih"]    = DRIVER_HIGH;
    mPropertyMap["Vth"]    = RECEIVER_THRESHOLD;
    mPropertyMap["Vterm"]  = TERMINATION_VOLTAGE;
    mPropertyMap["JAmpl"]  = MODULATION_JITTER_AMPLITUDE;
    mPropertyMap["JFreq"]  = MODULATION_FREQUENCY;
    mPropertyMap["CMAmpl"] = MODULATION_COMMONMODE_AMPLITUDE;
    mPropertyMap["Skew" ]  = SKEW;
    mPropertyMap["dt_rx"]  = DRIVER_FINE_DELAY;
    mPropertyMap["dt_tx"]  = RECEIVER_FINE_DELAY;

    mUnitMap["Hz"]  = 1.0;
    mUnitMap["kHz"] = 1.0e3;
    mUnitMap["MHz"] = 1.0e6;
    mUnitMap["mV"]  = 1.0e-3;
    mUnitMap["V"]   = 1.0;
    mUnitMap["fs"]  = 1.0e-15;
    mUnitMap["ps"]  = 1.0e-12;
    mUnitMap["ns"]  = 1.0e-9;
    mUnitMap["us"]  = 1.0e-6;
    mUnitMap["ms"]  = 1.0e-3;
    mUnitMap["s"]   = 1.0;
  }
  
  BistHxUtility(const BistHxUtility& anotherUtility);
  BistHxUtility& operator = (const BistHxUtility& anotherUtility); 

  map<string, string> mPropertyMap;
  map<string, double> mUnitMap;
public:
  static const string SWING;
  static const string OFFSET;
  static const string DRIVER_LOW;
  static const string DRIVER_HIGH;
  static const string RECEIVER_THRESHOLD;
  static const string TERMINATION_VOLTAGE;
  static const string MODULATION_JITTER_AMPLITUDE;
  static const string MODULATION_FREQUENCY;
  static const string MODULATION_COMMONMODE_AMPLITUDE;
  static const string SKEW;
  static const string DRIVER_FINE_DELAY;
  static const string RECEIVER_FINE_DELAY;
};

/**
 * HXInstrumentShmooParameter represents HX Instrument whose property can be changed
 * on the X or Y axis.
 */
class HXInstrumentShmooParameter : public ShmooParameter
{
public:
  HXInstrumentShmooParameter(
    const string& unit,
    const string& instrument,
    const string& property):
    ShmooParameter(unit),
    mBase(BistHxUtility::getInstance().lookupUnit(unit)),
    mInstrumentPin(instrument),
    mHXPins(instrument),
    mProperty(BistHxUtility::getInstance().lookupProperty(property)),
    mOriginalDriverLow(0.0),
    mOriginalDriverHigh(0.0),
    mOriginalPropertyValue(0.0)
  {
  }

  virtual ShmooParameter& saveValue();

  virtual ShmooParameter& restoreValue();

  virtual ShmooParameter& moveTo(double value);
  
  virtual string getShortName() const;

  virtual string getDescription() const;

  virtual string getParameterType() const;
 
  /*
   *----------------------------------------------------------------------*
   * Routine: setProperty
   *
   * Purpose: Set the HX instrument property' to 
   *            the specified value.       
   *----------------------------------------------------------------------*
   * Parameters:
   *   1. propertyName: the propertyName.e.g. "DriverLow"
   *   2. value: the specified value.  
   */
  void setProperty(const string& propertyName, double value);

  /*----------------------------------------------------------------------*
   * Routine: getProperty
   *
   * Purpose: get the HX instrument property's value 
   *----------------------------------------------------------------------*
   * Parameters:
   *   1. propertyName: the propertyName.e.g. "DriverLow"
   */
  double getProperty(const string& propertyName) const;

private:
  double mBase;
  string mInstrumentPin;
  HIGHSPEEDEXTENSION_PINS mHXPins;
  string mProperty;
  double mOriginalDriverLow;
  double mOriginalDriverHigh;
  double mOriginalPropertyValue;
};


/**
 * ResourceShmooParameter is an abstract class, it represents a Bist/HX resource
 * whose property can be changed on the X or Y axis.
 */
template <class T>
class ResourceShmooParameter : public ShmooParameter
{
public:
  ResourceShmooParameter(
    const string& unit,
    const string& resourceName,
    const string& property):
    ShmooParameter(unit),
    mResourceName(resourceName),
    mResource(resourceName),
    mProperty(BistHxUtility::getInstance().lookupProperty(property)),
    mBase(BistHxUtility::getInstance().lookupUnit(unit)),
    mOriginalDriverLow(0.0),
    mOriginalDriverHigh(0.0),
    mOriginalPropertyValue(0.0)
  {
  }

  virtual ShmooParameter& saveValue();

  virtual ShmooParameter& restoreValue();

  virtual ShmooParameter& moveTo(double value);

  virtual string getShortName() const;

  /*
   *----------------------------------------------------------------------*
   * Routine: setProperty
   *
   * Purpose: SET the BIST/HX resource property' to 
   *            the specified value.       
   *----------------------------------------------------------------------*
   * Parameters:
   *   1. propertyName: the propertyName.e.g. "DriverLow"
   *   2. value: the specified value.  
   */
  virtual void setProperty(const string& propertyName, double value) = 0;
 
  /*
   *----------------------------------------------------------------------*
   * Routine: getProperty
   *
   * Purpose: return the BIST/HX resource property's value.       
   *----------------------------------------------------------------------*
   * Parameters:
   *   1. propertyName: the propertyName.e.g. "DriverLow"
   */
  virtual double getProperty(const string& propertyName) const = 0; 

protected:
  string mResourceName;
  T mResource;
  string mProperty;
private:
  double mBase;
  double mOriginalDriverLow;
  double mOriginalDriverHigh;
  double mOriginalPropertyValue;
};


/**
 * HXResourceShmooParameter represents a HX resource
 * whose property can be changed on the X or Y axis.
 */
class HXResourceShmooParameter: public ResourceShmooParameter <HIGHSPEEDEXTENSION_RESOURCE>
{
  public:
  HXResourceShmooParameter(
    const string& unit,
    const string& resourceName,
    const string& property):
    ResourceShmooParameter<HIGHSPEEDEXTENSION_RESOURCE>(unit, resourceName, property)
  {
  }

  virtual void setProperty(const string& propertyName, double value);
 
  virtual double getProperty(const string& propertyName) const; 
  
  virtual string getDescription() const;
  
  virtual string getParameterType() const;

};

namespace
{
  /**
   *----------------------------------------------------------------------*
   * Routine: getRoundedLinearStep()
   *
   * Purpose: Return the linearStep to closest 2^n.
   *    For example, 5 will be rounded to 4.
   * Parameters:
   *   1. linearStep the original linearStep to be rounded. 
   *
   * Return Value: return the rounded lienarStep
   *----------------------------------------------------------------------*
   */
  inline unsigned int getRoundedLinearStep(unsigned int linearStep)
  {
    int roundedLinearStep = 1;

    while ( linearStep > 1 )
    {
      roundedLinearStep *= 2;
      linearStep /= 2;
    }
    return roundedLinearStep;
  }
}

/**
 * ShmooCoordinator generates the next point in the relative coordinate
 * system according to the current point position and the result of 
 * previous measured points.
 */
class ShmooCoordinator
{
public:
  /**
   *----------------------------------------------------------------------*
   * Routine: constructor
   *
   * Parameters:
   *   1. totalStepX: the total steps on X axis.
   *   2. totalStepY: the total steps on Y axis.
   *   3. linearStepX: the linear steps on X axis. 
   *        the actual linearStep will be the rounded one. For example, 5
   *        will be rounded to 4.
   *   4. linearStepY: the linear steps on Y axis.
   *        the actual linearStep will be the rounded one. For example, 5
   *        will be rounded to 4.
   *----------------------------------------------------------------------*
   */
  ShmooCoordinator(
    unsigned int totalStepX, 
    unsigned int totalStepY,
    unsigned int linearStepX, 
    unsigned int linearStepY);

 
  /**
   *----------------------------------------------------------------------*
   * Routine: start()
   *
   * Purpose: set the ShmooCoordinator to its initial state and start the 
   *   ShmooCoordinator .
   *
   *----------------------------------------------------------------------*
   */
  void start();
  
  /**
   *----------------------------------------------------------------------*
   * Routine: next()
   *
   * Purpose: move to next point to be measured according to current point
   *   and results of previous measured points.
   *
   * Parameters:
   *   1. shmooResult: stores the results of previous measured points.
   *----------------------------------------------------------------------*
   */
  void next(const ShmooResult& shmooResult);


  /**
   *----------------------------------------------------------------------*
   * Routine: isEnd()
   *
   * Purpose: check whether the ShmooCoordinator shoud stop.
   *
   * Return: a bool to indicate whether the ShmooCoordinator meets its end. 
   *----------------------------------------------------------------------*
   */

  bool isEnd() const 
  { 
    return mIsEnd; 
  }
 
  /**
   *----------------------------------------------------------------------*
   * Routine: getRelativeX()
   *
   * Return: relative Coordinator of current point on X axis.
   *----------------------------------------------------------------------*
   */
  unsigned int getRelativeX() 
  { 
    return mRelativeX; 
  }

  /**
   *----------------------------------------------------------------------*
   * Routine: getRelativeX()
   *
   * Return: relative Coordinator of current point on X axis.
   *----------------------------------------------------------------------*
   */
  unsigned int getRelativeY()  { return mRelativeY; }

   // for unit test only. Others should not call this method.
  string store();

   // for unit test only. Others should not call this method.
  void restore(const string& storeString);

private:
  
  /**
   *----------------------------------------------------------------------*
   * Routine: shouldCurrentPointBeTested()
   * 
   * Purpose: check whether current point should be tested.
   * 
   * Description:
   *   To be tested, current point should satisfy:
   *     1. it has not been tested before.
   *     2. the results of its surrounding points should not be the same.
   *
   * Note: this method is only called during linear examination in the 
   *   binary part.
   *
   *----------------------------------------------------------------------*
   */
  bool shouldCurrentPointBeTested(const ShmooResult& shmooResult) const;

  /**
   *----------------------------------------------------------------------*
   * Routine: moveForward()
   *
   * Purpose: move to next forward point according to current linear step
   *   on x axis and y axis.
   *
   * Note: this method is only called when linear examination in the 
   *  binary part and mIsForward is true.
   *
   *----------------------------------------------------------------------*
   */
  void moveForward();


  /**
   *----------------------------------------------------------------------*
   * Routine: decreaseLinearStep()
   *
   * Purpose: decrease linear step if necessary.
   *
   *----------------------------------------------------------------------*
   */
  void decreaseLinearStep();

  /**
   *----------------------------------------------------------------------*
   * Routine: startNewRound()
   *
   * Purpose: start a new round. A backward and forward examination in 
   *          the binary partis a round
   *
   *----------------------------------------------------------------------*
   */
  void startNewRound();

  unsigned int mTotalStepX;
  unsigned int mTotalStepY;

  unsigned int mOriginalLinearStepX;

  unsigned int mOriginalLinearStepY;

  /* Current step width on x axis */
  unsigned int mCurLinearStepX; 

  /* Current step width on y axis */
  unsigned int mCurLinearStepY; 

  /* relative coordinate  on X axis of current point */
  unsigned int mRelativeX;

  /* relative coordinate  on Y axis of current point */
  unsigned int mRelativeY;

  /*indicate whether end is met */
  bool mIsEnd;

  /*indicate in the linear part or binary part */
  bool mIsLinearPart;

 
  /*indicate whether there are any points measured in the last round.*/
  bool mHasPointMeasuredIntheLastRound;
};

/**
 * The abstract class ShmooMeasurement performs the measurement
 * and it should be called at each point that needs to be measured
 * in the whole shmoo.
 */
class ShmooMeasurement
{
public:
  
  ShmooMeasurement():
    mpParameterX(NULL),
    mpParameterY(NULL)
  {
  }

  /**
   *----------------------------------------------------------------------*
   * Routine: measure()
   *
   * Purpose: do the measurement. Should be implemented by concrete subclass.
   * Return: false if the whole shmoo should break. true otherwise.
   *----------------------------------------------------------------------*
   */
  virtual bool measure() = 0;

  /**
   *----------------------------------------------------------------------*
   * Routine: getResult()
   *
   * Purpose: get the result of measurement just now.
   *   Should be implemented by concrete subclass.
   *----------------------------------------------------------------------*
   */
  virtual ShmooCellResult getResult() const = 0;

  /**
   *----------------------------------------------------------------------*
   * Routine: save()
   *
   * Purpose: save the settings that may be destroyed by measurement.
   *   May be implemented by concrete subclass. The default implementation
   *   does nothing.
   *----------------------------------------------------------------------*
   */
  virtual ShmooMeasurement& save()
  { 
    return *this;
  }

  /**
   *----------------------------------------------------------------------*
   * Routine: restore()
   *
   * Purpose: restore the saved settings.
   *   May be implemented by concrete subclass. The default implementation
   *   does nothing.
   *----------------------------------------------------------------------*
   */
  virtual ShmooMeasurement& restore() 
  { 
    return *this;
  }

  /**
   *----------------------------------------------------------------------*
   * Routine: destructor
   *
   * Purpose: destroy the object.
   *----------------------------------------------------------------------*
   */
  virtual ~ShmooMeasurement()
  {
  }

protected:
  ShmooParameter *mpParameterX;
  ShmooParameter *mpParameterY;

};

enum TestMode
{
  NORMAL_TEST,
  CYCLE_ERROR_COUNT,
  EDGE_ERROR_COUNT,
  FIRST_FAIL_CYCLE
};

/**
 * FunctionalMeasurement performs functional measurement.
 */
class FunctionalMeasurement: public ShmooMeasurement
{
public:
 
  FunctionalMeasurement(const string& testMode, const string& resultPins);

  /**
   *----------------------------------------------------------------------*
   * Routine: measure()
   *
   * Purpose: do functional measurement. 
   *----------------------------------------------------------------------*
   */
  bool measure();

  /**
   *----------------------------------------------------------------------*
   * Routine: getResult()
   *
   * Return: return the functional measurement result.
   *----------------------------------------------------------------------*
   */
  ShmooCellResult getResult() const;

  ShmooMeasurement& save();
  
  ShmooMeasurement& restore();

  virtual ~FunctionalMeasurement()
  {
  }

  static const string NORMAL_FUNCTIONAL_TEST_STRING;
  static const string FIRST_FAIL_CYCLE_STRING;
  static const string CYCLE_ERROR_COUNT_STRING;
  static const string EDGE_ERROR_COUNT_STRING;
private:
  static double convertFfciBinaryToDouble(const char* p);
  TestMode mTestMode;
  string mRestoreFw;
  string mResultPins;
  ShmooCellResult mCellResult;
};


/**
 *The colorAllocator is used to allocate a color for 
 * every measurement value.
 */
class ColorAllocator
{
public:
 
  /**
   *----------------------------------------------------------------------*
   * Routine: constructor
   *
   * Parameters:
   *   1. resolution: if two measurement results' difference is larger 
   *        than the resolution, then each result will be allocated 
   *        a different color if not all the color has been allocated. 
   *----------------------------------------------------------------------*
   */
  ColorAllocator(double resolution);

  /**
   *----------------------------------------------------------------------*
   * Routine: getColorForUnMeasuredPoint()
   *
   * Return a char representing the color for unmeasured point. Currently
   *   the value is 'N'.
   *----------------------------------------------------------------------*
   */
  char getColorForUnMeasuredPoint() const
  {
    return 'N';
  }

  /**
   *----------------------------------------------------------------------*
   * Routine: getPassColor()
   *
   * Return a char representing the color for passed point. Currently
   *   the value is 'P'.
   *----------------------------------------------------------------------*
   */
  char getPassColor() const
  {
    return 'P';
  }

  /**
   *----------------------------------------------------------------------*
   * Routine: getFailColor()
   *
   * Return a char representing the color for failed point. Currently
   *   the value is 'F'.
   *----------------------------------------------------------------------*
   */
  char getFailColor() const
  {
    return 'F';
  }
  
  /**
   *----------------------------------------------------------------------*
   * Routine: addValue()
   *
   * Parameters:
   *   1. value: ask the ColorAllocator to allocate a color fora
   *         the specified value.
   *----------------------------------------------------------------------*
   */
  void addValue(double value);
  
  /**
   *----------------------------------------------------------------------*
   * Routine: getColor()
   *
   * Return a char representing the correspoing color for the specified value.
   *----------------------------------------------------------------------*
   */
  char getColor(double value) const;
   
  /**
   *----------------------------------------------------------------------*
   * Routine: getAllColors()
   *
   * Return a vector<char> containing all the colors.
   *----------------------------------------------------------------------*
   */
  const vector<char>& getAllColors() const;

  /**
   *----------------------------------------------------------------------*
   * Routine: setFailValue()
   *
   * Purpose: specify the fail value
   *   If the difference of a value and the fail value(if it is specified)
   *   is less than resolution/2, then the color for failed value will be 
   *   given(currently it is 'F'), otherwise, a preallocated will be 
   *   given.
   *----------------------------------------------------------------------*
   */
 // void setFailValue(double value);

  /**
   *----------------------------------------------------------------------*
   * Routine: getColorMap()
   *
   * Return a map<double, char> which maps measurement value to 
   *   allocated color.
   *----------------------------------------------------------------------*
   */
  const map<double, char>& getColorMap() const
  {
    return mValueColorMap;
  }
  
private:
  vector<char> mColors;
  map<double, char> mValueColorMap;
  static const char* spColors;
  
  double mResolution;
};


/** TpiShmooViewer display shmoo data in Shmoo Plot. 
 *  it is called when
 *
 *  - Start of the whole shmoo;
 *  - Stop of the whole shmoo;
 *  - Availability of a new measurement point.
 */
class TpiShmooViewer 
{
public:
  /**
   *----------------------------------------------------------------------*
   * Routine: constructor
   *
   * Parameters:
   *   1. pParameterX : shmoo parameter on the X Axis
   *   2. pParameterY : shmoo parameter on the Y Axis.
   *   3. pShmooResult: shmoo result container.
   *   4. title       : the title that will be displayed in the Shmoo Plot.
   *----------------------------------------------------------------------*
   */
  TpiShmooViewer(double startX,
		 double stopX,
		 unsigned int totalStepX,
                 const string& shortNameX,
                 const string& unitX,
                 double startY,
                 double stopY,
                 unsigned int totalStepY,
                 const string& shortNameY,
                 const string& unitY,
                 ShmooResult* pShmooResult,
                 const string& title,
                 double resultResolution,
                 int mode,
                 const string& setupPinsX,
                 const string& setupPinsY,
                 const string& resultPins);

  /**
   * will be called when the whole shmoo starts
   */
  void onStart();
  /**
   * will be called when the whole shmoo stops
   */
  void onStop();
  /**
   * will be called when a new measurement at point(a,b) is performed.
   */
  void onValue(unsigned int a, unsigned int b, const ShmooCellResult& cellResult);
 
  static const int FFCI_MODE = 0x01;
  static const int CYCLE_ERCT_MODE = 0x02;
  static const int OTHER_MODE = 0x04;

  //void setFailValue(double failValue);
private:
  /**
   * display the whole shmoo results in the Shmoo Plot.
   */
  void print() const;
  /**
   * display the setup information, such as start, stop on X/Y Axis.
   */
  void printFrame() const;
  /**
   * clear the color in the Shmoo Plot.
   */
  void printColor() const;
  /**
   * display the shmoo result in the Shmoo Plot.
   */
  void printData() const;
  /**
   * display the color- value mapping information in the Shmoo Plot.e.g 
   * Red means 2, White means 1.
   */
  void printColorMap() const;

  bool isAllPointsMeasured() const;

  bool isAllMeasuredPointsPassFail() const;

  void initializePinNameMessages();
  
  void printPin() const;
  ColorAllocator mColorAllocator;
  double mStartX;
  double mStopX;
  double mTotalStepX;
  string mShortNameX;
  string mUnitX;
  double mStartY;
  double mStopY;
  unsigned int mTotalStepY;
  string mShortNameY;
  string mUnitY;
  ShmooResult *mpShmooResult;
  string mTitle;
  struct timeval mLastUpdateTime;
  int mMode;
  vector<string> pinNameMessages;
  
  string mSetupPinsX;
  string mSetupPinsY;
  string mResultPins;

  struct TpiPin
  {
    string channel;
    string pinName;
  };

  class TpiPinCompare
  {
  public:
    bool operator()(const TpiPin& a, const TpiPin&b)
    {
      return a.channel < b.channel;
    }
  };
};

extern "C" 
{
  /*
   * Open Shmoo Plot
   */
  void OpenShmoo(unsigned char* status);
  /*
   * Write command to Shmoo Plot
   */
  void WriteShmoo(const char* cmd);
  /*
   * Close Shmoo Plot
   */
  void CloseShmoo();
}
#endif
