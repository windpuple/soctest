/**
 * (c) Copyright 2011, Verigy Technologies, all rights reserved.
 *
 * Modification History:
 *
 *
 */

//for testmethod framework interfaces
#include "testmethod.hpp"
//for testmethod API interfaces
#include "mapi.hpp"

#include "Frequency_byDigitalCaptureUtil.hpp"

/**
 *----------------------------------------------------------------------*
 * @testmethod class: Frequency_byDigitalCapture
 *
 * @Purpose: Test frequency by digtital capture
 *
 *----------------------------------------------------------------------*
 * @Description:
 *   This testmethod performs a digital capture test and analyzes the 
 *   digital capture data for the desired measurement pins which are
 *   specified in vector variable, to determine the frequency.
 * @Parameters:
 *   1.string vectorVariableName:              
 *     vector variable name.
 *   2.string algorithm:            {FFT|Linear Fit}
 *     default is FFT.
 *   3.testmethod::SpecValue  samplePeriod: {ns}
 *     sample period value.     
 *   4.testmethod::SpecValue targetFrequency           {MHz}
 *     this parameter is used in undersampling case.
 *     in case of undersampling, you should enter the target frequency.
 *     otherwise just use the default value 0.
 *   5.string output:               {ReportUI | None}
 *     Print message or not. 
 *     ReportUI - for debug mode
 *     None - for production mode
 *   
 *----------------------------------------------------------------------*
 */
 

class Frequency_byDigitalCapture: public testmethod::TestMethod
{
protected:
  string  vectorVariableName;
  string  algorithm;
  testmethod::SpecValue  samplePeriod;
  testmethod::SpecValue  targetFrequency;
  string  output;
  string mTestName;
  static string sDefaultTestname;

protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    addParameter("vectorVariableName",
                 "string",
                 &vectorVariableName);
    addParameter("algorithm",
                 "string",
                 &algorithm)
      .setDefault("FFT")
      .setOptions("FFT:Linear Fit");
    addParameter("samplePeriod",
                 "SpecValue",
                 &samplePeriod)
      .setDefault("0[ns]")
      .setComment("sample period, e.g. 40[ns]");
    addParameter("targetFrequency",
                 "SpecValue",
                 &targetFrequency)
      .setDefault("0[MHz]")
      .setComment("target frequency, e.g. 80[MHz]");
    addParameter("output",
                 "string",
                 &output)
      .setDefault("None")
      .setOptions("None:ReportUI");
    addParameter("testName",
                 "string",
                 &mTestName)
      .setDefault(sDefaultTestname)
      .setComment("test limit's name, default is \""+sDefaultTestname+"\"\n"
         "no unit means 'MHz' with this default name\n"
         "this limit is defined in limit section or testtable file.");

    addLimit(sDefaultTestname);
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
    static FrequencyUtil::FrequencyParam params;
    static FrequencyUtil::FrequencyResult results;
    
    ON_FIRST_INVOCATION_BEGIN();
      /* process parameters and store them to struct "params" */
      FrequencyUtil::processParameters(vectorVariableName,
                                       algorithm,
                                       samplePeriod.getValueAsTargetUnit("ns"),
                                       targetFrequency.getValueAsTargetUnit("MHz"),
                                       params);
      /* process limit and store it to struct "results" */
      results.testName = mTestName;
      
      TestTable* pLimitTable = TestTable::getDefaultInstance();
      pLimitTable->readCsvFile();
      results.isLimitTableUsed = pLimitTable->isTmLimitsCsvFile();
      if (results.isLimitTableUsed)
      {
        try
        {
          string key = params.testsuiteName + ":" + mTestName;
          V93kLimits::TMLimits::LimitInfo limitInfo =
            V93kLimits::tmLimits.getLimit(key);
          results.limit = limitInfo.TEST_API_LIMIT;
        }
        catch(Error& e)
        {
          results.limit = GET_LIMIT_OBJECT(mTestName);
        }
      }
      else
      {
        results.limit = GET_LIMIT_OBJECT(mTestName);
      }
      //use "MHz" for empty unit
      if (sDefaultTestname == mTestName && results.limit.unit().empty())
      {
        results.limit.unit("MHz");
      }
    ON_FIRST_INVOCATION_END();

    /* do test and store the results */
    FrequencyUtil::doMeasurement (params,results);


    /* datalog */
    FrequencyUtil::judgeAndDatalog (results);
  
    /* output results */
    FrequencyUtil::reportToUI (results,output);

    return ;
  }
 
  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   *
   *Note: TestMethod API should not be used in this method.
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    return ;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string  getComment() const
  {
     static string comment = _TML_VERSION;
     return comment;
  }
};

string Frequency_byDigitalCapture::sDefaultTestname = "passFrequency_MHz";

REGISTER_TESTMETHOD("AcTest.Frequency_byDigitalCapture", Frequency_byDigitalCapture);
