#ifndef INCLUDE_JITTERHISTOGRAM_H
#define INCLUDE_JITTERHISTOGRAM_H
#include <algorithm>
#include "CommonUtil.hpp"
#include "JitterUtil.hpp"

/******************************************************************************
 *                    jitter separation test utility class 
 ******************************************************************************
 *@Description:
 * By setting up different parameters,users can make the jitter separation
 * measurement in different conditions.
 *    pattern synchronization: find a passing pattern
 *    transtioon search on specified side(s): optimize the start of jitter data
 *                                           acquisition.
 *    data acquisition on specified side(s): sample the jitter data
 *    jitter separatioon calculation.
 * according the description,the whole process steps:
 * |----------------|     |------------|       |-------------|       |---------|
 * |    pattern     |     | transition |       |             |       |         |
 * |synchronization |---->|  search    |------>|     data    |------>|  post   |
 * |   (optional)   |     | (optional) |       | acquisition |       | process |
 * |----------------|     |------------|       |-------------|       |---------|
 *
 ******************************************************************************
 */ 
class JitterSeparationUtil
{
  public:

  // reliable linear fitting correlation coefficient limit
  static const DOUBLE RELIABLE_FITTING_THRESHOLD = 0.85;

  /**
   *---------------------------------------------------------------------------
   *         test parameters containe
   *---------------------------------------------------------------------------
   */
  struct  JitterSeparationParameter
  {
    //common parameter for jitter histogram, separation and stardust
    JitterUtil::JitterParameter commonParameter;
    //special paramters for jitter separation
    INT bitNumbers;
    DOUBLE fittingRangeMax;
    DOUBLE fittingRangeMin;
    INT BER_factor;        
  };
 /**
  *----------------------------------------------------------------------------
  *         test limits container                                    
  *----------------------------------------------------------------------------
  */
  struct JitterSeparationLimit
  {
    bool isLimitTableUsed;
    string randomJitterTestname;
    string deterministicJitterTestname;
    string totalJitterTestname;
    LIMIT randomJitterLimit;
    LIMIT deterministicJitterLimit;
    LIMIT totalJitterLimit;
  } ;
  /**
   *---------------------------------------------------------------------------
   *         test results container
   *---------------------------------------------------------------------------
   */
  struct ResultData
  {
    // BER data vector of left transition
    vector<DOUBLE> leftBERData;
 
    // BER data vector of right transition
    vector<DOUBLE> rightBERData;

    // the result of jitter 
    JitterSeparationType separationJitter;
 
    // correlation coefficient of the left side linear fitting arithmetic
    DOUBLE leftCorrelationCoef;
    
    // correlation coefficient of the right side linear fitting arithmetic
    DOUBLE rightCorrelationCoef;

    // initialize all stuffs to some defaults.
    void init()
    {
      leftBERData.clear();
      rightBERData.clear();
      separationJitter.randomJitter = 0.0;
      separationJitter.deterministicJitter = 0.0;
      separationJitter.totalJitter = 0.0;
      leftCorrelationCoef = 0.0;
      rightCorrelationCoef = 0.0;
    }
    ResultData()
    {
      init();
    }
  };
  /**
   *---------------------------------------------------------------------------
   * @Struct: JitterSeparationResult
   * @Purpose: container to store jitter separation measurement
   *         results
   *---------------------------------------------------------------------------
   * @Decription:
   *   This two-layered map contains result of test.The outside map contains
   *   every site's result.The inside map contains every pin's result.
   *   The outside map's key: INT is the index of site number
   *   The outside map's value:map<STRING,ResultData> is the result of the
   *   site which is indexed by key.
   *   The inside map's key: STRING is the pin's name.
   *   The inside map's value: ResultData is the result of the pin which is
   *   indexed by key.
   * @Note:
   *---------------------------------------------------------------------------
   */
  struct JitterSeparationResult
  {
    map<INT,map<STRING, ResultData> > resultMap;
    JitterUtil::JitterResult jitterResult;
    void init()
    {
      jitterResult.init();
      resultMap.clear();
    }
  } ;
  /**
   *---------------------------------------------------------------------------
   *         public interfaces of jitter separation  test
   *---------------------------------------------------------------------------
   */  
  
  static void processParameters(
    const STRING& pinlist,
    const STRING& portName,
    const STRING& specName_postfix,
    const DOUBLE UI_width_ns,
    const DOUBLE start_ns,
    const DOUBLE stop_ns,
    const DOUBLE dataAcquStepWidth_ns,
    const INT passOnMaxErrorCount,
    const STRING& autoSyncMode,
    const DOUBLE autoSyncStepWidth_ns,
    const STRING& transitionSearchMode,
    const INT bitNumbers,
    const DOUBLE fittingRangeMax,
    const DOUBLE fittingRangeMin,
    const INT BER_factor,
    const STRING& outputMode,
    JitterSeparationParameter& parameters);
  static void processLimit(
    const string& testname,
    JitterSeparationLimit& testlimit);
  static void doMeasurement(
    const JitterSeparationParameter& parameters,
    JitterSeparationResult& results);
  static void judgeAndDatalog(
    const JitterSeparationParameter& parameters,
    const JitterSeparationResult& results,
    const JitterSeparationLimit & testlimit);
  static void reportToUI(
    const JitterSeparationParameter& parameters,
    const JitterSeparationResult& results,
    const STRING& output);
  static bool processTestName(
    const string& testname,vector<string>& names);
  private:
  static void separationCalculation(
    const JitterSeparationParameter& parameters,
    JitterSeparationResult& results);
  static void applyPatternSyncValue(
    const JitterSeparationParameter& parameters,
    const JitterSeparationResult& results);
  static void preProcessErrorCount(const vector<INT>& source,
                                   const DOUBLE factor,
                                   const DOUBLE rangeMax,
                                   const DOUBLE rangeMin,
                                   const DOUBLE startPoint,
                                   const DOUBLE stepWidth,
                                   vector<DOUBLE>& result,
                                   DOUBLE& resultStartPoint);
  static void printBathtubCurve(const vector<INT> &,
                                const vector<INT> &,
                                const DOUBLE ,
                                const DOUBLE ,
                                const DOUBLE);
  static void prepareDataForAnalyzer(const STRING&,
                                     const vector<INT>&,
                                     const vector<INT>&,
                                     const DOUBLE,
                                     const DOUBLE,
                                     const DOUBLE,
                                     SCATTER_LOG &);
  static void linearInterpolation(vector<INT>& data);
};
  
/**
 *----------------------------------------------------------------------------- 
 * Routine: processTestName
 *
 * Purpose: process names of test limits
 *
 *-----------------------------------------------------------------------------
 * Description:
 *   the input testname is in the format as "(randomJitter,deterministicJitter,totalJitter)"
 *   the output names is in vector of "randomJitter", "deterministicJitter" and
 *   "totalJitter"
 *   return value: true if the test name is valid, otherwise, false is returned.
 * Note:
 *-----------------------------------------------------------------------------
 */
bool JitterSeparationUtil::processTestName(const string& testname,vector<string>& names)
{
  bool isValid = false;
  string validName = CommonUtil::trim(testname);
  string::size_type leadPos = validName.find("(");
  string::size_type postPos = validName.find(")");
  
  names.clear();
  if (leadPos != string::npos && postPos != string::npos && leadPos < postPos)
  {
    validName = validName.substr(leadPos+1,postPos-leadPos-1);
    CommonUtil::splitStr(validName,',',names);
    isValid = true;
  }
  return isValid;
}
  
/**
 *----------------------------------------------------------------------------- 
 *@Routine: processParameter
 *
 *@Purpose: parse input parameters and setup internal parameters
 *
 *----------------------------------------------------------------------------- 
 *@Description: according user's input to fill out interal 
 *@parameters Parameters:
 *   1.STRING& pinlist:
 *     Define a list of pins/pin groups the spec is shifted for.
 *     valid type :O,IO
 *   2.STRING& portName:           optional {@|portName}
 *     Port name of above test pins for Multiport Setups.
 *     NOTE:only pins of one port can be selected.
 *     default is @.
 *   3.STRING& specName_postfix:
 *     A spec-variable corresponding to each test-pin should be predefined
 *     and used by this TestMethod to do jitter measurement.
 *     For example:if Tx0 is the input pin,its corresponding
 *     spec-variables are Tx0_offset,this parameter needs to be
 *     set as "offset".
 *   4.DOUBLE UI_width_ns:
 *     Bit time of test pattern.
 *     For example:2.5Gb/s -> 0.4ns
 *   5.DOUBLE start_ns:
 *     --if autoSyncMode is "OFF":start of Data Acquisition
 *     --if autoSyncMode is "ON" or "ON_KEEP_VALUE": start of linear Pattern
 *     Alignment Search
 *   6.DOUBLE stop_ns:
 *     --if autoSyncMode is "OFF":stop of Data Acquisition
 *     --if autoSyncMode is "ON" or "ON_KEEP_VALUE": stop of linear Pattern
 *     Alignment Search
 *   7.DOUBLE dataAcquStepWidth_ns:
 *     Step width for Data Acquisition
 *   8.INT passOnMaxErrorCount:     optional
 *     It defines the pass criteria for all following execution.That is,
 *     besides normally regarding pass as 0 error count, users
 *     can specify the maximum edge count as the pass/fail
 *     threshold. default vaule: 0
 *   9.STRING& autoSyncMode: {OFF | ON | ON_KEEP_VALUE}
 *     Enabling of linear Pattern Alignment Search to find passing pattern.
 *       With ON_KEEP_VALUE option the Sync value will be kept
 *     after the finishing of the testsuite execution.
 *       With ON option the spec variable will be reset to its
 *     original value after finishing the test.
 *       With OFF option linear Pattern Alignment Search to find
 *     passing pattern is disable.
 *       default is ON.
 *   10.DOUBLE autoSyncStepWidth_ns:
 *      Step width for AutoSync Search.
 *   11.STRING& transitionSearchMode:  {OFF | ON}
 *        With ON,Binary Search for Pass/Fail Transition of
 *      MIN_BER poit with maximum search range of one "UI_width"
 *      and resolution of dataAcquStepWidth_ns.
 *        With OFF,transiton search will not be made.
 *      default is ON.
 * 
 *      NOTES: autoSyncMode and transitionSearchMode can't be
 *      OFF at the same time for jitter separation test, because
 *      this test need two side data to do jitter separation.
 *   12.INT bitNumbers:
 *      The total bit numbers of the pattern
 *   13.DOUBLE fittingRangeMax:
 *      Max BER number for fitting
 *   14.DOUBLE fittingRangeMin:
 *      Min BER number for fitting
 *   15.INT BER_factor,
 *      Target BER for total jitter calculation.
 *   16.STRING& outputMode: {SUMMARY | DETAIL | ANALYSIS}
 *      This parameter is in effect only if output is set ReportUI.
 *      SUMMARY - a result table will be printed in the Report Window.
 *      DETAIL  - an ASCII plot of the Error Count and the bathtub curve
 *                will be printed in report window.
 *      ANALYSIS - the jitter bathtub data will be transfer to signal
 *                analyzer tool for display and debugging.
 *      default is SUMMARY.
 *   17.JitterSeparationParameter& parameters
 *      this parameter's type is output,we use user's input to
 *      fill out this parameter.
 *   Note:
 *-----------------------------------------------------------------------------
 */
void JitterSeparationUtil::processParameters(
  const STRING& pinlist,
  const STRING& portName,
  const STRING& specName_postfix,
  const DOUBLE UI_width_ns,
  const DOUBLE start_ns,
  const DOUBLE stop_ns,
  const DOUBLE dataAcquStepWidth_ns,
  const INT passOnMaxErrorCount,
  const STRING& autoSyncMode,
  const DOUBLE autoSyncStepWidth_ns,
  const STRING& transitionSearchMode,
  const INT bitNumbers,
  const DOUBLE fittingRangeMax,
  const DOUBLE fittingRangeMin,
  const INT BER_factor,
  const STRING& outputMode,
  JitterSeparationParameter& parameters)
{
  JitterUtil::JitterParameter& commonParameter = parameters.commonParameter;
  STRING tempString = CommonUtil::trim(pinlist);
  JitterUtil::checkSetupPinlist(tempString);
  commonParameter.PinVector = JitterUtil::expandPinlistToPins(tempString);

  commonParameter.portName = CommonUtil::trim(portName);

  tempString = CommonUtil::trim(specName_postfix);
  if( tempString.empty())
  {
    STRING api = "Check parameter specName_postfix: ";
    STRING msg = "There is no specName_postfix! Please input specName_postfix.";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }
  commonParameter.specName_postfix = tempString;

  if(UI_width_ns <= 0)
  { 
    STRING api = "Check parameter UI_width_ns: ";
    STRING msg = "UI_width_ns should be greater than zero!";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }
  commonParameter.UI_width_ns = UI_width_ns;
  commonParameter.start_ns = start_ns;
  commonParameter.stop_ns = stop_ns;
  if(dataAcquStepWidth_ns <= 0)
  { 
    STRING api = "Check parameter dataAcquStepWidth_ns: ";
    STRING msg = "dataAcquStepWidth_ns should be greater than zero!";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }
  commonParameter.dataAcquStepWidth_ns = dataAcquStepWidth_ns;

  if(passOnMaxErrorCount < 0)
  { 
    STRING api = "Check parameter passOnMaxErrorCount: ";
    STRING msg = "passOnMaxErrorCount shoult not be negative!";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }
  commonParameter.passOnMaxErrorCount = passOnMaxErrorCount;

  tempString = CommonUtil::trim(autoSyncMode);
  if(tempString == "OFF")
  {
    commonParameter.autoSyncMode = JitterUtil::AUTOSYNC_OFF;
  }
  else if (tempString == "ON")
  {
    commonParameter.autoSyncMode = JitterUtil::AUTOSYNC_ON;
  } 
  else if (tempString == "ON_KEEP_VALUE")
  {
    commonParameter.autoSyncMode = JitterUtil::AUTOSYNC_ON_KEEP_VALUE;
  }
  else
  {
    STRING api = "Check parameter AUTOSYNC_MODE: ";
    STRING msg = "These is an unknow AUTOSYNC_MODE type.";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }

  if(autoSyncStepWidth_ns <= 0)
  { 
    STRING api = "Check parameter autoSyncStepWidth_ns: ";
    STRING msg = "autoSyncStepWidth_ns should be greater than zero!";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }
  commonParameter.autoSyncStepWidth_ns = autoSyncStepWidth_ns;

  tempString = CommonUtil::trim(transitionSearchMode); 
  if(tempString == "OFF")
  {
    if(commonParameter.autoSyncMode == JitterUtil::AUTOSYNC_OFF)
    {
      STRING api = "Check Parameter TRANSITIONSEARCH_MODE and"
                   "parameter AUTOSYNC_MODE: ";
      STRING msg = "autoSyncMode and transitionSearchMode can't be "
                   "OFF at the same time for jitter separation test,\n because"
                   "this test need two side data to do jitter separation.";
      throw Error(api.c_str(),msg.c_str(),api.c_str());
    }
    commonParameter.transitionSearchMode = JitterUtil::TRANSITIONSEARCH_OFF;
  }
  else if(tempString == "ON")
  {
    commonParameter.transitionSearchMode = JitterUtil::TRANSITIONSEARCH_ON;
  }
  else
  {
    STRING api = "Check parameter TRANSITIONSEARCH_MODE: ";
    STRING msg = "These is an unknow TRANSITIONSEARCH_MODE type.";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }

  commonParameter.transition = JitterUtil::BOTH;

  parameters.bitNumbers = bitNumbers;
  parameters.fittingRangeMax = fittingRangeMax;
  parameters.fittingRangeMin = fittingRangeMin;
  parameters.BER_factor = BER_factor;

  tempString = CommonUtil::trim(outputMode);
  if (tempString == "SUMMARY")
  {
    commonParameter.outputMode = JitterUtil::OUTPUT_SUMMARY;
  }
  else if(tempString == "DETAIL")
  {
    commonParameter.outputMode = JitterUtil::OUTPUT_DETAIL;
  }
  else if(tempString == "ANALYSIS")
  {
    commonParameter.outputMode = JitterUtil::OUTPUT_ANALYSIS;
  }
  else
  {
    STRING api = "Check parameter OUTPUT_MODE: ";
    STRING msg = "These is an unknow OUTPUT_MODE type.";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }
}

/**
 *-----------------------------------------------------------------------------
 *@Routine: processLimit
 *
 *@Purpose: process Limit(s)
 *
 *-----------------------------------------------------------------------------
 *@Description:
 *   
 *@Note:
 *-----------------------------------------------------------------------------
 */
void JitterSeparationUtil::processLimit(
  const string& testname,
  JitterSeparationLimit& testlimit)
{
  const string funcName = "JitterSeparationUtil::processLimit()";
  vector<string> names;
  if (processTestName(testname,names) && names.size() == 3)
  {
    testlimit.randomJitterTestname = names[0];
    testlimit.deterministicJitterTestname = names[1];
    testlimit.totalJitterTestname = names[2];
  }
  else
  {
    throw Error(funcName,
      "three test names are needed for random,deterministic, and total jitter testing.",
      funcName);
  }
  
  //first, try to get limit from test table 
  string testsuiteName;
  GET_TESTSUITE_NAME(testsuiteName);
  TesttableLimitHelper ttlHelper(testsuiteName);
  if (ttlHelper.isLimitCsvFileLoad())
  {
    ttlHelper.getLimit(testlimit.randomJitterTestname, testlimit.randomJitterLimit);
    ttlHelper.getLimit(testlimit.deterministicJitterTestname, testlimit.deterministicJitterLimit);
    ttlHelper.getLimit(testlimit.totalJitterTestname, testlimit.totalJitterLimit);
  }
      
  testlimit.isLimitTableUsed = ttlHelper.isAllInTable(); 

  //if not defined in test table, use testflow limit
  if(!testlimit.isLimitTableUsed)
  {
    testlimit.randomJitterLimit = GET_LIMIT_OBJECT(testlimit.randomJitterTestname);
    testlimit.deterministicJitterLimit = GET_LIMIT_OBJECT(testlimit.deterministicJitterTestname);
    testlimit.totalJitterLimit = GET_LIMIT_OBJECT(testlimit.totalJitterTestname);
  }

  //default is 'ps' as same as parameter definition
  if (testlimit.randomJitterLimit.unit().empty())
  {
  testlimit.randomJitterLimit.unit("ps");
  }
  if (testlimit.deterministicJitterLimit.unit().empty())
  {
  testlimit.deterministicJitterLimit.unit("ps");
  }    
  if (testlimit.totalJitterLimit.unit().empty())
  {
  testlimit.totalJitterLimit.unit("ps");
}
}
/**
 *-----------------------------------------------------------------------------
 *@Routine: doMeasurement
 *
 *@Purpose: execute measurement and store results
 *
 *-----------------------------------------------------------------------------
 *@Description:
 *
 *@Parameters:
 *    INPUT:
 *        parameters--------------test parameters
 *        result------------------test result container
 *
 *@RETURN:
 *@NOTE:
 * process steps:
 * |----------------|     |------------|       |-------------|       |---------|
 * |    pattern     |     | transition |       |             |       |         |
 * |synchronization |---->|  search    |------>|     data    |------>|  post   |
 * |   (optional)   |     | (optional) |       | acquisition |       | process |
 * |----------------|     |------------|       |-------------|       |---------|
 *-----------------------------------------------------------------------------
 */
void JitterSeparationUtil::doMeasurement(
  const JitterSeparationParameter & parameters,
  JitterSeparationResult& results)
{
  ON_FIRST_INVOCATION_BEGIN();
    results.init();
    CONNECT();
    FW_TASK("SQGB ACQF,0;");
  ON_FIRST_INVOCATION_END();

  const JitterUtil::JitterParameter& commonParameter = parameters.commonParameter;
  // autoSync
  if(commonParameter.autoSyncMode == JitterUtil::AUTOSYNC_ON || 
     commonParameter.autoSyncMode == JitterUtil::AUTOSYNC_ON_KEEP_VALUE)
  { 
    bool isEveryPinOfAllSitesFail = false;
    JitterUtil::autoSync(parameters.commonParameter,
                         results.jitterResult,
                         isEveryPinOfAllSitesFail);
    if(isEveryPinOfAllSitesFail)
    {
      return;
    }
  }
  // transition search
  if(commonParameter.transitionSearchMode == JitterUtil::TRANSITIONSEARCH_ON)
  {
    bool isEveryPinOfAllSitesFail = false;
    JitterUtil::transitionSearch(parameters.commonParameter,
                                 results.jitterResult,
                                 isEveryPinOfAllSitesFail);
    if(isEveryPinOfAllSitesFail)
    {
      return;
    }
  }
  //data acquisition
  JitterUtil::dataAcquire(parameters.commonParameter,results.jitterResult);
  
  //post process: calculation and apply pattern synchronization value
  ON_FIRST_INVOCATION_BEGIN();
    separationCalculation(parameters,results);
    if(commonParameter.autoSyncMode == JitterUtil::AUTOSYNC_ON_KEEP_VALUE)
    {
      applyPatternSyncValue(parameters,results);
    }
  ON_FIRST_INVOCATION_END();
}

/**
 *-----------------------------------------------------------------------------
 *@Routing: separationCalculation
 *
 *@Purpose: calculate jitter value of every pin of every site
 *
 *-----------------------------------------------------------------------------
 *@Description:
 *  the function calculate the jitter value according to the testing
 *  result(error count).
 *@Parameters:
 *   INPUT:
 *      parameters---------test parameters
 *   INPUT and OUTPUT:
 *      results------------test result container
 *@Return:
 *-----------------------------------------------------------------------------
 */
void JitterSeparationUtil::separationCalculation(
  const JitterSeparationParameter& parameters,
  JitterSeparationResult& results)
{
  const JitterUtil::JitterParameter& commonParameter = parameters.commonParameter;
  JitterUtil::JitterResult& commonResult = results.jitterResult;

  map<INT, map<STRING,JitterUtil::CommonResultData> >::const_iterator site_it;
  map<STRING,JitterUtil::CommonResultData>::const_iterator pin_it;
  
  for(site_it = commonResult.commonResultMap.begin();
      site_it != commonResult.commonResultMap.end();
      ++site_it)//for every site
  {
    for(pin_it = site_it->second.begin();
        pin_it != site_it->second.end();
        ++pin_it)//for every pin
    {
      if(pin_it->second.lastStatus == JitterUtil::BOTH_JITTER)
      {
        DOUBLE leftStartValue = 0.0, rightStartValue = 0.0;
        INT site = site_it->first;
        STRING pinName = pin_it->first;
        if(commonParameter.transitionSearchMode == JitterUtil::TRANSITIONSEARCH_ON)
        {
          leftStartValue = 
            commonResult.commonResultMap[site][pinName].leftTransitionVal;
          rightStartValue = 
            commonResult.commonResultMap[site][pinName].rightTransitionVal;
        }
        else  
        {
          leftStartValue = 
            commonResult.commonResultMap[site][pinName].autoSyncVal;
          rightStartValue = leftStartValue;
        }
        DOUBLE leftBERStartValue = 0.0, rightBERStartValue = 0.0;

        preProcessErrorCount(pin_it->second.leftErrorCount,
                             1.0/parameters.bitNumbers,
                             parameters.fittingRangeMax,
                             parameters.fittingRangeMin,
                             leftStartValue,
                             -commonParameter.dataAcquStepWidth_ns,
                             results.resultMap[site][pinName].leftBERData,
                             leftBERStartValue);

        preProcessErrorCount(pin_it->second.rightErrorCount,
                             1.0/parameters.bitNumbers,
                             parameters.fittingRangeMax,
                             parameters.fittingRangeMin,
                             rightStartValue,
                             commonParameter.dataAcquStepWidth_ns,
                             results.resultMap[site][pinName].rightBERData,
                             rightBERStartValue);

        /**
         * this part code only for offline mode, we need some dummy data
         * to do linear fitting. 
         * for online mode this part code can be removed.
         */
        INT offlineFlag = 0;
        INT dummyDataNumber = 16;
        GET_SYSTEM_FLAG("offline",&offlineFlag);
        if(offlineFlag)
        {
          results.resultMap[site][pinName].leftBERData.clear();
          results.resultMap[site][pinName].rightBERData.clear();
          for(INT loop = 0; loop < dummyDataNumber; ++loop)
          {
            results.resultMap[site][pinName].leftBERData.push_back(0.8/(dummyDataNumber - loop)); 
            results.resultMap[site][pinName].rightBERData.push_back(0.8/(dummyDataNumber - loop));
          }
          leftBERStartValue = 6;
          rightBERStartValue = 20;
        }

        DSP_JITTER_SEPARATION(
          results.resultMap[site][pinName].leftBERData,
          results.resultMap[site][pinName].rightBERData,
          leftBERStartValue,
          rightBERStartValue,
          commonParameter.dataAcquStepWidth_ns,
          commonParameter.UI_width_ns,
          0.5,
          parameters.BER_factor,
          results.resultMap[site][pinName].separationJitter,
          results.resultMap[site][pinName].leftCorrelationCoef,
          results.resultMap[site][pinName].rightCorrelationCoef);

        if(results.resultMap[site][pinName].leftCorrelationCoef 
                                                  < RELIABLE_FITTING_THRESHOLD)
        {
          cerr << "WARNING: Test Pin " << pinName 
               << " left side linear fitting correlation coefficient = " 
               << results.resultMap[site][pinName].leftCorrelationCoef
               << " less than reliable fitting limit " 
               << RELIABLE_FITTING_THRESHOLD << endl;
        }
        if(results.resultMap[site][pinName].rightCorrelationCoef 
                                                  < RELIABLE_FITTING_THRESHOLD)
        {
          cerr << "WARNING: Test Pin " << pinName 
               << " right side linear fitting correlation coefficient = " 
               << results.resultMap[site][pinName].rightCorrelationCoef
               << " less than reliable fitting limit " 
               << RELIABLE_FITTING_THRESHOLD << endl;
        }
      }//end if for jitter calculation
    }//end for every pin
  }//end for every site
}

/**
 *-----------------------------------------------------------------------------
 *@Routine: applyPatternSyncValue
 *
 *@Purpose: keep synchronization value
 *
 *-----------------------------------------------------------------------------
 *@Description:
 * if user sets the autoSyncMode parameter to ON_KEEP_VALUE, then the
 * synchronization value of the test pin will be keeped for the following
 * test suites.
 *
 *@Parameters:
 *   INPUT:
 *       Parameters------------test parameters
 *       results---------------result container
 *@RETURN:
 *-----------------------------------------------------------------------------
 */
void JitterSeparationUtil::applyPatternSyncValue(
  const JitterSeparationParameter& parameters,
  const  JitterSeparationResult& results)
{
  const JitterUtil::JitterParameter& commonParameter = parameters.commonParameter;
  JitterUtil::JitterResult commonResult = results.jitterResult;

  // firmware stream
  ostringstream fsString;
  Boolean isEveryPinOfAllSitesFail = true;
  FOR_EACH_SITE_BEGIN();
    INT siteNumber = CURRENT_SITE_NUMBER();
    Boolean isFirstTime = true;
    STRING_VECTOR::const_iterator it = commonParameter.PinVector.begin();
    STRING_VECTOR::const_iterator it_end = commonParameter.PinVector.end();
    for(;it != it_end;++it)
    {
      // autoSync pass, so we can apply the synchronization value to the
      // followig test suites.
      if(commonResult.commonResultMap[siteNumber][*it].lastStatus != JitterUtil::AUTOSYNC_FAIL)
      {
        if(isFirstTime)
        {
          isFirstTime = false;
          fsString << "PSFC " << siteNumber << ";";
        }
        isEveryPinOfAllSitesFail = false;
        fsString << "SHSP TIM," << "\"" << *it << "_" 
                 << commonParameter.specName_postfix;
        if((!commonParameter.portName.empty()) && commonParameter.portName != "@")
        {
          fsString << "@" << commonParameter.portName;
        }
        fsString << "\",(" << *it << "),,,;SHVL ";

        fsString << commonResult.commonResultMap[siteNumber][*it].autoSyncVal << ",;";
      }
    }//end for every pin of one site
  FOR_EACH_SITE_END();
  if(!isEveryPinOfAllSitesFail)
  {
    fsString << "PSFC ALL\n";
    //download and execute firmware command
    FW_TASK(fsString.str());
  }
}

/**
 *-----------------------------------------------------------------------------
 *@Routine: judgeAndDatalog
 *
 *@Purpose: judge and put result into event datalog stream
 *
 *-----------------------------------------------------------------------------
 *@Description:
 *    judge result of 'results' with pass limit form 'testlimit'
 *
 *@Parameters:
 *   INPUT:   
 *     parameters--------------test parameters
 *     testLimit---------------test limit container
 *     result------------------result container
 *
 *@RETURN:
 *-----------------------------------------------------------------------------
 */
void JitterSeparationUtil::judgeAndDatalog(
  const JitterSeparationParameter& parameters,
  const JitterSeparationResult& results,
  const JitterSeparationLimit & testlimit)
{
  const JitterUtil::JitterParameter& commonParameter = parameters.commonParameter;
  INT siteNumber = CURRENT_SITE_NUMBER();
  //user's input unit is ns,translate ns to limit's
  double factorRandom = 1000.0; 
  double factorDeterm = 1000.0;
  double factorTotal = 1000.0;
    
  ARRAY_D randomJitterValues(commonParameter.PinVector.size());
  ARRAY_D determJitterValues(commonParameter.PinVector.size());
  ARRAY_D totalJitterValues(commonParameter.PinVector.size());

  STRING_VECTOR::const_iterator it = commonParameter.PinVector.begin();
  STRING_VECTOR::const_iterator it_end = commonParameter.PinVector.end();
  
  int pinIndex = 0;
  for(;it != it_end; ++it,pinIndex++)
  {
    map<INT,map<STRING,ResultData> > ::const_iterator site_it;
    map<STRING,ResultData>::const_iterator pin_it;
    site_it = results.resultMap.find(siteNumber);
    // because setup error or other error, there is no result for this site.
    if(site_it == results.resultMap.end())
    {
      STRING api = "JitterSeparationUtil::judgeAndDatalog: ";
      STRING msg = "These is no result for this site.";
      throw Error(api.c_str(),msg.c_str(),api.c_str());
    }
    pin_it = site_it->second.find(*it);
    // because setup error or other error, there is no result for this site.
    if(pin_it == site_it->second.end())
    {
      STRING api = "JitterSeparationUtil::judgeAndDatalog: ";
      STRING msg = "These is no result for this pin.";
      throw Error(api.c_str(),msg.c_str(),api.c_str());
    }

    JitterUtil::JitterResult commonResult = 
      const_cast<JitterUtil::JitterResult&>(results.jitterResult);   
    switch(commonResult.commonResultMap[siteNumber][*it].lastStatus)
    {
      case JitterUtil::BOTH_JITTER:
        randomJitterValues[pinIndex] = 
          pin_it->second.separationJitter.randomJitter * factorRandom;
        determJitterValues[pinIndex] = 
          pin_it->second.separationJitter.deterministicJitter * factorDeterm;
        totalJitterValues[pinIndex] = 
          pin_it->second.separationJitter.totalJitter * factorTotal;
        break;
      default:
        randomJitterValues[pinIndex] = NAN;
        determJitterValues[pinIndex] = NAN;
        totalJitterValues[pinIndex] = NAN;
        break;
    }//end for switch
  }//end for pinlist

  //MPR log
  if (testlimit.isLimitTableUsed) //limit table way
  {
    TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
      testlimit.randomJitterTestname, V93kLimits::tmLimits, randomJitterValues);
    TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
      testlimit.deterministicJitterTestname, V93kLimits::tmLimits, determJitterValues);
    TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
      testlimit.totalJitterTestname, V93kLimits::tmLimits, totalJitterValues);
  }
  else // testflow limit way
  {
    TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
      testlimit.randomJitterTestname, testlimit.randomJitterLimit, randomJitterValues);
    TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
      testlimit.deterministicJitterTestname, testlimit.deterministicJitterLimit, determJitterValues);
    TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
      testlimit.totalJitterTestname, testlimit.totalJitterLimit, totalJitterValues);
  }  
}

/**
 *-----------------------------------------------------------------------------
 *@Routine: reportToUI
 *
 *@Purpose: output result to ui_report window
 *
 *-----------------------------------------------------------------------------
 *@Description:
 *   display:
 *       a) summary,just give the summary test result in ui_report
 *       b) detail,will give error count plot 
 *       c) analysis,you can get error count curve in signal analyzer
 *@Parameters: 
 *    INPUT:   
 *       parameters------------test parameters results
 *       results---------------result container
 *       output----------------"NONE" or "ReportUI"
 *@RETURN:
 *@Note:
 *  
 *-----------------------------------------------------------------------------
 */ 
void JitterSeparationUtil::reportToUI(
  const JitterSeparationParameter& parameters,
  const JitterSeparationResult& results,
  const STRING & output)
{
  if(output == "NONE")
  {
    return;
  }

  const JitterUtil::JitterParameter& commonParameter = parameters.commonParameter;

  STRING_VECTOR::const_iterator it = commonParameter.PinVector.begin();
  STRING_VECTOR::const_iterator it_end = commonParameter.PinVector.end();
  INT siteNumber = CURRENT_SITE_NUMBER();

  map<INT,map<STRING,ResultData > > ::const_iterator site_it;
  map<STRING,ResultData >::const_iterator pin_it;

  if(commonParameter.outputMode == JitterUtil::OUTPUT_SUMMARY)// summary mode
  {
    cout << "Jitter Test Summary:   " <<endl;
    cout << "site:                  " << siteNumber << endl;
    for(;it != it_end; ++it)
    {
      site_it = results.resultMap.find(siteNumber);
      // because setup error or other error, there is no result for this site.
      if(site_it == results.resultMap.end())
      {
        cout<<"Warning::There is no result fot this site: " 
            << siteNumber <<endl;
        continue;
      }      
      pin_it = site_it->second.find(*it);
      //because setup error or other errors,thers is no result for this pin.
      if(pin_it == site_it->second.end())
      {
        cout<<"Warning::There is no result for this pin: " << *it
            <<"in site: " << siteNumber <<endl;
        continue;
      }            
      // normal case
      JitterUtil::JitterResult commonResult = 
        const_cast<JitterUtil::JitterResult&>(results.jitterResult);
      switch(commonResult.commonResultMap[siteNumber][*it].lastStatus)
      {
        case JitterUtil::LEFT_JITTER:
        case JitterUtil::RIGHT_TRANSITION_FAIL:
          JitterUtil::printWaringMessage(siteNumber,*it);
          cout << "There is no transition on right!" << endl;
          break;
        case JitterUtil::RIGHT_JITTER:
        case JitterUtil::LEFT_TRANSITION_FAIL:
          JitterUtil::printWaringMessage(siteNumber,*it);
          cout << "There is no transition on left!" << endl;
          break;
        case JitterUtil::BOTH_JITTER:
          cout << "Pins:                    " << *it <<endl
               << "Left linear fitting correlation coefficient is: "
               << pin_it->second.leftCorrelationCoef << endl
               << "Right linear fitting correlation coefficient is: "
               << pin_it->second.rightCorrelationCoef << endl
               << "Random Jitter Result[ps]:      " << endl
               << pin_it->second.separationJitter.randomJitter * 1000 
               <<endl;
          cout << "Deterministic Jitter Result[ps]:     " << endl
               << pin_it->second.separationJitter.deterministicJitter * 1000
               <<endl;
          cout << "Total Jitter Result[ps]:     " << endl
               << pin_it->second.separationJitter.totalJitter * 1000
               <<endl;
          break;
        case JitterUtil::AUTOSYNC_FAIL:
          JitterUtil::printWaringMessage(siteNumber,*it);
          cout << "There is no pass pattern!" << endl;
          break;
        case JitterUtil::BOTH_TRANSITION_FAIL:
          JitterUtil::printWaringMessage(siteNumber,*it);
          cout << "There is no transition for both sides!" << endl;
          break;
        default:
          throw Error("JitterSeparationUtil::reportToUI",
                      "There is an unknown status for reportToUI!",
                      "JitterSeparationUtil::reportToUI");
      }//end for switch
    }//end for pinlist
  }//end for summary mode
  else if (commonParameter.outputMode == JitterUtil::OUTPUT_DETAIL)//detail mode
  {
    cout << "JItter Test Detail:  " << endl;
    cout << "site:                " << siteNumber <<endl;
    for(;it != it_end; ++it)
    {
      site_it = results.resultMap.find(siteNumber);
      // because setup error or other error, there is no result for this site.
      if(site_it == results.resultMap.end())
      {
        cout<<"Warning::There is no result fot this site: " 
            << siteNumber <<endl;
        continue;
      }    
      pin_it = site_it->second.find(*it);
      // because setup error or other error, there is no result for this pin.
      if(pin_it == site_it->second.end())
      {
        cout<<"Warning::There is no result for this pin: " << *it
            <<"in site: " << siteNumber <<endl;
        continue;
      }      
      // normal case 
      JitterUtil::JitterResult commonResult = 
        const_cast<JitterUtil::JitterResult&>(results.jitterResult);
      switch(commonResult.commonResultMap[siteNumber][*it].lastStatus)
      {
        case JitterUtil::LEFT_JITTER:
        case JitterUtil::RIGHT_TRANSITION_FAIL:
          JitterUtil::printWaringMessage(siteNumber,*it);
          cout << "There is no transition on right!" << endl;
          break;
        case JitterUtil::RIGHT_JITTER:
        case JitterUtil::LEFT_TRANSITION_FAIL:
          JitterUtil::printWaringMessage(siteNumber,*it);
          cout << "There is no transition on left!" << endl;
          break;
        case JitterUtil::BOTH_JITTER:
          cout << "Pins:                            " << *it <<endl
               << "Left linear fitting correlation coefficient is: "
               << pin_it->second.leftCorrelationCoef << endl
               << "Right linear fitting correlation coefficient is: "
               << pin_it->second.rightCorrelationCoef << endl
               << "Random Jitter Result[ps]:        " 
               << pin_it->second.separationJitter.randomJitter * 1000 
               << endl;
          cout << "Deterministic Jitter Result[ps]: " 
               << pin_it->second.separationJitter.deterministicJitter * 1000
               << endl;
          cout << "Total Jitter Result[ps]:         "
               << pin_it->second.separationJitter.totalJitter * 1000
               << endl;
          cout << "Bathtub Curve:   " <<endl;
          {
            DOUBLE leftStartValue = 0.0, rightStartValue = 0.0;
            if(commonParameter.transitionSearchMode == JitterUtil::TRANSITIONSEARCH_ON)
            {
              leftStartValue = 
                commonResult.commonResultMap[siteNumber][*it].leftTransitionVal;
              rightStartValue = 
                commonResult.commonResultMap[siteNumber][*it].rightTransitionVal;
            }
            else  
            {
              leftStartValue = 
                commonResult.commonResultMap[siteNumber][*it].autoSyncVal;
              rightStartValue = leftStartValue;
            }
            printBathtubCurve(
              commonResult.commonResultMap[siteNumber][*it].leftErrorCount,
              commonResult.commonResultMap[siteNumber][*it].rightErrorCount,
              leftStartValue,
              rightStartValue,
              commonParameter.dataAcquStepWidth_ns);
          }
          break;	  	  	  
        case JitterUtil::AUTOSYNC_FAIL:
          JitterUtil::printWaringMessage(siteNumber,*it);
          cout << "There is no pass pattern!" << endl;
          break;
        case JitterUtil::BOTH_TRANSITION_FAIL:
          JitterUtil::printWaringMessage(siteNumber,*it);
          cout << "There is no transition for both sides!" << endl;
          break;
        default:
          throw Error("JitterSeparationUtil::reportToUI",
                      "There is an unknown status for reportToUI!",
                      "JitterSeparationUtil::reportToUI");
      }
    }
  }
  else // analysis mode
  {
    cout << "Jitter Test Analysis:    " << endl;
    cout << "site       :             " << siteNumber << endl;
    for(;it != it_end; ++it)
    {
      site_it = results.resultMap.find(siteNumber);
      // because setup error or other error, there is no result for this site.
      if(site_it == results.resultMap.end())
      {
        cout<<"Warning::There is no result fot this site: " << siteNumber <<endl;
        continue;
      }      
      pin_it = site_it->second.find(*it);
      // because setup error or other error, there is no result for this pin.
      if(pin_it == site_it->second.end())
      {
        cout<<"Warning::There is no result for this pin: " << *it
            <<"in site: " << siteNumber <<endl;
        continue;
      }      

      // normal case
      JitterUtil::JitterResult commonResult = 
        const_cast<JitterUtil::JitterResult&>(results.jitterResult);
      switch(commonResult.commonResultMap[siteNumber][*it].lastStatus)
      {
        case JitterUtil::LEFT_JITTER:
        case JitterUtil::RIGHT_TRANSITION_FAIL:
          JitterUtil::printWaringMessage(siteNumber,*it);
          cout << "Tthere is no transition on right!" << endl;
          break;
        case JitterUtil::RIGHT_JITTER:
        case JitterUtil::LEFT_TRANSITION_FAIL:    
          JitterUtil::printWaringMessage(siteNumber,*it);
          cout << "There is no transition on left!" << endl;
          break;
        case JitterUtil::BOTH_JITTER:
          {
            DOUBLE leftStartValue = 0.0, rightStartValue = 0.0;
            if(commonParameter.transitionSearchMode == JitterUtil::TRANSITIONSEARCH_ON)
            {
              leftStartValue = 
                commonResult.commonResultMap[siteNumber][*it].leftTransitionVal;
              rightStartValue = 
                commonResult.commonResultMap[siteNumber][*it].rightTransitionVal;
            }
            else  
            {
              leftStartValue = 
                commonResult.commonResultMap[siteNumber][*it].autoSyncVal;
              rightStartValue = leftStartValue;
            }
            SCATTER_LOG separationWave;
            prepareDataForAnalyzer(
              pin_it->first,
              commonResult.commonResultMap[siteNumber][*it].leftErrorCount,
              commonResult.commonResultMap[siteNumber][*it].rightErrorCount,
              leftStartValue,
              rightStartValue,
              commonParameter.dataAcquStepWidth_ns,
              separationWave);
            PUT_DEBUG(*it,"JITTER SEPARATION",separationWave);
          }
          cout << "Pins:                            " << *it <<endl
               << "Left linear fitting correlation coefficient is: "
               << pin_it->second.leftCorrelationCoef << endl
               << "Right linear fitting correlation coefficient is: "
               << pin_it->second.rightCorrelationCoef << endl
               << "Random Jitter Result[ps]:        " 
               << pin_it->second.separationJitter.randomJitter * 1000 
               <<endl;
          cout << "Deterministic Jitter Result[ps]: " 
               << pin_it->second.separationJitter.deterministicJitter * 1000
               <<endl;
          cout << "Total Jitter Result[ps]:         "
               << pin_it->second.separationJitter.totalJitter * 1000
               <<endl;
          break;
        case JitterUtil::AUTOSYNC_FAIL:
          JitterUtil::printWaringMessage(siteNumber,*it);
          cout << ", there is no pass pattern!" << endl;
          break;
        case JitterUtil::BOTH_TRANSITION_FAIL:
          JitterUtil::printWaringMessage(siteNumber,*it);
          cout << "There is no transition for both sides!" << endl;
          break;
        default:
          throw Error("JitterSeparationUtil::reportToUI",
                      "There is an unknown status for reportToUI!",
                      "JitterSeparationUtil::reportToUI");
      }
    }
  }
}
/**
 *-----------------------------------------------------------------------------
 *@Routine: JitterSeparationUtil::preProcessErrorCount
 *
 *@Purpose: convert error count to BER(bit error ratio), and 
 *         adjust the BER's range according to parameter
 *         [rangeMax ,rangeMin].
 *-----------------------------------------------------------------------------
 *@Parameters: 
 *   INPUT: 
 *         source--------source data to be processed
 *         factor--------weighting factor
 *         rangeMax------the maximum point for the range
 *         rangeMin------the minimum point for the range
 *         startPoint----the start point of the source data
 *         stepWidth-----the time step width of the source data
 *   OUTPUT:
 *         result--------the result data
 *         resultStartPoint ----------the start point for the result data
 * 
 * @Return
 * ----------------------------------------------------------------------------
 */
void JitterSeparationUtil::preProcessErrorCount(const vector<INT>& source,
                                                const DOUBLE factor,
                                                const DOUBLE rangeMax,
                                                const DOUBLE rangeMin,
                                                const DOUBLE startPoint,
                                                const DOUBLE stepWidth,
                                                vector<DOUBLE>& result,
                                                DOUBLE& resultStartPoint)
{
  vector<INT> errorCountVec = source;
  linearInterpolation(errorCountVec); 
  Boolean isFirstTime = true;
  for(unsigned int loop = 0; loop < errorCountVec.size(); loop++)
  {
    DOUBLE value = errorCountVec[loop] * factor;
    if(value > rangeMin && value < rangeMax)
    {
      result.push_back(value);
      if(isFirstTime)
      {
        resultStartPoint = startPoint + loop * stepWidth;
        isFirstTime =false;
      }
    }
  }
}

/**
 *-----------------------------------------------------------------------------
 *@Routine: JitterSeparationUtil::linearInterpolation
 *
 *@Purpose: smooth data to ensure data is monotone increasing 
 * ---------------------------------------------------------------------------
 *@Parameters:
 *    data----------------the data to be processed 
 *-----------------------------------------------------------------------------
 */
void JitterSeparationUtil::linearInterpolation(vector<INT>& data)
{
  vector<INT>::size_type sizeOfVec = data.size();
  vector<INT>::size_type index = 0;
  vector<INT>::size_type iStart = 0;
  index = iStart +1;
  while (index < sizeOfVec)
  {
    if (data[index] - data[iStart] >=0)
    {
      index++;
      iStart++;
    }
    else
    {
      index++;
      while (index < sizeOfVec)
      {
        if (data[index] - data[iStart] >=0)
        {
          break;
        }
        index ++;
      }
      if (index == sizeOfVec)
      {
        data[sizeOfVec-1] = data[iStart];
        vector<INT>::size_type iIndex = 0;
        for (iIndex = iStart +1;iIndex < sizeOfVec -1; ++iIndex)
        {
          data[iIndex] = data[iStart];
        }
      }
      else
      {
        vector<INT>::size_type iIndex = 0;
        INT dStep = (data[index] - data[iStart])/(index-iStart);
        for (iIndex = iStart +1;iIndex < index; ++iIndex)
        {
          data[iIndex] = data[iStart] + dStep * (iIndex - iStart);
        }
        iStart = index;
        index  = index +1;
      }
    }
  }	
}

/**
 *-----------------------------------------------------------------------------
 * @Routine: JitterSeparationUtil::printBathtubCurve
 *
 * @Purpose: print bathtub curve to ui_report window
 *-----------------------------------------------------------------------------
 * @Parameters:
 *      leftErrorCount----------------left error count data 
 *      rightErrorCount---------------right error count data
 *      leftStartValue----------------the start point of left error count data
 *      rightStartValue---------------the start point of right error count data
 *      stepWidth---------------------the time step width for error count data
 * @Return:
 *-----------------------------------------------------------------------------
 */

void JitterSeparationUtil::printBathtubCurve(const vector<INT> & leftErrorCount,
                                             const vector<INT> & rightErrorCount,
                                             const DOUBLE leftStartValue,
                                             const DOUBLE rightStartValue,
                                             const DOUBLE stepWidth)
{
  // for left side
  INT length = leftErrorCount.size();
  // use function max_element get the max value of the ErrorCount Array
  INT maxValue = *(max_element(leftErrorCount.begin(),leftErrorCount.end()));
  //because the error count number offen is very big, so we adjust the number
  //every line can out put 80 "*" most
  INT loop = 0;
  for(INT loop = length -1;loop > -1; --loop)
  {
    double refence = 0.0;
    if(maxValue != 0)
    {
      refence = static_cast<double>(leftErrorCount[loop])/maxValue;
    }
    INT bar = static_cast<INT>(refence *80);
    for(INT i=0;i < bar;++i)
    {
      cout << "*";
    }
    cout << endl;
  }

  INT blankRow = static_cast<INT>((rightStartValue - leftStartValue)/stepWidth);
  if(blankRow > 10)
  {
    blankRow = 10;
  }
  for(loop = 0; loop < blankRow; ++loop)
  {
    cout << endl;
  }
  
  //for right side
  length = rightErrorCount.size();
  maxValue = *(max_element(rightErrorCount.begin(),rightErrorCount.end()));
  
  for(INT loop = 0;loop < length; ++loop)
  {
    double refence = 0.0;
    if(maxValue != 0)
    {
      refence = static_cast<double>(rightErrorCount[loop])/maxValue;
    }
    INT bar = static_cast<INT>(refence *80);
    for(INT i=0;i < bar;++i)
    {
      cout << "*";
    }
    cout << endl;
  }
}

/**
 *-----------------------------------------------------------------------------
 *@Routine: JitterSeparationUtil::prepareDataForAnalyzer
 *
 *@Purpose: parepare bathtub data for outputing to signal analyzer
 *-----------------------------------------------------------------------------
 *@Parameters:
 *  INPUT:
 *      pinName-----------------------pin name
 *      leftErrorCount----------------left error count data 
 *      rightErrorCount---------------right error count data
 *      leftStartValue----------------the start point of left error count data
 *      rightStartValue---------------the start point of right error count data
 *      stepWidth---------------------the time step width for error count data
 *  OUTPUT:
 *      dataForAnalyzer---------------bathtub data for outputing to signal
 *                                    analyzer
 *@Return:
 *-----------------------------------------------------------------------------
 */
void JitterSeparationUtil::prepareDataForAnalyzer(
  const STRING & pinName,
  const vector<INT>& leftErrorCount,
  const vector<INT>& rightErrorCount,
  const DOUBLE leftStartValue,
  const DOUBLE rightStartValue,
  const DOUBLE stepWidth,
  SCATTER_LOG& dataForAnalyzer)
{
  INT passPoint = static_cast<INT>((rightStartValue - leftStartValue)/stepWidth);
  if(passPoint > 10)
  {
    passPoint = 10;
  }
  INT size = leftErrorCount.size() + rightErrorCount.size() + passPoint;
  ARRAY_I errorCountArray(size);
  ARRAY_D timingArray(size);
  INT loop = 0;
  INT count = 0;
  for(loop = leftErrorCount.size() -1; loop >= 0; --loop)
  {
    errorCountArray[count] = leftErrorCount[loop];
    timingArray[count] = leftStartValue - loop * stepWidth;
    count++;
  }
  for(loop = 1; loop < passPoint + 1; ++loop)
  {
    errorCountArray[count] = 0;
    timingArray[count] = leftStartValue + loop * stepWidth;
    count++;
  }
  for(loop = 0 ; loop < static_cast<INT>(rightErrorCount.size()); ++loop)
  {
    errorCountArray[count] = rightErrorCount[loop];
    timingArray[count] = rightStartValue + loop * stepWidth;
    count++;
  }
  dataForAnalyzer.xAxis(timingArray);
  dataForAnalyzer.xTitle("Time");
  dataForAnalyzer.xUnit("ns");
  dataForAnalyzer.yAxis(errorCountArray);
  dataForAnalyzer.yTitle(pinName + " Separation Data");
  dataForAnalyzer.yUnit("Number");
}
#endif /*INCLUDE_JITTERHISTOGRAM_H*/
