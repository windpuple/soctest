//for testmethod framework interfaces
#include "testmethod.hpp"
//for testmethod API interfaces
#include "mapi.hpp"

#include "JitterHistogramUtilHX.hpp"
/**
 *----------------------------------------------------------------------*
 * @testmethod Class: JitterHistogramHX
 *
 * @Purpose: jitter measurement on the output side of a device.
 *
 *----------------------------------------------------------------------*
 * @Description:
 *   This function performs jitter test shift the spec value. 
 *   When the spec value is shifted,a function test will be runned,then
 *   we can get error count after function test.Through analyzing error
 *   count, we caculate jitter
 * @Parameters:
 *   1.string pinlist :                                                                
 *     Define a list of pins/pin groups the spec is shifted for.                                           
 *     valid type :O,IO
 *   2.testmethod::SpecValue UI_width:   {ns}
 *     Bit time of test pattern.
 *     For example:2.5Gb/s -> 0.4ns
 *   3.testmethod::SpecValue start:      {ns}
 *     --if autoSyncMode is "OFF":start of Data Acquisition
 *     --if autoSyncMode is "ON" : start of linear Pattern Alignment Search
 *   4.testmethod::SpecValue stop:       {ns}
 *     --if autoSyncMode is "OFF":stop of Data Acquisition
 *     --if autoSyncMode is "ON" : stop of linear Pattern Alignment Search      
 *   5.testmethod::SpecValue dataAcquStepWidth:  {ns}
 *     Step width for Data Acquisition
 *   6.string autoSyncMode: {OFF | ON }
 *     Enabling of linear Pattern Alignment Search to find passing pattern. 
 *     With ON option the spec variable will be reset to its original value after
 *     finishing the test.
 *     default is ON.
 *     With OFF option linear Pattern Alignment Search to find passing pattern is disable.
 *   7.testmethod::SpecValue autoSyncStepWidth: {ns}
 *      Step width for AutoSync Search.
 *   8.string transitionSearchMode:  {OFF | ON}
 *      With ON,Binary Search for Pass/Fail Transition of MIN_BER poit with maximum search
 *      range of one "UI_width" and resolution of dataAcquStepWidth_ns.
 *      With OFF,on transiton search will be made.
 *      default is ON.
 *   9.string transition:  {LEFT | RIGHT | BOTH}
 *      Determine which side of bit transition will be searched if transitionSearchMode is 
 *      ON and be acquired for jitter histogram calculation. If both autoSyncMode and 
 *      transitionSearchMode are OFF,this parameter is not in effect,and users have to choose
 *      proper values of start and stop for acquisition based on the test requirement.
 *      default is LEFT.
 *   10.string outputMode: {SUMMARY | DETAIL | ANALYSIS}
 *      This parameter is in effect only if output is set ReportUI.
 *      SUMMARY - a result table will be printed in the Report Window.
 *      DETAIL  - an ASCII plot of the Error Count and the histogram curve will be
 *                printed in report window.
 *      ANALYSIS - the jitter histogram data will be transfer to signal analyzer tool for 
 *                 display and debugging.
 *     default is SUMMARY.
 *   11.string output:               {ReportUI | None}
 *     Print message or not. 
 *     ReportUI - for debug mode
 *     None - for production mode
 *     default is ReportUI.
 *
 * NOTE: this testmethod just supports PinScale.
 *----------------------------------------------------------------------*
 */


class JitterHistogramHX: public testmethod::TestMethod
{
protected:
  string  pinlist;

  testmethod::SpecValue  UI_width;
  testmethod::SpecValue  start;
  testmethod::SpecValue  stop;
  testmethod::SpecValue  dataAcquStepWidth;

  string  autoSyncMode;
  testmethod::SpecValue  autoSyncStepWidth;
  string  transitionSearchMode;
  string  transition;
  string  outputMode;
  string  output;
  string mTestName;

protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    addParameter("pinlist",
                 "PinString",
                 &pinlist)
    .setComment("setup pins");


    addParameter("UI_width",
                 "SpecValue",
                 &UI_width)
    .setDefault("0[ns]")
    .setComment("bit time of test pattern,e.g. 0.4[ns]");

    addParameter("start",
                 "SpecValue",
                 &start)
    .setDefault("0[ns]")
    .setComment("start value, e.g. 0.4[ns]");

    addParameter("stop",
                 "SpecValue",
                 &stop)
    .setDefault("0[ns]")
    .setComment("stop value, e.g. 2[ns]");

    addParameter("dataAcquStepWidth",
                 "SpecValue",
                 &dataAcquStepWidth)
    .setDefault("0[ns]")
    .setComment("step width for data acquisition, e.g. 0.1[ns]");

    addParameter("autoSync",
                 "string",
                 &autoSyncMode)
    .setDefault("ON")
    .setOptions("ON:OFF")
    .setComment("autosync mode");

    addParameter("autoSync.stepWidth",
                 "SpecValue",
                 &autoSyncStepWidth)
    .setDefault("0[ns]")
    .setComment("setp width for autosync search,e.g. 2[ns]");

    addParameter("transitionSearch",
                 "string",
                 &transitionSearchMode)
    .setDefault("ON")
    .setOptions("ON:OFF")
    .setComment("transition search mode");

    addParameter("transitionSearch.transition",
                 "string",
                 &transition)
    .setDefault("LEFT")
    .setOptions("LEFT:RIGHT:BOTH")
    .setComment("determine data acquisition's direction");

    addParameter("output",
                 "string",
                 &output)
    .setDefault("ReportUI")
    .setOptions("ReportUI:NONE")
    .setComment("display result or not");

    addParameter("output.mode",
                 "string",
                 &outputMode)
    .setDefault("SUMMARY")
    .setOptions("SUMMARY:DETAIL:ANALYSIS")
    .setComment("SUMMARY: a result table will be printed in the Report Window\n"
                "DETAIL: an ASCII plot of the Error Count and the histogram"
                " curve will be printed in report window\n"
                "ANALYSIS: the jitter histogram data will be transfer to"
                " signal analyzer tool for display and debugging");
    addParameter("testName",
                 "string",
                 &mTestName)
    .setDefault("(peak_to_peak_jitter_ps,rms_jitter_ps)")
    .setComment("two test limits' names in pairs, "
                "like \"(name for peak to peak jitter, name for rms jitter\")\n"
                "pair.first is for peak to peak, no unit means 'ps' \n"
                "pair.second is for rms, no unit means 'ps'\n"
                "two limits are defined in limit section or testtable file.\n"
                "if test table is used, the limit is defined in file\n"
                "if predefined limit is used, the limit name must be as same as default.");

    addLimit("peak_to_peak_jitter_ps");
    addLimit("rms_jitter_ps");

  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
    static JitterHistogramUtilHX::JitterHistogramParameter parameters;
    static JitterHistogramUtilHX::JitterHistogramLimit testLimit;
    static JitterHistogramUtilHX::JitterHistogramResultHX results_hx;
    /*----------------------------
     * 1. prepare for test
     *----------------------------
     */
    ON_FIRST_INVOCATION_BEGIN();
    /*process all parameters needed in test*/
    JitterHistogramUtilHX::processParameters(pinlist,
                                             UI_width.getValueAsTargetUnit("ns"),
                                             start.getValueAsTargetUnit("ns"),
                                             stop.getValueAsTargetUnit("ns"),
                                             dataAcquStepWidth.getValueAsTargetUnit("ns"),
                                             autoSyncMode,
                                             autoSyncStepWidth.getValueAsTargetUnit("ns"),
                                             transitionSearchMode,
                                             transition,
                                             outputMode,
                                             parameters,
                                             results_hx.jitterDataHX);

    JitterHistogramUtilHX::processLimit(mTestName,testLimit);

    ON_FIRST_INVOCATION_END();

    /* do test and store the results */
    JitterHistogramUtilHX::doMeasurement(parameters, results_hx);

    /* datalog */
    JitterHistogramUtilHX::judgeAndDatalog(parameters,results_hx,testLimit);

    /* output results */
    JitterHistogramUtilHX::reportToUI(parameters,results_hx,output);

    return ;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   *
   *Note: TestMethod API should not be used in this method.
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    if (parameterIdentifier == "UI_width")
    {
      if (UI_width.getValueAsTargetUnit("ns") <= 0)
      {
        getParameter("UI_width").setValid(false);
        getParameter("UI_width").setMessage("UI_width shoult be greater than zero!");
      }
      else
      {
        getParameter("UI_width").setValid(true);
      }
    }
    else if (parameterIdentifier == "dataAcquStepWidth")
    {
      if (dataAcquStepWidth.getValueAsTargetUnit("ns") <= 0)
      {
        getParameter("dataAcquStepWidth").setValid(false);
        getParameter("dataAcquStepWidth").setMessage("dataAcquStepWidth shoult be greater than zero!");
      }
      else
      {
        getParameter("dataAcquStepWidth").setValid(true);
      }
    }
    else if (parameterIdentifier == "autoSync")
    {
      if (CommonUtil::trim(autoSyncMode) == "OFF")
      {
        getParameter("autoSync.stepWidth").setEnabled(false);
      }
      else
      {
        getParameter("autoSync.stepWidth").setEnabled(true);
      }
    }
    else if (parameterIdentifier == "autoSync.stepWidth")
    {
      if (autoSyncStepWidth.getValueAsTargetUnit("ns") <= 0)
      {
        getParameter("autoSync.stepWidth").setValid(false);
        getParameter("autoSync.stepWidth").setMessage("autoSyncStepWidth shoult be greater than zero!");
      }
      else
      {
        getParameter("autoSync.stepWidth").setValid(true);
      }
    }
    else if (parameterIdentifier == "transitionSearch")
    {
      if (CommonUtil::trim(transitionSearchMode) == "OFF")
      {
        getParameter("transitionSearch.transition").setEnabled(false);
      }
      else
      {
        getParameter("transitionSearch.transition").setEnabled(true);
      }
    }
    else if (parameterIdentifier == "output")
    {
      if (CommonUtil::trim(output) == "NONE")
      {
        getParameter("output.mode").setEnabled(false);
      }
      else
      {
        getParameter("output.mode").setEnabled(true);
      }
    }

    return ;
  }
  virtual const string  getComment() const
  {
    static string comment = _TML_VERSION;
    return comment;
  }
};

//define limit name

REGISTER_TESTMETHOD("AcTest.JitterHistogramHX", JitterHistogramHX);
