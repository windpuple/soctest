/**
 * (c) Copyright 2011, Verigy Technologies, all rights reserved.
 *
 * Modification History:
 *
 *
 */

#include "ShmooUtil.hpp"
#include <cmath>
#include <sstream>
using namespace std;

unsigned int StepParser::getTotalStep()
{
  if ( !mIsParsed )
  {
    parse();
    mIsParsed = true;
  }
  return mTotalStep;
}

unsigned int StepParser::getLinearStep()
{
  if ( !mIsParsed )
  {
    parse();
    mIsParsed = true;
  }
  return mLinearStep;
}

bool StepParser::isStepNumberSpecified()
{
  if( !mIsParsed )
  {
    parse();
    mIsParsed = true;
  }
  return mIsStepNumberSpecified;
}

void StepParser::parse()
{
  string modifiedExpression;

  //remove the spaces.
  for ( string::size_type i = 0; i < mExpression.length(); i++ )
  {
    if ( mExpression[i] != ' ' )
    {
      modifiedExpression += mExpression[i];
    }
  }
  mExpression = modifiedExpression;

  if(mExpression.empty())
  {
    setErrorMessage();
    return;
  }

  switch ( mExpression[0] )
  {
  case '#': //the expression is something like "#10"
    mIsStepNumberSpecified = true;
    if(mExpression.length() < 2)
    {
      setErrorMessage();
      return;
    }

    if ( mExpression[1] == '<' )
    {
      parseBinary();
    }
    else
    {
      mTotalStep = stringToUnsignedInt(mExpression.substr(1));
      mLinearStep = 1;
    }
    break;
  case 'F':
  case 'f': // the expression is something like "f0.1" or "f#10";
    if(mExpression.length() < 2)
    {
      setErrorMessage();
      return;
    }

    if ( mExpression[1] == '#' )
    {
      mIsStepNumberSpecified = true;
      if(mExpression.length() < 3)
      {
        setErrorMessage();
        return;
      }

      mTotalStep = stringToUnsignedInt(mExpression.substr(2));
    }
    else
    {
      mIsStepNumberSpecified = false;
      mTotalStep = stepWidthStringToTotalStep(mExpression.substr(1));
    }
    mLinearStep = 4;
    if(mLinearStep > mTotalStep)
    {
      mLinearStep = mTotalStep;
    }
   break;
  default: //the expression is like "0.1"
    mIsStepNumberSpecified = false;
    mTotalStep = stepWidthStringToTotalStep(mExpression);
    mLinearStep = 1;
    break;
  }

  if(mLinearStep > mTotalStep)
  {
    setErrorMessage();
    return;
  }

  if(mTotalStep > 100)
  {
    mMessage = "totalStep should be less than or equal to 100!";
    return;
  }
}

void StepParser::parseBinary()
{
  string::size_type firstLeft = 1;
  
  string::size_type firstRight = mExpression.find_first_of( '>', firstLeft + 2);

  if(firstRight == string::npos)
  {
    setErrorMessage();
    return;
  }

  string::size_type secondLeft = mExpression.find_first_of ( '<', firstRight + 2);
  if(secondLeft == string::npos)
  {
    setErrorMessage();
    return;
  }

  string::size_type secondRight = mExpression.length() - 1;

  if(secondRight < secondLeft + 2    ||
     mExpression[secondRight] != '>' ||
     mExpression[firstRight + 1] != '/')
  {
    setErrorMessage();
    return;
  }

  mTotalStep = stringToUnsignedInt(
    mExpression.substr(firstLeft + 1, firstRight - firstLeft -1) );
  mLinearStep = stringToUnsignedInt(
    mExpression.substr(secondLeft + 1, secondRight - secondLeft - 1) );
}

void StepParser::setErrorMessage()
{
  mMessage = "There is a syntax error in the step, please correct it!";
}

unsigned int StepParser::stepWidthStringToTotalStep(
  const string& stepWidthString)
{
  double stepWidth = 0.0;

  try
  {
    stepWidth = CommonUtil::string2Double(stepWidthString, "stepWidth");
  }
  catch(Error& e)
  {
    setErrorMessage();
  }
  
  // stepWidth cannot be 0.
  if(abs(stepWidth) <= 1e-11)
  {
    setErrorMessage();
  }
  int totalStep = static_cast<int> ( (mTotalDifference+mTotalDifference*1e-9)/stepWidth );//fix CR70585
  if(totalStep <= 0)
  {
    setErrorMessage();
  }
  return static_cast<unsigned int> (totalStep);
}

unsigned int StepParser::stringToUnsignedInt(const string& unsignedIntString)
{
  int value = 0;
  try
  {
    value  = 
      static_cast<int> (CommonUtil::string2Double(unsignedIntString, "int"));
  }
  catch(Error& e)
  {
    setErrorMessage();
  }
 
  if(value <= 0)
  {
    setErrorMessage();
  }
  return static_cast<unsigned int>(value);
}

bool ShmooResult::isPointDifferent(unsigned x1, unsigned y1, unsigned x2, unsigned y2) const
{
  const ShmooCellResult& cellResult1 = mPointResults.find(make_pair(x1, y1))->second;
  const ShmooCellResult& cellResult2 = mPointResults.find(make_pair(x2, y2))->second;
  
  if(cellResult1.resultType != cellResult2.resultType)
  {
    return true;
  }
  return (abs(cellResult1.value - cellResult2.value) >= mResolution);
}

const string ShmooParameter::SPEC_VARIABLE = "SpecVariable";
const string ShmooParameter::BIST_RESOURCE = "BIST Resource";
const string ShmooParameter::HX_INSTRUMENT = "HX Instrument";
const string ShmooParameter::HX_RESOURCE = "HX Resource";

string SpecShmooParameter::getDescription() const
{
  string description = "Parameter: ";
  if(mSpecType == TM::LEV)
  {
    description += "level";
  }
  else
  {
    description += "timing";
  }
  description += "\nSpec     : ";
  description += mSpecName;
  description += "\nSetupPins: ";
  description +=  mSetupPins;
  return description;
}

const string BistHxUtility::SWING = "Swing";
const string BistHxUtility::OFFSET = "Offset";
const string BistHxUtility::DRIVER_LOW = "DriverLow";
const string BistHxUtility::DRIVER_HIGH = "DriverHigh"; 
const string BistHxUtility::RECEIVER_THRESHOLD = "ReceiverThreshold";
const string BistHxUtility::TERMINATION_VOLTAGE = "TerminationVoltage";
const string BistHxUtility::MODULATION_JITTER_AMPLITUDE = "ModulationJitterAmplitude";
const string BistHxUtility::MODULATION_FREQUENCY = "ModulationFrequency";
const string BistHxUtility::MODULATION_COMMONMODE_AMPLITUDE = "ModulationCommonModeAmplitude";
const string BistHxUtility::SKEW = "Skew";
const string BistHxUtility::DRIVER_FINE_DELAY = "DriverFineDelay";
const string BistHxUtility::RECEIVER_FINE_DELAY = "ReceiverFineDelay";

string BistHxUtility::lookupProperty(const string& property) const
{
  map<string, string> ::const_iterator i = mPropertyMap.find(property);
  string r = property;

  if (i != mPropertyMap.end()) {
      r = i->second;
  }
  return r;

}

double BistHxUtility::lookupUnit(const string& unit) const
{
  map<string, double>::const_iterator i = mUnitMap.find(unit);
  assert (i != mUnitMap.end());
  return i->second;
}

bool BistHxUtility::isValidProperty(const string& property) const
{
  string translatedProperty = lookupProperty(property);
  bool isValid = false;
  for(map<string, string>::const_iterator i = mPropertyMap.begin();
     i != mPropertyMap.end();
     ++i)
  {
    if(i->second == translatedProperty)
    {
      isValid = true;
      break;
    }
  }
  return isValid;
}

bool BistHxUtility::isValidUnit(const string& unit) const
{
  return mUnitMap.find(unit) != mUnitMap.end();
}

string BistHxUtility::getAllValidUnitString() const
{
  assert (mUnitMap.size() > 1);
  map<string, double>::const_iterator iterator = mUnitMap.begin();
  string allValidUnitString = iterator->first;
  iterator++;
  for(; iterator != mUnitMap.end(); iterator++)
  {
    allValidUnitString += ", ";
    allValidUnitString += iterator->first;
  }
  return allValidUnitString;
}

string BistHxUtility::getUnitOptions() const
{
  assert (mUnitMap.size() > 1);
  map<string, double>::const_iterator iterator = mUnitMap.begin();
  string unitOptions = iterator->first;
  iterator++;
  for(; iterator != mUnitMap.end(); iterator++)
  {
    unitOptions += ':';
    unitOptions += iterator->first;
  }
  return unitOptions;
}

string BistHxUtility::getUnitOptions(const string& property) const
{
  string translatedProperty = lookupProperty(property);
  if(translatedProperty == SWING || translatedProperty == OFFSET ||
     translatedProperty == DRIVER_LOW || translatedProperty == DRIVER_HIGH ||
     translatedProperty == RECEIVER_THRESHOLD||translatedProperty == TERMINATION_VOLTAGE ||
     translatedProperty == MODULATION_COMMONMODE_AMPLITUDE)
  {
     return "mV:V";
  }

  if(translatedProperty == MODULATION_FREQUENCY)
  {
    return "Hz:kHz:MHz";
  }

  if(translatedProperty == SKEW || translatedProperty == DRIVER_FINE_DELAY ||
     translatedProperty == RECEIVER_FINE_DELAY ||
     translatedProperty == MODULATION_JITTER_AMPLITUDE)
  {
    return "fs:ps:ns:ms:s";
  }

  return "";
}

bool BistHxUtility:: isValidUnit(const string& property, const string& unit) const
{
  string translatedProperty = lookupProperty(property);
  if(translatedProperty == SWING || translatedProperty == OFFSET ||
     translatedProperty == DRIVER_LOW || translatedProperty == DRIVER_HIGH ||
     translatedProperty == RECEIVER_THRESHOLD||translatedProperty == TERMINATION_VOLTAGE ||
     translatedProperty == MODULATION_COMMONMODE_AMPLITUDE)
  {
     return unit=="mV" || unit =="V";
  }

  if(translatedProperty == MODULATION_FREQUENCY)
  {
    return unit == "Hz"|| unit == "kHz"|| unit == "MHz";
  }

  if(translatedProperty == SKEW || translatedProperty == DRIVER_FINE_DELAY ||
     translatedProperty == RECEIVER_FINE_DELAY ||
     translatedProperty == MODULATION_JITTER_AMPLITUDE)
  {
    return unit == "fs"|| unit == "ps"|| unit == "ns" || unit == "ms"|| unit == "s";
  }
  return false;
}


string BistHxUtility::getPropertyOptions() const
{
  assert (mPropertyMap.size() > 1);
  map<string, string>::const_iterator iterator = mPropertyMap.begin();
  string options = iterator->second;
  iterator++;
  for(; iterator != mPropertyMap.end(); iterator++)
  {
    options += ':';
    options += iterator->second;
  }
  return options;
}

string BistHxUtility::getPropertyDefault() const
{
  assert (mPropertyMap.size() > 0);
  return mPropertyMap.begin()->second;
}

string BistHxUtility::getShortProperty(const string& property) const
{
  for(map<string, string>::const_iterator iterator = mPropertyMap.begin();
      iterator != mPropertyMap.end();
      ++iterator)
  {
    if(iterator->second == property)
    {
      return iterator->first;
    }
  }
  return property;
}

string BistHxUtility::getBaseUnit(const string& property) const
{
  string translatedProperty = lookupProperty(property);
  if(translatedProperty == SWING || translatedProperty == OFFSET || 
     translatedProperty == DRIVER_LOW || translatedProperty == DRIVER_HIGH ||
     translatedProperty == RECEIVER_THRESHOLD||translatedProperty == TERMINATION_VOLTAGE ||
     translatedProperty == MODULATION_COMMONMODE_AMPLITUDE)
  {
     return "V";
  }

  if(translatedProperty == MODULATION_FREQUENCY) 
  {
    return "Hz";
  }

  if(translatedProperty == SKEW || translatedProperty == DRIVER_FINE_DELAY ||
     translatedProperty == RECEIVER_FINE_DELAY ||
     translatedProperty == MODULATION_JITTER_AMPLITUDE)
  {
    return "s";
  }
  
  return "";
}


string BistHxUtility::getTargetUnit(const string& property) const
{
  return getBaseUnit(property);
}


template <class T>
double BistHxUtility::getProperty(const T& t, const string& propertyName) const
{
  if(propertyName == BistHxUtility::DRIVER_LOW)
  {
    return t.getDriverLow();
  }
  if(propertyName == BistHxUtility::DRIVER_HIGH)
  {
    return t.getDriverHigh();
  }
  if(propertyName == BistHxUtility::RECEIVER_THRESHOLD)
  {
    return t.getReceiverThreshold();
  }
  if(propertyName == BistHxUtility::TERMINATION_VOLTAGE)
  {
    return t.getTerminationVoltage();
  }
  if(propertyName == BistHxUtility::MODULATION_JITTER_AMPLITUDE)
  {
    return t.getModulationJitterAmplitude();
  }
  if(propertyName == BistHxUtility::MODULATION_FREQUENCY)
  {
    return t.getModulationFrequency();
  }
  if(propertyName == BistHxUtility::MODULATION_COMMONMODE_AMPLITUDE)
  {
    return t.getModulationCommonModeAmplitude();
  }
  if(propertyName == BistHxUtility::SKEW)
  {
    return t.getSkew();
  }
  assert (false);
  return 0;
}

template <class T>
double BistHxUtility::getHighSpeedProperty(const T&t, const string& propertyName) const
{
  if(propertyName == BistHxUtility::DRIVER_FINE_DELAY)
  {
    return t.getDriverFineDelay();
  }
  if(propertyName == BistHxUtility::RECEIVER_FINE_DELAY)
  {
    return t.getReceiverFineDelay();
  }
  assert (false);
  return 0;
}

bool BistHxUtility::isHighSpeedProperty(const string& propertyName) const
{
  return propertyName== BistHxUtility::DRIVER_FINE_DELAY || propertyName == BistHxUtility::RECEIVER_FINE_DELAY;
}

template <class T>
void BistHxUtility::setProperty(T& t, const string& propertyName, double value) const
{
  if(propertyName == BistHxUtility::DRIVER_LOW)
  {
    t.driverLow(value);
    return;
  }
  if(propertyName == BistHxUtility::DRIVER_HIGH)
  {
    t.driverHigh(value);
    return;
  }
  if(propertyName == BistHxUtility::RECEIVER_THRESHOLD)
  {
    t.receiverThreshold(value);
    return;
  }
  if(propertyName == BistHxUtility::TERMINATION_VOLTAGE)
  {
    t.terminationVoltage(value);
    return;
  }
  if(propertyName == BistHxUtility::MODULATION_JITTER_AMPLITUDE)
  {
    t.modulationJitterAmplitude(value);
    return;
  }
  if(propertyName == BistHxUtility::MODULATION_FREQUENCY)
  {
    t.modulationFrequency(value);
    return;
  }
  if(propertyName == BistHxUtility::MODULATION_COMMONMODE_AMPLITUDE)
  {
    t.modulationCommonModeAmplitude(value);
    return;
  }
  if(propertyName == BistHxUtility::SKEW)
  {
    t.skew(value);
    return;
  }
}

template <class T>
void BistHxUtility::setHighSpeedProperty(T& t, const string& propertyName, double value) const
{
  if(propertyName == BistHxUtility::DRIVER_FINE_DELAY)
  {
    t.driverFineDelay(value);
    return;
  }
  if(propertyName == BistHxUtility::RECEIVER_FINE_DELAY)
  {
    t.receiverFineDelay(value);
    return;
  }
}

ShmooParameter& HXInstrumentShmooParameter::saveValue()
{
  if (mProperty == BistHxUtility::SWING || mProperty == BistHxUtility::OFFSET)
  {
    mOriginalDriverLow =  getProperty(BistHxUtility::DRIVER_LOW);
    mOriginalDriverHigh = getProperty(BistHxUtility::DRIVER_HIGH);
  }
  else
  {
    mOriginalPropertyValue = getProperty(mProperty);
  }
  return *this;
}

ShmooParameter& HXInstrumentShmooParameter::restoreValue()
{
  if (mProperty == BistHxUtility::SWING || mProperty == BistHxUtility::OFFSET)
  {
    setProperty(BistHxUtility::DRIVER_LOW, mOriginalDriverLow);
    setProperty(BistHxUtility::DRIVER_HIGH, mOriginalDriverHigh);
  }
  else
  {
    setProperty(mProperty, mOriginalPropertyValue);
  }
  return *this;
}

ShmooParameter& HXInstrumentShmooParameter::moveTo(double aValue)
{
  double value = aValue*mBase;
  bool isSwing = (mProperty == BistHxUtility::SWING), isOffset = (mProperty == BistHxUtility::OFFSET);
  if (isSwing || isOffset)
  {
    double low = getProperty(BistHxUtility::DRIVER_LOW);
    double high = getProperty(BistHxUtility::DRIVER_HIGH);
    double delta;
    if(isSwing)
    {
      delta  = (value - (high - low)) / 2;
      high  += delta;
      low   -= delta;
    }
    else
    {
      delta  = value - (high + low) / 2;
      high  += delta;
      low   += delta;
    }

    setProperty(BistHxUtility::DRIVER_LOW, low);
    setProperty(BistHxUtility::DRIVER_HIGH, high);
  }
  else
  {
    setProperty (mProperty, value);
  }
  return *this;
}

string HXInstrumentShmooParameter::getShortName() const
{
  return BistHxUtility::getInstance().getShortProperty(mProperty);
}

string HXInstrumentShmooParameter::getDescription() const
{
  return string("HX Instrument: ") + mInstrumentPin +
        "\nProperty: " + mProperty;
}

string HXInstrumentShmooParameter::getParameterType() const
{
  return HX_INSTRUMENT;
}

void HXInstrumentShmooParameter::setProperty(const string& propertyName, double value)
{
  if(BistHxUtility::getInstance().isHighSpeedProperty(propertyName))
  {
    BistHxUtility::getInstance().setHighSpeedProperty(mHXPins, propertyName, value);
  }
  else
  {
    BistHxUtility::getInstance().setProperty(mHXPins, propertyName, value);
  }
}

double HXInstrumentShmooParameter::getProperty(const string& propertyName) const
{
  double value = 0.0;
  if(BistHxUtility::getInstance().isHighSpeedProperty(propertyName))
  {
    value = BistHxUtility::getInstance().getHighSpeedProperty(mHXPins, propertyName);
  }
  else
  {
    value = BistHxUtility::getInstance().getProperty(mHXPins, propertyName);
  }
  return value;
}

template <class T>
ShmooParameter& ResourceShmooParameter<T>::saveValue()
{
  if (mProperty == BistHxUtility::SWING || mProperty == BistHxUtility::OFFSET)
  {
    mOriginalDriverLow = getProperty(BistHxUtility::DRIVER_LOW);
    mOriginalDriverHigh = getProperty(BistHxUtility::DRIVER_HIGH);
  }
  else
  {
    mOriginalPropertyValue = getProperty(mProperty);
  }
  return *this;
}

template <class T>
ShmooParameter& ResourceShmooParameter<T>::restoreValue()
{
  if (mProperty == BistHxUtility::SWING || mProperty == BistHxUtility::OFFSET)
  {
    setProperty(BistHxUtility::DRIVER_LOW, mOriginalDriverLow);
    setProperty(BistHxUtility::DRIVER_HIGH, mOriginalDriverHigh);
  }
  else
  {
    setProperty(mProperty, mOriginalPropertyValue);
  }
  mResource.update();
  return *this;
}

template <class T>
ShmooParameter& ResourceShmooParameter<T>::moveTo(double aValue)
{
  double value = aValue*mBase;
  bool isSwing = (mProperty == BistHxUtility::SWING), isOffset = (mProperty == BistHxUtility::OFFSET);
  if (isSwing || isOffset)
  {
    double low = getProperty(BistHxUtility::DRIVER_LOW);
    double high =getProperty(BistHxUtility::DRIVER_HIGH);
    double delta;
    if(isSwing)
    {
      delta  = (value - (high - low)) / 2;
      high  += delta;
      low   -= delta;
    }
    else
    {
      delta  = value - (high + low) / 2;
      high  += delta;
      low   += delta;
    }

    setProperty(BistHxUtility::DRIVER_LOW, low);
    setProperty(BistHxUtility::DRIVER_HIGH, high);
  }
  else
  {
    setProperty(mProperty, value);
  }
  mResource.update();
  return *this;
}

template <class T>
string ResourceShmooParameter<T>::getShortName() const
{
  return BistHxUtility::getInstance().getShortProperty(mProperty);
}

void HXResourceShmooParameter::setProperty(const string& propertyName, double value)
{
  if(BistHxUtility::getInstance().isHighSpeedProperty(propertyName))
  {
    BistHxUtility::getInstance().setHighSpeedProperty(mResource, propertyName, value);
  }
  else
  {
    BistHxUtility::getInstance().setProperty(mResource, propertyName, value);
  }
}

double HXResourceShmooParameter::getProperty(const string& propertyName) const
{
  double value = 0.0;
  if(BistHxUtility::getInstance().isHighSpeedProperty(propertyName))
  {
    value = BistHxUtility::getInstance().getHighSpeedProperty(mResource, propertyName);
  }
  else
  {
    value = BistHxUtility::getInstance().getProperty(mResource, propertyName);
  }
  return value;
}

string HXResourceShmooParameter::getParameterType() const
{
  return HX_RESOURCE;
}

string HXResourceShmooParameter::getDescription() const
{
  return string("HX Resource: ") + mResourceName +
      "\nProperty: " + mProperty;

}

ShmooCoordinator::ShmooCoordinator(
  unsigned int totalStepX,
  unsigned int totalStepY, 
  unsigned int linearStepX,
  unsigned int linearStepY) :
  mTotalStepX(totalStepX), 
  mTotalStepY(totalStepY),
  mOriginalLinearStepX(getRoundedLinearStep(linearStepX)),
  mOriginalLinearStepY(getRoundedLinearStep(linearStepY)),
  mCurLinearStepX(0),
  mCurLinearStepY(0),
  mRelativeX(0),
  mRelativeY(0),
  mIsEnd(false),
  mIsLinearPart(true),
  mHasPointMeasuredIntheLastRound(false)
{
}

void ShmooCoordinator::start()
{
  mRelativeX = 0;
  mRelativeY = 0;
  mCurLinearStepX = mOriginalLinearStepX;
  mCurLinearStepY = mOriginalLinearStepY;
  mIsLinearPart = true;
  mIsEnd = false;

  mHasPointMeasuredIntheLastRound = false;
}

void ShmooCoordinator::next(const ShmooResult& shmooResult)
{
  do
  {
    moveForward();
  }
  while ( !mIsEnd && !shouldCurrentPointBeTested(shmooResult) );
  /* A point will be measured, so update mLastRoundWhenAPointMeasured*/
  if(!mIsEnd)
  {
    mHasPointMeasuredIntheLastRound = true;
  }
}

bool ShmooCoordinator::shouldCurrentPointBeTested(
  const ShmooResult& shmooResult) const
{
  if ( shmooResult.isPointTested(mRelativeX, mRelativeY) )
  {
    return false;
  }

  if(mIsLinearPart)
  {
    return true;
  }

  unsigned int minX = 0;
  unsigned int minY = 0;
 
  /* checker wether current point is near the edge */
  if ( mRelativeX > mCurLinearStepX )
  {
    minX = mRelativeX - mCurLinearStepX;
  }
  if ( mRelativeY > mCurLinearStepY )
  {
    minY = mRelativeY - mCurLinearStepY;
  }

  unsigned int maxX = min(mTotalStepX, mRelativeX + mCurLinearStepX);
  unsigned int maxY = min(mTotalStepY, mRelativeY + mCurLinearStepY);
  unsigned int x1 = 0, y1 = 0, x2 = 0, y2 = 0;

  /**
   * check if there are two surrouding points with different results.
   */
  for ( y1 = minY; y1 <= maxY; y1 += mCurLinearStepY )
  {
    for ( x1 = minX; x1 <= maxX; x1 += mCurLinearStepX )
    {
      for ( y2 = minY; y2 <= maxY; y2 += mCurLinearStepY )
      {
        for ( x2 = minX; x2 <= maxX; x2 += mCurLinearStepX )
       {

         if ( shmooResult.isPointTested(x1, y1) && shmooResult.isPointTested(x2, y2) )
        {
          if(shmooResult.isPointDifferent(x1, y1, x2, y2))
          {
            return true;
          }
        }
       }
      }
    }
  }
  return false;
}

void ShmooCoordinator::moveForward()
{

  /**
   * meets the forward end, so it shoud move to (0,0) to restart.
   */
  if ( mRelativeX + mCurLinearStepX > mTotalStepX && 
       mRelativeY + mCurLinearStepY > mTotalStepY )
  {
    /*not in linear part now*/
    mIsLinearPart = false;
    mRelativeX = 0;
    mRelativeY = 0;
    /*In the last round, some new points are measured, 
     *so perform another round without decreasing linear steps*/
    if(mHasPointMeasuredIntheLastRound)
    {
      mHasPointMeasuredIntheLastRound = false;
    }
    else if(mCurLinearStepX == 1 && mCurLinearStepY == 1)
    {
      mIsEnd = true;
    }
    else
    {
      decreaseLinearStep();
      mHasPointMeasuredIntheLastRound = false;
    }
    return;
  }
 
  mRelativeX += mCurLinearStepX;

  if ( mRelativeX > mTotalStepX )
  {
    mRelativeX = 0;
    mRelativeY += mCurLinearStepY;
  }
}

void ShmooCoordinator::decreaseLinearStep()
{
  if ( mCurLinearStepX > 1 ) mCurLinearStepX /= 2;
  if ( mCurLinearStepY > 1 ) mCurLinearStepY /= 2;
}

string ShmooCoordinator::store()
{
  ostringstream os;
  os<< mTotalStepX << " "
    << mTotalStepY << " "
    << mCurLinearStepX << " "
    << mCurLinearStepY << " "
    << endl;
  os<< mRelativeX << " "
    << mRelativeY <<" "
    << mIsEnd <<" "
    <<mIsLinearPart<<" "
    << mHasPointMeasuredIntheLastRound<<" "<<endl;
  return os.str();
}

void ShmooCoordinator::restore(const string& storeString)
{
  istringstream is(storeString);
  is>> mTotalStepX 
    >> mTotalStepY
    >> mCurLinearStepX
    >> mCurLinearStepY;
  is>> mRelativeX
    >> mRelativeY
    >> mIsEnd
    >> mIsLinearPart;
}

const string FunctionalMeasurement::NORMAL_FUNCTIONAL_TEST_STRING = "pass/fail";
const string FunctionalMeasurement::FIRST_FAIL_CYCLE_STRING = "first failing cycle";
const string FunctionalMeasurement::CYCLE_ERROR_COUNT_STRING = "cycle error count";
const string FunctionalMeasurement::EDGE_ERROR_COUNT_STRING = "edge error count";

FunctionalMeasurement::FunctionalMeasurement(
  const string& testMode, 
  const string& resultPins):
  mResultPins(resultPins)
{
  assert(testMode == NORMAL_FUNCTIONAL_TEST_STRING ||
         testMode == FIRST_FAIL_CYCLE_STRING ||
         testMode == CYCLE_ERROR_COUNT_STRING ||
         testMode == EDGE_ERROR_COUNT_STRING);

  if(testMode == NORMAL_FUNCTIONAL_TEST_STRING)
  {
    mTestMode = NORMAL_TEST;
  }
  else if(testMode == FIRST_FAIL_CYCLE_STRING)
  {
    mTestMode = FIRST_FAIL_CYCLE;
  }
  else if(testMode == CYCLE_ERROR_COUNT_STRING)
  {
    mTestMode = CYCLE_ERROR_COUNT;
  }
  else if(testMode == EDGE_ERROR_COUNT_STRING)
  {
    mTestMode = EDGE_ERROR_COUNT;
  }
}

ShmooMeasurement& FunctionalMeasurement::save()
{
  if(mTestMode == CYCLE_ERROR_COUNT || mTestMode == EDGE_ERROR_COUNT)
  {
    // store the error map status.
    FW_TASK("DCRM? EMAP,(@@)\n", mRestoreFw);
    if(mTestMode == CYCLE_ERROR_COUNT)
    {
      FW_TASK("DCRM EMAP,1,PFC,(@@)\n");
    }
    else
    {
      FW_TASK("DCRM EMAP,8,PF,(@@)\n");
    }
  }
  
  // make the functional test only cares the specified result pins.
  ostringstream os;
  os<< "SREC STOR,(@)\n";
  os<< "SREC ACT,("<<mResultPins<<")\n";
  FW_TASK(os.str());
  return *this;
}

ShmooMeasurement& FunctionalMeasurement::restore()
{
  FW_TASK("SREC RSTO,(@)\n");
  if(mTestMode == CYCLE_ERROR_COUNT || mTestMode == EDGE_ERROR_COUNT)
  {
    FW_TASK(mRestoreFw);
  }

  return *this;
}

bool FunctionalMeasurement::measure()
{
  static string pinList = mResultPins;   //maybe pin, pingroup, port

  mCellResult.value = 0;
  ostringstream executeOs;
  string resultString;
  string::size_type i;

  executeOs << "FTST ? \n";
  executeOs << "PASS ? ("<<pinList<<")\n";
  FW_TASK(executeOs.str(), resultString);

  /**
   *The result string contains something like "PASS P" or "PASS F"
   * P means PASS, F means FAIL.
   */
  i = resultString.find("PASS");
  if (i == string::npos)
  {
    /**
     * PASS? doesn't support port that hasn't been executed for 
     * performance reasons. Ref. CR-73199. So, need get pinlist by 
     * portlist first.
     *  
     * DFPT? {(portlist)} returns: 
     *   DFPT {(pinlist)}, {(port)} 
     */
    pinList.clear();

    STRING_VECTOR resultList;
    CommonUtil::splitStr(mResultPins, ',', resultList);

    for (UINT iPort=0; iPort<resultList.size(); iPort++)
    {
      executeOs.str("");
      resultString.clear();
      executeOs << "DFPT ? ("<<resultList[iPort]<<")\n";
      FW_TASK(executeOs.str(), resultString);

      i = resultString.find("DFPT");
      if (i == string::npos)
      {
        //not a port
        pinList += resultList[iPort];
      }
      else
      {
        string::size_type iBegin = resultString.find("(") + 1;
        string::size_type iEnd = resultString.find(")");
        pinList += resultString.substr(iBegin, iEnd - iBegin);
      }

      if (iPort<resultList.size()-1)
      {
        pinList += ",";
      }
    }

    executeOs.str("");
    resultString.clear();
    executeOs << "PASS ? ("<<pinList<<")\n";
    FW_TASK(executeOs.str(), resultString);

    i = resultString.find("PASS");
  }

  if (i == string::npos)
  {
    throw Error("FunctionalMeasurement::measure", 
                "Can't get response for PASS? FW cmd.");
  }

  i = i + 4;
  while(resultString[i] == ' ')
  {
    i++;
  }
  assert(resultString[i] == 'P' || resultString[i] == 'F');

  if(resultString[i]== 'P')
  {
    mCellResult.resultType = ShmooCellResult::SHMOO_CELL_PASS;
  }
  else if(mTestMode == NORMAL_TEST)
  {
    mCellResult.resultType = ShmooCellResult::SHMOO_CELL_FAIL;
  }
  else if(mTestMode == CYCLE_ERROR_COUNT || mTestMode == EDGE_ERROR_COUNT)
  {
    executeOs.str("");
    resultString.clear();
    executeOs << "ERCT? ERCG, ("<<mResultPins<<")\n";
    FW_TASK(executeOs.str(), resultString);

    /**
     * The result string contains something like "ERCT ERCG, VALID, 157, F160, (@)"
     * where 157 is the error count number.
     */
     
    static const string erctString = "VALD";
    i = resultString.find(erctString);
    assert(i != string::npos);
    i = i + 4;
    while(resultString[i] == ' ' || resultString[i] == ',')
    {
      i++;
    }
    string::size_type numberBegin = i;
    while(resultString[i] != ',')
    {
      i++;
    }
    string::size_type numberEnd = i - 1;
    mCellResult.resultType = ShmooCellResult::SHMOO_CELL_VALUE;
    mCellResult.value = atoi(resultString.substr(numberBegin, numberEnd - numberBegin + 1).c_str());
  }
  else 
  {
    executeOs.str("");
    resultString.clear();
    executeOs << "EMAP? COMB,0,100000000000,CYCL,1,PF,EOLY,BYTE,13,("<<mResultPins<<")\n";
    FW_TASK(executeOs.str(), resultString);

    /**
     * The resultString contains something like "EMAP 
     * COMB,0,12000000,CYCL,8,PF,EOLY,BYTE,EOB,(O1,O2),#9000000010",
     * after that is the binary data stream. So it can be
     * divided into 4 parts: 
     * 1. EMAP
     * 2. #9  means that the length of part 3 .i.e "000000010" is 9.
     * 3. 000000010 
     * 4. binary data stream: it is always consisted of 64
     *    '0' or '1' bits.
     */
    static const string emapString = "EMAP";
    i = resultString.find(emapString);
    i = i + emapString.size();
    while(resultString[i] != '#')
    {
      i++;
    }
    i++;
     
    unsigned int part2Length = resultString[i] - '0';
    i = i + 1 + part2Length;
    mCellResult.resultType = ShmooCellResult::SHMOO_CELL_VALUE;
    mCellResult.value = convertFfciBinaryToDouble(resultString.c_str() + i);
  }
  return true;
}

ShmooCellResult FunctionalMeasurement::getResult() const
{
  return mCellResult;
}

double FunctionalMeasurement::convertFfciBinaryToDouble(const char* p)
{
  /**
   * the binary are composed of 64 0 or 1 bits/ 8 chars.
   *
   * The number 64 and 32 has nothing to do with the size 
   * of double/int/unsigned int.
   */
  const unsigned char *pUINT8 = (const unsigned char*)(p);
  double result = 0;
  for(unsigned int i = 0; i < 8; i++)
  {
    result = result*256 + (pUINT8[i] - 0);
  }
  return result;
}

const char* ColorAllocator::spColors = "onmlbcdieghjpafkruvqts";

ColorAllocator::ColorAllocator(double resolution)
  :mResolution(resolution)
{
  static const unsigned int numColors = strlen(spColors);
  mColors.resize(strlen(spColors));
  copy(spColors, spColors + numColors, mColors.begin()); 
}

void ColorAllocator::addValue(double value)
{
  double minValue = value, maxValue = value;
  bool shouldUpdate = false;
  if(mValueColorMap.size() == 0)
  {
     minValue = value;
     maxValue = value;
     shouldUpdate = true;
  }
  else 
  {
     if(mValueColorMap.begin()->first < minValue)
     {
        minValue = mValueColorMap.begin()->first;
        shouldUpdate = true;
     }
     if(mValueColorMap.rbegin()->first > maxValue)
     {
        maxValue = mValueColorMap.rbegin()->first;
        shouldUpdate = true;
     }
  }
 
  if(shouldUpdate)
  {
    mValueColorMap.clear();

    size_t numColors = mColors.size();
    double deltaValue = (maxValue - minValue) /(numColors-1);

    for (size_t i = 0; i < numColors; ++i) 
    {
        double val = minValue + i* deltaValue;

        val = round (val / mResolution) * mResolution;

        if(mValueColorMap.find(val) == mValueColorMap.end())
        {
          mValueColorMap[val] = mColors[i];
        }
    }

  }
	
}

char ColorAllocator::getColor(double value) const
{
    for (map<double, char>::const_iterator ti = mValueColorMap.begin(); ti != mValueColorMap.end(); ++ti) 
    {
      if (value <= ti->first) 
      {
        return ti->second;
      }
    }
    return mValueColorMap.rbegin()->second;

}


const vector<char>& ColorAllocator::getAllColors() const
{
  return mColors;
}

TpiShmooViewer::
TpiShmooViewer(double startX,
               double stopX,
               unsigned int totalStepX,
               const string& shortNameX,
               const string& unitX,
               double startY,
               double stopY,
               unsigned int totalStepY,
               const string& shortNameY,
               const string& unitY,
               ShmooResult* pShmooResult,
               const string& title,
               double resultResolution,
               int mode,
               const string& setupPinsX,
               const string& setupPinsY,
               const string& resultPins)
  :mColorAllocator(resultResolution),
  mStartX(startX),
  mStopX(stopX),
  mTotalStepX(totalStepX),
  mShortNameX(shortNameX),
  mUnitX(unitX),
  mStartY(startY),
  mStopY(stopY),
  mTotalStepY(totalStepY),
  mShortNameY(shortNameY),
  mUnitY(unitY),
  mpShmooResult(pShmooResult),
  mTitle(title),
  mMode(mode),
  mSetupPinsX(setupPinsX),
  mSetupPinsY(setupPinsY),
  mResultPins(resultPins)
{
  gettimeofday(&mLastUpdateTime, NULL);
  if(mMode == FFCI_MODE)
  {
    initializePinNameMessages();
  }
}

void TpiShmooViewer::initializePinNameMessages()
{
  vector<TpiPin> tpiPins;
  //The code below is copied from /opt/93000/src/pws/tf_hp/tf_sh2d_tsk.c
  string answer;
  FW_TASK("DFPN? (@)\n", answer);
  static const int MAX_CHANNEL_LENGTH = 5;
  static const int MAX_PIN_NAME_LENGTH = 16;
  static const int MAX_IO_LENGTH = 2;
  char channel[MAX_CHANNEL_LENGTH + 1]; 
  char pinName[MAX_PIN_NAME_LENGTH + 1];
  char oio[MAX_IO_LENGTH + 1];
  const char* answerPointer = answer.c_str();
  while (*answerPointer != '\0')
  {
    // locate channel 
    while(!isspace(*answerPointer))  // locate channel 
    {
      answerPointer++;
    }

    //extract channel
    sscanf(answerPointer, "%5s", channel);  
  
    //locate pinname
    while (*answerPointer != '(')                    
    {
      answerPointer++;
    }

    //extract pinname
    sscanf(answerPointer, "%s", pinName);    
    //The pin name contains '(' but omit ')'     
    pinName[strlen((char *)pinName) - 1] = '\0';        

    // answer conf: CONF IO,F160,(PINNAME) 
    string conf_query = "CONF ? ";
    conf_query += pinName;
    //'(' is already contained in pinName. 
    conf_query += ")\n";
    string confAnswer;
    FW_TASK(conf_query,confAnswer);

    //I/O mode
    sscanf(confAnswer.c_str() + 5, "%[^,]", oio);  
    if ((strcmp((char *)oio, "O") == 0) || 
        ( strcmp((char *)oio,"IO") == 0))
    {
      TpiPin myPin;
      myPin.channel = channel;
      myPin.pinName = pinName;
      tpiPins.push_back(myPin);
    }
  
    //get next answer
    while((*answerPointer != '\n') && (*answerPointer!= '\0'))
    {
      answerPointer++;
    }

    answerPointer++;
  }
 
  //sort by channel
  sort(tpiPins.begin(), tpiPins.end(), TpiPinCompare());
  string::size_type maxPinLength = 0;
  for(vector<TpiPin>::const_iterator it = tpiPins.begin();
      it != tpiPins.end();
      ++it)
  {
    if(it->pinName.length()>maxPinLength)
    {
      maxPinLength = it->pinName.length();
    }
  }
  
  for(vector<TpiPin>::iterator it = tpiPins.begin();
      it != tpiPins.end();
      ++it)
  {
    if(it->pinName.length() < maxPinLength)
    {
      it->pinName.append(maxPinLength - it->pinName.length(), ' ');
    }
    it->pinName.append(1, '-');
  }

  maxPinLength = maxPinLength + 1;
  ostringstream os;
  static const string prefix = "DP2D*X*XXXXXXXXXXXX*XXXXXXX*"
  "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*";
  for(string::size_type i = 0; i < maxPinLength ; ++i)
  {
    os.str("");
    os<<prefix;
    for(vector<TpiPin>::iterator it = tpiPins.begin();
        it != tpiPins.end();
        ++it)
    {
      os<<it->pinName[i];
    }
    os<<'&';
    pinNameMessages.push_back(os.str());
  }
}


void TpiShmooViewer::onStart() 
{
}

void TpiShmooViewer::onStop() 
{
  print();
}

void TpiShmooViewer::onValue(unsigned int a, unsigned int b, const ShmooCellResult& cellResult) 
{
  if((cellResult.resultType == ShmooCellResult::SHMOO_CELL_VALUE))
  {
    mColorAllocator.addValue(cellResult.value);
  }
  struct timeval  tv;
  gettimeofday(&tv, NULL);

  time_t dsec  = tv.tv_sec  - mLastUpdateTime.tv_sec;
  suseconds_t dusec = tv.tv_usec - mLastUpdateTime.tv_usec;

  if (dsec >= 2 && dusec >= 0) 
  {
    mLastUpdateTime = tv;
    print();
  }
}

void TpiShmooViewer::print() const
{
  unsigned char ok = 0;
  OpenShmoo(&ok);
  WriteShmoo("SP2D&");

  /* enable the shmoo plot's fill fast on feature.*/
  if(!isAllPointsMeasured())
  {
    WriteShmoo("SF2D&");
  }
  printFrame();
  
  if(mMode == FFCI_MODE)
  {
    printPin();
  }
  /*
   * If all the shmoo points' results are PASS/FAIL, then overlay 
   * in Shmoo plot is supported.
   */
  //if(!isAllMeasuredPointsPassFail())
  //{
    //printColor();
  //}
  printData();
  /*
   * If all the shmoo points' results are PASS/FAIL, then overlay 
   * in Shmoo plot is supported.
   */
  if(!isAllMeasuredPointsPassFail())
  {
    printColorMap();
  }
  WriteShmoo("ED2D&");
  CloseShmoo();
}

void TpiShmooViewer::printPin() const
{
  for(vector<string>::const_iterator it = pinNameMessages.begin();
      it != pinNameMessages.end();
      ++it)
  {
    WriteShmoo(it->c_str());
  }
}

void TpiShmooViewer::printData() const
{
 
  for(unsigned y = 0; y <= mTotalStepY; y += 1)
  {
    ostringstream cmd;
    cmd << "DX2D*";
    char color;

    for (unsigned int x = 0; x <= mTotalStepX; x += 1)
    {
     if (mpShmooResult->isPointTested(x, y))
     { 
        ShmooCellResult cellResult = mpShmooResult->getResult(x, y);
          if (cellResult.resultType == ShmooCellResult::SHMOO_CELL_PASS)
          {
            color = mColorAllocator.getPassColor();
          }
          else if(cellResult.resultType == ShmooCellResult::SHMOO_CELL_FAIL)
          {
            color = mColorAllocator.getFailColor();
          }
      
        else
        {
          color = mColorAllocator.getColor(cellResult.value);
        }
      }
      else
      {
        color = mColorAllocator.getColorForUnMeasuredPoint();
      }
      cmd << color;
    }
    cmd << "&";
    WriteShmoo(cmd.str().c_str());
  }

}

void TpiShmooViewer::printFrame() const
{

  ostringstream xDim, xName, yDim, yName, fName, rPinName;

  xDim << "XV2D*" << mStartX << "*"
  <<mStopX << "*#"
  << mTotalStepX + 1 << "&";

  xName << "XP2D*" << mShortNameX
  << "*"<<mSetupPinsX<<"**" << mUnitX << "&";

  yDim << "YV2D*" << mStartY << "*"
  << mStopY << "*#"
  << mTotalStepY + 1 << "&";

  yName << "YP2D*" << mShortNameY
  << "*"<<mSetupPinsY<<"**" << mUnitY << "&";

  fName << "CT2D*" << mTitle<< "&";

  rPinName << "RP2D*" << mResultPins << "&";

  //the writing sequence must be in order
  WriteShmoo(fName.str().c_str());
  WriteShmoo(rPinName.str().c_str());
  WriteShmoo(xName.str().c_str());
  WriteShmoo(yName.str().c_str());
  WriteShmoo(xDim.str().c_str());
  WriteShmoo(yDim.str().c_str());
}

void TpiShmooViewer::printColor() const
{
  for (vector<char>::const_iterator it = mColorAllocator.getAllColors().begin(); 
       it!= mColorAllocator.getAllColors().end(); 
       ++it )
  {
    ostringstream shmooCmd;

    shmooCmd << "DL2D*" << *it << "&";
    WriteShmoo(shmooCmd.str().c_str());
  }
}

void TpiShmooViewer::printColorMap() const
{
  for(map<double,char>::const_iterator it = mColorAllocator.getColorMap().begin();
  it != mColorAllocator.getColorMap().end();
  ++it)
  {
    ostringstream shmooCmd;
    if(mMode == OTHER_MODE)
    {
      /**
       * only send this command when the result is value-based (the color map is not empty).
       * so if the results are all pass/fail, this command is not sent.
       */ 
      shmooCmd << "DL2D*" <<it->second<<'*'<< it->first<< "*V&";
    }
    else
    {
      shmooCmd << "DL2D*" <<it->second<<'*'<< it->first<< "&";
    }
    WriteShmoo(shmooCmd.str().c_str());
		
  }
}

bool TpiShmooViewer::isAllPointsMeasured() const
{

  for(unsigned y = 0; y <= mTotalStepY; y += 1)
  {

    for (unsigned int x = 0; x <= mTotalStepX; x += 1)
    {
     if (!mpShmooResult->isPointTested(x, y))
     {
       return false;
     }
    }
  }
  return true;
}

bool TpiShmooViewer::isAllMeasuredPointsPassFail() const
{
  
  for(unsigned y = 0; y <= mTotalStepY; y += 1)
  {

    for (unsigned int x = 0; x <= mTotalStepX; x += 1)
    {
     if (mpShmooResult->isPointTested(x, y))
     {
       const ShmooCellResult& cellResult = mpShmooResult->getResult(x,y);
       if(cellResult.resultType == ShmooCellResult::SHMOO_CELL_VALUE)
       {
         return false;
       }
     }
    }
  }
  return true;
}
