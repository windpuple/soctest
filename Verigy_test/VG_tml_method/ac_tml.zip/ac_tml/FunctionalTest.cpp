/**
 * (c) Copyright 2011, Verigy Technologies, all rights reserved.
 *
 * Modification History:
 *
 *
 */

//for testmethod framework interfaces
#include "testmethod.hpp"
//for testmethod API interfaces
#include "mapi.hpp"

#include "FunctionalUtil.hpp"

/**
 *----------------------------------------------------------------------*
 * @Testmethod Class: FunctionalTest
 *
 * @Purpose: do functional test
 *
 *----------------------------------------------------------------------*
 * @Description:
 *
 * @Parameters:
 *
 *----------------------------------------------------------------------*
 */

class FunctionalTest: public testmethod::TestMethod
{
protected:
  string mTestName;
  FunctionalUtil::LogInfo mLogInfo;
  int mUnburstMode;
protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    mUnburstMode = -1;
    addParameter("testName",
                 "string",
                 &mTestName)
      .setDefault("Functional")
      .setComment("test limit's name, default is \"Functional\"\n"
         "if test table is used, the limit is defined in file\n"
         "if predefined limit is used, the limit name must be as same as default.");
  
    addLimit(getParameter("testName").getDefault());
  }
  
  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
    ON_FIRST_INVOCATION_BEGIN();
      GET_TESTFLOW_FLAG("unburst_mode", &mUnburstMode);
      //check whether limit table is used.
      TestTable* pLimitTable = TestTable::getDefaultInstance();
      pLimitTable->readCsvFile();
      mLogInfo.testName = mTestName;
      mLogInfo.testNumber = 0;
      mLogInfo.isLimitTableUsed = pLimitTable->isTmLimitsCsvFile();
      if (mLogInfo.isLimitTableUsed)
      {
        string testsuiteName;
        GET_TESTSUITE_NAME(testsuiteName);
        string keyInTable = testsuiteName + ":" + mTestName;
        try
        {
          V93kLimits::TMLimits::LimitInfo limitInfo =
            V93kLimits::tmLimits.getLimit(keyInTable);
          mLogInfo.testNumber = limitInfo.TestNumber;
          mLogInfo.softBinNumberString = limitInfo.BinsNumString;
          mLogInfo.hardBinNumber = limitInfo.BinhNum;
          mLogInfo.isLimitTableUsed = true;
        }
        catch (Error e)
        {
          //resort to testflow limit
          mLogInfo.isLimitTableUsed = false;
        }
      }
       
    ON_FIRST_INVOCATION_END();

    if( mUnburstMode == UNBURST_OFF )
    {
      ON_FIRST_INVOCATION_BEGIN();
        CONNECT();
        Sequencer.reset();
        FUNCTIONAL_TEST();
      ON_FIRST_INVOCATION_END();
      FunctionalUtil::logFunctionalTest(mLogInfo);
    }
    else
    {
      FunctionalUtil::unburstAndExecute(Primary.getLabel(),mUnburstMode,mLogInfo);
    }
    return ;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string  getComment() const
  {
     static string comment = _TML_VERSION;
     return comment;
  }
};

REGISTER_TESTMETHOD("AcTest.FunctionalTest", FunctionalTest);
