#ifndef INCLUDE_JITTERHX_H_
#define INCLUDE_JITTERHX_H_
#include <algorithm>
#include "CommonUtil.hpp"

#include "setBasedSpecSearchTM/FW.h"

#define FOR_PER_SITE_PER_PIN_START FOR_EACH_SITE_BEGIN();siteNumber = CURRENT_SITE_NUMBER();it = parameters.PinVector.begin();it_end = parameters.PinVector.end();for(;it != it_end; ++it){;

#define FOR_PER_SITE_PER_PIN_END } FOR_EACH_SITE_END();

using namespace spec_search_pro;

/******************************************************************************
 *                    jitter  test utility class 
 ******************************************************************************
 *Description:
 * By setting up different parameters,users can make the jitter 
 * measurement in different conditions.
 *    pattern synchronization: find a passing pattern
 *    transtioon search on specified side(s): optimize the start of jitter data
 *                                           acquisition.
 *    data acquisition on specified side(s): sample the jitter data
 * according the description,the whole process steps:
 * |----------------|     |------------|       |-------------|
 * |    pattern     |     | transition |       |             |
 * |synchronization |---->|  search    |------>|     data    |
 * |   (optional)   |     | (optional) |       | acquisition | 
 * |----------------|     |------------|       |-------------| 
 * some action is optional in the whole process, so all kinds of user's select 
 * like this chart:
 *-------|--------|---------|----------------|---------|-----------------|----------------
 * case  |autoSync|pass/fail|transitionSearch|pass/fail|acquisition start|acquisition stop
 *number |   mode |         |       mode     |         |                 |
 *-------|--------|---------|----------------|---------|-----------------|----------------*
 *   1   |   off  |         |     off        |         | start parameter | stop parameter *
 *-------|--------|---------|----------------|---------|-----------------|----------------*
 *   2   |   off  |         |     on         |  pass   |traisition of    |optimized data  *
 *       |        |         |                |         |binary search    |acquisition stop*
 *-------|--------|---------|----------------|---------|-----------------|----------------*
 *   3   |   off  |         |     on         |  fail   |measurement      |measurement     *
 *       |        |         |                |         |stop             |sotp            *
 *-------|--------|---------|----------------|---------|-----------------|----------------*
 *   4   |   on   |   pass  |     off        |         |autosync         |optimized data  *
 *       |        |         |                |         |position         |acquisition stop*
 *-------|--------|---------|----------------|---------|-----------------|----------------*
 *   5   |   on   |   fail  |     off        |         |measurement      |measurement     *
 *       |        |         |                |         |stop             |sotp            *
 *-------|--------|---------|----------------|---------|-----------------|----------------*
 *   6   |   on   |   pass  |     on         |  fail   |measurement      |measurement     *
 *       |        |         |                |         |stop             |sotp            *
 *-------|--------|---------|----------------|---------|-----------------|----------------*
 *   7   |   on   |   pass  |     on         |  pass   |traisition of    |optimized data  *
 *       |        |         |                |         |binary search    |acquisition stop*
 *-------|--------|---------|----------------|---------|-----------------|----------------*
 *   8   |   on   |   fail  |     on         |  n/a    |mearsurement     |mearsurement    *
 *       |        |         |                |         |stop             |stop            *
 *-------|--------|---------|----------------|---------|-----------------|----------------*
 ******************************************************************************
 */ 
class JitterUtilHX
{
public:
  //transition search direction: left,right,both  
  enum TRANSITION
  {
    LEFT, RIGHT, BOTH
  };
  //autosync mode:on,off,on_keep_value
  enum AUTOSYNC_MODE
  {
    AUTOSYNC_OFF,
    AUTOSYNC_ON,
    AUTOSYNC_ON_KEEP_VALUE
  };
  //transition search mode: on,off
  enum TRANSITIONSEARCH_MODE
  {
    TRANSITIONSEARCH_OFF,
    TRANSITIONSEARCH_ON
  };  

  enum ACTION_STATUS
  {
    //the following five items are used to identify the status of autoSync
    AUTOSYNC_PASSFAIL, //first autosync linear search result(P------>F)
    AUTOSYNC_FAILPASS, //first autosync linear search result(F------>P)
    AUTOSYNC_ALLPASS,  //first autosync linear search result(P------>P)
    AUTOSYNC_PASS,     //autosync linear search result(find pass pattern)
    AUTOSYNC_FAIL,     //autosync linear search result(can't find pass pattern)
    //the following six items are used to identify the status of 
    //transitionSearch according to the user's seclect.
    LEFT_TRANSITION_PASS,
    LEFT_TRANSITION_FAIL,
    RIGHT_TRANSITION_PASS,
    RIGHT_TRANSITION_FAIL,
    BOTH_TRANSITION_PASS,
    BOTH_TRANSITION_FAIL,
    //the following three items are used to identify the status of jitter
    //measurement according to the user's seclect.
    LEFT_JITTER,
    RIGHT_JITTER,
    BOTH_JITTER,
    //this item is used to initialize.
    NO_ACTION
  };


  //output mode: summary,detail,analysis
  enum OUTPUT_MODE 
  {
    OUTPUT_SUMMARY,
    OUTPUT_DETAIL,
    OUTPUT_ANALYSIS
  };

  /**
   *---------------------------------------------------------------------------
   *         test parameters container
   *---------------------------------------------------------------------------
   */
  typedef struct JitterParameter
  {
    STRING_VECTOR PinVector;
    DOUBLE UI_width_ns;
    DOUBLE start_ns;
    DOUBLE stop_ns;
    DOUBLE dataAcquStepWidth_ns;
    AUTOSYNC_MODE autoSyncMode;
    DOUBLE autoSyncStepWidth_ns;
    TRANSITIONSEARCH_MODE transitionSearchMode;
    TRANSITION transition;
    OUTPUT_MODE outputMode;
  } JitterParameter;



  /**
   *=============================================================================
   * HX   
   *=============================================================================
   */
  //per pin
  typedef struct HXPIN_RESOURCE
  {
    STRING_VECTOR TestPins; //High speed pins string, "HR1+,HR2+"
    STRING_VECTOR vHSPins; //High speed single pin vector (positive pins), [HR1+][HR2+]  hr1��Ӧ[LR1_0,LR1_1,LR1_2,LR1_3]��hr2��Ӧ[LR2_0,LR2_1,LR2_2,LR2_3]
    STRING_VECTOR vLSLanePins; //Low speed pins of each lane,[LR1_0,LR1_1,LR1_2,LR1_3][LR2_0,LR2_1,LR2_2,LR2_3]
    STRING_VECTOR vLSPins; //Low speed single pin vector, [LR1_0][LR1_1][LR1_2][LR1_3][LR2_0][LR2_1]...
    STRING_VECTOR vBoardLane; //Board lane string. [HXA301:0][HXA301:1]  lane�ı���
    INT Lanes_Number; //Total lanes number of specified high speed pins, "2"
    INT MUX; // MUX mode, "2" or "4"
  } HXPIN_RESOURCE;


  //per lane
  typedef struct SYNC_EDGE
  {
    DOUBLE RightSide_Start;
    DOUBLE RightSide_Stop;
    DOUBLE LeftSide_Start;
    DOUBLE LeftSide_Stop;

    //-----------------------------
    ACTION_STATUS lastStatus;   
    DOUBLE autoSyncVal;   
    DOUBLE leftTransitionVal;   
    DOUBLE rightTransitionVal;

    vector<INT> leftErrorCount;   
    vector<INT> rightErrorCount;

    //-----------------------------
    //ARRAY_I Func_Result;
    vector<INT> Func_Result;

    //ARRAY_D TimeStamp;
    vector<DOUBLE> TimeStamp;

    DOUBLE dOldDelay;   
    DOUBLE dActStrobePos;

    INT iSteps;
    DOUBLE startValue;
    DOUBLE stopValue; 
    DOUBLE dTimeDelta;

    INT Stop_Test_Flag;
    INT pass_flag_left, pass_flag_right;

    INT iSteps_left, iSteps_right;
    DOUBLE startValue_left, stopValue_left;
    DOUBLE startValue_right, stopValue_right;
    DOUBLE dTimeDelta_left, dTimeDelta_right;

    vector<INT> ErrorCount_left, ErrorCount_right;//ARRAY_I
    vector<DOUBLE> TimeStamp_left, TimeStamp_right;//ARRAY_D

    void init()
    {
      RightSide_Start = 0.0;
      RightSide_Stop = 0.0;
      LeftSide_Start = 0.0;
      LeftSide_Stop = 0.0;

      lastStatus = NO_ACTION;
      autoSyncVal = 0.0;
      leftTransitionVal = 0.0;
      rightTransitionVal = 0.0;
      //leftErrorCount.clear();
      //rightErrorCount.clear();

      dOldDelay = 0.0;
      dActStrobePos = 0.0;

      iSteps = 0;
      startValue = 0.0;
      stopValue = 0.0;
      dTimeDelta = 0.0;

      Stop_Test_Flag = 0;
      pass_flag_left = 0;
      pass_flag_right = 0;

      iSteps_left = 0;
      iSteps_right = 0;
      startValue_left = 0.0;
      stopValue_left = 0.0;
      startValue_right = 0.0;
      stopValue_right = 0.0;
      dTimeDelta_left = 0.0;
      dTimeDelta_right = 0.0;
    }

    SYNC_EDGE()
    {
      init();
    }

  } SYNC_EDGE;

  typedef struct JitterDataHX
  {
    //Key:1)site index, 2)pin name
    map<INT,map<STRING, HXPIN_RESOURCE> > HXPIN_Resource;

    //Key:1)site index, 2)pin name, lane index
    map<INT,map<STRING, map<INT, SYNC_EDGE> > > Sync_Result;

    void init()
    {
      //HXPIN_Resource.clear();
      Sync_Result.clear();
    }
  } JitterDataHX;
  //===========================================================================

  /**
   *---------------------------------------------------------------------------
   *         public interfaces of common jitter test
   *---------------------------------------------------------------------------
   */  


  //--------------------------------------------------------------
  static void checkSetupPinlist(const STRING& pins); 
  static STRING_VECTOR expandPinlistToPins(const STRING & pinlist);
  static void printWaringMessage(const INT, const STRING&, const INT lane);

  //==========================hx==================================

  static void hx_autoSync(
                         const JitterParameter& parameters,
                         JitterDataHX& jitter_data_hx,
                         bool& isEveryPinOfAllSitesFail);

  static void hx_transitionSearch(
                                 const JitterParameter& parameters,
                                 JitterDataHX& jitter_data_hx,
                                 bool& isEveryPinOfAllSitesFail);

  static void hx_dataAcquire(
                            const JitterParameter& parameters,
                            JitterDataHX& jitter_data_hx);

  static void DCR_comd(STRING& LSPinName);

  //--------------------------------------------------------------
  static void HXPins_Parsing(const JitterParameter& parameters,
                             JitterDataHX& jitter_data_hx);

  static void Coarse_Sync(const JitterParameter& parameters,
                          JitterDataHX& jitter_data_hx,
                          DOUBLE Transition_Buffer);

  static void HX_Error_Count_Acquire(
                                    const JitterParameter& parameters,
                                    JitterDataHX& jitter_data_hx,
                                    TRANSITION active);

  //==============================================================
};

/**
 *-----------------------------------------------------------------------------
 * Routine: checkSetupPinlist
 *
 * Purpose: check setup pin types
 *
 *-----------------------------------------------------------------------------
 * Description:
 *  for jitter measurement,only O,IO type pins are valid. 
 * Note:
 *-----------------------------------------------------------------------------
 */
inline void JitterUtilHX::checkSetupPinlist(const STRING& pins)
{
  if (pins.empty())
  {
    STRING api = "Check setup pin: ";
    STRING msg = "There is no setup pin! Please input setup pin(s).";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }
  try
  {
    PinUtility.getDigitalPinNamesFromPinList(pins,TM::O_PIN|TM::IO_PIN,TRUE,TRUE);
  }
  catch (ErrorInfo & e)
  {
    STRING api = "Check setup pin: ";
    STRING msg = "Some pin in pins is not any kind of O,IO pin!";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }
}

/*
 *-----------------------------------------------------------------------------
 *Routine: JitterUtilHX::expandPinlistToPins
 *
 *Purpose: expand pinlist to individual pins
 *-----------------------------------------------------------------------------
 *Description:
 *Use PinUtility API to expand pinlist to pins
 *
 *Parameters:
 * 1)pinlist: needed be separated
 *
 *Output:
 * the string vector of individual pins.
 *-----------------------------------------------------------------------------
 */
inline STRING_VECTOR 
JitterUtilHX::expandPinlistToPins(const STRING & pinlist)
{
  STRING_VECTOR resultExpandedPinVector;
  STRING_VECTOR expandedDigitalPinVector;
  STRING_VECTOR splitPinlist;

  resultExpandedPinVector.clear();
  CommonUtil::splitStr(pinlist,',',splitPinlist);
  for (STRING_VECTOR::const_iterator it = splitPinlist.begin();
      it != splitPinlist.end();++it)
  {
    //expandedDigitalPinVector = PinUtility.getDigitalPinNamesFromPinList(*it,TM::IO_PIN|TM::O_PIN, TRUE,TRUE);
    //resultExpandedPinVector += expandedDigitalPinVector;
    resultExpandedPinVector.push_back( *it );
  }
  return resultExpandedPinVector;
}


/**
 *-----------------------------------------------------------------------------
 * Routine: HXPins_Parsing
 *
 * Purpose: parse high speed pin parameters for further using
 *
 *-----------------------------------------------------------------------------
 * Description:
 * 
 *Parameters:
 * 1)parameters: inputed parameters from testmethod
 * 2)jitter_data_hx: parsed high speed pin's info
 *Output:
 * 

 * Note:
 *-----------------------------------------------------------------------------
 */


inline void JitterUtilHX::HXPins_Parsing(const JitterParameter& parameters,
                                         JitterDataHX& jitter_data_hx)//input only one name of the high speed pin
{
  //Get Testflow & Debug Flags
  INT isDebugAnalogOn;
  GET_TESTFLOW_FLAG("debug_analog", &isDebugAnalogOn);

  HXPIN_RESOURCE* HXPIN_Resource;
  INT siteNumber;


  STRING_VECTOR::const_iterator it = parameters.PinVector.begin();
  STRING_VECTOR::const_iterator it_end = parameters.PinVector.end();

  //----------------------------------------
  FOR_EACH_SITE_BEGIN();
  siteNumber = CURRENT_SITE_NUMBER();
  it = parameters.PinVector.begin();
  it_end = parameters.PinVector.end();
  for (;it != it_end; ++it)
  {
    //----------------------------------------

    HXPIN_Resource = &(jitter_data_hx.HXPIN_Resource[siteNumber][*it]);

    // Get High speed pins string
    (*HXPIN_Resource).TestPins.push_back(*it);

    // Get Lanes number
    fwout<<"FXRT? RTIM,,(" << *it << ")" << endl;
    (*HXPIN_Resource).Lanes_Number = fwresult.size();
    //(*HXPIN_Resource).Lanes_Number = 1;//hx debug

    // Get High speed single pin vector & Low speed pins of each lane
    for (int lane=0; lane< (*HXPIN_Resource).Lanes_Number; lane++)
    {
      (*HXPIN_Resource).vLSLanePins.push_back(fwresult[lane][1]); //Note: result looks like FXRT RTIM,(LR1_0,LR1_1,LR1_2,LR1_3),(HR1+,HR1-)//hx debug

      //hx debug:FXRT RTIM,(DD6,NDD6,DD6_1,DD6_3),(DD6_HS,NDD6_HS)
      //(*HXPIN_Resource).vLSLanePins.push_back("DD6,NDD6,DD6_1,DD6_3");//hx debug

      (*HXPIN_Resource).vHSPins.push_back(fwresult[lane][2].substr(0, fwresult[lane][2].find(",")));//hx debug
      //(*HXPIN_Resource).vHSPins.push_back("DD6_HS");//hx debug
    }

    // Get Low speed single pin vector
    STRING_VECTOR vLSPins_internal[(*HXPIN_Resource).Lanes_Number];

    //[LR1_0,LR1_1,LR1_2,LR1_3][LR2_0,LR2_1,LR2_2,LR2_3] convert to
    //[LR1_0][LR1_1][LR1_2][LR1_3][LR2_0][LR2_1]...

    //vLSPins_internal[0] = PIN_UTILITY::getDigitalPinNamesFromPinList((*HXPIN_Resource).vLSLanePins[0], TM::O_PIN | TM::IO_PIN);	    
    vLSPins_internal[0] += expandPinlistToPins( (*HXPIN_Resource).vLSLanePins[0] );

    (*HXPIN_Resource).MUX = vLSPins_internal[0].size();//mux��2 or 4��to show whether 2 or 4 slow pins connect 1 high speed pin//hx debug
    //(*HXPIN_Resource).MUX = 4;
    vLSPins_internal[0].clear();

    for (int lane=0; lane< (*HXPIN_Resource).Lanes_Number; lane++)
    {

      int index_cur=0;
      int index_next = 0;
      STRING LSLanePin_temp = (*HXPIN_Resource).vLSLanePins[lane];

      for (int i=0; i<(*HXPIN_Resource).MUX; i++)
      {
        index_next=LSLanePin_temp.find(",");
        if (index_next<0)
        {
          vLSPins_internal[lane].push_back(LSLanePin_temp);
          break;
        }
        STRING vlspin_name_temp = LSLanePin_temp.substr(index_cur,index_next);
        vLSPins_internal[lane].push_back(vlspin_name_temp);
        LSLanePin_temp = LSLanePin_temp.substr(index_next+1);
      }
      //vLSPins_internal[lane] = PIN_UTILITY::getDigitalPinNamesFromPinList(
      //			(*HXPIN_Resource).vLSLanePins[lane], TM::O_PIN | TM::IO_PIN);

    }

    for (int i=0; i<(*HXPIN_Resource).Lanes_Number; i++)
    {

      for (int j=0; j<(*HXPIN_Resource).MUX; j++)
      {
        (*HXPIN_Resource).vLSPins.push_back(vLSPins_internal[i][j]);
      }
    }
    //	(*HXPIN_Resource).vLSPins.push_back("DD6");
    //	(*HXPIN_Resource).vLSPins.push_back("DD6_1");
    //	(*HXPIN_Resource).vLSPins.push_back("NDD6");
    //	(*HXPIN_Resource).vLSPins.push_back("DD6_3");

    // Get BoardLane of HX Pins, like [HXA301:0][HXA301:1]    //lane�ı���
    fwout<<"DFAN? (" << *it << ")" << endl;//Note: result looks like DFAN "HXA301,TQ1+,o","19",(HR1+)
    //hx debug:DFAN "HXA305,TQ2+,o","H15",(DD6_HS)


    for (unsigned int i=0; i<fwresult.size(); i++)//hx debug
    {
      //for (unsigned int i=0; i<(*HXPIN_Resource).Lanes_Number; i++) {
      //for (int i=0; i<(*HXPIN_Resource).Lanes_Number; i++) {//hx debug
      int lane = atoi(fwresult[i][0].substr(9,1).c_str());//hx debug
      //int lane = 2;//hx debug
      lane--;
      ostringstream lane_description;
      lane_description<< fwresult[i][0].substr(0, 6)<<":"<<lane;//hx debug
      (*HXPIN_Resource).vBoardLane.push_back(lane_description.str());//hx debug
      //(*HXPIN_Resource).vBoardLane.push_back("HXA305:1");//hx debug
    }

    isDebugAnalogOn = 0;//hx debug
    // Debug Information
    if (isDebugAnalogOn)
    {
      cout<<"(*HXPIN_Resource).TestPins: "<<(*HXPIN_Resource).TestPins[0]<<endl;
      cout<<"(*HXPIN_Resource).Lanes_Number: "<<(*HXPIN_Resource).Lanes_Number<<endl;
      cout<<"(*HXPIN_Resource).MUX: "<<(*HXPIN_Resource).MUX <<endl;

      for (int lane=0; lane< (*HXPIN_Resource).Lanes_Number; lane++)
      {

        cout<<"(*HXPIN_Resource).vHSPins: "<<(*HXPIN_Resource).vHSPins[lane]<<endl;
        cout<<"(*HXPIN_Resource).vLSLanePins: "<<(*HXPIN_Resource).vLSLanePins[lane] <<endl;
        cout<<"(*HXPIN_Resource).vBoardLane: "<<(*HXPIN_Resource).vBoardLane[lane]<<endl;

        for (int i=0; i<(*HXPIN_Resource).MUX; i++)
        {

          cout<<"(*HXPIN_Resource).vLSPins: "<<(*HXPIN_Resource).vLSPins[lane*(*HXPIN_Resource).MUX+i]<<endl;

        }
      }
    }

    //----------------------------------------
  }
  FOR_EACH_SITE_END();
  //----------------------------------------
}


//========================================================================================

//Multi-lane Coarse_Sync
//DOUBLE Transition_Buffer, unit [UI] 
inline void JitterUtilHX::hx_autoSync(
                                     const JitterParameter& parameters,
                                     JitterDataHX& jitter_data_hx,
                                     bool& isEveryPinOfAllSitesFail)
{
  ON_FIRST_INVOCATION_BEGIN();

  INT iSteps = 0;
  DOUBLE dStart, dEnd;
  DOUBLE dActStrobePos = 0;
  DOUBLE dTimeDelta;

  DOUBLE UI_Width;
  UI_Width = parameters.UI_width_ns;


  INT siteNumber;
  INT max_step = 0;

  // for the second linear search,the range range is 1.5 * UI_width_ns,which
  // is for sure that we can get a transiton in this range
  DOUBLE searchRangeFactor = 1.5; 

  if (parameters.start_ns != 0 && parameters.stop_ns != 0)
  {
    //ns
    dStart = parameters.start_ns;
    dEnd = parameters.stop_ns;
  }
  else
  {
    //ps
    dStart = (0-UI_Width*3);//*1e-3;
    dEnd = (0+UI_Width*3);//*1e-3;
  }

  if (parameters.autoSyncStepWidth_ns != 0)
  {
    dTimeDelta = parameters.autoSyncStepWidth_ns;
    iSteps = (INT)((dEnd-dStart)/dTimeDelta);
  }
  else
  {
    dTimeDelta = UI_Width/10;//*1e-3;//ps to ns
    iSteps = 60;
  }

  STRING_VECTOR::const_iterator it = parameters.PinVector.begin();
  STRING_VECTOR::const_iterator it_end = parameters.PinVector.end();

  //=======================prepare first autoSync test(each site,each pin)==========================

  //----------------------------------------	
  FOR_EACH_SITE_BEGIN();
  siteNumber = CURRENT_SITE_NUMBER();
  it = parameters.PinVector.begin();
  it_end = parameters.PinVector.end();
  for (;it != it_end; ++it)
  {
    //----------------------------------------

    HXPIN_RESOURCE& HXPIN_Resource = jitter_data_hx.HXPIN_Resource[siteNumber][*it];

    for (int lane=0; lane<HXPIN_Resource.Lanes_Number; lane++)
    {

      SYNC_EDGE& Sync_Result = jitter_data_hx.Sync_Result[siteNumber][*it][lane];

      //Get old delay of ReceiverFineDelay for future restore
      Sync_Result.dOldDelay = HIGHSPEEDEXTENSION_LANE(HXPIN_Resource.vBoardLane[lane]).getReceiverFineDelay();//hx debug
      //Sync_Result.dOldDelay= 1;//hx debug

      Sync_Result.Func_Result.clear();
      Sync_Result.TimeStamp.clear();
      Sync_Result.Func_Result.resize(iSteps);
      Sync_Result.TimeStamp.resize(iSteps);
    }
    //----------------------------------------
  }
  FOR_EACH_SITE_END();
  //----------------------------------------

  //======================first autoSync test==================================
  for (int i=0; i<iSteps; i++)
  {

    dActStrobePos = dStart + dTimeDelta * (DOUBLE) i;

    //----------------------------------------
    FOR_EACH_SITE_BEGIN();
    siteNumber = CURRENT_SITE_NUMBER();
    it = parameters.PinVector.begin();
    it_end = parameters.PinVector.end();
    for (;it != it_end; ++it)
    {
      //----------------------------------------

      //break;//hx debug

      HXPIN_RESOURCE& HXPIN_Resource = jitter_data_hx.HXPIN_Resource[siteNumber][*it];      

      for (int lane=0; lane<HXPIN_Resource.Lanes_Number; lane++)
      {
        HIGHSPEEDEXTENSION_LANE(HXPIN_Resource.vBoardLane[lane]).receiverFineDelay(dActStrobePos*1e-9);
        //receiverFineDelay unit is second,
        //dActStrobePos unit is ps,ps = 1e-12second//new dActStrobePos unit is ns				
      }
      //----------------------------------------
    }
    FOR_EACH_SITE_END();
    //----------------------------------------

    FUNCTIONAL_TEST();

    //----------------------------------------
    FOR_EACH_SITE_BEGIN();
    siteNumber = CURRENT_SITE_NUMBER();
    it = parameters.PinVector.begin();
    it_end = parameters.PinVector.end();
    for (;it != it_end; ++it)
    {
      //----------------------------------------

      HXPIN_RESOURCE& HXPIN_Resource = jitter_data_hx.HXPIN_Resource[siteNumber][*it];

      for (int lane=0; lane<HXPIN_Resource.Lanes_Number; lane++)
      {

        SYNC_EDGE& Sync_Result = jitter_data_hx.Sync_Result[siteNumber][*it][lane];

        Sync_Result.Func_Result[i]= GET_FUNCTIONAL_RESULT(HXPIN_Resource.vLSLanePins[lane]);
        Sync_Result.TimeStamp[i]=dActStrobePos;

      }

      //----------------------------------------
    }
    FOR_EACH_SITE_END();
    //----------------------------------------
  }//end_for (int i=0; i<iSteps; i++)

  //======================first updateResultForAutoSync==========================
  isEveryPinOfAllSitesFail = true;

  //----------------------------------------
  FOR_EACH_SITE_BEGIN();
  siteNumber = CURRENT_SITE_NUMBER();
  it = parameters.PinVector.begin();
  it_end = parameters.PinVector.end();
  for (;it != it_end; ++it)
  {
    //----------------------------------------

    HXPIN_RESOURCE& HXPIN_Resource = jitter_data_hx.HXPIN_Resource[siteNumber][*it];

    for (int lane=0; lane<HXPIN_Resource.Lanes_Number; lane++)
    {

      SYNC_EDGE& Sync_Result = jitter_data_hx.Sync_Result[siteNumber][*it][lane];

      INT pass_flag=0;
      INT pass_num=0;
      INT fail_num=0;

      //======================first updateResultForAutoSync==========================
      //Calculation
      for (int i=1; i<iSteps-2; i++)
      {
        if (Sync_Result.Func_Result[i]!=1 && Sync_Result.Func_Result[i+1]==1 && Sync_Result.Func_Result[i+2]==1)
        {
          Sync_Result.lastStatus = AUTOSYNC_FAILPASS;
          Sync_Result.autoSyncVal = Sync_Result.TimeStamp[i+1];
          isEveryPinOfAllSitesFail = false;     

          //Flag Setup
          pass_flag=1;
          break;
        }

        if (Sync_Result.Func_Result[i]==1 && Sync_Result.Func_Result[i+1]!=1 && Sync_Result.Func_Result[i+2]!=1)
        {
          Sync_Result.lastStatus = AUTOSYNC_PASSFAIL;
          Sync_Result.autoSyncVal = Sync_Result.TimeStamp[i+1];
          isEveryPinOfAllSitesFail = false;

          //Flag Setup
          pass_flag=1;
          break;
        }

        if (1 == Sync_Result.Func_Result[i])
        {
          pass_num++;
        }
        else if (0 == Sync_Result.Func_Result[i])
        {
          fail_num++;
        }
      }

      if (pass_flag==0)
      {
        if (0 == fail_num && pass_num > 0)
        {
          Sync_Result.autoSyncVal = parameters.start_ns;
          Sync_Result.lastStatus = AUTOSYNC_ALLPASS;
          isEveryPinOfAllSitesFail = false;
        }
        else if (0 == pass_num && fail_num > 0)
        {
          Sync_Result.lastStatus = AUTOSYNC_FAIL;
        }
        else
        {
          cout<<"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"<<endl;
          cout<<HXPIN_Resource.vHSPins[lane]<<"ERROR:HX_auto_Sync() Fail!"<<endl;
          cout<<"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"<<endl;
        }
      }
    }

    //----------------------------------------
  }
  FOR_EACH_SITE_END();
  //----------------------------------------

  //==================prepare second AutoSync================================
  if (isEveryPinOfAllSitesFail)
  {
    STRING api = "In function JitterUtilHX::HX_autoSync: ";
    STRING msg = "Every Pin Of All Sites is Fail.";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
    return;
  }

  max_step = 0;

  //----------------------------------------
  FOR_EACH_SITE_BEGIN();
  siteNumber = CURRENT_SITE_NUMBER();
  it = parameters.PinVector.begin();
  it_end = parameters.PinVector.end();
  for (;it != it_end; ++it)
  {
    //----------------------------------------

    HXPIN_RESOURCE& HXPIN_Resource = jitter_data_hx.HXPIN_Resource[siteNumber][*it];

    for (int lane=0; lane<HXPIN_Resource.Lanes_Number; lane++)
    {

      SYNC_EDGE& Sync_Result = jitter_data_hx.Sync_Result[siteNumber][*it][lane];

      Sync_Result.startValue = 0.0;
      Sync_Result.stopValue = 0.0;

      if (Sync_Result.lastStatus != AUTOSYNC_FAIL)
      {
        Sync_Result.startValue = Sync_Result.autoSyncVal;
        if (Sync_Result.lastStatus == AUTOSYNC_PASSFAIL)
        {
          Sync_Result.stopValue = Sync_Result.startValue - 
                                  searchRangeFactor * parameters.UI_width_ns;
        }
        else if (Sync_Result.lastStatus == AUTOSYNC_FAILPASS)
        {
          Sync_Result.stopValue = Sync_Result.startValue + 
                                  searchRangeFactor * parameters.UI_width_ns;
        }
        else if (Sync_Result.lastStatus == AUTOSYNC_ALLPASS)
        {
          //the first search is all pass, so it's no need to search again
          //for this pin of this site.
          continue;
        }
        else
        {
          STRING api = "In function JitterUtilHX::HX_autoSync: ";
          STRING msg = "These is an unexpected action status.";
          throw Error(api.c_str(),msg.c_str(),api.c_str());
        }
      }//end if lastStatus != AUTOSYNC_FAIL

      if ((Sync_Result.stopValue-Sync_Result.startValue) < 0)
      {
        Sync_Result.dTimeDelta = -dTimeDelta;
      }
      else
      {
        Sync_Result.dTimeDelta = dTimeDelta;
      }


      Sync_Result.iSteps = (INT)((Sync_Result.stopValue-Sync_Result.startValue)/Sync_Result.dTimeDelta);
      if (Sync_Result.iSteps > max_step)
      {
        max_step = Sync_Result.iSteps;
      }

      Sync_Result.Func_Result.clear();
      Sync_Result.TimeStamp.clear();
      Sync_Result.Func_Result.resize(Sync_Result.iSteps);
      Sync_Result.TimeStamp.resize(Sync_Result.iSteps);   

    }//end for lanes

    //----------------------------------------
  }
  FOR_EACH_SITE_END();
  //----------------------------------------

  //==================second autoSync test=============================================================================

  for (int i=0; i<max_step; i++)
  {

    //----------------------------------------
    FOR_EACH_SITE_BEGIN();
    siteNumber = CURRENT_SITE_NUMBER();
    it = parameters.PinVector.begin();
    it_end = parameters.PinVector.end();
    for (;it != it_end; ++it)
    {
      //----------------------------------------

      HXPIN_RESOURCE& HXPIN_Resource = jitter_data_hx.HXPIN_Resource[siteNumber][*it];  

      for (int lane=0; lane<HXPIN_Resource.Lanes_Number; lane++)
      {

        SYNC_EDGE& Sync_Result = jitter_data_hx.Sync_Result[siteNumber][*it][lane];

        if (Sync_Result.iSteps>i)//every collect has different max��min, so some is finished, so is not yet. Finished one has no need to run any more.
        {
          Sync_Result.dActStrobePos = Sync_Result.startValue + Sync_Result.dTimeDelta * (DOUBLE) i;
          HIGHSPEEDEXTENSION_LANE(HXPIN_Resource.vBoardLane[lane]).receiverFineDelay(Sync_Result.dActStrobePos*1e-9);
        }
      }

      //----------------------------------------
    }
    FOR_EACH_SITE_END();
    //----------------------------------------

    FUNCTIONAL_TEST();

    //----------------------------------------
    FOR_EACH_SITE_BEGIN();
    siteNumber = CURRENT_SITE_NUMBER();
    it = parameters.PinVector.begin();
    it_end = parameters.PinVector.end();
    for (;it != it_end; ++it)
    {
      //----------------------------------------

      HXPIN_RESOURCE& HXPIN_Resource = jitter_data_hx.HXPIN_Resource[siteNumber][*it];

      for (int lane=0; lane<HXPIN_Resource.Lanes_Number; lane++)
      {

        SYNC_EDGE& Sync_Result = jitter_data_hx.Sync_Result[siteNumber][*it][lane];

        if (Sync_Result.iSteps>i)
        {
          Sync_Result.Func_Result[i]= GET_FUNCTIONAL_RESULT(HXPIN_Resource.vLSLanePins[lane]);        
          Sync_Result.TimeStamp[i]=Sync_Result.dActStrobePos;
        }
      }

      //----------------------------------------
    }
    FOR_EACH_SITE_END();
    //----------------------------------------
  }//end_for (int i=0; i<max_step; i++)	


  //==================second updateResultForAutoSync=============================================================================

  //----------------------------------------
  FOR_EACH_SITE_BEGIN();
  siteNumber = CURRENT_SITE_NUMBER();
  it = parameters.PinVector.begin();
  it_end = parameters.PinVector.end();
  for (;it != it_end; ++it)
  {
    //----------------------------------------

    HXPIN_RESOURCE& HXPIN_Resource = jitter_data_hx.HXPIN_Resource[siteNumber][*it];

    for (int lane=0; lane<HXPIN_Resource.Lanes_Number; lane++)
    {

      SYNC_EDGE& Sync_Result = jitter_data_hx.Sync_Result[siteNumber][*it][lane];

      INT pass_flag=0;

      //Calculation
      for (int i=1; i<Sync_Result.iSteps-2; i++)
      {
        if (Sync_Result.Func_Result[i]!=1 && Sync_Result.Func_Result[i+1]==1 && Sync_Result.Func_Result[i+2]==1)
        {
          Sync_Result.autoSyncVal = (Sync_Result.TimeStamp[i+1] + Sync_Result.autoSyncVal)/2;

          Sync_Result.lastStatus = AUTOSYNC_PASS;

          isEveryPinOfAllSitesFail = false;     

          //Flag Setup
          pass_flag=1;
          break;
        }
        else if (Sync_Result.Func_Result[i]==1 && Sync_Result.Func_Result[i+1]!=1 && Sync_Result.Func_Result[i+2]!=1)
        {

          Sync_Result.autoSyncVal = (Sync_Result.TimeStamp[i] + Sync_Result.autoSyncVal)/2;

          Sync_Result.lastStatus = AUTOSYNC_PASS;

          isEveryPinOfAllSitesFail = false;

          //Flag Setup
          pass_flag=1;
        }
      }

      if (pass_flag==0)
      {
        if (AUTOSYNC_PASS == Sync_Result.lastStatus)
        {
          Sync_Result.autoSyncVal += 
          static_cast<int>((parameters.stop_ns - parameters.start_ns) / 
                           parameters.autoSyncStepWidth_ns) * 
          parameters.autoSyncStepWidth_ns/2.0;

          Sync_Result.lastStatus = AUTOSYNC_PASS;

          isEveryPinOfAllSitesFail = false;
        }
        else
        {
          Sync_Result.lastStatus = AUTOSYNC_FAIL;
        }     
      }

      //Reset ReceiverFineDelay
      HIGHSPEEDEXTENSION_LANE(HXPIN_Resource.vBoardLane[lane]).receiverFineDelay(Sync_Result.dOldDelay);
    }

    //----------------------------------------
  }
  FOR_EACH_SITE_END();
  //----------------------------------------


  ON_FIRST_INVOCATION_END();
}

//========================================================================================

inline void JitterUtilHX::hx_transitionSearch(
                                             const JitterParameter& parameters,
                                             JitterDataHX& jitter_data_hx,
                                             bool& isEveryPinOfAllSitesFail)
{
  ON_FIRST_INVOCATION_BEGIN();

  DOUBLE dTimeDelta;
  dTimeDelta = parameters.dataAcquStepWidth_ns;

  INT siteNumber;
  INT max_step = 0;

  STRING_VECTOR::const_iterator it = parameters.PinVector.begin();
  STRING_VECTOR::const_iterator it_end = parameters.PinVector.end();

  //=================prepare left search==========================

  max_step = 0;
  //----------------------------------------
  FOR_EACH_SITE_BEGIN();
  siteNumber = CURRENT_SITE_NUMBER();
  it = parameters.PinVector.begin();
  it_end = parameters.PinVector.end();
  for (;it != it_end; ++it)
  {
    //----------------------------------------

    if (parameters.transition == LEFT || parameters.transition == BOTH)
    {

      HXPIN_RESOURCE& HXPIN_Resource = jitter_data_hx.HXPIN_Resource[siteNumber][*it];    

      for (int lane=0; lane<HXPIN_Resource.Lanes_Number; lane++)
      {

        SYNC_EDGE& Sync_Result = jitter_data_hx.Sync_Result[siteNumber][*it][lane];

        //Get old delay of ReceiverFineDelay for future restore
        Sync_Result.dOldDelay = HIGHSPEEDEXTENSION_LANE(HXPIN_Resource.vBoardLane[lane]).getReceiverFineDelay();

        if (Sync_Result.lastStatus == AUTOSYNC_PASS)
        {
          Sync_Result.startValue = Sync_Result.autoSyncVal - parameters.UI_width_ns;
          Sync_Result.stopValue = Sync_Result.autoSyncVal;
        }
        if (Sync_Result.lastStatus == NO_ACTION)
        {
          Sync_Result.startValue = parameters.start_ns - parameters.UI_width_ns;
          Sync_Result.stopValue = parameters.start_ns;
        }

        if ((Sync_Result.stopValue-Sync_Result.startValue) < 0)
        {
          Sync_Result.dTimeDelta = -dTimeDelta;
        }
        else
        {
          Sync_Result.dTimeDelta = dTimeDelta;
        }

        Sync_Result.iSteps = (INT)((Sync_Result.stopValue-Sync_Result.startValue)/Sync_Result.dTimeDelta);
        if (Sync_Result.iSteps > max_step)
        {
          max_step = Sync_Result.iSteps;
        }

        Sync_Result.Func_Result.clear();
        Sync_Result.TimeStamp.clear();
        Sync_Result.Func_Result.resize(Sync_Result.iSteps);
        Sync_Result.TimeStamp.resize(Sync_Result.iSteps);

      }//end for lanes

    }//end_parameters.transition == LEFT || parameters.transition == BOTH

    //----------------------------------------
  }
  FOR_EACH_SITE_END();
  //----------------------------------------

  //===========================left search==========================
  for (int i=0; i<max_step; i++)
  {

    //----------------------------------------
    FOR_EACH_SITE_BEGIN();
    siteNumber = CURRENT_SITE_NUMBER();
    it = parameters.PinVector.begin();
    it_end = parameters.PinVector.end();
    for (;it != it_end; ++it)
    {
      //----------------------------------------

      HXPIN_RESOURCE& HXPIN_Resource = jitter_data_hx.HXPIN_Resource[siteNumber][*it];

      for (int lane=0; lane<HXPIN_Resource.Lanes_Number; lane++)
      {

        SYNC_EDGE& Sync_Result = jitter_data_hx.Sync_Result[siteNumber][*it][lane];

        if (Sync_Result.iSteps>i)//every collect has different max��min, so some is finished, so is not yet. Finished one has no need to run any more.
        {
          Sync_Result.dActStrobePos = Sync_Result.startValue + Sync_Result.dTimeDelta * (DOUBLE) i;
          HIGHSPEEDEXTENSION_LANE(HXPIN_Resource.vBoardLane[lane]).receiverFineDelay(Sync_Result.dActStrobePos*1e-9);
        }
      }

      //----------------------------------------
    }
    FOR_EACH_SITE_END();
    //----------------------------------------

    FUNCTIONAL_TEST();

    //----------------------------------------
    FOR_EACH_SITE_BEGIN();
    siteNumber = CURRENT_SITE_NUMBER();
    it = parameters.PinVector.begin();
    it_end = parameters.PinVector.end();
    for (;it != it_end; ++it)
    {
      //----------------------------------------

      HXPIN_RESOURCE& HXPIN_Resource = jitter_data_hx.HXPIN_Resource[siteNumber][*it];

      for (int lane=0; lane<HXPIN_Resource.Lanes_Number; lane++)
      {

        SYNC_EDGE& Sync_Result = jitter_data_hx.Sync_Result[siteNumber][*it][lane];

        if (Sync_Result.iSteps>i)
        {
          Sync_Result.Func_Result[i]= GET_FUNCTIONAL_RESULT(HXPIN_Resource.vLSLanePins[lane]);        
          Sync_Result.TimeStamp[i]=Sync_Result.dActStrobePos;       
        }
      }

      //----------------------------------------
    }
    FOR_EACH_SITE_END();
    //----------------------------------------
  }//end_for (int i=0; i<max_step; i++)

  //=================left updateResultForTransitionSearch==========================================================
  isEveryPinOfAllSitesFail = true;

  //----------------------------------------
  FOR_EACH_SITE_BEGIN();
  siteNumber = CURRENT_SITE_NUMBER();
  it = parameters.PinVector.begin();
  it_end = parameters.PinVector.end();
  for (;it != it_end; ++it)
  {
    //----------------------------------------

    HXPIN_RESOURCE& HXPIN_Resource = jitter_data_hx.HXPIN_Resource[siteNumber][*it];

    for (int lane=0; lane<HXPIN_Resource.Lanes_Number; lane++)
    {

      SYNC_EDGE& Sync_Result = jitter_data_hx.Sync_Result[siteNumber][*it][lane];

      Sync_Result.pass_flag_left = 0;

      //Calculation
      for (int i=1; i<Sync_Result.iSteps-2; i++)
      {
        if (Sync_Result.Func_Result[i]!=1 && Sync_Result.Func_Result[i+1]==1 && Sync_Result.Func_Result[i+2]==1)
        {

          Sync_Result.leftTransitionVal = Sync_Result.TimeStamp[i+1];
          if (parameters.transition == LEFT)
          {
            Sync_Result.lastStatus = LEFT_TRANSITION_PASS;
          }
          isEveryPinOfAllSitesFail = false;

          //Flag Setup
          Sync_Result.pass_flag_left = 1;
          break;
        }
      }

      if (Sync_Result.pass_flag_left==0)
      {
        if (parameters.transition == LEFT)
        {
          Sync_Result.lastStatus = LEFT_TRANSITION_FAIL;      
        }
      }
    }

    //----------------------------------------
  }
  FOR_EACH_SITE_END();
  //----------------------------------------

  //=================prepare right search=============================
  max_step = 0;
  //----------------------------------------
  FOR_EACH_SITE_BEGIN();
  siteNumber = CURRENT_SITE_NUMBER();
  it = parameters.PinVector.begin();
  it_end = parameters.PinVector.end();
  for (;it != it_end; ++it)
  {
    //----------------------------------------

    if (parameters.transition == RIGHT || parameters.transition == BOTH)
    {

      HXPIN_RESOURCE& HXPIN_Resource = jitter_data_hx.HXPIN_Resource[siteNumber][*it];

      for (int lane=0; lane<HXPIN_Resource.Lanes_Number; lane++)
      {

        SYNC_EDGE& Sync_Result = jitter_data_hx.Sync_Result[siteNumber][*it][lane];

        //Get old delay of ReceiverFineDelay for future restore
        //Sync_Result.dOldDelay = HIGHSPEEDEXTENSION_LANE(HXPIN_Resource.vBoardLane[lane]).getReceiverFineDelay();

        if (Sync_Result.lastStatus == AUTOSYNC_PASS)
        {
          Sync_Result.startValue = Sync_Result.autoSyncVal;
          Sync_Result.stopValue = Sync_Result.autoSyncVal + parameters.UI_width_ns;
        }
        if (Sync_Result.lastStatus == NO_ACTION)
        {
          Sync_Result.startValue = parameters.start_ns;
          Sync_Result.stopValue = parameters.start_ns + parameters.UI_width_ns;
        }

        if ((Sync_Result.stopValue-Sync_Result.startValue) < 0)
        {
          Sync_Result.dTimeDelta = -dTimeDelta;
        }
        else
        {
          Sync_Result.dTimeDelta = dTimeDelta;
        }

        Sync_Result.iSteps = (INT)((Sync_Result.stopValue-Sync_Result.startValue)/Sync_Result.dTimeDelta);
        if (Sync_Result.iSteps > max_step)
        {
          max_step = Sync_Result.iSteps;
        }

        Sync_Result.Func_Result.clear();
        Sync_Result.TimeStamp.clear();      
        Sync_Result.Func_Result.resize(Sync_Result.iSteps);
        Sync_Result.TimeStamp.resize(Sync_Result.iSteps);
      }//end for lanes

    }//end_parameters.transition == RIGHT || parameters.transition == BOTH

    //----------------------------------------
  }
  FOR_EACH_SITE_END();
  //----------------------------------------

  //===========================right search==========================
  for (int i=0; i<max_step; i++)
  {

    //----------------------------------------
    FOR_EACH_SITE_BEGIN();
    siteNumber = CURRENT_SITE_NUMBER();
    it = parameters.PinVector.begin();
    it_end = parameters.PinVector.end();
    for (;it != it_end; ++it)
    {
      //----------------------------------------

      HXPIN_RESOURCE& HXPIN_Resource = jitter_data_hx.HXPIN_Resource[siteNumber][*it];

      for (int lane=0; lane<HXPIN_Resource.Lanes_Number; lane++)
      {

        SYNC_EDGE& Sync_Result = jitter_data_hx.Sync_Result[siteNumber][*it][lane];

        if (Sync_Result.iSteps>i)//every collect has different max��min, so some is finished, so is not yet. Finished one has no need to run any more.
        {
          Sync_Result.dActStrobePos = Sync_Result.startValue + Sync_Result.dTimeDelta * (DOUBLE) i;
          HIGHSPEEDEXTENSION_LANE(HXPIN_Resource.vBoardLane[lane]).receiverFineDelay(Sync_Result.dActStrobePos*1e-9);
        }
      }

      //----------------------------------------
    }
    FOR_EACH_SITE_END();
    //----------------------------------------

    FUNCTIONAL_TEST();

    //----------------------------------------
    FOR_EACH_SITE_BEGIN();
    siteNumber = CURRENT_SITE_NUMBER();
    it = parameters.PinVector.begin();
    it_end = parameters.PinVector.end();
    for (;it != it_end; ++it)
    {
      //----------------------------------------

      HXPIN_RESOURCE& HXPIN_Resource = jitter_data_hx.HXPIN_Resource[siteNumber][*it];

      for (int lane=0; lane<HXPIN_Resource.Lanes_Number; lane++)
      {

        SYNC_EDGE& Sync_Result = jitter_data_hx.Sync_Result[siteNumber][*it][lane];

        if (Sync_Result.iSteps>i)
        {
          Sync_Result.Func_Result[i]= GET_FUNCTIONAL_RESULT(HXPIN_Resource.vLSLanePins[lane]);        
          Sync_Result.TimeStamp[i]=Sync_Result.dActStrobePos;
        }
      }

      //----------------------------------------
    }
    FOR_EACH_SITE_END();
    //----------------------------------------
  }//end_for (int i=0; i<max_step; i++)	


  //=================right updateResultForTransitionSearch==========================================================

  //----------------------------------------
  FOR_EACH_SITE_BEGIN();
  siteNumber = CURRENT_SITE_NUMBER();
  it = parameters.PinVector.begin();
  it_end = parameters.PinVector.end();
  for (;it != it_end; ++it)
  {
    //----------------------------------------

    HXPIN_RESOURCE& HXPIN_Resource = jitter_data_hx.HXPIN_Resource[siteNumber][*it];

    for (int lane=0; lane<HXPIN_Resource.Lanes_Number; lane++)
    {

      SYNC_EDGE& Sync_Result = jitter_data_hx.Sync_Result[siteNumber][*it][lane];

      Sync_Result.pass_flag_right = 0;

      //Calculation
      for (int i=1; i<Sync_Result.iSteps-2; i++)
      {
        if (Sync_Result.Func_Result[i]==1 && Sync_Result.Func_Result[i+1]!=1 && Sync_Result.Func_Result[i+2]!=1)
        {

          Sync_Result.rightTransitionVal = Sync_Result.TimeStamp[i];
          if (parameters.transition == RIGHT)
          {
            Sync_Result.lastStatus = RIGHT_TRANSITION_PASS;
          }
          isEveryPinOfAllSitesFail = false;

          //Flag Setup
          Sync_Result.pass_flag_right=1;
          break;
        }
      }

      if (Sync_Result.pass_flag_right==0)
      {
        if (parameters.transition == RIGHT)
        {
          Sync_Result.lastStatus = RIGHT_TRANSITION_FAIL;     
        }
      }

      //=====================check for BOTH=========================
      if (parameters.transition == BOTH)
      {
        if (1== Sync_Result.pass_flag_right && 1==Sync_Result.pass_flag_left)
        {
          Sync_Result.lastStatus = BOTH_TRANSITION_PASS;
          isEveryPinOfAllSitesFail = false;
        }
        else if (0== Sync_Result.pass_flag_right && 0==Sync_Result.pass_flag_left)
        {
          Sync_Result.lastStatus = BOTH_TRANSITION_FAIL;
        }
        else
        {
          if (1== Sync_Result.pass_flag_right)
          {
            Sync_Result.lastStatus = RIGHT_TRANSITION_PASS;
            isEveryPinOfAllSitesFail = false;
          }
          if (1== Sync_Result.pass_flag_left)
          {
            Sync_Result.lastStatus = LEFT_TRANSITION_PASS;
            isEveryPinOfAllSitesFail = false;
          }
        }
      }//end_if(parameters.transition == BOTH)

      //Reset ReceiverFineDelay
      HIGHSPEEDEXTENSION_LANE(HXPIN_Resource.vBoardLane[lane]).receiverFineDelay(Sync_Result.dOldDelay);

    }//end_for (int lane=0; lane<HXPIN_Resource.Lanes_Number; lane++)

    //----------------------------------------
  }
  FOR_EACH_SITE_END();
  //----------------------------------------

  ON_FIRST_INVOCATION_END();
}

inline void JitterUtilHX::DCR_comd(STRING& LSPinName)
{
  //--------------------------------------------------------------
  // Use first mux pin to determine period, port and xmode
  string sPinOne;
  string sPortName = "";
  sPinOne = LSPinName;

  fwout << "DFPT? (@)" << endl;
  for (size_t i = 0; i< fwresult.size(); i++)
  {
    if (fwresult[i][0].find(sPinOne) != string::npos)
    {
      sPortName = fwresult[i][1];
      break;
    }
  }
  if (sPortName == "")
  {
    cout << "ERROR: PORT NAME NOT FOUND" << endl;
  }
  else
  {
    //cout << "Port: " << sPortName << endl;
  }

  //Set Per Edge result for EMAP
  fwout << "DCRM EMAP,8,PF,(@@);DCRP 0,(" << sPortName << ");DCRT RAM,(@@);\n" << endl;
  //DCRM EMAP,8,PF,(@@); 
  //Digital Compare Result Mode
  //EMAP	Detailed Error Map
  //8��8��edge for now, always use all��
  //PF	Only a one bit Pass/Fail result will be returned.
  //(@@) all port

  //DCRP 0,(DDHIC_PORT);
  //Digital Compare Result Positioning
  //(DDHIC_PORT)will change��need to find port from highspeed pin

  //Digital Compare Result Target
  //DCRT RAM,(@@);
  //--------------------------------------------------------------
}


//========================================================================================
inline void JitterUtilHX::hx_dataAcquire(
                                        const JitterParameter& parameters,
                                        JitterDataHX& jitter_data_hx)
{

  ON_FIRST_INVOCATION_BEGIN();

  DOUBLE dTimeDelta;
  dTimeDelta = parameters.dataAcquStepWidth_ns;

  INT siteNumber;

  INT max_step_left = 0;
  INT max_step_right = 0;

  STRING_VECTOR::const_iterator it = parameters.PinVector.begin();
  STRING_VECTOR::const_iterator it_end = parameters.PinVector.end();

  //=============================prepare search=================================
  max_step_left = 0;
  max_step_right = 0;

  //----------------------------------------
  FOR_EACH_SITE_BEGIN();
  siteNumber = CURRENT_SITE_NUMBER();
  it = parameters.PinVector.begin();
  it_end = parameters.PinVector.end();
  for (;it != it_end; ++it)
  {
    //----------------------------------------

    HXPIN_RESOURCE& HXPIN_Resource = jitter_data_hx.HXPIN_Resource[siteNumber][*it];

    DCR_comd(HXPIN_Resource.vLSPins[0]);

    //---------------------------------------------
    for (int lane=0; lane<HXPIN_Resource.Lanes_Number; lane++)
    {

      SYNC_EDGE& Sync_Result = jitter_data_hx.Sync_Result[siteNumber][*it][lane];

      Sync_Result.iSteps_left = 0;
      Sync_Result.iSteps_right = 0;

      //---------------------------------------------
      if (parameters.transitionSearchMode == TRANSITIONSEARCH_OFF &&
          parameters.autoSyncMode == AUTOSYNC_OFF) //case 1
      {
        if (parameters.transition == LEFT)
        {
          Sync_Result.startValue_left = parameters.start_ns;
          Sync_Result.stopValue_left = parameters.stop_ns;

          if ((Sync_Result.stopValue_left-Sync_Result.startValue_left) < 0)
          {
            Sync_Result.dTimeDelta_left = -dTimeDelta;
          }
          else
          {
            Sync_Result.dTimeDelta_left = dTimeDelta;
          }

          Sync_Result.iSteps_left = (INT)(abs((Sync_Result.stopValue_left-
                                               Sync_Result.startValue_left)/dTimeDelta));
          if (Sync_Result.iSteps_left > max_step_left)
          {
            max_step_left = Sync_Result.iSteps_left;
          }

        }
        else if (parameters.transition == RIGHT)
        {
          Sync_Result.startValue_right = parameters.start_ns;
          Sync_Result.stopValue_right = parameters.stop_ns;
          if ((Sync_Result.stopValue_right-Sync_Result.startValue_right) < 0)
          {
            Sync_Result.dTimeDelta_right = -dTimeDelta;
          }
          else
          {
            Sync_Result.dTimeDelta_right = dTimeDelta;
          }

          Sync_Result.iSteps_right = (INT)(abs((Sync_Result.stopValue_right-
                                                Sync_Result.startValue_right)/dTimeDelta));
          if (Sync_Result.iSteps_right > max_step_right)
          {
            max_step_right = Sync_Result.iSteps_right;
          }

        }
        else if (parameters.transition == BOTH)
        {
          STRING api = "In function JitterUtilHX::dataAcquire: ";
          STRING msg = "Because we don't do autoSync and transitionSearch, \
							 so BOTH option is meanless,please select RITHG or LEFT.";
          throw Error(api.c_str(),msg.c_str(),api.c_str());
        }
      }
      //---------------------------------------------
      else if (parameters.transitionSearchMode == TRANSITIONSEARCH_ON) //case 2,3,6,7,8
      {

        if ((parameters.transition == LEFT || parameters.transition == BOTH) &&
            (Sync_Result.lastStatus == LEFT_TRANSITION_PASS ||
             Sync_Result.lastStatus == BOTH_TRANSITION_PASS))
        {
          Sync_Result.startValue_left = Sync_Result.leftTransitionVal;
          Sync_Result.stopValue_left = Sync_Result.leftTransitionVal - parameters.UI_width_ns;
          if ((Sync_Result.stopValue_left-Sync_Result.startValue_left) < 0)
          {
            Sync_Result.dTimeDelta_left = -dTimeDelta;
          }
          else
          {
            Sync_Result.dTimeDelta_left = dTimeDelta;
          }

          Sync_Result.iSteps_left = (INT)(abs((Sync_Result.stopValue_left-
                                               Sync_Result.startValue_left)/dTimeDelta));
          if (Sync_Result.iSteps_left > max_step_left)
          {
            max_step_left = Sync_Result.iSteps_left;
          }

        }
        if ((parameters.transition == RIGHT || parameters.transition == BOTH) &&
            (Sync_Result.lastStatus == RIGHT_TRANSITION_PASS ||
             Sync_Result.lastStatus == BOTH_TRANSITION_PASS))
        {
          Sync_Result.startValue_right = Sync_Result.rightTransitionVal;
          Sync_Result.stopValue_right = Sync_Result.rightTransitionVal + parameters.UI_width_ns;
          if ((Sync_Result.stopValue_right-Sync_Result.startValue_right) < 0)
          {
            Sync_Result.dTimeDelta_right = -dTimeDelta;
          }
          else
          {
            Sync_Result.dTimeDelta_right = dTimeDelta;
          }

          Sync_Result.iSteps_right = (INT)(abs((Sync_Result.stopValue_right-
                                                Sync_Result.startValue_right)/dTimeDelta));
          if (Sync_Result.iSteps_right > max_step_right)
          {
            max_step_right = Sync_Result.iSteps_right;
          }
        }
      }
      //---------------------------------------------
      else //case 4,5
      {
        if ((parameters.transition == LEFT || parameters.transition == BOTH) &&
            (Sync_Result.lastStatus == AUTOSYNC_PASS))
        {
          Sync_Result.startValue_left = Sync_Result.autoSyncVal;
          Sync_Result.stopValue_left = Sync_Result.autoSyncVal - parameters.UI_width_ns;
          if ((Sync_Result.stopValue_left-Sync_Result.startValue_left) < 0)
          {
            Sync_Result.dTimeDelta_left = -dTimeDelta;
          }
          else
          {
            Sync_Result.dTimeDelta_left = dTimeDelta;
          }

          Sync_Result.iSteps_left = (INT)(abs((Sync_Result.stopValue_left-
                                               Sync_Result.startValue_left)/dTimeDelta));
          if (Sync_Result.iSteps_left > max_step_left)
          {
            max_step_left = Sync_Result.iSteps_left;
          }
        }
        if ((parameters.transition == RIGHT || parameters.transition == BOTH) &&
            (Sync_Result.lastStatus == AUTOSYNC_PASS))
        {
          Sync_Result.startValue_right = Sync_Result.autoSyncVal;
          Sync_Result.stopValue_right = Sync_Result.autoSyncVal + parameters.UI_width_ns;
          if ((Sync_Result.stopValue_right-Sync_Result.startValue_right) < 0)
          {
            Sync_Result.dTimeDelta_right = -dTimeDelta;
          }
          else
          {
            Sync_Result.dTimeDelta_right = dTimeDelta;
          }

          Sync_Result.iSteps_right = (INT)(abs((Sync_Result.stopValue_right-
                                                Sync_Result.startValue_right)/dTimeDelta));
          if (Sync_Result.iSteps_right > max_step_right)
          {
            max_step_right = Sync_Result.iSteps_right;
          }
        }
      }//end_case

      //Get old delay of ReceiverFineDelay for future restore
      Sync_Result.dOldDelay = HIGHSPEEDEXTENSION_LANE(HXPIN_Resource.vBoardLane[lane]).getReceiverFineDelay();//hx debug

      Sync_Result.ErrorCount_left.clear();
      Sync_Result.ErrorCount_right.clear();
      Sync_Result.TimeStamp_left.clear();
      Sync_Result.TimeStamp_right.clear();

      Sync_Result.ErrorCount_left.resize(Sync_Result.iSteps_left);
      Sync_Result.ErrorCount_right.resize(Sync_Result.iSteps_right);
      Sync_Result.TimeStamp_left.resize(Sync_Result.iSteps_left);
      Sync_Result.TimeStamp_right.resize(Sync_Result.iSteps_right);

    }//end_for (int lane=0; lane<HXPIN_Resource.Lanes_Number; lane++)

    //----------------------------------------
  }
  FOR_EACH_SITE_END();
  //----------------------------------------


  //================================= search=====================================
  if (parameters.transition == LEFT || parameters.transition == BOTH)
  {

    for (int i=0; i<max_step_left; i++)
    {

      //----------------------------------------
      FOR_EACH_SITE_BEGIN();
      siteNumber = CURRENT_SITE_NUMBER();
      it = parameters.PinVector.begin();
      it_end = parameters.PinVector.end();
      for (;it != it_end; ++it)
      {
        //----------------------------------------

        HXPIN_RESOURCE& HXPIN_Resource = jitter_data_hx.HXPIN_Resource[siteNumber][*it];

        for (int lane=0; lane<HXPIN_Resource.Lanes_Number; lane++)
        {

          SYNC_EDGE& Sync_Result = jitter_data_hx.Sync_Result[siteNumber][*it][lane];

          Sync_Result.lastStatus = LEFT_JITTER;

          if (Sync_Result.iSteps_left>i)//every collect has different max��min, so some is finished, so is not yet. Finished one has no need to run any more.
          {
            Sync_Result.dActStrobePos = Sync_Result.startValue_left + Sync_Result.dTimeDelta_left * (DOUBLE) i;
            HIGHSPEEDEXTENSION_LANE(HXPIN_Resource.vBoardLane[lane]).receiverFineDelay(Sync_Result.dActStrobePos*1e-9);
          }
        }
        //----------------------------------------
      }
      FOR_EACH_SITE_END();
      //----------------------------------------

      FUNCTIONAL_TEST();  

      //----------------------------------------
      FOR_EACH_SITE_BEGIN();
      siteNumber = CURRENT_SITE_NUMBER();
      it = parameters.PinVector.begin();
      it_end = parameters.PinVector.end();
      for (;it != it_end; ++it)
      {
        //----------------------------------------

        HXPIN_RESOURCE& HXPIN_Resource = jitter_data_hx.HXPIN_Resource[siteNumber][*it];

        for (int lane=0; lane<HXPIN_Resource.Lanes_Number; lane++)
        {

          SYNC_EDGE& Sync_Result = jitter_data_hx.Sync_Result[siteNumber][*it][lane];

          if (Sync_Result.iSteps_left>i)
          {
            fwout << "ERCT? ERCG,MUX,(" << HXPIN_Resource.vLSLanePins[lane] << ")" << endl;//ERror CounT
            Sync_Result.ErrorCount_left[i] = atoi(fwresult[0][2].c_str());
            Sync_Result.TimeStamp_left[i]=Sync_Result.dActStrobePos;
          }

        }
        //----------------------------------------
      }
      FOR_EACH_SITE_END();
      //----------------------------------------
    }//end_for (int i=0; i<max_step_left; i++)
  }//end_if(parameters.transition == LEFT || parameters.transition == BOTH)


  //------------------------------------------------------------------------------
  if (parameters.transition == RIGHT || parameters.transition == BOTH)
  {

    for (int i=0; i<max_step_right; i++)
    {

      //----------------------------------------
      FOR_EACH_SITE_BEGIN();
      siteNumber = CURRENT_SITE_NUMBER();
      it = parameters.PinVector.begin();
      it_end = parameters.PinVector.end();
      for (;it != it_end; ++it)
      {
        //----------------------------------------

        HXPIN_RESOURCE& HXPIN_Resource = jitter_data_hx.HXPIN_Resource[siteNumber][*it];

        for (int lane=0; lane<HXPIN_Resource.Lanes_Number; lane++)
        {

          SYNC_EDGE& Sync_Result = jitter_data_hx.Sync_Result[siteNumber][*it][lane];

          Sync_Result.lastStatus = RIGHT_JITTER;

          if (Sync_Result.iSteps_right>i)//every collect has different max��min, so some is finished, so is not yet. Finished one has no need to run any more.
          {
            Sync_Result.dActStrobePos = Sync_Result.startValue_right + Sync_Result.dTimeDelta_right * (DOUBLE) i;
            HIGHSPEEDEXTENSION_LANE(HXPIN_Resource.vBoardLane[lane]).receiverFineDelay(Sync_Result.dActStrobePos*1e-9);
          }
        }

        //----------------------------------------
      }
      FOR_EACH_SITE_END();
      //----------------------------------------

      FUNCTIONAL_TEST();

      //----------------------------------------
      FOR_EACH_SITE_BEGIN();
      siteNumber = CURRENT_SITE_NUMBER();
      it = parameters.PinVector.begin();
      it_end = parameters.PinVector.end();
      for (;it != it_end; ++it)
      {
        //----------------------------------------

        HXPIN_RESOURCE& HXPIN_Resource = jitter_data_hx.HXPIN_Resource[siteNumber][*it];

        for (int lane=0; lane<HXPIN_Resource.Lanes_Number; lane++)
        {

          SYNC_EDGE& Sync_Result = jitter_data_hx.Sync_Result[siteNumber][*it][lane];

          if (Sync_Result.iSteps_right>i)
          {
            fwout << "ERCT? ERCG,MUX,(" << HXPIN_Resource.vLSLanePins[lane] << ")" << endl;//ERror CounT
            Sync_Result.ErrorCount_right[i] = atoi(fwresult[0][2].c_str());
            Sync_Result.TimeStamp_right[i]=Sync_Result.dActStrobePos;
          }

        }
        //----------------------------------------
      }
      FOR_EACH_SITE_END();
      //----------------------------------------
    }//end_for (int i=0; i<max_step_left; i++)
  }//end_if(parameters.transition == RIGHT || parameters.transition == BOTH)

  //------------------------------------------------------------------------------
  if (parameters.transition == BOTH)
  {
    //----------------------------------------
    FOR_EACH_SITE_BEGIN();
    siteNumber = CURRENT_SITE_NUMBER();
    it = parameters.PinVector.begin();
    it_end = parameters.PinVector.end();
    for (;it != it_end; ++it)
    {
      //----------------------------------------

      HXPIN_RESOURCE& HXPIN_Resource = jitter_data_hx.HXPIN_Resource[siteNumber][*it];

      for (int lane=0; lane<HXPIN_Resource.Lanes_Number; lane++)
      {

        SYNC_EDGE& Sync_Result = jitter_data_hx.Sync_Result[siteNumber][*it][lane];
        Sync_Result.lastStatus = BOTH_JITTER;

      }

      //----------------------------------------
    }
    FOR_EACH_SITE_END();
    //----------------------------------------	

  }//end_if(parameters.transition == BOTH)


  //===========================Reset ReceiverFineDelay=============================================
  //----------------------------------------
  FOR_EACH_SITE_BEGIN();
  siteNumber = CURRENT_SITE_NUMBER();
  it = parameters.PinVector.begin();
  it_end = parameters.PinVector.end();
  for (;it != it_end; ++it)
  {
    //----------------------------------------

    HXPIN_RESOURCE& HXPIN_Resource = jitter_data_hx.HXPIN_Resource[siteNumber][*it];

    //Reset ReceiverFineDelay
    for (int lane=0; lane<HXPIN_Resource.Lanes_Number; lane++)
    {
      SYNC_EDGE& Sync_Result = jitter_data_hx.Sync_Result[siteNumber][*it][lane];     

      Sync_Result.leftErrorCount.clear();
      Sync_Result.rightErrorCount.clear();

      for (unsigned int loop = 0; loop < Sync_Result.ErrorCount_left.size(); ++loop)
      {
        Sync_Result.leftErrorCount.push_back(Sync_Result.ErrorCount_left[loop]);
      }

      for (unsigned int loop = 0; loop < Sync_Result.ErrorCount_right.size(); ++loop)
      {
        Sync_Result.rightErrorCount.push_back(Sync_Result.ErrorCount_right[loop]);
      }

      HIGHSPEEDEXTENSION_LANE(HXPIN_Resource.vBoardLane[lane]).receiverFineDelay(Sync_Result.dOldDelay);//hx debug
    }

    //----------------------------------------
  }
  FOR_EACH_SITE_END();
  //----------------------------------------

  ON_FIRST_INVOCATION_END();

}


//========================================================================================

//Multi-lane Coarse_Sync
//DOUBLE Transition_Buffer, unit [UI] 
inline void JitterUtilHX::Coarse_Sync(
                                     const JitterParameter& parameters,
                                     JitterDataHX& jitter_data_hx,
                                     DOUBLE Transition_Buffer) 
{

  ON_FIRST_INVOCATION_BEGIN();

  INT siteNumber;

  DOUBLE UI_Width;//(ps)
  UI_Width = parameters.UI_width_ns;

  DOUBLE Transition_Buffer;//empirical value 

  INT iSteps = 60;
  DOUBLE dStart = 0-UI_Width*3;//10 steps per 1 UI��total 60steps(-30steps <- 0 -> +30steps)��30����1/10��= 3 UI
  DOUBLE dActStrobePos = 0; 
  DOUBLE dTimeDelta = UI_Width/10;

  //First Search within 3.5 UIs,10 steps per 1 UI, identify Rising&Falling Edge  

  STRING_VECTOR::const_iterator it = parameters.PinVector.begin();
  STRING_VECTOR::const_iterator it_end = parameters.PinVector.end();  

  //----------------------------------------	
  FOR_EACH_SITE_BEGIN();
  siteNumber = CURRENT_SITE_NUMBER();
  it = parameters.PinVector.begin();
  it_end = parameters.PinVector.end();
  for (;it != it_end; ++it)
  {
    //----------------------------------------

    HXPIN_RESOURCE& HXPIN_Resource = jitter_data_hx.HXPIN_Resource[siteNumber][*it];

    for (int lane=0; lane<HXPIN_Resource.Lanes_Number; lane++)
    {

      SYNC_EDGE& Sync_Result = jitter_data_hx.Sync_Result[siteNumber][*it][lane];

      //Get old delay of ReceiverFineDelay for future restore
      Sync_Result.dOldDelay = HIGHSPEEDEXTENSION_LANE(HXPIN_Resource.vBoardLane[lane]).getReceiverFineDelay();//hx debug
      //dOldDelay[lane] = 1;//hx debug

      Sync_Result.Func_Result.clear();
      Sync_Result.TimeStamp.clear();
      Sync_Result.Func_Result.resize(iSteps);
      Sync_Result.TimeStamp.resize(iSteps);
    }
    //----------------------------------------
  }
  FOR_EACH_SITE_END();
  //----------------------------------------	

  for (int i=0; i<iSteps; i++)
  {

    dActStrobePos = dStart + dTimeDelta * (DOUBLE) i;

    //----------------------------------------
    FOR_EACH_SITE_BEGIN();
    siteNumber = CURRENT_SITE_NUMBER();
    it = parameters.PinVector.begin();
    it_end = parameters.PinVector.end();
    for (;it != it_end; ++it)
    {
      //----------------------------------------

      HXPIN_RESOURCE& HXPIN_Resource = jitter_data_hx.HXPIN_Resource[siteNumber][*it];

      for (int lane=0; lane<HXPIN_Resource.Lanes_Number; lane++)
      {
        HIGHSPEEDEXTENSION_LANE(HXPIN_Resource.vBoardLane[lane]).receiverFineDelay(dActStrobePos*1e-9);//receiverFineDelay unit is second

      }
      //----------------------------------------
    }
    FOR_EACH_SITE_END();
    //----------------------------------------

    FUNCTIONAL_TEST();

    //----------------------------------------
    FOR_EACH_SITE_BEGIN();
    siteNumber = CURRENT_SITE_NUMBER();
    it = parameters.PinVector.begin();
    it_end = parameters.PinVector.end();
    for (;it != it_end; ++it)
    {
      //----------------------------------------

      HXPIN_RESOURCE& HXPIN_Resource = jitter_data_hx.HXPIN_Resource[siteNumber][*it];

      for (int lane=0; lane<HXPIN_Resource.Lanes_Number; lane++)
      {

        SYNC_EDGE& Sync_Result = jitter_data_hx.Sync_Result[siteNumber][*it][lane];

        Sync_Result.Func_Result[i]= GET_FUNCTIONAL_RESULT(HXPIN_Resource.vLSLanePins[lane]);
        Sync_Result.TimeStamp[i]=dActStrobePos;     

      }

      //----------------------------------------
    }
    FOR_EACH_SITE_END();
    //----------------------------------------
  }//end_for (int i=0; i<iSteps; i++)


  //----------------------------------------
  FOR_EACH_SITE_BEGIN();
  siteNumber = CURRENT_SITE_NUMBER();
  it = parameters.PinVector.begin();
  it_end = parameters.PinVector.end();
  for (;it != it_end; ++it)
  {
    //----------------------------------------

    HXPIN_RESOURCE& HXPIN_Resource = jitter_data_hx.HXPIN_Resource[siteNumber][*it];

    for (int lane=0; lane<HXPIN_Resource.Lanes_Number; lane++)
    {

      INT LeftSide_stop_index;

      SYNC_EDGE& Sync_Result = jitter_data_hx.Sync_Result[siteNumber][*it][lane]; 

      LeftSide_stop_index=0;

      INT pass_flag=0;

      //Calculation
      for (int i=1; i<iSteps-2; i++)
      {
        if (Sync_Result.Func_Result[i]!=1 && Sync_Result.Func_Result[i+1]==1 && Sync_Result.Func_Result[i+2]==1)
        {

          Sync_Result.LeftSide_Stop = Sync_Result.TimeStamp[i+1];
          LeftSide_stop_index = i+1;

          Sync_Result.LeftSide_Start = Sync_Result.LeftSide_Stop - UI_Width*Transition_Buffer;//buffer is only a empirical value

          //Flag Setup
          pass_flag=1;
          break;
        }
      }

      if (pass_flag==0)
      {
        cout<<"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"<<endl;
        cout<<HXPIN_Resource.vHSPins[lane]<<" ERROR:Coarse_Sync() Leftside Fail!"<<endl;
        cout<<"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"<<endl;
        Sync_Result.LeftSide_Start = 0;
        Sync_Result.LeftSide_Stop = 0;
        //return;
      }

      pass_flag=0;
      for (int i=LeftSide_stop_index; i<iSteps-2; i++)//from LeftSide_stop_index start to search RightSide_Start
      {
        if (Sync_Result.Func_Result[i]==1 && Sync_Result.Func_Result[i+1]!=1 && Sync_Result.Func_Result[i+2]!=1)
        {

          Sync_Result.RightSide_Start = Sync_Result.TimeStamp[i];

          Sync_Result.RightSide_Stop = Sync_Result.RightSide_Start + UI_Width*Transition_Buffer;

          //Flag Setup
          pass_flag=1;
          break;
        }
      }

      if (pass_flag==0)
      {
        cout<<"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"<<endl;
        cout<<HXPIN_Resource.vHSPins[lane]<<" ERROR:Coarse_Sync() Rightside Fail!"<<endl;
        cout<<"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"<<endl;
        Sync_Result.RightSide_Start = 0;
        Sync_Result.RightSide_Stop = 0;
        //			return;
      }

      //Reset ReceiverFineDelay
      HIGHSPEEDEXTENSION_LANE(HXPIN_Resource.vBoardLane[lane]).receiverFineDelay(Sync_Result.dOldDelay);
    }

    //----------------------------------------
  }
  FOR_EACH_SITE_END();
  //----------------------------------------

  ON_FIRST_INVOCATION_END();
}

//-------------------------------------------------------------------------------------------------------------------

//Single Lane Error Count Acquire
inline void JitterUtilHX::HX_Error_Count_Acquire(
                                                const JitterParameter& parameters,
                                                JitterDataHX& jitter_data_hx,
                                                TRANSITION active)
{

  ON_FIRST_INVOCATION_BEGIN();

  DOUBLE dTimeDelta;
  dTimeDelta = parameters.dataAcquStepWidth_ns;

  INT siteNumber;

  INT max_step_left = 0;
  INT max_step_right = 0;

  STRING_VECTOR::const_iterator it = parameters.PinVector.begin();
  STRING_VECTOR::const_iterator it_end = parameters.PinVector.end();


  //----------------------------prepare---------------------------------------------
  //----------------------------------------
  FOR_EACH_SITE_BEGIN();
  siteNumber = CURRENT_SITE_NUMBER();
  it = parameters.PinVector.begin();
  it_end = parameters.PinVector.end();
  for (;it != it_end; ++it)
  {
    //----------------------------------------

    HXPIN_RESOURCE& HXPIN_Resource = jitter_data_hx.HXPIN_Resource[siteNumber][*it];

    DCR_comd(HXPIN_Resource.vLSPins[0]);

    //---------------------------------------------
    for (int lane=0; lane<HXPIN_Resource.Lanes_Number; lane++)
    {

      SYNC_EDGE& Sync_Result = jitter_data_hx.Sync_Result[siteNumber][*it][lane];

      Sync_Result.iSteps_left = 0;
      Sync_Result.iSteps_right = 0;

      if (LEFT == active || BOTH == active)
      {
        Sync_Result.iSteps_left = (INT)(abs((Sync_Result.LeftSide_Stop-Sync_Result.LeftSide_Start)/dTimeDelta));

        if (Sync_Result.iSteps_left > max_step_left)
        {
          max_step_left = Sync_Result.iSteps_left;
        }

      }
      if (RIGHT == active || BOTH == active)
      {

        Sync_Result.iSteps_left = (INT)(abs((Sync_Result.RightSide_Stop-Sync_Result.RightSide_Start)/dTimeDelta));

        if (Sync_Result.iSteps_right > max_step_right)
        {
          max_step_right = Sync_Result.iSteps_right;
        }

      }

      //Get old delay of ReceiverFineDelay for future restore
      Sync_Result.dOldDelay = HIGHSPEEDEXTENSION_LANE(HXPIN_Resource.vBoardLane[lane]).getReceiverFineDelay();//hx debug

      Sync_Result.ErrorCount_left.clear();
      Sync_Result.ErrorCount_right.clear();
      Sync_Result.TimeStamp_left.clear();
      Sync_Result.TimeStamp_right.clear();

      Sync_Result.ErrorCount_left.resize(Sync_Result.iSteps_left);
      Sync_Result.ErrorCount_right.resize(Sync_Result.iSteps_right);
      Sync_Result.TimeStamp_left.resize(Sync_Result.iSteps_left);
      Sync_Result.TimeStamp_right.resize(Sync_Result.iSteps_right);

    }//end_for (int lane=0; lane<HXPIN_Resource.Lanes_Number; lane++)

    //----------------------------------------
  }
  FOR_EACH_SITE_END();
  //----------------------------------------

  //----------------------------left---------------------------------------------	
  if (LEFT == active || BOTH == active)
  {
    for (int i=0; i<max_step_left; i++)
    {

      //----------------------------------------
      FOR_EACH_SITE_BEGIN();
      siteNumber = CURRENT_SITE_NUMBER();
      it = parameters.PinVector.begin();
      it_end = parameters.PinVector.end();
      for (;it != it_end; ++it)
      {
        //----------------------------------------

        HXPIN_RESOURCE& HXPIN_Resource = jitter_data_hx.HXPIN_Resource[siteNumber][*it];

        for (int lane=0; lane<HXPIN_Resource.Lanes_Number; lane++)
        {

          SYNC_EDGE& Sync_Result = jitter_data_hx.Sync_Result[siteNumber][*it][lane];

          if (Sync_Result.iSteps_left>i)//every collect has different max��min, so some is finished, so is not yet. Finished one has no need to run any more.
          {
            Sync_Result.dActStrobePos = Sync_Result.LeftSide_Start + dTimeDelta * (DOUBLE) i;
            HIGHSPEEDEXTENSION_LANE(HXPIN_Resource.vBoardLane[lane]).receiverFineDelay(Sync_Result.dActStrobePos*1e-9);
          }
        }
        //----------------------------------------
      }
      FOR_EACH_SITE_END();
      //----------------------------------------

      FUNCTIONAL_TEST();

      //----------------------------------------
      FOR_EACH_SITE_BEGIN();
      siteNumber = CURRENT_SITE_NUMBER();
      it = parameters.PinVector.begin();
      it_end = parameters.PinVector.end();
      for (;it != it_end; ++it)
      {
        //----------------------------------------

        HXPIN_RESOURCE& HXPIN_Resource = jitter_data_hx.HXPIN_Resource[siteNumber][*it];

        for (int lane=0; lane<HXPIN_Resource.Lanes_Number; lane++)
        {

          SYNC_EDGE& Sync_Result = jitter_data_hx.Sync_Result[siteNumber][*it][lane];


          if (Sync_Result.iSteps_left>i)
          {

            fwout << "ERCT? ERCG,MUX,(" << HXPIN_Resource.vLSLanePins[lane] << ")" << endl;//ERror CounT
            Sync_Result.ErrorCount_left[i] = atoi(fwresult[0][2].c_str());
            Sync_Result.TimeStamp_left[i]=Sync_Result.dActStrobePos;

          }

        }
        //----------------------------------------
      }
      FOR_EACH_SITE_END();
      //----------------------------------------
    }//end_for (int i=0; i<max_step_left; i++)
  }//end_if( LEFT == active || BOTH == active )

  //----------------------------right---------------------------------------------	
  if (RIGHT == active || BOTH == active)
  {
    for (int i=0; i<max_step_right; i++)
    {

      //----------------------------------------
      FOR_EACH_SITE_BEGIN();
      siteNumber = CURRENT_SITE_NUMBER();
      it = parameters.PinVector.begin();
      it_end = parameters.PinVector.end();
      for (;it != it_end; ++it)
      {
        //----------------------------------------

        HXPIN_RESOURCE& HXPIN_Resource = jitter_data_hx.HXPIN_Resource[siteNumber][*it];

        for (int lane=0; lane<HXPIN_Resource.Lanes_Number; lane++)
        {

          SYNC_EDGE& Sync_Result = jitter_data_hx.Sync_Result[siteNumber][*it][lane];

          if (Sync_Result.iSteps_right>i)//every collect has different max��min, so some is finished, so is not yet. Finished one has no need to run any more.
          {
            Sync_Result.dActStrobePos = Sync_Result.RightSide_Start + dTimeDelta * (DOUBLE) i;
            HIGHSPEEDEXTENSION_LANE(HXPIN_Resource.vBoardLane[lane]).receiverFineDelay(Sync_Result.dActStrobePos*1e-9);
          }
        }
        //----------------------------------------
      }
      FOR_EACH_SITE_END();
      //----------------------------------------

      FUNCTIONAL_TEST();

      //----------------------------------------
      FOR_EACH_SITE_BEGIN();
      siteNumber = CURRENT_SITE_NUMBER();
      it = parameters.PinVector.begin();
      it_end = parameters.PinVector.end();
      for (;it != it_end; ++it)
      {
        //----------------------------------------

        HXPIN_RESOURCE& HXPIN_Resource = jitter_data_hx.HXPIN_Resource[siteNumber][*it];

        for (int lane=0; lane<HXPIN_Resource.Lanes_Number; lane++)
        {

          SYNC_EDGE& Sync_Result = jitter_data_hx.Sync_Result[siteNumber][*it][lane];

          if (Sync_Result.iSteps_right>i)
          {

            fwout << "ERCT? ERCG,MUX,(" << HXPIN_Resource.vLSLanePins[lane] << ")" << endl;//ERror CounT
            Sync_Result.ErrorCount_right[i] = atoi(fwresult[0][2].c_str());
            Sync_Result.TimeStamp_right[i]=Sync_Result.dActStrobePos;

          }

        }
        //----------------------------------------
      }
      FOR_EACH_SITE_END();
      //----------------------------------------
    }//end_for (int i=0; i<max_step_right; i++)
  }//end_if( RIGHT == active || BOTH == active )


  //=========================================================================================


  //----------------------------------------
  FOR_EACH_SITE_BEGIN();
  siteNumber = CURRENT_SITE_NUMBER();
  it = parameters.PinVector.begin();
  it_end = parameters.PinVector.end();
  for (;it != it_end; ++it)
  {
    //----------------------------------------

    HXPIN_RESOURCE& HXPIN_Resource = jitter_data_hx.HXPIN_Resource[siteNumber][*it];

    //Reset ReceiverFineDelay
    for (int lane=0; lane<HXPIN_Resource.Lanes_Number; lane++)
    {
      SYNC_EDGE& Sync_Result = jitter_data_hx.Sync_Result[siteNumber][*it][lane];     

      Sync_Result.leftErrorCount.clear();
      Sync_Result.rightErrorCount.clear();

      for (unsigned int loop = 0; loop < Sync_Result.ErrorCount_left.size(); ++loop)
      {
        Sync_Result.leftErrorCount.push_back(Sync_Result.ErrorCount_left[loop]);
      }

      for (unsigned int loop = 0; loop < Sync_Result.ErrorCount_right.size(); ++loop)
      {
        Sync_Result.rightErrorCount.push_back(Sync_Result.ErrorCount_right[loop]);
      }

      HIGHSPEEDEXTENSION_LANE(HXPIN_Resource.vBoardLane[lane]).receiverFineDelay(Sync_Result.dOldDelay);//hx debug
    }

    //----------------------------------------
  }
  FOR_EACH_SITE_END();
  //----------------------------------------

  ON_FIRST_INVOCATION_END();  

}


inline void JitterUtilHX::printWaringMessage(const INT siteNumber,
                                             const STRING& pinName,
                                             const INT lane)
{
  cout << "Warning::For site:     " << siteNumber << endl; 
  cout << "          For Pin:     " << pinName << endl;
  cout << "         For lane:     " << lane << endl;
}

#endif //INCLUDE_JITTERHX_H_
