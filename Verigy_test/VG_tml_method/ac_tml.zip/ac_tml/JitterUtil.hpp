#ifndef INCLUDE_JITTER_H_
#define INCLUDE_JITTER_H_
#include <algorithm>
#include "CommonUtil.hpp"

/******************************************************************************
 *                    jitter  test utility class 
 ******************************************************************************
 *Description:
 * By setting up different parameters,users can make the jitter 
 * measurement in different conditions.
 *    pattern synchronization: find a passing pattern
 *    transtioon search on specified side(s): optimize the start of jitter data
 *                                           acquisition.
 *    data acquisition on specified side(s): sample the jitter data
 * according the description,the whole process steps:
 * |----------------|     |------------|       |-------------|
 * |    pattern     |     | transition |       |             |
 * |synchronization |---->|  search    |------>|     data    |
 * |   (optional)   |     | (optional) |       | acquisition | 
 * |----------------|     |------------|       |-------------| 
 * some action is optional in the whole process, so all kinds of user's select 
 * like this chart:
 *-------|--------|---------|----------------|---------|-----------------|---------------
 * case  |autoSync|pass/fail|transitionSearch|pass/fail|acquisition start|acquisition stop
 *number |   mode |         |       mode     |         |                 |
 *-------|--------|---------|----------------|---------|-----------------|----------------*
 *   1   |   off  |         |     off        |         | start parameter | stop parameter *
 *-------|--------|---------|----------------|---------|-----------------|----------------*
 *   2   |   off  |         |     on         |  pass   |traisition of    |optimized data  *
 *       |        |         |                |         |binary search    |acquisition stop*
 *-------|--------|---------|----------------|---------|-----------------|----------------*
 *   3   |   off  |         |     on         |  fail   |measurement      |measurement     *
 *       |        |         |                |         |stop             |sotp            *
 *-------|--------|---------|----------------|---------|-----------------|----------------*
 *   4   |   on   |   pass  |     off        |         |autosync         |optimized data  *
 *       |        |         |                |         |position         |acquisition stop*
 *-------|--------|---------|----------------|---------|-----------------|----------------*
 *   5   |   on   |   fail  |     off        |         |measurement      |measurement     *
 *       |        |         |                |         |stop             |sotp            *
 *-------|--------|---------|----------------|---------|-----------------|----------------*
 *   6   |   on   |   pass  |     on         |  fail   |measurement      |measurement     *
 *       |        |         |                |         |stop             |sotp            *
 *-------|--------|---------|----------------|---------|-----------------|----------------*
 *   7   |   on   |   pass  |     on         |  pass   |traisition of    |optimized data  *
 *       |        |         |                |         |binary search    |acquisition stop*
 *-------|--------|---------|----------------|---------|-----------------|----------------*
 *   8   |   on   |   fail  |     on         |  n/a    |mearsurement     |mearsurement    *
 *       |        |         |                |         |stop             |stop            *
 *-------|--------|---------|----------------|---------|-----------------|----------------*
 ******************************************************************************
 */ 
class JitterUtil
{
  public:
  //transition search direction: left,right,both  
  enum TRANSITION {LEFT, RIGHT, BOTH};
  //autosync mode:on,off,on_keep_value
  enum AUTOSYNC_MODE
  {
    AUTOSYNC_OFF,
    AUTOSYNC_ON,
    AUTOSYNC_ON_KEEP_VALUE
  };
  //transition search mode: on,off
  enum TRANSITIONSEARCH_MODE
  {
    TRANSITIONSEARCH_OFF,
    TRANSITIONSEARCH_ON
  };
  //output mode: summary,detail,analysis
  enum OUTPUT_MODE 
  {
    OUTPUT_SUMMARY,
    OUTPUT_DETAIL,
    OUTPUT_ANALYSIS
  };
  /**
   *---------------------------------------------------------------------------
   *         test parameters container
   *---------------------------------------------------------------------------
   */
  typedef struct JitterParameter
  {
    STRING_VECTOR PinVector;
    STRING portName;
    STRING specName_postfix;
    DOUBLE UI_width_ns;
    DOUBLE start_ns;
    DOUBLE stop_ns;
    DOUBLE dataAcquStepWidth_ns;
    INT    passOnMaxErrorCount;
    AUTOSYNC_MODE autoSyncMode;
    DOUBLE autoSyncStepWidth_ns;
    TRANSITIONSEARCH_MODE transitionSearchMode;
    TRANSITION transition;
    OUTPUT_MODE outputMode;
  } JitterParameter;
  /**
   *---------------------------------------------------------------------------
   *         test results container
   *---------------------------------------------------------------------------
   */
  enum ACTION_STATUS
  {
    //the following five items are used to identify the status of autoSync
    AUTOSYNC_PASSFAIL, //first autosync linear search result(P------>F)
    AUTOSYNC_FAILPASS, //first autosync linear search result(F------>P)
    AUTOSYNC_ALLPASS,  //first autosync linear search result(P------>P)
    AUTOSYNC_PASS,     //autosync linear search result(find pass pattern)
    AUTOSYNC_FAIL,     //autosync linear search result(can't find pass pattern)
    //the following six items are used to identify the status of 
    //transitionSearch according to the user's seclect.
    LEFT_TRANSITION_PASS,
    LEFT_TRANSITION_FAIL,
    RIGHT_TRANSITION_PASS,
    RIGHT_TRANSITION_FAIL,
    BOTH_TRANSITION_PASS,
    BOTH_TRANSITION_FAIL,
    //the following three items are used to identify the status of jitter
    //measurement according to the user's seclect.
    LEFT_JITTER,
    RIGHT_JITTER,
    BOTH_JITTER,
    //this item is used to initialize.
    NO_ACTION
  };
  struct CommonResultData
  {
    /**
     * parameter lastStatus is used to reflect the current status during the  
     * process of doing jittermeasurement.
     * For example, at first the value of of this parameter is NO_ACTION;
     * after autoSync the value is AUTOSYNC_PASS;
     * after transtionsearch the value is BOTH_TRANSITION_PASS;
     * after data acquire and calculation the value is BOTH_JITTER.
     */
    ACTION_STATUS lastStatus;

    // the result of autoSync value
    DOUBLE autoSyncVal;

    // the result of left transiton search value
    DOUBLE leftTransitionVal;

    // the result og right transiton search value
    DOUBLE rightTransitionVal;

    // error count vector of left transition
    vector<INT> leftErrorCount;

    // error count vector of right transition
    vector<INT> rightErrorCount;

    // initialize all stuffs to some defaults.
    void init()
    {
      lastStatus = NO_ACTION;
      autoSyncVal = 0.0;
      leftTransitionVal = 0.0;
      rightTransitionVal = 0.0;
      leftErrorCount.clear();
      rightErrorCount.clear();
    }
    CommonResultData()
    {
      init();
    }
  };
  /**
   *---------------------------------------------------------------------------
   * Struct: JitterResult
   * Purpose: container to store common jitter measurement results
   *---------------------------------------------------------------------------
   * Decription:
   *   This two-layered map contains result of test.The outside map contains
   *   every site's result.The inside map contains every pin's result.
   *   The outside map's key: INT is the index of site number
   *   The outside map's value:map<STRING,CommonResultData> is the result of the
   *   site which is indexed by key.
   *   The inside map's key: STRING is the pin's name.
   *   The inside map's value: CommonResultData is the result of the pin which 
   *   is indexed by key.
   * Note:
   *---------------------------------------------------------------------------
   */
  typedef struct JitterResult
  {
    map<INT,map<STRING, CommonResultData> > commonResultMap;
    void init()
    {
      commonResultMap.clear();
    }
  } JitterResult;
  /**
   *---------------------------------------------------------------------------
   *         public interfaces of common jitter test
   *---------------------------------------------------------------------------
   */  
  
  static void autoSync(
    const JitterParameter& parameters,
    JitterResult & results,
    bool &isEveryPinOfAllSitesFail);
  static void transitionSearch(
    const JitterParameter& parameters,
    JitterResult& results,
    bool &isEveryPinOfAllSitesFail); 
  static void dataAcquire(
    const JitterParameter& paraeters,
    JitterResult & results);
  static void checkSetupPinlist(const STRING& pins); 
  static void updateResultForAutoSync(
    const SEARCH_FUNC_TASK & task,
    const JitterParameter& parameters,
    JitterResult& results,
    bool &isEveryPinOfAllSitesFail);
  static void updateResultForTransitionSearch(
    const SEARCH_FUNC_TASK & task1,
    const SEARCH_FUNC_TASK & task2,
    const JitterParameter & parameters,
    JitterResult& results,
    bool &isEveryPinOfAllSitesFail);
  static void updateResultForDataAcquire(
    const ERROR_COUNT_ACQUIRE & task1,
    const ERROR_COUNT_ACQUIRE & task2,
    const JitterParameter& paraeters,
    JitterResult& results);
  static STRING_VECTOR expandPinlistToPins(const STRING & pinlist);
  static void printWaringMessage(const INT, const STRING&);
};
  
/**
 *-----------------------------------------------------------------------------
 * Routine: checkSetupPinlist
 *
 * Purpose: check setup pin types
 *
 *-----------------------------------------------------------------------------
 * Description:
 *  for jitter measurement,only O,IO type pins are valid. 
 * Note:
 *-----------------------------------------------------------------------------
 */
inline void JitterUtil::checkSetupPinlist(const STRING& pins)
{
  if(pins.empty()) 
  {
    STRING api = "Check setup pin: ";
    STRING msg = "There is no setup pin! Please input setup pin(s).";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }
  try
  {
    PinUtility.getDigitalPinNamesFromPinList(pins,TM::O_PIN|TM::IO_PIN,TRUE,TRUE);
  }
  catch (ErrorInfo & e)
  {
    STRING api = "Check setup pin: ";
    STRING msg = "Some pin in pins is not any kind of O,IO pin!";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }
}

/*
 *-----------------------------------------------------------------------------
 *Routine: JitterUtil::expandPinlistToPins
 *
 *Purpose: expand pinlist to individual pins
 *-----------------------------------------------------------------------------
 *Description:
 *Use PinUtility API to expand pinlist to pins
 *
 *Parameters:
 * 1)pinlist: needed be separated
 *
 *Output:
 * the string vector of individual pins.
 *-----------------------------------------------------------------------------
 */
inline STRING_VECTOR 
JitterUtil::expandPinlistToPins(const STRING & pinlist)
{
  STRING_VECTOR resultExpandedPinVector;
  STRING_VECTOR expandedDigitalPinVector;
  STRING_VECTOR splitPinlist;

  resultExpandedPinVector.clear();
  CommonUtil::splitStr(pinlist,',',splitPinlist);
  for(STRING_VECTOR::const_iterator it = splitPinlist.begin();
      it != splitPinlist.end();++it)
  {
    expandedDigitalPinVector = PinUtility.getDigitalPinNamesFromPinList(*it,
                                                       TM::IO_PIN|TM::O_PIN,
                                                                       TRUE,
                                                                       TRUE);
    resultExpandedPinVector += expandedDigitalPinVector;
  }
  return resultExpandedPinVector;
}
/*
 *-----------------------------------------------------------------------------
 *Routine: autoSync
 *
 *Purpose: in order to find the passing pattern
 *
 *-----------------------------------------------------------------------------
 *Description:
 *  For the synchronization two linear search will be executed in the region 
 *  defined by the start/stop parameter. We will get a pass/fail transition 
 *  and a fail/pass transition,the autosync vaule will be the center of the 
 *  pass area.
 *
 *  Please note that this routine will also can find a synchronization position
 *  for failing pattern by re-defining 'pass' threshold according to 
 *  passOnMaxErrorCount parameter.
 *INPUT:
 *     parameters------------test parameters
 *     results---------------test results container
 *     isEveryPinOfAllSitesFail-------if this parameter's value is true,
 *                                    the mearsurement will stop
 *Return:
 *NOTE:
 * for every pin of every site, the search condition is as following:
 *-------------------|-----------------|---------------
 * search result case|first search     |second search
 *-------------------|-----------------|---------------
 *       1           | pass/fail       | fail/pass
 *       3           | fail/pass       | pass/fail
 *       5           | allpass         |  no need
 *       6           | allfail         |  no need
 *-----------------------------------------------------------------------------
 */

inline void JitterUtil::autoSync(
  const JitterParameter & parameters,
  JitterResult& results,
  bool& isEveryPinOfAllSitesFail)
{
  SEARCH_FUNC_TASK *errorCountSearchTask = NULL;
  if(parameters.passOnMaxErrorCount > 0)
  {
    errorCountSearchTask = new SEARCH_FUNC_TASK(parameters.passOnMaxErrorCount,
                                                TM::ERROR_PER_EDGE);
  }
  else
  {
    errorCountSearchTask = new SEARCH_FUNC_TASK;
  }

  ON_FIRST_INVOCATION_BEGIN();  
    STRING_VECTOR::const_iterator it = parameters.PinVector.begin();
    STRING_VECTOR::const_iterator it_end = parameters.PinVector.end();
    //first linear search
    for(;it != it_end; ++it)
    {
      STRING specName = *it + "_" + parameters.specName_postfix;
      (*errorCountSearchTask).pin(*it)
                             .spec(specName,TM::TIM)
                             .start(parameters.start_ns)
                             .stop(parameters.stop_ns)
                             .stepWidth(parameters.autoSyncStepWidth_ns)
                             .method(TM::Linear)
                             .resultPins(*it);
    }
    errorCountSearchTask->execute();

    updateResultForAutoSync(*errorCountSearchTask,
                             parameters,
                             results,
                             isEveryPinOfAllSitesFail);
    //second linear search
    if(!isEveryPinOfAllSitesFail)
    {
      // for the second linear search,the range range is 1.5 * UI_width_ns,which
      // is for sure that we can get a transiton in this range
      DOUBLE searchRangeFactor = 1.5;
      FOR_EACH_SITE_BEGIN();
        INT siteNumber = CURRENT_SITE_NUMBER();
        it = parameters.PinVector.begin();
        it_end = parameters.PinVector.end();
        for(;it != it_end; ++it)
        {
          DOUBLE startValue = 0.0;
          DOUBLE stopValue = 0.0;
          if(results.commonResultMap[siteNumber][*it].lastStatus != AUTOSYNC_FAIL)
          {
            startValue = results.commonResultMap[siteNumber][*it].autoSyncVal;
            if(results.commonResultMap[siteNumber][*it].lastStatus 
               == AUTOSYNC_PASSFAIL)
            {
              stopValue = startValue - 
                          searchRangeFactor * parameters.UI_width_ns;
            }
            else if(results.commonResultMap[siteNumber][*it].lastStatus 
                    == AUTOSYNC_FAILPASS)
            {
              stopValue = startValue + 
                          searchRangeFactor * parameters.UI_width_ns;
            }
            else if(results.commonResultMap[siteNumber][*it].lastStatus 
                    == AUTOSYNC_ALLPASS)
            {
              //the first search is all pass, so it's no need to search again
              //for this pin of this site.
              continue;
            }
            else
            {
              STRING api = "In function JitterUtil::autoSync: ";
              STRING msg = "These is an unexpected action status.";
              throw Error(api.c_str(),msg.c_str(),api.c_str());
            }
            STRING specName = *it + "_" + parameters.specName_postfix;
            (*errorCountSearchTask).pin(*it)
                                   .spec(specName,TM::TIM)
                                   .start(startValue)
                                   .stop(stopValue)
                                   .stepWidth(parameters.autoSyncStepWidth_ns)
                                   .method(TM::Linear)
                                   .resultPins(*it);
          }//end if lastStatus != AUTOSYNC_FAIL
        }//end for pins
      FOR_EACH_SITE_END();
      errorCountSearchTask->execute();

      updateResultForAutoSync(*errorCountSearchTask,
                               parameters,
                               results,
                               isEveryPinOfAllSitesFail);
    }
  ON_FIRST_INVOCATION_END();

  delete errorCountSearchTask;
}

/**
 *-----------------------------------------------------------------------------
 *Routine: updateResultForAutoSync
 *
 *Purpose: updata result for synchronization
 *
 *-----------------------------------------------------------------------------
 *Description:
 *
 *INPUT:
 *     task-------------------------synchronization linear search
 *     parameters-------------------test parameters
 *     results----------------------test result container
 *     isEveryPinOfAllSitesFail-----if this parameter's value is
 *                                  true,the mearsurement will stop
 *Return:
 *-----------------------------------------------------------------------------
 */
inline void JitterUtil::updateResultForAutoSync(
  const SEARCH_FUNC_TASK & task,
  const JitterParameter & parameters,
  JitterResult& results,
  bool& isEveryPinOfAllSitesFail)
{
  isEveryPinOfAllSitesFail = true;
  FOR_EACH_SITE_BEGIN();
  INT siteNumber = CURRENT_SITE_NUMBER();
  STRING_VECTOR::const_iterator it = parameters.PinVector.begin();
  STRING_VECTOR::const_iterator it_end = parameters.PinVector.end();
  for(;it != it_end; ++it)
  {
    switch(results.commonResultMap[siteNumber][*it].lastStatus)
    {
      case NO_ACTION://update for the first search
        //we use autoSyncVal to remember the pass value of the first search.
        if (task.getPassFail(*it))
        {
          results.commonResultMap[siteNumber][*it].autoSyncVal = 
                                                        task.getPassValue(*it);
          if(task.getResultSpec(*it) == TM::TransitionPassFail)
          {
            results.commonResultMap[siteNumber][*it].lastStatus = AUTOSYNC_PASSFAIL;
          }
          else
          {
            results.commonResultMap[siteNumber][*it].lastStatus = AUTOSYNC_FAILPASS;
          }
          isEveryPinOfAllSitesFail = false;
        }
        else
        {
          if(task.getResultSpec(*it) == TM::AllPass)
          {
            results.commonResultMap[siteNumber][*it].autoSyncVal = 
                                                           parameters.start_ns;
            results.commonResultMap[siteNumber][*it].lastStatus = AUTOSYNC_ALLPASS;
            isEveryPinOfAllSitesFail = false;
          }
          else
          {
            results.commonResultMap[siteNumber][*it].lastStatus = AUTOSYNC_FAIL;
          }
        }
        break;
      case AUTOSYNC_PASSFAIL: 
      case AUTOSYNC_FAILPASS://update for the second search
        if (task.getPassFail(*it))
        {
          // 1. first search result: AUTOSYNC_PASSFAIL
          //the first search result is p/f, the second linear search get 
          //another p/f,because the second search's begining point is pass,so
          //we calculate the autoSyncValue: (the first search's pass value + 
          //the second search's pass value )/2 
          //                   ----|             |----
          //                       |             |    
          //                       |_____________|    
          //                                  |->p/f->|  first search --->
          //                 |<--f/p<--|       <----second search
          // 2. first search resullt: AUTOSYNC_FAILPASS
          //the first search result is f/p, the second linear search get p/f, 
          //we calculate the autoSyncValue: (the first search's  pass value + 
          //the second search's  pass value )/2 
          //                   ----|             |----
          //                       |             |    
          //                       |_____________|    
          //                 |->f/p->|  first search --->
          //                              |-->p/f-->|   ----->second search
          results.commonResultMap[siteNumber][*it].autoSyncVal =
            (task.getPassValue(*it) + 
            results.commonResultMap[siteNumber][*it].autoSyncVal)/2;
          results.commonResultMap[siteNumber][*it].lastStatus = AUTOSYNC_PASS;
          isEveryPinOfAllSitesFail = false;
        }
        else
        {
          results.commonResultMap[siteNumber][*it].lastStatus = AUTOSYNC_FAIL;
        }
        break;
      case AUTOSYNC_ALLPASS://update for the second search
        //the first search result is p/p, so it's no need do second search 
        //we calculate the autoSyncValue: 
        // (the first search's first pass value + the first search's 
        // last pass value )/2
        //                   ----|             |----
        //                       |             |    
        //                       |_____________|    
        //                        |--->p/p--->|  first search --->
        //                        don't need second search
        results.commonResultMap[siteNumber][*it].autoSyncVal += 
          static_cast<int>((parameters.stop_ns - parameters.start_ns) / 
          parameters.autoSyncStepWidth_ns) * 
          parameters.autoSyncStepWidth_ns/2.0;
        results.commonResultMap[siteNumber][*it].lastStatus = AUTOSYNC_PASS;
        isEveryPinOfAllSitesFail = false;
        break;
      case AUTOSYNC_FAIL: //update after the second search
        //the first search result is f/f, so it's no need do second search 
        //this pin of this site is fail, we can't do jitter mearsurement for 
        //this pin. 
        //                   ----|             |----
        //                       |             |    
        //                       |_____________|    
        //                        |--->f/f--->|  first search --->
        //                        don't need second search
        break;
      default:
        throw Error("JitterUtil::updateResultForAutoSync",
                    ",it should't come here! It's an unexpected status!",
                    "JitterUtil::updateResultForAutoSync");
    }
  }//end for every pin
  FOR_EACH_SITE_END();
}
/**
 *-----------------------------------------------------------------------------
 *Routine: transitionSearch
 *
 *Purpose: optimization of acquisition start
 *
 *-----------------------------------------------------------------------------
 *Description:
 * For accurate jitter measurements,the data acquisition should use a fine
 * resolution which might lead to longer test time. The tradeoff between
 * accuracy and test time raises the need for an optimization of the exact
 * acquisition area. Areas with a stable error count don't contribute to the
 * mearsurement accuracy and should be avoided. Therefore the first data
 * acquisition should start at the position in time where the error count
 * starts to increase for the first time when moving the strobes towards the
 * eye boundaries on the left or right, respectively.
 *INPUT: 
 *   parameters-----------------test parameters
 *   results--------------------test results container
 *   isEveryPinOfAllSitesFail---if this parameter's value is
 *                              true,the mearsurement will stop
 *Return: 
 *-----------------------------------------------------------------------------
 */
inline void JitterUtil::transitionSearch(
  const JitterParameter& parameters,
  JitterResult& results,
  bool &isEveryPinOfAllSitesFail)
{
  SEARCH_FUNC_TASK *errorCountSearchTaskLeft = NULL;
  SEARCH_FUNC_TASK *errorCountSearchTaskRight = NULL;
  if(parameters.passOnMaxErrorCount > 0)
  {
    if(parameters.transition == LEFT || parameters.transition == BOTH)
    {
      errorCountSearchTaskLeft = 
       new SEARCH_FUNC_TASK(parameters.passOnMaxErrorCount,TM::ERROR_PER_EDGE);
    }
    if(parameters.transition == RIGHT || parameters.transition == BOTH)
    {
      errorCountSearchTaskRight =
       new SEARCH_FUNC_TASK(parameters.passOnMaxErrorCount,TM::ERROR_PER_EDGE);
    }
  }
  else
  { 
    if(parameters.transition == LEFT || parameters.transition == BOTH)
    {
      errorCountSearchTaskLeft = new SEARCH_FUNC_TASK;
    }
    if(parameters.transition == RIGHT || parameters.transition == BOTH)
    {
      errorCountSearchTaskRight = new SEARCH_FUNC_TASK;
    }
  }
  ON_FIRST_INVOCATION_BEGIN();
    STRING_VECTOR::const_iterator it = parameters.PinVector.begin();
    STRING_VECTOR::const_iterator it_end = parameters.PinVector.end();
    for(; it != it_end; ++it)
    {
      INT siteNumber = CURRENT_SITE_NUMBER();
      STRING specName = *it + "_" + parameters.specName_postfix;
      FOR_EACH_SITE_BEGIN();
        //autoSync mode is ON or ON_KEEP_VALUE,so we use autoSyncVal as
        //transition search's start or stop vaule
        siteNumber = CURRENT_SITE_NUMBER();
        if (results.commonResultMap[siteNumber][*it].lastStatus == AUTOSYNC_PASS)
        {
          if (parameters.transition == LEFT || parameters.transition == BOTH)
          {
            (*errorCountSearchTaskLeft)
              .pin(*it)
              .spec(specName,TM::TIM)
              .method(TM::Binary)
              .resultPins(*it)
              .resolution(parameters.dataAcquStepWidth_ns)
              .start(results.commonResultMap[siteNumber][*it].autoSyncVal - 
                     parameters.UI_width_ns)
              .stop(results.commonResultMap[siteNumber][*it].autoSyncVal);
          }
          if (parameters.transition == RIGHT || parameters.transition == BOTH)
          {
            (*errorCountSearchTaskRight)
              .pin(*it)
              .spec(specName,TM::TIM)
              .method(TM::Binary)
              .resultPins(*it)
              .resolution(parameters.dataAcquStepWidth_ns)
              .start(results.commonResultMap[siteNumber][*it].autoSyncVal)
              .stop(results.commonResultMap[siteNumber][*it].autoSyncVal + 
                    parameters.UI_width_ns);
          }
        }
      FOR_EACH_SITE_END();
      //autoSync mode is OFF,so all sites' set up are the same
      if(results.commonResultMap[siteNumber][*it].lastStatus == NO_ACTION)
      {
        if (parameters.transition == LEFT || parameters.transition == BOTH)
        {
          (*errorCountSearchTaskLeft)
            .pin(*it)
            .spec(specName,TM::TIM)
            .method(TM::Binary)
            .resultPins(*it)
            .resolution(parameters.dataAcquStepWidth_ns)
            .start(parameters.start_ns - parameters.UI_width_ns)
            .stop(parameters.start_ns);
        }  
        if (parameters.transition == RIGHT || parameters.transition == BOTH)
        {
          (*errorCountSearchTaskRight)
            .pin(*it)
            .spec(specName,TM::TIM)
            .method(TM::Binary)
            .resultPins(*it)
            .resolution(parameters.dataAcquStepWidth_ns)
            .start(parameters.start_ns)
            .stop(parameters.start_ns + parameters.UI_width_ns);
        }
      }
    } //end for pin
    if(parameters.transition == LEFT || parameters.transition == BOTH)
    {
      errorCountSearchTaskLeft->execute();
    }
    if(parameters.transition == RIGHT || parameters.transition == BOTH)
    {
      errorCountSearchTaskRight->execute();
    }

    updateResultForTransitionSearch(*errorCountSearchTaskLeft,
                                    *errorCountSearchTaskRight,
                                     parameters,
                                     results,
                                     isEveryPinOfAllSitesFail);
  ON_FIRST_INVOCATION_END();
  if(errorCountSearchTaskLeft != NULL)
  {
    delete errorCountSearchTaskLeft;
  }
  if(errorCountSearchTaskRight != NULL)
  {
    delete errorCountSearchTaskRight;
  }
}

/*
 *-----------------------------------------------------------------------------
 *Routine: updateResultForTransitionSearch
 *
 *Purpose: updata result for transition search
 *
 *-----------------------------------------------------------------------------
 *Description:
 *
 *INPUT:
 *     taskLeft---------------------left transition search
 *     taskRight--------------------right transition search
 *     parameters-------------------test parameters
 *     results----------------------test result container
 *     isEveryPinOfAllSitesFail-----if this parameter's value is true,the 
 *                                  mearsurement will stop
 *Return:
 *-----------------------------------------------------------------------------
 */
inline void JitterUtil::updateResultForTransitionSearch(
  const SEARCH_FUNC_TASK & taskLeft,
  const SEARCH_FUNC_TASK & taskRight,
  const JitterParameter & parameters,
  JitterResult & results,
  bool &isEveryPinOfAllSitesFail)
{
  isEveryPinOfAllSitesFail = true;
  FOR_EACH_SITE_BEGIN();
  INT siteNumber = CURRENT_SITE_NUMBER();
  STRING_VECTOR::const_iterator it = parameters.PinVector.begin();
  STRING_VECTOR::const_iterator it_end = parameters.PinVector.end();
  for(;it != it_end; ++it)
  {
    if(parameters.transition == LEFT)//left side
    {
      if (taskLeft.getPassFail(*it))
      {
        results.commonResultMap[siteNumber][*it].lastStatus = LEFT_TRANSITION_PASS;
        results.commonResultMap[siteNumber][*it].leftTransitionVal = 
                                                    taskLeft.getPassValue(*it);
        isEveryPinOfAllSitesFail = false;
      }
      else
      {
        results.commonResultMap[siteNumber][*it].lastStatus = LEFT_TRANSITION_FAIL;
      }
    }
    else if(parameters.transition == RIGHT)//right side
    {
      if (taskRight.getPassFail(*it))
      {
        results.commonResultMap[siteNumber][*it].lastStatus = RIGHT_TRANSITION_PASS;
        results.commonResultMap[siteNumber][*it].rightTransitionVal =
                                                   taskRight.getPassValue(*it);
        isEveryPinOfAllSitesFail = false;
      }
      else
      {
        results.commonResultMap[siteNumber][*it].lastStatus = RIGHT_TRANSITION_FAIL;
      }
    }
    else//both side
    {
      if (taskLeft.getPassFail(*it) && taskRight.getPassFail(*it))//both side pass
      {
        results.commonResultMap[siteNumber][*it].lastStatus = BOTH_TRANSITION_PASS;
        results.commonResultMap[siteNumber][*it].leftTransitionVal = 
                                                    taskLeft.getPassValue(*it);
        results.commonResultMap[siteNumber][*it].rightTransitionVal = 
                                                   taskRight.getPassValue(*it);
        isEveryPinOfAllSitesFail = false;
      }
      else if(taskLeft.getPassFail(*it))//left pass,right fail
      {
        results.commonResultMap[siteNumber][*it].lastStatus = LEFT_TRANSITION_PASS;
        results.commonResultMap[siteNumber][*it].leftTransitionVal = 
                                                    taskLeft.getPassValue(*it);
        isEveryPinOfAllSitesFail = false;
      }
      else if(taskRight.getPassFail(*it))//right pass,left fail
      {
        results.commonResultMap[siteNumber][*it].lastStatus = RIGHT_TRANSITION_PASS;
        results.commonResultMap[siteNumber][*it].rightTransitionVal = 
                                                   taskRight.getPassValue(*it);
        isEveryPinOfAllSitesFail = false;
      }
      else//both side fail
      {
        results.commonResultMap[siteNumber][*it].lastStatus = BOTH_TRANSITION_FAIL;
      }
    }
  }
  FOR_EACH_SITE_END();
}

/**
 *-----------------------------------------------------------------------------
 *Routine: dataAcquire
 *
 *Purpose: acquire error count data
 *
 *-----------------------------------------------------------------------------
 *Description:
 * carry out error count data acquire
 *
 *INTPUT:
 *    parameters---------------test parameters
 *    results------------------test results
 *Return:
 *-----------------------------------------------------------------------------
 *NOTE:
 *-------|--------|---------|----------------|---------|-----------------|---------------
 * case  |autoSync|pass/fail|transitionSearch|pass/fail|acquisition start|acquisition stop
 *number |   mode |         |       mode     |         |                 |
 *-------|--------|---------|----------------|---------|-----------------|----------------*
 *   1   |   off  |         |     off        |         | start parameter | stop parameter *
 *-------|--------|---------|----------------|---------|-----------------|----------------*
 *   2   |   off  |         |     on         |  pass   |traisition of    |optimized data  *
 *       |        |         |                |         |binary search    |acquisition stop*
 *-------|--------|---------|----------------|---------|-----------------|----------------*
 *   3   |   off  |         |     on         |  fail   |measurement      |measurement     *
 *       |        |         |                |         |stop             |sotp            *
 *-------|--------|---------|----------------|---------|-----------------|----------------*
 *   4   |   on   |   pass  |     off        |         |autosync         |optimized data  *
 *       |        |         |                |         |position         |acquisition stop*
 *-------|--------|---------|----------------|---------|-----------------|----------------*
 *   5   |   on   |   fail  |     off        |         |measurement      |measurement     *
 *       |        |         |                |         |stop             |sotp            *
 *-------|--------|---------|----------------|---------|-----------------|----------------*
 *   6   |   on   |   pass  |     on         |  fail   |measurement      |measurement     *
 *       |        |         |                |         |stop             |sotp            *
 *-------|--------|---------|----------------|---------|-----------------|----------------*
 *   7   |   on   |   pass  |     on         |  pass   |traisition of    |optimized data  *
 *       |        |         |                |         |binary search    |acquisition stop*
 *-------|--------|---------|----------------|---------|-----------------|----------------*
 *   8   |   on   |   fail  |     on         |  n/a    |mearsurement     |mearsurement    *
 *       |        |         |                |         |stop             |stop            *
 *-------|--------|---------|----------------|---------|-----------------|----------------*
 */
inline void JitterUtil::dataAcquire(
  const JitterParameter & parameters,
  JitterResult& results)
{
  ERROR_COUNT_ACQUIRE errorCountAcquireTaskLeft,errorCountAcquireTaskRight;
  ON_FIRST_INVOCATION_BEGIN();
    STRING_VECTOR::const_iterator it = parameters.PinVector.begin();
    STRING_VECTOR::const_iterator it_end = parameters.PinVector.end();

    INT look_ahead_steps = 9;
    const DOUBLE CHANNEL_NL_UNCERTAINTY = 30;//unit is ps.
    DOUBLE look_ahead_time = max(0.05*parameters.UI_width_ns-look_ahead_steps 
                                 * parameters.dataAcquStepWidth_ns,
                                 CHANNEL_NL_UNCERTAINTY * 1e-3);//unit is ns

    for(; it != it_end; ++it)
    {
      STRING specName = *it + "_" + parameters.specName_postfix;
      if(parameters.transitionSearchMode == TRANSITIONSEARCH_OFF &&
         parameters.autoSyncMode == AUTOSYNC_OFF) 
      { //case 1
        if(parameters.transition == LEFT || parameters.transition == BOTH)
        {
          errorCountAcquireTaskLeft.pin(*it)
                                   .port(parameters.portName)
                                   .spec(specName,TM::TIM)
                                   .stepWidth(parameters.dataAcquStepWidth_ns)
                                   .start(parameters.start_ns)
                                   .stop(parameters.stop_ns)
                                   .errorCountMode(TM::ERROR_PER_EDGE);
        }
        if(parameters.transition == RIGHT || parameters.transition == BOTH)
        {
          errorCountAcquireTaskRight.pin(*it)
                                    .port(parameters.portName)
                                    .spec(specName,TM::TIM)
                                    .stepWidth(parameters.dataAcquStepWidth_ns)
                                    .start(parameters.start_ns)
                                    .stop(parameters.stop_ns)
                                    .errorCountMode(TM::ERROR_PER_EDGE);
        }
        if(parameters.transition == BOTH)
        {
          STRING api = "In function JitterUtil::dataAcquire: ";
          STRING msg = "Because we don't do autoSync and transitionSearch, \
                       so BOTH option is meanless,please select RITHG or LEFT.";
          throw Error(api.c_str(),msg.c_str(),api.c_str());
        }
      }
      else if(parameters.transitionSearchMode == TRANSITIONSEARCH_ON)
      { //case 2,3,6,7,8
        FOR_EACH_SITE_BEGIN();
          INT siteNumber = CURRENT_SITE_NUMBER();
          if((parameters.transition == LEFT || parameters.transition == BOTH) &&
             (results.commonResultMap[siteNumber][*it].lastStatus == LEFT_TRANSITION_PASS ||
              results.commonResultMap[siteNumber][*it].lastStatus == BOTH_TRANSITION_PASS))
          {
            errorCountAcquireTaskLeft
             .pin(*it)
             .port(parameters.portName)
             .spec(specName,TM::TIM)
             .stepWidth(parameters.dataAcquStepWidth_ns)
             .start(results.commonResultMap[siteNumber][*it].leftTransitionVal)
             .stop(results.commonResultMap[siteNumber][*it].leftTransitionVal - 
                   parameters.UI_width_ns)
             .errorCountMode(TM::ERROR_PER_EDGE)
             .enableFastStop(look_ahead_time,look_ahead_steps);
          }
          if((parameters.transition == RIGHT || parameters.transition == BOTH) &&
             (results.commonResultMap[siteNumber][*it].lastStatus == RIGHT_TRANSITION_PASS ||
              results.commonResultMap[siteNumber][*it].lastStatus == BOTH_TRANSITION_PASS))
          {
            errorCountAcquireTaskRight
             .pin(*it)
             .port(parameters.portName)
             .spec(specName,TM::TIM)
             .stepWidth(parameters.dataAcquStepWidth_ns)
             .start(results.commonResultMap[siteNumber][*it].rightTransitionVal)
             .stop(results.commonResultMap[siteNumber][*it].rightTransitionVal + 
                   parameters.UI_width_ns)
             .errorCountMode(TM::ERROR_PER_EDGE)
             .enableFastStop(look_ahead_time,look_ahead_steps);
          }
        FOR_EACH_SITE_END();
      }
      else 
      { //case 4,5
        FOR_EACH_SITE_BEGIN();
          INT siteNumber = CURRENT_SITE_NUMBER();
          if((parameters.transition == LEFT || parameters.transition == BOTH) &&
             (results.commonResultMap[siteNumber][*it].lastStatus == AUTOSYNC_PASS))
          {
            errorCountAcquireTaskLeft
             .pin(*it)
             .port(parameters.portName)
             .spec(specName,TM::TIM)
             .stepWidth(parameters.dataAcquStepWidth_ns)
             .start(results.commonResultMap[siteNumber][*it].autoSyncVal)
             .stop(results.commonResultMap[siteNumber][*it].autoSyncVal - 
                   parameters.UI_width_ns)
             .errorCountMode(TM::ERROR_PER_EDGE)
             .enableFastStop(look_ahead_time,look_ahead_steps);
          }
          if((parameters.transition == RIGHT || parameters.transition == BOTH) &&
             (results.commonResultMap[siteNumber][*it].lastStatus == AUTOSYNC_PASS))
          {
            errorCountAcquireTaskRight
             .pin(*it)
             .port(parameters.portName)
             .spec(specName,TM::TIM)
             .stepWidth(parameters.dataAcquStepWidth_ns)
             .start(results.commonResultMap[siteNumber][*it].autoSyncVal)
             .stop(results.commonResultMap[siteNumber][*it].autoSyncVal +
                   parameters.UI_width_ns)
             .errorCountMode(TM::ERROR_PER_EDGE)
             .enableFastStop(look_ahead_time,look_ahead_steps);
          }
        FOR_EACH_SITE_END();
      }
    }
    if (parameters.transition == LEFT || parameters.transition == BOTH)
    {
      errorCountAcquireTaskLeft.execute(TM::FAST_STOP);
    }
    if (parameters.transition == RIGHT || parameters.transition == BOTH)
    {
      errorCountAcquireTaskRight.execute(TM::FAST_STOP);
    }

    FOR_EACH_SITE_BEGIN();
      updateResultForDataAcquire(errorCountAcquireTaskLeft,
                                 errorCountAcquireTaskRight,
                                 parameters,
                                 results);
    FOR_EACH_SITE_END();

  ON_FIRST_INVOCATION_END();
}

/**
 *-----------------------------------------------------------------------------
 *Routine: updateResultForDataAcquire
 *
 *Purpose: updata result for data acquire
 *
 *-----------------------------------------------------------------------------
 *Description:
 *  get error count data after data acquire
 *INPUT:
 *     taskLeft---------------------left error count acquire
 *     taskRight--------------------right error count acquire
 *     parameters-------------------test parameters
 *     results----------------------test result container
 *
 *Return:
 *-----------------------------------------------------------------------------
 */
inline void JitterUtil::updateResultForDataAcquire(
  const ERROR_COUNT_ACQUIRE & taskLeft,
  const ERROR_COUNT_ACQUIRE & taskRight,
  const JitterParameter& parameters,
  JitterResult & results)
{
  INT siteNumber = CURRENT_SITE_NUMBER();
  STRING_VECTOR::const_iterator it = parameters.PinVector.begin();
  STRING_VECTOR::const_iterator it_end = parameters.PinVector.end();
  for(;it != it_end; ++it)
  {
    if(parameters.transition == LEFT || parameters.transition == BOTH)
    {
      results.commonResultMap[siteNumber][*it].lastStatus = LEFT_JITTER;
      vector<INT>& referenceErrorCountVec =
                             results.commonResultMap[siteNumber][*it].leftErrorCount;
      ARRAY_I tempArray(taskLeft.getErrorCount(*it));
      INT sizeOfArray = tempArray.size();
      for(INT loop = 0;loop <sizeOfArray;++loop)
      {
        referenceErrorCountVec.push_back(tempArray[loop]);
      }
    }
    if(parameters.transition == RIGHT || parameters.transition == BOTH)
    {
      results.commonResultMap[siteNumber][*it].lastStatus = RIGHT_JITTER;
      vector<INT>& referenceErrorCountVec =
		                    results.commonResultMap[siteNumber][*it].rightErrorCount;
      ARRAY_I tempArray(taskRight.getErrorCount(*it));
      INT sizeOfArray = tempArray.size();
      for(INT loop = 0;loop <sizeOfArray;++loop)
      {
        referenceErrorCountVec.push_back(tempArray[loop]);
      }
    }
    if(parameters.transition == BOTH)
    {
      results.commonResultMap[siteNumber][*it].lastStatus = BOTH_JITTER;
    }
  }
}


inline void JitterUtil::printWaringMessage(const INT siteNumber,
                                    const STRING& pinName)
{
  cout << "Warning::For site:     " << siteNumber << endl; 
  cout << "          For Pin:     " << pinName << endl;
}

#endif //INCLUDE_JITTER_H_
