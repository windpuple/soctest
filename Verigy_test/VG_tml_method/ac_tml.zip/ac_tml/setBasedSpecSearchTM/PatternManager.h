#ifndef PATTERNMANAGER_H_
#define PATTERNMANAGER_H_

#include <string>
#include <vector>

namespace spec_search_pro{
class PatternManager
{
public:
  PatternManager();
  virtual ~PatternManager();
    
  static int copyLabel(std::string sourceLabel, std::string destinationLabel);
  static int renameLabel(std::string sourceLabel, std::string destinationLabel);
  static int saveLabel(std::string labelName);
  static int mergeLabelFromFile(std::string fileName);
  static int createBurst(std::string burstName, std::vector<std::string> labelsToCall, std::string portName="");
  static int deleteLabel(std::string label, std::string portName="");
  static bool isPatternAvailable(std::string labelFile, std::string labelType="ALL", std::string port="@@");
  static int updatePatternManager();
  static bool isMultiport(std::string labelName); 
  static unsigned long long getCyclesFromLabel(std::string label, std::string portName="@");
    
  static bool isMainPattern(std::string labelName);
    
  /**
   * @input param: burstName - burst to be created.
   * @input param: labelsToCall - labels called in burst
   * @input param: syncGroup - sync group used for multi-port pattern only, default is empty.
   * @input param: port - port name. default is "@" meaning default port, 
   *   otherwise, specific port is input for multiport burst creation.
   * @input param: toRemoveIfExisted - remove existed burst if it is true, or just update it.
   *   default is true, to remove this existing burst.
   * @return: integer number: postive number for success, negative number for failure.
   */  
  static int createBurst(const std::string& burstName, 
    const std::vector<std::string>& labelsToCall, 
    const std::string& syncGroup, 
    const std::string& port = "@", 
    const bool toRemoveIfExisted = true);
     
  /*
   * @input param: mpBurst - multi-port burst name
   * @input param: port    - port name
   * @output param: labelsInBurst - labels in the burst on the port
   * @output param: syncGroup - sync group
   * @return: 
   */
  static int getMultiPortBurstInfo_ByPort(const std::string& mpBurst, 
    const std::string& port, 
    std::vector<std::string>& labelsInBurst, 
    std::string& syncGroup);

  /*get ports of multi-port pattern
   *@input param: multiport pattern
   *@output param: ports
   *@return: integer number: postive number for success, negative number for failure. 
   */
  static int getPortsOfMPPattern(const std::string& mpBurst, std::vector<std::string>& ports);
    
  /*get port name of port based pattern
   *@input param: port based pattern
   *@output param: port
   *@return: integer number: postive number for success, negative number for failure. 
   */
  static int getPortOfPattern(const std::string& pattern, std::string& port);
    
  /*change the number of CLEV/CTIM command in the pattern
   *@input param: label name 
   *@input param: new set number
   *@input param: change commad: CTIM or CLEV
   *@input param: port
   *@return: true for success, false for failure
   */
  static bool changeSetNumberForLabel(const std::string& label,const int setNum, 
    const std::string& changeCmd, const std::string& port = "@@");
};
};
#endif /*PATTERNMANAGER_H_*/
