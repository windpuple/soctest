#include "EquationManager.hpp"
#include "DebugUtil.hpp"
#include <iostream>
#include <sstream>
#define _PTHREADS
#include <boost/regex.hpp>
#include "mapi.hpp"
#include "FW.h"

using namespace std;
using namespace boost;

namespace spec_search_pro {

int EquationManager::msMaxLevSet = -1;
int EquationManager::msMaxTimSet = -1;

EquationManager::EquationManager()
:mTargetEquationNumber(1),mTargetSetNumber(1),mMaxSetNumberOfEquation(1),mNewAddedSetNumber(0),
mIsParseDone(false)
{

}

EquationManager::~EquationManager()
{
}

void
EquationManager::querySystemConfiguredSet()
{
  string answer;
  FW_TASK("DSCP?",answer);
  regex expr("DSCP[ \\t]*[0-9]+,[0-9]+,([0-9]+),([0-9]+).*");
  smatch what;
  if (regex_match(answer,what,expr))
  {
    istringstream inTimStream(string(what[1].first,what[1].second));
    inTimStream >> msMaxTimSet;
    istringstream inLevStream(string(what[2].first,what[2].second));
    inLevStream >> msMaxLevSet;
  }
}

void 
EquationManager::configEquationManager(const string& setupPin, const string& specName, 
  const string& specType)
{ 
  mSetupPin = setupPin;
  mSpecName = specName;
  mIsParseDone = false;
  
  if (specType != "LEV" && specType != "TIM")
  {
    throw Error("EquationManager::ConfigEquationManager()",
      "valid spec type must be \"TIM\" or \"LEV\"",
      "EquationManager::ConfigEquationManager()");    
  }
  mSpecType = specType;
  
  cleanUp();
}

bool 
EquationManager::doUploadAndParse(const int equationNum, const int setNum)
{
  static string funcName = "EquationManager::doUploadAndParse()";
  cleanUp();
  
  mTargetEquationNumber = equationNum;
  mTargetSetNumber = setNum;

  //query equation settings 
  string queryCmd = "EQSP? "+mSpecType+",EQN\n";
  string eqAnswer;
  FW_TASK(queryCmd,eqAnswer);
  if (eqAnswer.empty())
  {
    throw Error(funcName,"no equation setup is ready for parsing.",funcName);
  }
  
  istringstream inStream(eqAnswer);

  //find starter
  //regex eqStarter("EQSP[ \\t]+(LEV|TIM),EQN,#([0-9]+)");
  bool isHeadFound = false;
  string line;
  regex regHeadExpr("[ \\t]*EQSP[ \\t]+("+mSpecType+"),EQN,#([0-9]+)(.*)");
  smatch what;
  while( !getline(inStream,line).eof())
  {
    if (regex_match(line,what,regHeadExpr))
    {
      string remaingStuff(what[3].first,what[3].second);
      mPreModifyContent = remaingStuff + "\n";
      isHeadFound = true;
      break;
    }
  }
  
  if (isHeadFound)
  {
    ostringstream targetEquationId;
    targetEquationId << "[ \\t]*EQNSET[ \\t]+" << mTargetEquationNumber << "[ \\t]+.*";
    if (regex_match(mPreModifyContent,regex(targetEquationId.str())) || 
        findAndKeepStuff(inStream,targetEquationId.str(),mPreModifyContent))
    {
      mIsParseDone = parseTargetSet(inStream);
    }
    else
    {
      throw Error(funcName,"cannot find the target equation setups",funcName);
    }
  }
  else
  {
    throw Error(funcName,"cannot find the EQSP head line.",funcName);
  }  
  
  return mIsParseDone;
}

bool 
EquationManager::findAndKeepStuff(istringstream& inputStream,const string& regExprStr, 
  string& stringContainer)
{
  bool isFound = false;
  regex regExpr(regExprStr);
  
  string line;
  while( !getline(inputStream,line).eof())
  {
    stringContainer += line + "\n";
    if (regex_match(line,regExpr))
    {
      isFound = true;
      break;
    }
  }
  return isFound;
}

bool
EquationManager::parseTargetSet(istringstream& inputStream)
{
  bool isFound = false;
    
  ostringstream toMatchTargetSetStream;
  toMatchTargetSetStream << "[ \\t]*(LEVELSET|TIMINGSET)[ \\t]+" 
    << mTargetSetNumber << "[ \\t]+.*";
  
  if (findAndKeepStuff(inputStream,toMatchTargetSetStream.str(),mPreModifyContent))
  {
    mSetDefTemplate = "";
    string line;
    mMaxSetNumberOfEquation = mTargetSetNumber;
    bool isTagetSetContent = true;
    while(!getline(inputStream,line).eof())
    {
      regex toMatchNextSetExpr("[ \\t]*(LEVELSET|TIMINGSET)[ \\t]+([0-9]+)[ \\t]+.*");
      regex toMatchNextEquationExpr("[ \\t]*EQNSET[ \\t]+([0-9]+)[ \\t]+.*");
      regex toMatchEndingExpr("[ \\t]*(\\@).*");
      regex toMatchCommentLine("[ \\t]*#.*");
      if (regex_match(line,toMatchNextSetExpr))
      {
        //still in current equation section
        ++mMaxSetNumberOfEquation;
        mPreModifyContent += line + "\n";
        isTagetSetContent = false;
      }
      else if (regex_match(line,toMatchEndingExpr) || regex_match(line,toMatchNextEquationExpr))
      { 
        //reach at the end of this euqation set or end of equation file
        mPostModifyContent += line + "\n";
        //to continue to remember the remaining stuff untill the end of content;
        while(!getline(inputStream,line).eof())
        {
          mPostModifyContent += line+"\n";
        }
        break;
      }
      else 
      {
        //still in current set section
        if (isTagetSetContent && !regex_match(line,toMatchCommentLine))
        {
          mSetDefTemplate += line+"\n";
        }
        mPreModifyContent += line + "\n";
      }
    }
    isFound =  true;
  }
  else
  {
    isFound = false;  
  }
  
  TrainOut("target equation["
    << mTargetEquationNumber << "] set["
    << mTargetSetNumber << "] content:\n" 
    << mSetDefTemplate);
  
  //validate whether the spec varible exists or not
  regex tagetSpecVarExpr("[^#].*\\b("+mSpecName+")\\b.*");
  if (!regex_match(mSetDefTemplate,tagetSpecVarExpr))
  {
      ostringstream errorMsg;
      errorMsg << "spec variable \"" << mSpecName << "\" is not defined in equation[" 
        << mTargetEquationNumber << "],set[" << mTargetSetNumber << "].";
      string funcName = "EquationManager::parseTargetSet()";
      throw Error(funcName, errorMsg.str(), funcName);
  }
  else if (!mSetupPin.empty() && mSetupPin != "@")
  {
    //process setup pinlist within the template set content
    defineNewExpressionForPins(); 
  }

  return isFound;
}

void
EquationManager::defineNewExpressionForPins()
{
  regex tagetSpecEquationExpr("[^#].*\\b("+mSpecName+")\\b.*");
  istringstream setDefinitionSectionStream(mSetDefTemplate);
  
  /*key: single pin name
   *value: spec based euqation definition
   *e.g.
   *["Xin1"] => "vih=VIH \n vil=VIL+0.2\n";
   *["Xin2"] => "vih=VIH+0.1 \n vil=VIL\n" 
   */
  map<string,string> pinSpecEquationMap;
  
  bool isPinDefFound = false;
  static regex pinStartLineExpr("[ \\t]*(PINS)[ \\t]+.*");
  static regex blankLineExpr("(^[ \t]*$)|([ \t]*#.*)");

  string specEquation;
  //this vector contains single pin or pin group names
  vector<string> pinVector;
  string line;
  while(!getline(setDefinitionSectionStream,line).eof())
  {
    if (regex_match(line,blankLineExpr))
    {
      continue;
    }
    else if (regex_match(line,pinStartLineExpr)) //match "PINS ...."
    {
      //push previous definitions if spec defined for pins
      if (isPinDefFound && regex_match(specEquation,tagetSpecEquationExpr))
      {
        for(vector<string>::size_type i = 0; i < pinVector.size(); ++i)
        {
          pinSpecEquationMap[pinVector[i]] = specEquation;
        }
      }
      isPinDefFound = false;
      pinVector.clear();
      specEquation = "";
      
      string::size_type posPinB = line.find("PINS ");
      string pinList;
      
      //to retrieve pin name
      for(posPinB += 4; posPinB != string::npos; )
      {
        posPinB = line.find_first_not_of(" \t#",posPinB);
        if (posPinB == string::npos)
        {
          break;
        }
        string::size_type posPinE = line.find_first_of(" \t#",posPinB);
        string pinOrGroup;
        if (posPinE == string::npos)
        { 
          pinOrGroup = line.substr(posPinB,line.size()-posPinB);
        }
        else  
        {
          pinOrGroup = line.substr(posPinB,posPinE-posPinB);

        }
        
        pinVector.push_back(pinOrGroup);
        
        pinList += pinOrGroup + ",";
        
        if (line[posPinE] == '#')
        {
          break; //reach at comment part
        }
        //update search starting point
        posPinB = posPinE;
      }//end-for 
      if (!pinList.empty())
      {
        isPinDefFound = true;
        pinList.erase(pinList.size()-1,1);
        pinVector = pinVector + PinUtility.expandDigitalPinNamesFromPinList(
          pinList,TM::ALL_DIGITAL,TM::IGNORE_MISSING_PIN_NAMES);
      }
    }
    else if (isPinDefFound) //spec variable equation definition
    {
      specEquation += line + "\n";
    }
    else
    {
      continue;
    }
  }//while
  
  //push last definitions
  if (isPinDefFound && regex_match(specEquation,tagetSpecEquationExpr))
  {
    for(vector<string>::size_type i = 0; i < pinVector.size(); ++i)
    {
      pinSpecEquationMap[pinVector[i]] = specEquation;
    }
  }
  
  //to define new set for pin
  mPinSetDefTemplate = "";
  vector<string> expandSetupPinVector = 
    PinUtility.expandDigitalPinNamesFromPinList(mSetupPin,TM::ALL_DIGITAL,TM::IGNORE_MISSING_PIN_NAMES);

  for (vector<string>::size_type i = 0; i < expandSetupPinVector.size(); ++i)
  {
    map<string,string>::const_iterator itPinDef = pinSpecEquationMap.find(expandSetupPinVector[i]);
    if (itPinDef != pinSpecEquationMap.end())
    {
      mPinSetDefTemplate += "PINS "+itPinDef->first+"\n"+itPinDef->second;
    }
    else
    {
      throw Error("EquationManager::defineNewExpressionForPins()",
        "no such spec equation definition for pin: "+expandSetupPinVector[i],
        "EquationManager::defineNewExpressionForPins()");
    }
  }
  
  if (pinSpecEquationMap.empty())
  {
    //means no proper pin-spec is defined
      throw Error("EquationManager::defineNewExpressionForPins()",
        "no such spec equation definition for pin: "+mSetupPin,
        "EquationManager::defineNewExpressionForPins()");
  }
  else
  {
    //print out training information
    TrainOut("spec var(" << mSpecName << ")'s equation definition on PINS("
      << mSetupPin << "):\n"
      << mPinSetDefTemplate);
  }
}

bool
EquationManager::defineSet(const int newSetNum, const double specValue)
{
  bool isDone = false;
  if (!mIsParseDone)
  {
    ErrorOut("target equation and set was not parsed yet.");
    return false; 
  }

  //remember the newly added number of sets
  ++mNewAddedSetNumber;
  
  ostringstream newSetNumStream;
  newSetNumStream << newSetNum;
  
  string setHeadStr;
  //define new set with number
  setHeadStr = mSpecType=="TIM"?"TIMINGSET":"LEVELSET";
  setHeadStr += " "+newSetNumStream.str() + " ";
  //define comments
  newSetNumStream.str("");
  newSetNumStream << "\"set for spec search\" #create set for spec search, "
    << mSpecName << "=" << specValue << "\n";
  setHeadStr += " "+newSetNumStream.str();

  regex tagetSpecVarExpr("\\b"+mSpecName+"\\b");
  ostringstream specValueStream;
  specValueStream << specValue;
  
  //define new set content with precalculated spec value
  string setContentStr;
  if (mSetupPin == "@" || mSetupPin.empty())
  {
    setContentStr = regex_replace(mSetDefTemplate,tagetSpecVarExpr,specValueStream.str());
  }
  else
  {
    setContentStr = regex_replace(mPinSetDefTemplate,tagetSpecVarExpr,specValueStream.str());
    setContentStr = mSetDefTemplate + setContentStr;
  }
  
  mNewSetContent += setHeadStr + setContentStr;
  
  return isDone;
}

bool
EquationManager::downloadEquation()
{
  if (!mIsParseDone)
  {
    ErrorOut("target equation and set was not parsed yet.");
    return false; 
  }

  //compose new equation setups in string
  ostringstream targetSetNumStream;
  targetSetNumStream << mTargetSetNumber;
  
  string eqContent = "\n"+ mPreModifyContent;
  eqContent += "#--------------------------------------------------------------------\n";
  eqContent += "# <START>: new sets for spec search based on set["+targetSetNumStream.str()+"]\n";
  eqContent += "#--------------------------------------------------------------------\n";
  eqContent += mNewSetContent;
  eqContent += "#--------------------------------------------------------------------\n";
  eqContent += "# <END>: new sets for spec search based on set["+targetSetNumStream.str()+"]\n";
  eqContent += "#--------------------------------------------------------------------\n\n";
  eqContent += mPostModifyContent;
  string::size_type len = eqContent.size()-1; //to exclude '@' for size
  
  ostringstream eqCommand; 
  eqCommand<<"EQSP "<<mSpecType<<",EQN,#9";
  eqCommand.width(9);
  eqCommand.fill('0');
  eqCommand<<len;
  eqCommand<<eqContent;
  
  //flush the new equation definitions...
  FW_TASK(eqCommand.str());
  
  //print out training information
  TrainOut("  Total " << mNewAddedSetNumber << " sets are appended to "
           << "Equation[" << mTargetEquationNumber 
           << "] based on the content of set[" << mTargetSetNumber << "].");

  cleanUp();
  return true;
}

int
EquationManager::getPrimaryLevelSetNum()
{
  int levelSetNo = -1;
  
  fwout << "SPRM?" << endl; 
  //answer would be like: 
  // SPRM timing_specset_id,timing set id,level set id, dps set id
  // SPRM "multi-port spec",timing set id,level set id, dps set id

  if (fwresult.size() == 1)
  {
    int level_id = 0;
    istringstream levelStr(fwresult[0][2]);
    levelStr >> level_id;
    const int equa_base = 100000;
    const int spec_base = 1000;
    //level_id = 100000*equation_set_no + 1000*spec_set_no + level_set_no
    if (level_id > 100000)
    {
      int equation = level_id/equa_base;
      int spec_set = (level_id - equation*equa_base)/spec_base;
      levelSetNo = level_id - equation*equa_base - spec_set*spec_base; 
    }
    else
    {
      ErrorOut("query primary level set failed: equation based level id number is not correct.");
    }
  }
  else
  {
    ErrorOut("query primary level setup failed: invalid result.");
  }
  return levelSetNo;
}


int
EquationManager::getPrimaryTimingSetNum(const string& port)
{
  int timingSetNo = -1;
  if (port.empty())
  {
    fwout << "SPRM?" << endl; 
    //answer would be: SPRM timing_specset_id,timing set id,level set id, dps set id
  }
  else
  {
    fwout << "SPRM? (" << port << ")" <<endl;
    //answer would be: SPRM "multi-port spec",timing set id,level set id, dps set id, (port)
  }
  if (fwresult.size() == 1)
  {
    istringstream timingStr(fwresult[0][1]);
    timingStr >> timingSetNo;
  }
  else
  {
    ErrorOut("query primary timing setup failed: invalid result.");
  }
  return timingSetNo;
}

int
EquationManager::getUsedTimingSetNum()
{
  int usedTimingSets = 0;

  /*query currently the total number of used timing sets
   *
   * total = number of timing set in default port of equation based
   *         + number of timing set for ports 
   *         + number of fixed timing set  
   */

  //pair value: <equation set number, number of spec set with this equation set>
  vector<pair<int,int> > defaultPortSetNum;
  vector<string> multiportSpec;
  
  fwout << "SDSC? TIM,SPS,,," << endl;
  //answer is formatted as: 
  //normal equation set: SDSC TIM,SPS,1,2,,"xxx"
  //multi-port:          SDSC TIM,SPS,,,"multiport","xxx"
  for (unsigned int iResult = 0; iResult < fwresult.size(); ++iResult)
  {
    if (!fwresult[iResult][2].empty() && !fwresult[iResult][3].empty()) //normal equation/spec set
    {
      defaultPortSetNum.push_back(
        make_pair(fwresult[iResult].getIntParam(2),fwresult[iResult].getIntParam(3)));
    }
    else //multi-port
    {
      multiportSpec.push_back(fwresult[iResult][3]);
    }
  }
  
  //default port (equation based)
  int defaultPortSets = 0;
  for (vector<pair<int,int> >::const_iterator it = defaultPortSetNum.begin();
       it != defaultPortSetNum.end(); ++it)
  {
    //query timing set in equation set
	  fwout << "TSUS? " << 100 * it->first + it->second << endl;
	  //answer is formatted as: TSUS 101,2
	  defaultPortSets += fwresult[0].getIntParam(1);
  }
  
  //multi-port
  int multiPortSets = 0;
  for (vector<string>::size_type iPort = 0; iPort < multiportSpec.size(); ++iPort)
  {
    fwout << "TSUS? \"" << multiportSpec[iPort] << "\",(@@)" << endl;
    //answer is formatted as: TSUS "port1",2,(a)\nTSUS "port2",1,(b)\n
    for (unsigned int iSet = 0; iSet < fwresult.size(); ++iSet)
    {
      multiPortSets += fwresult[iSet].getIntParam(1);
    }
  }
   
  //query the fixed timing set
  int fixedTimingSets = 0;
  fwout << "WSUS? " << endl;
  //answer is formatted as: WSUS 3
  if (!fwresult.empty())
  {
    int waveforms = fwresult[0].getIntParam(0);
    //get set per waveform
    for (int wave = 1; wave <= waveforms; ++wave)
    {
      fwout << "TSUS? " << wave << endl;
      //add up the timing set
      fixedTimingSets += fwresult[0].getIntParam(1);
    }
  }
  
  //sum up
  usedTimingSets = defaultPortSets + multiPortSets + fixedTimingSets;

  return usedTimingSets;
}

int
EquationManager::getSpecSetNumOfEquation(const int equation)
{
  fwout << "SDSC? LEV,SPS,"<< equation << ",," << endl;
  return int(fwresult.size());
}

int
EquationManager::getUsedLevelSetNum()
{
  int usedLevelSet = 0;

  /*query currently the total number of used level sets
   *
   * total = number of level set in equation * number of spec set for equation 
   *         + number of fixed level set  
   */
  
  //pair value: <equation set number, number of spec set with this equation set>
  map<int,int> equationSpecsetMap;
  fwout << "SDSC? LEV,SPS,,," << endl;
  //answer is formatted as: SDSC LEV,SPS,1,2,"xxx"
  for (unsigned int iSet = 0; iSet < fwresult.size(); ++iSet)
  {
    equationSpecsetMap[fwresult[iSet].getIntParam(2)] = fwresult[iSet].getIntParam(3);
  }
  
  // LSUS? for level set of equation set
  string lsusAnswer;
  int equationLevelSets = 0;
  //loop for all possible equation set
  for(int i  = 1; i <= 99; ++i)
  {
    fwout<<"LSUS? "<<i<<endl;
    int levelSet = fwresult[0].getIntParam(0);
    if (levelSet > 0)
    {
      map<int,int>::const_iterator setIterator = equationSpecsetMap.find(levelSet);
      if (setIterator != equationSpecsetMap.end())
      {
    	//total level set of this equation = num of level set in equation * num of spec set for equation 
        equationLevelSets += levelSet * (setIterator->second);
      }
      else
      {
        equationLevelSets += levelSet;
      }
    }
  }
  //query fixed level set
  int fixedLevelSets = 0;
  fwout<<"LSUS?"<<endl;
  fixedLevelSets = fwresult[0].getIntParam(0);
  
  //sum up
  usedLevelSet = equationLevelSets + fixedLevelSets;

  return usedLevelSet;
}
};
