#ifndef EQUATIONPARSER_HPP_
#define EQUATIONPARSER_HPP_
#include <string>
#include <map>
#include <vector>
#include <sstream>

namespace spec_search_pro{
/*
 * Managing some equation handlings for specific spec variable and pins:
 *   some main jobs:
 * - query and parse equation settings by target euqation and set number
 * - define new sets based on the target equation and set number
 *
 */

class EquationManager
{
public:
  EquationManager();
  virtual ~EquationManager();
  
  /*set specific spec and pin for equation manager
   * @param setupPin - the pin names whoes spec variable is handled.
   * @param specName - the name of spec variable (not including "port" name)
   * @param specType - the type of spec variable (TIM or LEV)
   */
  void configEquationManager(
    const std::string& setupPin, 
    const std::string& specName, 
    const std::string& specType);
  
  /*update the equation setups and parse out the definition of target equation and set number
   *@param targetEquationNum - the equation number to be parsed
   *@param targetSetNum - the set number to be parsed 
   * 
   *@return true - for success, false - for failure
   */
  bool doUploadAndParse(const int targetEquationNum, const int targetSetNum);

  /*download the modified equation setups and clean up upon download.
   *@return true - for success, false - for failure
   */
  bool downloadEquation();

  /**
   * @purpose: define one set with specific spec value.
   * @return: true: success, false: fail.
   * */
  bool defineSet(const int newSetNum, const double specValue);
  
  /*clean up data based target equation and set number
   */
  void cleanUp()
  {
    mSetDefTemplate = mPreModifyContent = mPostModifyContent = mNewSetContent = ""; 
    mNewAddedSetNumber = mMaxSetNumberOfEquation = 0;
    mIsParseDone = false;
  }
  
  /*get the level set number of primary equation
   * @return level set number
   */
  static int getPrimaryLevelSetNum();

  /*get the timing set number of primary equation
   * @param port - specific port name in case of multi-port,otherwise empty string is used.
   * @return timing set number
   */
  static int getPrimaryTimingSetNum(const std::string& port = "");
  
  int getTargetEquationSetNum()const
  {
    return mTargetEquationNumber;
  }
  
  int getTargetSetNum()const
  {
    return mTargetSetNumber;
  }
  
  /*return the maximum number of level set which configured by users
   */
  static int getConfiguredLevelSetNum() 
  {  
    if (msMaxLevSet == -1)
    {
      querySystemConfiguredSet();
    }
    return msMaxLevSet;    
  }
  
 /*return the maximum number of timing set which configured by users
  */
  static int getConfiguredTimingSetNum() 
  {
    if (msMaxTimSet == -1)
    {
      querySystemConfiguredSet();
    }
    return msMaxTimSet;
  }
  
  /**
   * get maximum set number of the current equation number
   * @param: equationNum - the equation number
   *
   */
  int getMaxSetNumOfCurrentEquationSet() const
  {
    return mMaxSetNumberOfEquation;
  }
  
  /**
   * get total number of currently defined timing sets
   */
  int getUsedTimingSetNum();

  /**
   * get total number of currently defined level sets
   */
  int getUsedLevelSetNum();
  
  /**
   * get total number of spec set for one equation set
   */
  static int getSpecSetNumOfEquation(const int equation);

private:
  static void querySystemConfiguredSet();
  
  void defineNewExpressionForPins();
  
  bool parseTargetSet(std::istringstream& inputStream);

  /*find out the target string in regular expression and keep the searched content until/including
   *the target string.
   *if not found, all content is kept.
   * 
   *@input param inputStream - the stream to be scanned.
   *@input param regExprStr - the target string used by regular expression
   *@output param stringContainer - the string to keep the content
   * 
   *@return true - found, false - not found
   */
  bool findAndKeepStuff(
    std::istringstream& inputStream,
    const std::string& regExprStr,
    std::string& stringContainer);

  
private:
  static int msMaxLevSet;
  static int msMaxTimSet;
  int mTargetEquationNumber;
  int mTargetSetNumber;
  int mMaxSetNumberOfEquation;
  int mNewAddedSetNumber;
  bool mIsParseDone;
  
  std::string mSetupPin;
  std::string mSpecName;
  std::string mSpecType;
  std::string mSetDefTemplate;    //all pins' equation definition template
  std::string mPinSetDefTemplate; //pin specific equation definition template
  std::string mPreModifyContent;  //the content before target set number, will not be modified
  std::string mPostModifyContent; //the content after target set number, will not be modified
  std::string mNewSetContent; //newly created/modified sets
};
};

#endif /*EQUATIONPARSER_HPP_*/
