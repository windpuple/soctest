//for test method framework interfaces
#include "testmethod.hpp"

//for test method API interfaces
#include "mapi.hpp"

#include "SetBasedSpecSearchTMUtil.hpp"
#include "../CommonUtil.hpp"

using namespace std;

/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class SetBasedSpecSearch: public testmethod::TestMethod {
protected:
  string mWorkMode;
  string mSetupPin;
  testmethod::SpecVariable  mSpecVar;
  testmethod::SpecValue  mStart;
  testmethod::SpecValue  mStop;
  testmethod::SpecValue  mStepwidth;
  string mAlgorithm;
  string mSearchPatternName;
  string mChangeSetPatternName;
  string mNewBurstPatternName;
  string mReportToUI;
  bool mIsMultiPort;
  SetBasedSpecSearchTMUtil* mpSearchUtility;
  SetBasedSpecSearchTMUtil::SearchParam mSearchParamContainer;
  SetBasedSpecSearchTMUtil::SearchLimit mSearchLimit; 
  bool mIsSearchConditionChanged;
  string mTestName;
protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   *
   *Note: Test Method API should not be used in this method.
   */
  virtual void initialize()
  {
    mIsSearchConditionChanged = true;
    mpSearchUtility = new SetBasedSpecSearchTMUtil(); 

    addParameter("specVar",
                 "SpecVariable",
                 &mSpecVar,
                 testmethod::TM_PARAMETER_INPUT)
      .setComment("spec variable\n"
        "in case of multiport pattern, port name is must. e.g. LEV.1.myvar@portA");
    
    //alogrithm related parameters
    addParameter("algorithm",
                 "string",
                 &mAlgorithm,
                 testmethod::TM_PARAMETER_INPUT)
      .setDefault("linear")
      .setOptions("linear:fast_linear")
      .setComment("\n"
          "searching algorithm: \n"
         "\"linear\": linear set-based search\n"
         "  (1)spec value at each step (i.e. \"stepwidth\") is predefined as specific sets in equation\n"
         "  (2)corresponding burst pattern is created\n"
         "  (3)functional test is executed with that burst pattern\n"
         "  (4)the pass/failure transition is scanned out\n"
         "  (5)the spec value is firgured out at transition point\n"
         "\"fast_linear\": do two steps linear searches for larger search range:\n"
         "  (1) run coarse linear search, stepwidth = sqrt(range/stepwidth)\n"
         "  (2) find out the transition of pass/failure\n"
         "  (3) within the transition range, do further linear search, stepwidth = stepwidth\n"
         );
  
   addParameter("start",
               "SpecValue",
               &mStart,
               testmethod::TM_PARAMETER_INPUT)
     .setDefault("1[ns]")
     .setComment("search start point");
  
   addParameter("stop",
               "SpecValue",
               &mStop,
               testmethod::TM_PARAMETER_INPUT)
     .setDefault("2[ns]")
     .setComment("search stop point");
  
   addParameter("stepwidth",
               "SpecValue",
               &mStepwidth,
               testmethod::TM_PARAMETER_INPUT)
     .setDefault("0.1[ns]")
     .setComment("search stepwith");
 
   addParameter("setupPinlist",
                "PinString",
                &mSetupPin,
                testmethod::TM_PARAMETER_INPUT)
     .setComment("setup pins whoes dependent spec variable is searched.");
  
   addParameter("workMode",
                 "string",
                 &mWorkMode,
                 testmethod::TM_PARAMETER_INPUT)
     .setOptions("evaluation:training:production")
     .setDefault("training")
     .setComment("\nset work mode\n"
          "\"training\": set search condition to generate proper setup for search.\n"
          "\"evaluation\": evaluate the performance of training condition "
          "with dynamic downloading the new burst pattern.\n"
          "\"production\": all training setup must be saved for production "
          "and set the new burst pattern as primary label.");
    
    //for training mode only
/*    addParameter("workMode.searchPatternOnPort",
                 "string",
                 &mSearchPatternName,
                 testmethod::TM_PARAMETER_INPUT)
      .setComment("\n"
          "the name of search pattern on port for multiport spec search.\n");
*/    
    addParameter("workMode.CTIM/CLEV_TemplatePatternName",
                 "string",
                 &mChangeSetPatternName,
                 testmethod::TM_PARAMETER_INPUT)
      .setComment("\n"
          "the pattern which calles CTIM/CLEV command as simple as followed:\n"
          "[1] CTIM/CLEV 1\n"
          "[2] at least one vector, depends on application\n"
          "NOTE: this pattern is used to generate multiple CTIM/CLEV patterns "
          "which are used in new burst pattern.");

    addParameter("workMode.newBurstPatternName",
                 "string",
                 &mNewBurstPatternName,
                testmethod::TM_PARAMETER_INPUT)
      .setComment("\n"
          "the burst pattern to be created for set-based search.\n"
          "it combines CTIM/CLEV pattern and "
          "normal search pattern as followed:\n"
          "------------------------\n"
          "CALL CTIM/CLEV pattern\n"
          "CALL search pattern\n"
          "...\n"
          "CALL CTIM/CLEV pattern\n"
          "CALL search pattern\n"
          "------------------------\n"
          "[NOTE]\n"
          "if not specified, the name is created as \""+DEFAULT_BURST_PATTERN_NAME_FORMAT+"\".");

    addParameter("output",
                 "string",
                 &mReportToUI)
      .setDefault("None")
      .setOptions("ReportUI:None")
      .setComment("ReportUI: print result to UI report window\n"
                  "None: no result to UI report window");   
    addParameter("testName",
                 "string",
                 &mTestName)
      .setDefault("SpecSearch_Test")
      .setComment("test limit's name, default is \"SpecSearch_Test\"\n"
         "this limit is defined in limit section or testtable file.");

    addLimit(getParameter("testName").getDefault());  
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
    static string sTestMethodName = "Test method(\"SetBasedSpecSearch\")";
    SetBasedSpecSearchTMUtil::SearchResult resultPerSite;

    ON_FIRST_INVOCATION_BEGIN(); 
       
      //process  parameters
      if (mIsSearchConditionChanged)
      {
        mpSearchUtility->processParameter(
          mSetupPin,
          mSpecVar,
          mStart,
          mStop,
          mStepwidth,
          mAlgorithm,
          mNewBurstPatternName,
          mSearchParamContainer);
      }

      //process limit
        mpSearchUtility->processLimit(
        mTestName,
        mSearchParamContainer,
        mSearchLimit);
  
      if (mWorkMode == "training")
      {
        DebugInfo::getInfoHandler().enableDebugInfo();
        if (mIsSearchConditionChanged)
        { 
          mpSearchUtility->doTraining(mSearchParamContainer,
                                      mChangeSetPatternName,
                                      mSearchPatternName);
          mIsSearchConditionChanged = false;
        }
        else
        {
          TrainOut("search condition is same as before, training is skipped.");
        }
      }
      else if (mWorkMode == "evaluation")
      {
        DebugInfo::getInfoHandler().disableDebugInfo();          
        mpSearchUtility->doEvaluation(mSearchParamContainer);
      }
      else if (mWorkMode == "production")
      {
        DebugInfo::getInfoHandler().disableDebugInfo();          
      }
      else
      {
        throw Error(sTestMethodName,
          "invalid work mode: "+mWorkMode,
          sTestMethodName);
      }
      
    ON_FIRST_INVOCATION_END();
    
    //execute measurement on all active sites
    mpSearchUtility->doMeasurement(mSearchParamContainer,resultPerSite);
   
    //datalog for current site 
    mpSearchUtility->judgeAndDatalog(
      mSearchParamContainer,
      resultPerSite,
      mSearchLimit);

    //report result for current site 
    mpSearchUtility->reportToUI(mSearchParamContainer,resultPerSite,mReportToUI);

  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   *
   *Note: Test Method API should not be used in this method.
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //search condition change is regardless of "output" and "workMode"
    mIsSearchConditionChanged |= 
      (parameterIdentifier != "output" &&
       parameterIdentifier != "workMode");
    
    if(parameterIdentifier == "specVar")
    {
      getParameter(parameterIdentifier).setValid(!mSpecVar.mName.empty());
      //search conditions' units depend on spec variable's unit in equation
      mStart.setBaseUnit(mSpecVar.mUnit);
      mStop.setBaseUnit(mSpecVar.mUnit);
      mStepwidth.setBaseUnit(mSpecVar.mUnit);
      mIsMultiPort = (!SetBasedSpecSearchTMUtil::getPortNameOfSpecVar(mSpecVar).empty());
      //getParameter("workMode.searchPatternOnPort").setVisible(mIsMultiPort);
    }
    else if(parameterIdentifier == "workMode")
    {
      if (mWorkMode == "training" || mWorkMode == "production" || mWorkMode == "evaluation")
      {
        getParameter(parameterIdentifier).setValid(true);
        bool isForTraining = (mWorkMode == "training"?true:false);
        getParameter("workMode.CTIM/CLEV_TemplatePatternName").setEnabled(isForTraining);
        getParameter("workMode.newBurstPatternName").setEnabled(isForTraining);
        //getParameter("workMode.searchPatternOnPort").setEnabled(isForTraining);
        getParameter("algorithm").setEnabled(isForTraining);
        getParameter("setupPinlist").setEnabled(isForTraining);
        getParameter("specVar").setEnabled(isForTraining);
        getParameter("start").setEnabled(isForTraining);
        getParameter("stop").setEnabled(isForTraining);  
        getParameter("stepwidth").setEnabled(isForTraining);
      }
      else
      {
        getParameter(parameterIdentifier).setValid(false);
      }
    }
/*    else if (parameterIdentifier == "workMode.searchPatternOnPort")
    {
      bool isValid = !(mWorkMode == "training" && mIsMultiPort && mSearchPatternName.empty());
      getParameter(parameterIdentifier).setValid(isValid);
    }*/ 
    else if (parameterIdentifier == "workMode.CTIM/CLEV_TemplatePatternName")
    {
      bool isValid = !(mWorkMode == "training" && mChangeSetPatternName.empty());
      getParameter(parameterIdentifier).setValid(isValid);
    }
    else if (parameterIdentifier == "algorithm")
    {
      bool isValid = (mAlgorithm == "linear" || mAlgorithm == "fast_linear");
      getParameter(parameterIdentifier).setValid(isValid);
    }
    else if (parameterIdentifier == "testName")
    {
      getParameter(parameterIdentifier).setValid(!mTestName.empty());
    }
    else if(parameterIdentifier == "output")
    {
      bool isValid = (mReportToUI == "ReportUI" || mReportToUI == "None");
      getParameter(parameterIdentifier).setValid(isValid);  
    }
     
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string  getComment() const
  {
     static string comment =  _TML_VERSION;
     return comment;
  }
};

REGISTER_TESTMETHOD("AcTest.SetBasedSpecSearch", SetBasedSpecSearch);
