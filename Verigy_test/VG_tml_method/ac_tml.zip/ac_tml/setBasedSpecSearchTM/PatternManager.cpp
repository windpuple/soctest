#include "PatternManager.h"
#include "FW.h"
#include "TestMethod.h"
#include "tpi_c.h"
#include "libcicpi.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

using namespace std;

namespace spec_search_pro{

PatternManager::PatternManager()
{
}

PatternManager::~PatternManager()
{
}

int PatternManager::deleteLabel(string label, string port)
{
  if (port == "" || port == "@")
  {
    if (Primary.getLabel() == label)
    {
      //current start label is the one to be deleted
      //make sure start label is set to a different one using Primary.label() to keep cache in sync
      Primary.label("");
      FLUSH();    
    }
  }

  if (port == "")
  {
    fwout << "DLTS \"" << label << "\"" << endl;    
  }
  else
  {
    fwout << "DLTS \"" << label << "\",("<< port << ")" << endl;        
  }

  return 1;
}

int PatternManager::renameLabel(string sourceLabel, string destinationLabel)
{
  assert(destinationLabel.size() <= 128);

  fwout << "SQLB? \"" << sourceLabel << "\",ALL,(@@)" << endl;

  if (fwresult.size() != 1)
  {
    if (fwresult.size() >1)
    {
      cerr << "renameLabel - source-label not unique: " << sourceLabel << endl;
    }
    else
    {
      cerr << "renameLabel - source-label not found: " << sourceLabel << endl;            
    }
    return -1;        
  }

  if (fwresult[0].count()==6)
  {
    //mp label    
    fwout << "SQLB \"" << destinationLabel 
          << "\"," << fwresult[0][1] << "," 
          << fwresult[0][2] << "," << fwresult[0][3] 
          << ",\"" <<fwresult[0][4] << "\",("<< fwresult[0][5] <<")" << endl;        
  }
  else
  {
    fwout << "SQLB \"" << destinationLabel 
          << "\"," << fwresult[0][1] << "," 
          << fwresult[0][2] << "," << fwresult[0][3] 
          << ",\"" <<fwresult[0][4] << "\"" << endl;        

  }
  updatePatternManager(); 
  return 1;
}

int PatternManager::saveLabel(string labelName)
{
  char dev_path[1024];
  char tmp_path[1024]; //TODO: is that sufficient?
  char pathToLabelFile[1024]; //TODO: is that sufficient?
  GetDevPath(dev_path);
  GetTmpPath(tmp_path);

  sprintf(pathToLabelFile,"%s/Labels",tmp_path);
  fstream labelFile(pathToLabelFile,ios::out);
  labelFile << "1" << endl << labelName << endl;
  labelFile.close();
  INT32 retState;
  DataManager(dm_vector, dm_save, dev_path, 
    const_cast<char*>(labelName.c_str()), 49 | 0x80, &retState);

  if (retState<0)
  {
    cerr << "could not save the file \"" << labelName << "\"." << endl;
    return -1;
  }
  else
  {
    return 1;    
  }
}

int PatternManager::mergeLabelFromFile(string fileName)
{

  char dev_path[1024];
  GetDevPath(dev_path);
  INT32 retState;
  //merge in the just created new label 
  DataManager(dm_vector, dm_append, dev_path, 
    const_cast<char*>(fileName.c_str()), 0, &retState);  
  if (retState<0)
  {
    cerr << "could not merge the file \"" << fileName << "\"." << endl;
    return -1;
  }

  //workaround: need to set new merged pattern out of data. Otherwise PatternManager has an issue    
  fwout << "TSTL \"" << fileName << "\"," << endl;
  fwout << "TCMT? 0,1" << endl;
  if (fwresult.size()>0) 
  {
    fwout << "tcmt " << fwresult[0][0] << ",\"" << fwresult[0][1] << "\"" << endl;
  }
  else
  {
    fwout << "tcmt 0,\"\"" << endl;
  }
  //workaround: update pattern manager
  updatePatternManager(); 
  return 1;    
}

int PatternManager::copyLabel(string sourceLabel, string destinationLabel)
{
  //check if destination already exists
  if (isPatternAvailable(destinationLabel))
  {
    cerr << destinationLabel << " already exists: will be deleted first." << endl;
    deleteLabel(destinationLabel);
  }

  //workaround: update pattern manager
  updatePatternManager(); 

  //rename the label
  renameLabel(sourceLabel, destinationLabel);

  saveLabel(destinationLabel);

  //rename original back
  renameLabel(destinationLabel, sourceLabel);    

  //merge in the just created new label 
  mergeLabelFromFile(destinationLabel);

  return 1;
}

/**
 * precondition: the label must be activated before editing CTIM/CLEV number
 * */
bool PatternManager::changeSetNumberForLabel(
                                            const string& label,
                                            const int setNum,  
                                            const string& changeCommand,
                                            const string& port)
{
  bool isDone = false;
  if (changeCommand != "CLEV" && changeCommand != "CTIM")
  {
    cerr<<"command \""<<changeCommand<<"\" is not supported!"<<endl;
    return isDone;
  }

  fwout<<"TSTL \""+label+"\","<<endl;
  if (port == "@")
  {
    fwout << "SQLB? \"" << label << "\",MAIN,(@@)"<< endl;  
  }
  else
  {
    fwout << "SQLB? \"" << label << "\",MAIN,(" << port << ")"<< endl;
  }
  if (fwresult.empty())
  {
    cerr << "Error in readCyclesFromLabel( \"" << label 
         << "\",\"" << port << "\"): label not found." << endl;
    return 0;
  }

  int seqNoStart = fwresult[0].getIntParam(2);
  int seqNoStop =  fwresult[0].getIntParam(3);

  for (int i=seqNoStart; i<seqNoStop; i++)
  {
    fwout << "SQPG? " << i << ",(" << port << ")" << endl;
    if (fwresult[0][1] == changeCommand)
    {
      fwout<< "SQPG "<<i<<","<<changeCommand<<","<<setNum<<",,,("<<port<<")"<<endl;
      isDone = true;
      //break;//only one command should be allowed in label?? 
    }
  }

  return isDone; 
}

int
PatternManager::getPortOfPattern(const string& pattern, string& port)
{
  port.clear();
  if (pattern.empty() || !isMultiport(pattern))
  {
    return -1;
  }

  fwout << "SQLB?\"" << pattern << "\",ALL,(@@)" << endl;
  for (unsigned int i = 0; i < fwresult.size(); i++)
  {
    // e.g. SQLB "ALL_NB",MPBU,6,7,"Memory Group",(MEM1_Port)
    if (fwresult[i].count() > 5)
    {
      port = fwresult[i][5];
    }
    else
    {
      return -2;
    }
  }
  return 1;
}

int
PatternManager::getPortsOfMPPattern(const string& mpBurst, vector<string>& ports)
{
  ports.clear();
  if (mpBurst.empty() || !isMultiport(mpBurst))
  {
    return -1;
  }

  fwout << "SQLB?\"" << mpBurst << "\",MPBU,(@@)" << endl;
  for (unsigned int i = 0; i < fwresult.size(); i++)
  {
    // e.g. SQLB "ALL_NB",MPBU,6,7,"Memory Group",(MEM1_Port)
    if (fwresult[i].count() > 5)
    {
      ports.push_back(fwresult[i][5]);
    }
    else
    {
      return -2;
    }
  }
  return 1;
}

int 
PatternManager::getMultiPortBurstInfo_ByPort(const string& mpBurst, const string& port, 
                                             vector<string>& labelsInBurst, string& syncGroup)
{
  labelsInBurst.clear();
  syncGroup.clear();

  if (mpBurst.empty())
  {
    return -1;
  }

  fwout << "SQLB?\"" << mpBurst << "\",MPBU,("<< port <<")" << endl;

  // e.g. SQLB "ALL_NB",MPBU,6,7,"Memory Group",(MEM1_Port)
  if (fwresult.empty())
  {
    return 0;
  }
  if (fwresult.size() > 1)
  {
    return -1;
  }
  if (fwresult[0].count() <= 5)
  {
    return -2;
  }

  syncGroup = fwresult[0][4];

  const int start = fwresult[0].getIntParam(2);
  const int end   = fwresult[0].getIntParam(3);

  for (int i = start; i < end; i++)
  {
    fwout << "SQPG?" << i << ",(" << port << ")"<< endl;
    // SQPG 6,CALL,,"MEM1.end",,(MEM1_Port)
    if ((fwresult.size() == 1) && (fwresult[0].count() > 5))
    {
      labelsInBurst.push_back(fwresult[0][3]);
    }
    else
    {
      return -3;
    }
  }

  return 1;
}

int 
PatternManager::createBurst(const string& burstName, 
  const vector<string>& labelsToCall, 
  const string& syncGroup, 
  const string& port, 
  const bool toRemoveIfExisted)
{
  int debug = 0;
  bool isMultiport = (port != "@");
  //string port;
  string wavetable;
  if (labelsToCall.empty())
  {
    cerr << "createBurst: no labelsToCall specified. Creating empty burst \"" 
         << burstName << "\"" << endl; 
  }
  else
  {
    //get wavetable, not absolutly necessary...
    //using wavetable of first label for the burst
    fwout << "SQLB? \"" << labelsToCall[0] << "\",MAIN,(@@)" << endl;
    wavetable = fwresult[0][4];
  }

  if (isPatternAvailable(burstName))
  {
    if (isMultiport && !toRemoveIfExisted)
    {
      // deleteLabel(burstName, port);
    }
    else
    {
      cerr << "Warning: label with " << burstName << " already existed: will be deleted first." << endl;
      deleteLabel(burstName);
    }
  }

  int smSizeOfBurst;
  smSizeOfBurst = labelsToCall.size();
  smSizeOfBurst++; //one more sequencer inst. is needed: "BEND"


  //get current SM size
  fwout << "DMAS? SQPG,SM,(" << port << ")" << endl;
  int SMcurrentSize = fwresult[0].getIntParam(2);
  if (debug)
  {
    cerr << "memory size before: " << SMcurrentSize << endl;
  }

  //check if there is enough memory
  fwout << "DMAS? MFRE, SM, (@)" << endl;
  if (fwresult[0].getIntParam(2) < (smSizeOfBurst + 1) * 8)
  {
    //the unit of DMAS? MFRE is [vectorSize]
    //one sequencer command needs 8 * vectorSize
    cerr << "not enough memory available to create burst " << burstName << endl;
    return -1;    
  }


  if (debug)
  {
    cerr << "creating new BurstLabel: " << burstName << " for port " << port << endl;
  }

  fwout << "DMAS SQPG,SM," << SMcurrentSize + smSizeOfBurst + 1 << ",(" << port << ")" << endl;
  if (isMultiport)
  {
    //cerr << "before if compare ok"<< syncGroup <<endl;
    if (syncGroup.compare("[wavetable]")==0)
    {
      // default sync group specified, use wavetable name
      cerr << "should not be here"<< syncGroup <<endl;
      fwout << "SQLB \"" << burstName << "\",MPBU," << SMcurrentSize << "," << SMcurrentSize+smSizeOfBurst-1 
      << ",\"" << wavetable << "\",(" << port << ")" << endl;
    }
    else
    {
      // use syncGroup name
      fwout << "SQLB \"" << burstName << "\",MPBU," 
            << SMcurrentSize << "," << SMcurrentSize+smSizeOfBurst-1 
            << ",\"" << syncGroup << "\",(" << port << ")" << endl;
    }
  }
  else
  {
    fwout << "SQLB \"" << burstName << "\",BRST," 
          << SMcurrentSize << "," << SMcurrentSize+smSizeOfBurst-1 
          << ",\"" << wavetable << "\",(" << port << ")" << endl;        
  }

  for (int i=0; i<(int)labelsToCall.size(); i++)
  {
    if (debug)
    {
      cerr << "adding " << labelsToCall[i] << endl;
    }

    fwout << "SQPG " << SMcurrentSize + i 
          << ",CALL,,\"" << labelsToCall[i] 
          << "\",,(" << port << ")" << endl;
  }

  fwout << "SQPG " << SMcurrentSize + smSizeOfBurst-1 
        << ",BEND,,,,(" << port << ")" << endl;

  //workaround: update pattern manager
  updatePatternManager();

  return 1;
}

int PatternManager::createBurst(string burstName, vector<string> labelsToCall, std::string portName)
{
  if (burstName.size() > 128)
  {
    cerr << "burst name is too long";
    return -1;
  }

  int debug = 0;
  bool isMultiport = false;
  string port;
  string wavetable = "";
  if (labelsToCall.size() == 0)
  {
    cerr << "createBurst: no labelsToCall specified. Creating empty burst \"" 
         << burstName << "\"" << endl; 
  }
  else
  {
    if (portName == "")
    {
      //when no portName is specified; map to first port (for compatibility)
      fwout << "SQLB? \"" << labelsToCall[0] << "\",MAIN,(@@)" << endl;
      if (fwresult[0].count() == 6)
      {
        //multiport
        port = fwresult[0][5];
      }
      else
      {
        port = "@";    
      }
    }
    else
    {
      port = portName;    
    }     
    //get wavetable
    fwout << "SQLB? \"" << labelsToCall[0] << "\",MAIN,(" << port << ")" << endl;
    wavetable = fwresult[0][4];

    if (port == "@") 
    {
      isMultiport = false;
    }
    else 
    {
      isMultiport = true;
    }

    if (debug) 
    {
      cerr << "multiport = " << isMultiport << " port = " << port << endl;
    }
  }

  if (isPatternAvailable(burstName, isMultiport?"MPBU":"BRST", port))
  {
    //delete label if it already exists
    cerr << "Warning: label \"" << burstName << "\" on port \"" 
         << port << "\" already existed and will be overwritten." << endl;
    deleteLabel(burstName, port);
  }

  int smSizeOfBurst;
  smSizeOfBurst = labelsToCall.size();
  smSizeOfBurst++; //one more sequencer inst. is needed: "BEND"


  //get current SM size
  fwout << "DMAS? SQPG,SM,(" << port << ")" << endl;
  int SMcurrentSize = fwresult[0].getIntParam(2);
  if (debug) 
  {
    cerr << "memory size before: " << SMcurrentSize << endl;
  }
  //check if there is enough memory
  fwout << "DMAS? MFRE, SM, (@)" << endl;
  if (fwresult[0].getIntParam(2) < ((smSizeOfBurst + 1) * 8))
  {
    //the unit of DMAS? MFRE is [vectorSize]
    //one sequencer command needs 8 * vectorSize
    cerr << "not enough memory available to create burst " << burstName << endl;
    return -1;    
  }

  if (debug) 
  {
    cerr << "creating new BurstLabel: " << burstName << " for port " << port << endl;
  }

  fwout << "SAOF APP" << endl; //enter append mode    
  fwout << "DMAS SQPG,SM," << smSizeOfBurst << ",(" << port << ")" << endl;
  if (isMultiport)
  {
    fwout << "SQLB \"" << burstName << "\",MPBU,0," << smSizeOfBurst-1 
          << ",\"" << wavetable << "\",(" << port << ")" << endl;
  }
  else
  {
    fwout << "SQLB \"" << burstName << "\",BRST,0," << smSizeOfBurst-1 
          << ",\"" << wavetable << "\",(" << port << ")" << endl;        
  }

  for (vector<string>::size_type i=0; i<labelsToCall.size(); i++)
  {
    if (debug)
    {
      cerr << "adding " << labelsToCall[i] << endl;
    }
    fwout << "SQPG " << i << ",CALL,,\"" << labelsToCall[i] 
          << "\",,(" << port << ")" << endl;
  }
  fwout << "SQPG " << smSizeOfBurst-1 << ",BEND,,,,(" << port << ")" << endl;
  fwout << "SAOF ZERO" << endl; //leave append mode

  //workaround: update pattern manager
  updatePatternManager();

  return 1;
}

bool PatternManager::isPatternAvailable(string labelFile, string labelType, string port)
{
  fwout << "SQLB? \"" << labelFile << "\"," << labelType 
        << ",(" << port << ")" << endl;
  if (fwresult.size() >0)
  {
    return true;
  }
  else
  {
    return false;    
  }
}

bool PatternManager::isMultiport(string labelName)
{
  fwout << "SQLB? \"" << labelName << "\",ALL,(@@)" << endl;  
  if (fwresult.empty())
  {
    cerr << "label " << labelName 
         << "doesn't exist. Can't return isMultiport()" << endl;
    return false;
  }
  if (fwresult.size()>1) 
  {
    return true;
  }
  else
  {
    if (fwresult[0][1] != "MAIN") 
    { 
      cerr << "Type >>" <<fwresult[0][1] << "<<  for " 
        << labelName << " not supported. Can't return isMultiport()" << endl;
    }
    else
    {
      if (fwresult[0].count() == 5) 
      {
        return false;
      }
      else
      { 
        return true;
      }
    }
  }
  return false;
}

bool PatternManager::isMainPattern(string labelName)
{
  fwout << "SQLB? \"" << labelName << "\",ALL,(@@)" << endl;  
  if (fwresult.empty())
  {
    cerr << "label " << labelName 
         << "doesn't exist. Can't return isMultiport()" << endl;
    return false;
  }

  return(fwresult[0][1] == "MAIN"); 
}

int PatternManager::updatePatternManager()
{
  //TODO: find out if it's a pattern master file
  INT32 retState;
  DataManager(dm_pattern_master_file, dm_pldump , "..", "comm_file", 0, &retState);
  return retState;    
}



unsigned long long PatternManager::getCyclesFromLabel(std::string label, std::string port)
{
  //TODO: rewrite method to parse and analyze sequencer program to remove dummy-label-creation for MP
  int seqNoStart;
  int seqNoStop; 

  fwout << "SQLB? \"" << label << "\",MAIN,(@@)" << endl;
  if (fwresult.empty())
  {
    cerr << "Error in readCyclesFromLabel( \"" << label 
         << "\",\"" << port << "\"): label not found." << endl;
    return 0;
  }

  seqNoStart = fwresult[0].getIntParam(2);
  seqNoStop =  fwresult[0].getIntParam(3);

  for (int i=seqNoStart; i<seqNoStop; i++)
  {
    fwout << "SQPG? " << i << ",(" << port << ")" << endl;
    if (fwresult[0][1] == "MBGN" || 
         fwresult[0][1] == "WTER" || 
         fwresult[0][1] == "MJPE" || 
         fwresult[0][1] == "MEND" || 
         fwresult[0][1] == "JMPE" || 
         fwresult[0][1] == "RETC"|| 
         fwresult[0][1] == "MACT"|| 
         fwresult[0][1] == "MRPT")
    {
      cerr << "Error in readCyclesFromLabel( \"" << label 
           << "\",\"" << port 
           << "\"): Not possible to determine cycles for label that contains " 
           << fwresult[0][1] << endl;
      return 0;
    }
  }

  //valid label --> get cycles
  int cycles = 0;
  //save old label for restoration later
  fwout << "SQSL?" << endl;    
  string previousLabel = fwresult[0][0];
  string uptdBefore;
  if (isMultiport(label))
  {
    //need to create a dummy multiport burst to determine cycles using vrcs-fw-command
    vector<string> dummy;
    dummy.push_back(label);
    fwout << "UPTD? VEC" << endl;
    //query updt status of vector before creating dummy vector
    uptdBefore = fwresult[0][1];
    createBurst("dummyToDetermineCycles", dummy);
    fwout << "sqsl \"" << "dummyToDetermineCycles" << "\"" << endl;    
  }
  else
  {
    fwout << "sqsl \"" << label << "\"" << endl;
  }
  fwout << "vrcs? strt,(" << port << ")" << endl;
  int paddedSize = fwresult[0].getIntParam(2);
  fwout << "getv? " << paddedSize-1 << ", 1,(" << port << ")" << endl;
  if (fwresult[0][4] == "BRK") cycles = fwresult[0].getIntParam(0);
  else cycles = paddedSize;
  //restore old start label
  fwout << "sqsl \"" << previousLabel << "\"" << endl;
  if (isMultiport(label))
  {
    //delete dummy label
    deleteLabel("dummyToDetermineCycles");
    //reset uptd status
    fwout << "UPTD VEC," << uptdBefore << endl;
  }

  return cycles;  
}
};
