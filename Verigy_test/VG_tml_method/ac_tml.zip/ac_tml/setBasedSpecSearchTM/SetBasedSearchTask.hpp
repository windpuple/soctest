#ifndef SETBASEDSEARCHTASK_HPP_
#define SETBASEDSEARCHTASK_HPP_

#include "testmethod.hpp"
#include <map>
#include <vector>
#include <string>
#include <sstream>

namespace spec_search_pro{
/*
 * SetBasedSearchResult: contain results of all tested sites.
 */
class SetBasedSearchResult
{
public:
  //this SearchResult contain search result for one site
  struct SearchResult
  {
    bool isTransitionFound;
    bool isPassToFail;
    double passValue;
    double failValue;
    SearchResult():isTransitionFound(false),isPassToFail(false),passValue(0),failValue(0)
    {
    }
    SearchResult& operator=(const SearchResult& other)
    {
      if (this != &other)
      {
        this->isTransitionFound = other.isTransitionFound;
        this->isPassToFail = other.isPassToFail;
        this->failValue = other.failValue;
        this->passValue = other.passValue;
      }
      return *this;
    }
    ~SearchResult()
    {
      
    };
  };

  SetBasedSearchResult();
  
  ~SetBasedSearchResult();
  
  void setResultOnSite(const int site, const SearchResult& result)
  {
    mPerSiteResultMap[site] = result;
  }
  
  void cleanUpAllResults()
  {
    mPerSiteResultMap.clear();
  }
  
  const bool isPassedOnSite(const int site)const;
  
  const bool isPassToFailOnSite(const int site)const;
  
  double getPassValueOnSite(const int site)const;
  
  double getFailValueOnSite(const int site)const;
  
private:  
  std::map<int, SearchResult> mPerSiteResultMap;
};

/*
 * SetBasedSearchCondition: contain search conditions.
 */
class SetBasedSearchCondition
{
public:
  SetBasedSearchCondition(
    double start, double stop, double stepWidth, const std::string& burst);
  
  ~SetBasedSearchCondition();
  
  SetBasedSearchCondition(const SetBasedSearchCondition& other)
  {
    mStart = other.mStart;
    mStepWidth = other.mStepWidth;
    mBurstName = other.mBurstName;
    mSpecValueVector = other.mSpecValueVector;
  }
  
  void setBurstPattern(const std::string& burst)
  {
    mBurstName = burst;
  }
  
  double getSpecValueByIndex(const int index) const;
  
  const size_t getMeasuredPoints()const
  {
    return mSpecValueVector.size();
  }
  
  const std::string& getBurstName()const
  {
    return mBurstName;
  }
  
  void dumpInfo() const;
  
private:  
  double mStart;
  double mStop;
  double mStepWidth;
  int mStep;
  std::string mBurstName;
  
  /*vector containing all spec values which will be changed for search.
   *e.g. [0.1,0.2,0.3,0.4]
   */
  std::vector<double> mSpecValueVector;
  
};

//forward declaration
class EquationManager;
class PatternManager;

/*
 * this class implements set-based search:
 * - cache search conditions in SetBasedSearchCondition
 * - cache search results in SetBasedSearchResult
 * - do training
 * - do search and process result
 */
class SetBasedSearchTask
{
public:
  struct MultiPortInfo
  {
    std::map<std::string,std::vector<std::string> > portLabelsMap;
    std::map<std::string,std::string> portSyncGroupMap;
    std::vector<std::string> ports;
    std::string mpPattern;
  };
  
public:
  SetBasedSearchTask(const testmethod::SpecVariable& specVar, 
    const std::string& setupPins,
    SetBasedSearchCondition* pCondition);

  virtual ~SetBasedSearchTask();
	
  /*base number is used to differentiate sub search level
   *e.g. 2nd search level, 1000 could be used
   *3rd search level, 10000 could be used.
   *
   *for different sub search level, users have to set different base number for making 
   *one unique search key number.
   *
   *this number is used in generateSubSearchKeyByIndex()
   */
  void setSearchKeyBase(const int base)
  {
    mSearchKeyBase = base;	
  }
	
  /*generate sub search key which identifies the sub search condition
   *e.g. if first search indexes are defined as: 3 and 4, base is 1000
   *key = 1007
   *if there are 3rd level search, base could be 10000, indexs: 3,4
   *key = 10007
   */
  int generateSubSearchKeyByIndex(const int indexLeft, const int indexRight)
  {
    return (indexLeft+indexRight+mSearchKeyBase);
  }

  /*add one sub-search condition
   *@param sumOfIndex - this number must be calculated via generateSubSearchKeyByIndex()
   *
   *
   */
  void addSubSearchCondition(const int sumOfIndex, SetBasedSearchCondition* pSubSearchCondition);
  
  /*
   *@purpose: define the label name which calls CTIM/CLEV # to change timing/level set
   */
  const std::string defineSearchLabelName(
    const std::string& prefix, 
    const double specVal)
  {
    std::ostringstream name;
    name << prefix << "_V" << specVal;
    return name.str();
  }

  void doTraining(
    const std::string& templatePatternOf_CLEV_CTIM); 
	
  void doSearch();
	
  void dumpInfo() const;
	
  /*
   *@purpose: get status of search on current site
   * true for pass (transition was found), false for fail. 
   */
  const bool getPassFail() const;
	
  /*
   *@purpose: get spec value at passing point.
   */
  double getPassValue()const;
	
  /*
   *@purpose: get spec value at failure point.
   */	
  double getFailValue()const;

  /*
   *@purpose: clean up all internal resouces and reset results.
   */  
  void cleanUp()
  {
    mIndexBurstMap.clear();  
    for(std::map< std::string, const SetBasedSearchCondition* >::iterator it = mBurstConditionMap.begin();
        it != mBurstConditionMap.end();
        ++it)
    {
      delete it->second;
    }
    mBurstConditionMap.clear(); 
    mpParentCondition = 0; //the memory it points to has been released in above.
    
    mIndexBurstMap.clear();
    
    mSiteBurstMap.clear();
    
    mSearchResultOnAllSites.cleanUpAllResults();
    
    mSpecVar.reset();
    
    mSetupPinlist.clear();
    
  }
  
private:
  const SetBasedSearchCondition* getSearchConditionByBurstName(const std::string& burst) const;

  const SetBasedSearchCondition* getSearchConditionBySite(const int site) const;

  std::string::size_type processResult(const std::string& fwAnswer, const int site, 
    const SetBasedSearchCondition* pCond,
    const std::string::size_type offsetOfERMP);
  
  void preparePatternSetup(
    const std::string& highLevelBurstPattern, 
    const std::string& actualTempCallPattern,
    MultiPortInfo& mpInfo);
  
  void prepareEquationSetup(EquationManager& theEquationManager);
  
  int generateNewSetups(
      const SetBasedSearchCondition& condition,
      EquationManager& theEquationManager,
      const std::string& burstPattern,
      const std::string& templateOfCallLabel,
      const std::vector<std::string>& searchPattern,
      const std::string& ctimclevCommand,
      const int setNumberOffset,
      const MultiPortInfo& mpInfo);
  
private: 
  static std::string msDefaultCLEVCTIMTemplateName;
  int mSearchKeyBase;
  testmethod::SpecVariable mSpecVar;
  std::string mSpecName;
  std::string mPortName;
  bool mIsMultiPort;
  std::string mSetupPinlist;
  SetBasedSearchResult mSearchResultOnAllSites;
  SetBasedSearchCondition* mpParentCondition;
  
  /*map containing all search burst patterns per key, including first-level and sub-fine search.
   *
   *key: key=2*indexInSpecValueVector+1, if (special) key = 0, burst pattern is for first-level search.
   *value: burst pattern name
   * 
   *e.g. 
   *[0]["set_based_search_burst"]         - burst for first-level search
   *[1001]["subSearch1"]   - burst for sub search 
   *[1003]["subSearch3"]   - burst for sub search
   *[1005]["subSearch5"]   - burst for sub search
   * 
   *how to define, e.g :
   *first-level measured points:     0.1            0.2           0.3            0.4
   *                     index:       0              1             2              3
   *                                  |______________|_____________|______________|
   *                                         |              |             |
   *                                         |              |             |
   *                                         V              V             V
   *keys :                            | key=base+0+1 | key=base+1+2| key=base+2+3 |
   *values :                          |  "subSearch1"| "subSearch3"|  "subSearch5"| 
   *  
   */
  std::map< int, const std::string > mIndexBurstMap;
  
  /*map containing search conditions by burst pattern, including first-level and sub-fine search.
   *key:   burst pattern name
   *value: pointer to search condition
   * 
   *e.g. 
   *["set_based_search_burst"][pCond]             
   *["subSearch1"][pSubCond1]    
   *["subSearch3"][pSubCond3]   
   *["subSearch5"][pSubCond5] 
   *
   *how is sub search defined:
   * 
   *first-level burst pattern:  "set_based_search_burst"
   *first-level condition:      pCond(range[0.1,0.4], stepwidth 0.1) 
   * 
   *1st measured points:    0.1                       0.2                      0.3                      0.4
   *index of points:         0                         1                        2                        3
   *                         |_________________________|________________________|________________________|
   *                                       |                        |                        |
   *                                       V                        V                        V
   *<sub search burst name>  |      "subSearch1"       |       "subSearch3"     |       "subSearch5"     |  
   *<sub search condition>   | pCond1([0.11,0.19],0.01)|pCond3([0.21,0.29],0.01)|pCond5([0.31,0.39],0.01)|
   *
   */
  std::map< std::string, const SetBasedSearchCondition* > mBurstConditionMap;
  
  /*map containing all sites and their used burst pattern:
   *key: site number
   *value: burst pattern
   *for example:
   * [1]["set_based_search_burst"] 
   * [2]["subSearch5"] 
   * [3]["subSearch5"]
   * [4]["subSearch1"]
   */
  std::map<int, const std::string> mSiteBurstMap;

};
};
#endif /*SETBASEDSEARCHTASK_HPP_*/
