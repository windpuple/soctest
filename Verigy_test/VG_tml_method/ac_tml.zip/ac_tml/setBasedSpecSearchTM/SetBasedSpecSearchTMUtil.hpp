#ifndef SETBASEDSPECSEARCHTMUTIL_HPP_
#define SETBASEDSPECSEARCHTMUTIL_HPP_

#include "mapi.hpp"
#include "SetBasedSearchTask.hpp"
#include "DebugUtil.hpp"
#include <string>

const std::string DEFAULT_BURST_PATTERN_NAME_FORMAT = "_SS_{search_conditions}";
#define SPEC_SEARCH_SCALE (100000)
#define SS_IS_VALUE_EQUAL(left,right) (fabs((left)-(right)) < 1e-38)
/**
 * The utility class for spec search.
 */
class SetBasedSpecSearchTMUtil
{
public:
  struct SearchParam
  {
    //use input variables
    std::string testsuiteName;
    std::string setupPinlist;
    std::string burstPattern;
    std::string port;
    testmethod::SpecVariable specVar;
    double start;
    double stop;
    double range; 
    double stepwidth;
    std::string algorithm;

    //constructor 
    SearchParam():start(0),stop(0),range(0),stepwidth(0)
    {
      
    }
    //assigment
    SearchParam& operator=(const SearchParam& rh)
    {
      if (this != &rh)
      {
        this->testsuiteName = rh.testsuiteName;
        this->setupPinlist = rh.setupPinlist;
        this->burstPattern = rh.burstPattern;
        this->port = rh.port;
        this->specVar = rh.specVar;
        this->start = rh.start;
        this->stop = rh.stop;
        this->range = rh.range;
        this->stepwidth = rh.stepwidth;
        this->algorithm = rh.algorithm;
      }
      return *this;
    }

    //operator ==
    const bool operator==(const SearchParam& rh)
    {
      return (this->testsuiteName == rh.testsuiteName &&
              this->setupPinlist == rh.setupPinlist &&
              this->burstPattern == rh.burstPattern &&
              this->port == rh.port &&
              this->specVar.mFullName == rh.specVar.mFullName &&
              SS_IS_VALUE_EQUAL(this->start,rh.start) &&
              SS_IS_VALUE_EQUAL(this->stop,rh.stop) &&
              SS_IS_VALUE_EQUAL(this->stepwidth,rh.stepwidth) &&
              this->algorithm == rh.algorithm);
    }
      
    ~SearchParam()
    {
    }
    
  }; 
  
  struct SearchLimit
  {
    bool isLimitTableUsed;
    string testname;
    LIMIT limit;
  };
 
  /**
   * search result containter for one site.
   */
  struct SearchResult
  {
    bool isPassToFail; //true for PassToFail transition
    bool isPassed;     //transition is found
    double pValue;
    double fValue;
    SearchResult():isPassToFail(false),isPassed(false),pValue(0),fValue(0)
    { 
     
    }
  }; 


public:  

  SetBasedSpecSearchTMUtil():mpSetBasedTask(0)
  {

  }

  virtual ~SetBasedSpecSearchTMUtil()
  {
    if (mpSetBasedTask!= 0)
    {
      delete mpSetBasedTask;
    }
    mpSetBasedTask = 0;
  }
 
  /**
   * Parse the port information of a timing spec variable.
   * if port is defined, port it returned; otherwise, empty string is returned.
   *
   * @param specVar - spec variable to be parsed.
   *   
   */  
  static const 
  std::string getPortNameOfSpecVar(const testmethod::SpecVariable& specVar)
  {
    std::string port;
    std::string::size_type pos = specVar.mName.find("@");
    if (pos != std::string::npos) //multi-port and spec var is local definition for this port.
    {
      port = specVar.mName.substr(pos+1,specVar.mName.size()-pos-1);
    }
    return port; 
  }
   
  /*
   *----------------------------------------------------------------------*
   * Routine: processParameters
   *
   * Purpose: parse input parameters and setup internal parameters
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note: this function must be called in ON_FIRST_INVOCATION block!
   *----------------------------------------------------------------------*
   */
  void 
  processParameter(
    const std::string& setupPinlist,
    const testmethod::SpecVariable& spec,
    testmethod::SpecValue& start,
    testmethod::SpecValue& stop,
    testmethod::SpecValue& stepwidth,
    const std::string& algorithm,
    const std::string& burstPattern,
    SearchParam& toParam)
  {
    const std::string funcName = "SetBasedSpecSearchTMUtil::processParameters()";
    
    SearchParam tempCondition;

    GET_TESTSUITE_NAME(tempCondition.testsuiteName);
    
    tempCondition.setupPinlist = setupPinlist;
    vector<string> pinlistVector;
    if (!tempCondition.setupPinlist.empty())
    {
      PinUtility.getDigitalPinNamesFromPinList(
        tempCondition.setupPinlist,
        TM::I_PIN|TM::O_PIN|TM::IO_PIN,true,true);
    }
    else
    {
      tempCondition.setupPinlist = "@";
    }
    
    tempCondition.specVar = spec;
    if (tempCondition.specVar.mName.empty())
    {
      throw Error(funcName,"spec variable is invalid: "+tempCondition.specVar.mFullName);
    }
    else
    {
      tempCondition.port = getPortNameOfSpecVar(spec);
    }
     
      
    tempCondition.algorithm = algorithm;
    if (tempCondition.algorithm != "linear" && tempCondition.algorithm != "fast_linear")
    {
      throw Error(funcName,"invalid algorithm: "+tempCondition.algorithm);
    }
    
    std::string specTargetUnit = (tempCondition.specVar.mType=="LEV"?"V":"ns");
    //preprocess stepwidth
    tempCondition.stepwidth = stepwidth.getValueAsTargetUnit(specTargetUnit);
    if (tempCondition.stepwidth < 0)
    {
      throw Error(funcName,"the specified stepwidth must be positive."); 
    }
    else if (tempCondition.stepwidth <= 1/SPEC_SEARCH_SCALE)
    {
      throw Error(funcName,"the specified stepwidth is too small.");  
    }
   
    //round start to fine stepwidth
    tempCondition.start = start.getValueAsTargetUnit(specTargetUnit);
    tempCondition.stop = stop.getValueAsTargetUnit(specTargetUnit);

    tempCondition.range = fabs(tempCondition.stop - tempCondition.start);
    if (tempCondition.range < tempCondition.stepwidth)
    {
      throw Error(funcName,"the difference of start and stop is less than stepwidth.");  
    }
    
    if (tempCondition.start > tempCondition.stop)
    {
      double tmp = tempCondition.stop;
      tempCondition.stop = tempCondition.start;
      tempCondition.start = tmp;
    }
   
    tempCondition.burstPattern = burstPattern;
    if (tempCondition.burstPattern.empty())
    {
      //generate default pattern name with search conditions
      ostringstream newBurstPattern;
      newBurstPattern << "_SS_";
      string::size_type posChar = 0;
      while ( (posChar = setupPinlist.find_first_not_of(", \t\b\n",posChar)) != string::npos)
      {
        newBurstPattern << setupPinlist[posChar];
        posChar = setupPinlist.find_first_of(", \t\b\n",posChar);
      }

      //escape '@()#' which is invalid char for pattern name
      string searchSpecName = spec.mFullName;
      string::size_type pos = 0;
      while( (pos = searchSpecName.find_first_of("@()#*",pos)) != string::npos)
      {
        searchSpecName.replace(pos++,1,"~");
      }

      newBurstPattern << "_"
        << searchSpecName << "_"
        << tempCondition.start << "_"
        << tempCondition.stop << "_"
        << tempCondition.stepwidth << "_"
        << algorithm;
      tempCondition.burstPattern = newBurstPattern.str();
      if (tempCondition.burstPattern.size() >= 128) 
      {
        throw Error(funcName,
          "the length of new burst pattern name exceeds limitation.");
      }
    }
   
    if (!(toParam == tempCondition))
    {  
      toParam = tempCondition;
      //prepare search conditions
      processSearchCondition(toParam);
    }

  }

  /*
   *----------------------------------------------------------------------*
   * Routine: processLimit
   *
   * Purpose: get testname and limit according to
   *   input limit parameter.
   *
   *----------------------------------------------------------------------*
   * Description:
   *    input parameters:
   *      testname - limit name 
   *      searchParam - parameters of search
   *    output parameter:
   *      searchLimit          - containing all limit information for datalog.     
   * Note: this function must be called in ON_FIRST_INVOCATION block!
   *----------------------------------------------------------------------*
   */
  void 
  processLimit(const std::string& testname,
               const SearchParam& searchParam,
               SearchLimit& testlimit)
  {
    testlimit.isLimitTableUsed = false;
    testlimit.testname = testname;

    TestTable* pLimitTable = TestTable::getDefaultInstance();
    pLimitTable->readCsvFile();
    if (pLimitTable->isTmLimitsCsvFile())
    {
      try
      {
	V93kLimits::TMLimits::LimitInfo& limitInfo = 
          V93kLimits::tmLimits.getLimit(searchParam.testsuiteName, testlimit.testname);
        testlimit.limit = limitInfo.TEST_API_LIMIT;
        testlimit.isLimitTableUsed = true;
      }
      catch(Error& e)
      {
        testlimit.isLimitTableUsed = false;
      }
    }
    else
    {
      testlimit.isLimitTableUsed = false;
    }

    if (!testlimit.isLimitTableUsed)
    {
      testlimit.limit = GET_LIMIT_OBJECT(testlimit.testname);
    } 
  }
  
  /*
   *----------------------------------------------------------------------*
   * Routine: doTraining
   *
   * Purpose: generate pattern, burst and timing/level sets 
   *          for set-based search.
   *
   *----------------------------------------------------------------------*
   * Description:
   *   
   * Note: this function must be called in ON_FIRST_INVOCATION block!
   *----------------------------------------------------------------------*
   */  
  void 
  doTraining(SearchParam& param, const std::string& templatePatternOfCallSet, 
    const std::string& searchPattern)
  {
    //if timing/level or vector setup is changed, throw error
    std::string status;
    FW_TASK("UPTD? " + param.specVar.mType, status);
    if (!status.empty() && status[status.size()-1] == '0')
    {
      throw Error("SetBasedSpecSearchTMUtil::doTraining()",
        "timing/level file was changed, please reload or save it before training.");
    }

    FW_TASK("UPTD? VEC\n", status);
    if (!status.empty() && status[status.size()-1] == '0')
    {
      throw Error("SetBasedSpecSearchTMUtil::doTraining()",
        "vector file was changed, please reload or save it before training.");
    }
    
    //generate pattern names
    std::string multiportPattern;
    std::string normalSearchPattern = searchPattern;
    if (!param.port.empty()) 
    {
      //for multi-port test, the MPPattern use the primary pattern 
      multiportPattern = Primary.getLabel();
    }
    else
    {
      //for non-multi-port test, the search pattern use the primary pattern 
      normalSearchPattern = Primary.getLabel();
      TrainOut("primary pattern \"" << normalSearchPattern << "\" is used as search pattern.");
    }

    mpSetBasedTask->doTraining(templatePatternOfCallSet);    
  }
  
  /*
   *----------------------------------------------------------------------*
   * Routine: doEvaluation
   *
   * Purpose: generate pattern, burst and timing/level sets.
   *
   *----------------------------------------------------------------------*
   * Description:
   *   
   * Note: this function must be called in ON_FIRST_INVOCATION block!
   *----------------------------------------------------------------------*
   */
  void 
  doEvaluation(SearchParam& param)
  {
      Primary.label(param.burstPattern);
  }
  /*
   *----------------------------------------------------------------------*
   * Routine: doTraining
   *
   * Purpose: generate pattern, burst and timing/level sets.
   *
   *----------------------------------------------------------------------*
   * Description:
   *   
   * Note: this function must be called in ON_FIRST_INVOCATION block!
   *----------------------------------------------------------------------*
   */
  void 
  doMeasurement(SearchParam& param, SearchResult& result)
  {
    if (mpSetBasedTask == 0)
    {
      throw Error("SetBasedSpecSearchTMUtil::doMeasurement",
        "set based search task is not instantiated yet in \"selected execution\".");
    }
    
    ON_FIRST_INVOCATION_BEGIN();
      if (Primary.getLabel() != param.burstPattern)
      {
        throw Error("SetBasedSpecSearchTMUtil::doMeasurement",
          "please specify \"" + param.burstPattern + "\" as primary patten.");
      }
      
      CONNECT();
      mpSetBasedTask->doSearch();
      
    ON_FIRST_INVOCATION_END();

    result.isPassed = mpSetBasedTask->getPassFail();
    result.pValue = mpSetBasedTask->getPassValue();
    result.fValue = mpSetBasedTask->getFailValue(); 
  }
  
  /*
   *----------------------------------------------------------------------*
   * Routine: judgeAndDatalog
   *
   * Purpose: judge and put result into event datalog stream.
   *
   *----------------------------------------------------------------------*
   * Description:
   *   judge results of 'result' with pass limits from 'param'
   * 
   *   INPUT:  param       - test parameters
   *           result      - result container
   *   OUTPUT: 
   *   RETURN: 
   * Note:
   *----------------------------------------------------------------------*
   */
  static void 
  judgeAndDatalog(const SearchParam& param, const SearchResult& result,
    const SearchLimit& searchLimit)
  {
    if (searchLimit.isLimitTableUsed)
    {
      //log pass value
      TestSet.cont(TM::CONTINUE)
             .judgeAndLog_ParametricTest(param.setupPinlist,
                                         searchLimit.testname,
                                         V93kLimits::tmLimits,
                                         result.pValue);
      //log fail value
      TestSet.cont(TM::CONTINUE)
             .judgeAndLog_ParametricTest(param.setupPinlist,
                                         searchLimit.testname,
                                         V93kLimits::tmLimits, 
                                         result.fValue);
    }
    else
    {
      //log pass value
      TESTSET().cont(TM::CONTINUE)
               .judgeAndLog_ParametricTest(param.setupPinlist,
                                           searchLimit.testname,
                                           searchLimit.limit,
                                           result.pValue);
      //log fail value
      TESTSET().cont(TM::CONTINUE)
               .judgeAndLog_ParametricTest(param.setupPinlist,
                                           searchLimit.testname,
                                           searchLimit.limit,
                                           result.fValue);

    } 
  }
  
  /*
   *----------------------------------------------------------------------*
   * Routine: reportToUI
   *
   * Purpose: output result to UIWindow 
   *
   *----------------------------------------------------------------------*
   * Description:
   *   display: 
   *       a) pass or fail,
   *       b) pass and fail value.
   * 
   *   INPUT:  param              - test parameters
   *           result             - result container
   *           output             - "None" or "ReportUI" 
   *   OUTPUT: 
   *   RETURN:  
   * Note:
   *----------------------------------------------------------------------*
   */  
  static void 
  reportToUI(const SearchParam& param, const SearchResult& result, const std::string& output)
  {
    if (output != "ReportUI")   
    {
      return;
    }
    int site = CURRENT_SITE_NUMBER();
    if(result.isPassed)
    { 
      const static INT OUTPUT_WIDTH = 10;
      cout<<"PASSED on site "<<site<<" :"<<endl;
      cout<<param.specVar.mName
          <<"                          P = "
          <<setiosflags(ios_base::left)
          <<setw(OUTPUT_WIDTH) 
          <<result.pValue
          <<"   "
          <<param.specVar.mUnit
          <<"             P"
          <<endl;
        
      cout<<param.specVar.mName
          <<"                          F = "
          <<setiosflags(ios_base::left)
          <<setw(OUTPUT_WIDTH) 
          <<result.fValue
          <<"   "
          <<param.specVar.mUnit
          <<"             P"
          <<endl;  
    }
    else
    {
      cout<<"FAILED on site "<<site<<" :\n"
          <<param.specVar.mName<<"                          P = ******             F\n"
          <<param.specVar.mName<<"                          F = ******             F"
          <<endl;
    }
  }
  
private: 
  //set based task
  spec_search_pro::SetBasedSearchTask* mpSetBasedTask;

  /*
   *----------------------------------------------------------------------*
   * Routine: processSearchCondition 
   *
   * Purpose: generate set-based search conditions 
   *
   *----------------------------------------------------------------------*
   * Description:
   *   
   * Note: this function must be called in ON_FIRST_INVOCATION block!
   *----------------------------------------------------------------------*
   */
 
  void 
  processSearchCondition(SearchParam& param)
  {
    //firstly to remove old task
    if (mpSetBasedTask != 0)
    {
      delete mpSetBasedTask;
    } 

    //build up new task
    if (param.algorithm == "linear")
    {
      spec_search_pro::SetBasedSearchCondition* pCondition = 
        new spec_search_pro::SetBasedSearchCondition(
              param.start,param.stop,param.stepwidth,param.burstPattern);
      
      mpSetBasedTask = 
        new spec_search_pro::SetBasedSearchTask(
              param.specVar,param.setupPinlist,pCondition);
    }
    else //for fast_linear algorithm
    {
      //the optimal coarse stepwidth
      double coarseStepwidth = param.range/sqrt(param.range/param.stepwidth);
      //round coarse stepwidth to fine stepwidth
      coarseStepwidth = int(coarseStepwidth/param.stepwidth)*param.stepwidth;
      
      spec_search_pro::SetBasedSearchCondition* pCondition = 
        new spec_search_pro::SetBasedSearchCondition(
              param.start,param.stop,coarseStepwidth,param.burstPattern);  

      mpSetBasedTask = 
        new spec_search_pro::SetBasedSearchTask(
              param.specVar,param.setupPinlist,pCondition);
         
      //add sub-fine search conditions
      for (size_t i = 0; i < pCondition->getMeasuredPoints() -1; ++i)
      {
        double subStart = pCondition->getSpecValueByIndex(i) + param.stepwidth;
        double subStop = pCondition->getSpecValueByIndex(i+1) - param.stepwidth;
        ostringstream subBurstPattern;
        int sumOfIndex = mpSetBasedTask->generateSubSearchKeyByIndex(i,i+1);
        subBurstPattern << pCondition->getBurstName() << "_" << sumOfIndex;
        
        spec_search_pro::SetBasedSearchCondition* pSubCondition = 
          new spec_search_pro::SetBasedSearchCondition(
                subStart,subStop,param.stepwidth,subBurstPattern.str());
        
        mpSetBasedTask->addSubSearchCondition(sumOfIndex,pSubCondition);
      }
    }
  }
};

#endif /*SETBASEDSPECSEARCHTMUTIL_HPP_*/
