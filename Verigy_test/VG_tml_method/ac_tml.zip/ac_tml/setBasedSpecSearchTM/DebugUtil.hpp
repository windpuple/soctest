#ifndef DEBUGUTIL_HPP_
#define DEBUGUTIL_HPP_
#include <sstream>
#include <iostream>

#ifdef DEBUG_SEARCH
#define DebugOut(message) \
  if (DebugInfo::getInfoHandler().isDebugOn())\
  {\
    std::cout << "<Debug Info>" << message << std::endl;\
  }
#else
#define DebugOut(message)
#endif

#define TrainOut(message) \
  if (DebugInfo::getInfoHandler().isDebugOn())\
  {\
    std::cout << "<Training Info>" << message << std::endl;\
  }

#define ErrorOut(message) \
  if (DebugInfo::getInfoHandler().isDebugOn())\
  {\
    std::cerr << "<Error Info>" << message << std::endl;\
  }

#define WarnOut(message) \
  if (DebugInfo::getInfoHandler().isDebugOn())\
  {\
    std::cerr << "<Warning Info>" << message << std::endl;\
  }


/*
 * Set and get the flag of debuging information
 */
class DebugInfo
{
public:
  static DebugInfo& getInfoHandler()
  {
    static DebugInfo myInfo;
    return myInfo;
  }
  
  const bool isDebugOn()const
  {
    return mIsEnabled; 
  }
  
  void enableDebugInfo()
  {
    mIsEnabled = true;  
  }
  
  void disableDebugInfo()
  {
    mIsEnabled = false;  
  }

  
private:
  DebugInfo():mIsEnabled(false)
  {
    
  }
  ~DebugInfo()
  {
    
  }
private:
  bool mIsEnabled;
};
#endif /*DEBUGUTIL_HPP_*/
