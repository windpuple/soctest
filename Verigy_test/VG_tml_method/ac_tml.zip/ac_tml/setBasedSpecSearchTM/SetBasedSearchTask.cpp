#include "SetBasedSearchTask.hpp"
#include "PatternManager.h"
#include "EquationManager.hpp"
#include "DebugUtil.hpp"
#include "mapi.hpp"
#include "FW.h"
#include <cmath>

using namespace std;

namespace spec_search_pro {

string SetBasedSearchTask::msDefaultCLEVCTIMTemplateName = "_SetBasedSearchTask_ChangeSet_Template_";

//
//-----------------------------SetBasedSearchResult-----------------------
//
SetBasedSearchResult::SetBasedSearchResult()
{

}

SetBasedSearchResult::~SetBasedSearchResult()
{

}

const bool 
SetBasedSearchResult::isPassedOnSite(const int site)const
{
  bool isPass = false;
  map<int,SearchResult>::const_iterator itResult = mPerSiteResultMap.find(site);
  if (itResult != mPerSiteResultMap.end())
  {
    isPass = itResult->second.isTransitionFound;    
  }
  else
  {
    ostringstream errorMsg;
    errorMsg << "no such result on site[" <<site<<"]";
    throw Error("SetBasedSearchResult::isPassedOnSite()",
      errorMsg.str(),"SetBasedSearchResult::isPassedOnSite()");
  }
  
  return isPass;
}

const bool 
SetBasedSearchResult::isPassToFailOnSite(const int site)const
{
  bool isP2F = false;
  map<int,SearchResult>::const_iterator itResult = mPerSiteResultMap.find(site);
  if (itResult != mPerSiteResultMap.end())
  {
    isP2F = itResult->second.isPassToFail;    
  }
  else
  {
    ostringstream errorMsg;
    errorMsg << "no such result on site[" <<site<<"]";
    throw Error("SetBasedSearchResult::isPassToFailOnSite()",
      errorMsg.str(),"SetBasedSearchResult::isPassToFailOnSite()");
  }
  
  return isP2F;  
}

double 
SetBasedSearchResult::getPassValueOnSite(const int site)const
{
  double pValue = 0;
  map<int,SearchResult>::const_iterator itResult = mPerSiteResultMap.find(site);
  if (itResult != mPerSiteResultMap.end())
  {
    pValue = itResult->second.passValue;    
  }
  else
  {
    ostringstream errorMsg;
    errorMsg << "no such result on site[" <<site<<"]";
    throw Error("SetBasedSearchResult::getPassValueOnSite()",
      errorMsg.str(),"SetBasedSearchResult::getPassValueOnSite()");
  }
  
  return pValue;  
}

double 
SetBasedSearchResult::getFailValueOnSite(const int site)const
{
  double fValue = 0;
  map<int,SearchResult>::const_iterator itResult = mPerSiteResultMap.find(site);
  if (itResult != mPerSiteResultMap.end())
  {
    fValue = itResult->second.failValue;    
  }
  else
  {
    ostringstream errorMsg;
    errorMsg << "no such result on site[" <<site<<"]";
    throw Error("SetBasedSearchResult::getFailValueOnSite()",
      errorMsg.str(),"SetBasedSearchResult::getFailValueOnSite()");
  }
  
  return fValue;  
}

//
//-----------------------------SetBasedSearchCondition--------------------
//
SetBasedSearchCondition::SetBasedSearchCondition(
  double start, double stop, double stepWidth, const string& burst)
:mStart(start),mStop(stop),mStepWidth(stepWidth),mStep(0),mBurstName(burst)
{
  mSpecValueVector.clear(); 
  double specValue = mStart;
  for(specValue = mStart; specValue <= mStop; specValue += mStepWidth)
  {
	  mSpecValueVector.push_back(specValue);
  }
  
  //correct the last mesurement point with stop value
  double& lastValue = mSpecValueVector[mSpecValueVector.size()-1];
  if (mStop - lastValue < mStepWidth/2)
  {
	  lastValue = mStop;
  }
  else if (specValue - mStop < mStepWidth/2)
  {
    //--------------------mStop
    //---lastValue----------*-----specValue
    //add one more which is valid for measurement
    mSpecValueVector.push_back(mStop);
  }
}

SetBasedSearchCondition::~SetBasedSearchCondition()
{
}

double 
SetBasedSearchCondition::getSpecValueByIndex(const int index) const
{
  double value = 0;
  if (size_t(index) < mSpecValueVector.size())
  {
    value = mSpecValueVector[index];
  }
  else
  {
    ostringstream errorMsg;
    errorMsg << "index <"<<index<<"> is out of range [0,"<<mSpecValueVector.size()-1<<"].";

    throw Error("SetBasedSearchCondtion::getSpecValueByIndex()",
      errorMsg.str(),"SetBasedSearchCondtion::getSpecValueByIndex()");
  }
  return value;
}

void
SetBasedSearchCondition::dumpInfo() const
{
  cout << "pattern: " << mBurstName
       << "\nrange: [" << mStart << "," << mStop << "], stepwidth = " << mStepWidth
       << "\n" << getMeasuredPoints() << " measurement at points: ";
  
  for (vector<double>::size_type i = 0; i < mSpecValueVector.size(); ++i)
  {
    cout << mSpecValueVector[i] << "  ";
  }
  cout << "\n" << endl;
}

//
//-----------------------------SetBasedSearchTask--------------------
//
SetBasedSearchTask::SetBasedSearchTask(const testmethod::SpecVariable& specVar, 
    const string& setupPins, SetBasedSearchCondition*  pCond)
:mSearchKeyBase(1000),mSpecVar(specVar),mSetupPinlist(setupPins)
{
  if (pCond == 0)
  {
    throw Error("SetBasedSearchTask",
      "constructor error: null pointer of search condition.","SetBasedSearchTask");
  }

  static map<string, string> sPinPortMap;
  if (sPinPortMap.empty())
  {
    fwout << "DFPT? (@@)" << endl;
    for (size_t iResult = 0; iResult < fwresult.size(); ++iResult)
    {
      string pinlist = fwresult[iResult][0];
      string port = fwresult[iResult][1];
      vector<string> pinVector = 
        PinUtility.getDigitalPinNamesFromPinList(pinlist,TM::ALL_DIGITAL);
      for (vector<string>::size_type iPin = 0; iPin < pinVector.size(); ++iPin)
      {
        sPinPortMap.insert(make_pair(pinVector[iPin], port));
      } 
    }
  }

  //check the consistency between setup pin and port 
  vector<string> setupPinVector;
  if (!mSetupPinlist.empty() && mSetupPinlist != "@")
  {
    setupPinVector = PinUtility.getDigitalPinNamesFromPinList(mSetupPinlist,TM::ALL_DIGITAL);
  }
  bool isPinInSamePort = true;
  string portnameFromPin;
  for (vector<string>::const_iterator pinIt = setupPinVector.begin(); 
       pinIt != setupPinVector.end(); ++pinIt)
  {
    map<string,string>::const_iterator mapIt = sPinPortMap.find(*pinIt);
    if (mapIt != sPinPortMap.end())
    {
      if (portnameFromPin.empty())
      {
        portnameFromPin = mapIt->second;
      } 
      else if (portnameFromPin != mapIt->second)
      {
        isPinInSamePort = false;
        break;
      }
      else
      {
        continue;
      }
    }
    else
    {
      isPinInSamePort = false;
      break;
    }
  }
  
  if (!isPinInSamePort)
  {
    throw Error("SetBasedSearchTask",
      "pins among setupPinlist belong to different port.","SetBasedSearchTask");
  }
   
  mIndexBurstMap.insert(make_pair(0,pCond->getBurstName()));
  mBurstConditionMap.insert(make_pair(pCond->getBurstName(),pCond));
  mpParentCondition = pCond;
  
  /*
   *-----------detect multi-port based search---------
   *for timing, this requires: multi-port equation setup and multi-port burst pattern
   *for level, this requires: multi-port burst pattern
   */
  mIsMultiPort = false;
  string::size_type pos = mSpecVar.mName.find("@");
  //multi-port and spec var is local definition for this port.
  if (pos != string::npos) 
  {
    mSpecName = mSpecVar.mName.substr(0,pos);
    mPortName = mSpecVar.mName.substr(pos+1,mSpecVar.mName.size()-pos-1);
    mIsMultiPort = (mPortName != "@");
  }
  else
  {
    mSpecName = mSpecVar.mName;
    mPortName = "@";
  }

  if (!portnameFromPin.empty() && mPortName != portnameFromPin)
  {
    throw Error("SetBasedSearchTask",
      "the port name of spec variable is not consistent with port of setup pinlist.",
      "SetBasedSearchTask");
  }
}

SetBasedSearchTask::~SetBasedSearchTask()
{
  cleanUp();
}

void
SetBasedSearchTask::addSubSearchCondition(const int sumOfIndex, SetBasedSearchCondition* pSubCondition)
{
  if (pSubCondition == 0)
  {
    throw Error("SetBasedSearchTask::addSubSearchCondition()","null pointer of sub search condition",
      "SetBasedSearchTask::addSubSearchCondition()"); 
  }
  
  if (sumOfIndex <= 0)
  {
    throw Error("SetBasedSearchTask::addSubSearchCondition()","sum of index must be larger than zero",
      "SetBasedSearchTask::addSubSearchCondition()");
  }

  //cache it 
  mIndexBurstMap.insert(make_pair(sumOfIndex,pSubCondition->getBurstName()));
  mBurstConditionMap.insert(make_pair(pSubCondition->getBurstName(),pSubCondition));
}

void
SetBasedSearchTask::dumpInfo() const
{
  cout << "**search information**" << endl;
  for (map< string, const SetBasedSearchCondition* >::const_iterator it = mBurstConditionMap.begin();
       it != mBurstConditionMap.end();
       ++it)
  {
    it->second->dumpInfo();
  }
  
  cout << "**pattern per site informaion**" << endl;
  for (map< int, const string>::const_iterator it = mSiteBurstMap.begin();
       it != mSiteBurstMap.end();
       ++it)
  {
    cout << "site: " << it->first << ", pattern: \"" << it->second << "\"\n";
  }

}

int
SetBasedSearchTask::generateNewSetups(
    const SetBasedSearchCondition& condition,
    EquationManager& theEquationManager,
    const string& burstPattern,
    const string& templatePatternOf_CLEV_CTIM,
    const vector<string>& normalSearchPatternVector,
    const string& ctimclevCommand,
    const int setNumberOffset,
    const MultiPortInfo& mpInfo)
{
  static string funcName = "SetBasedSearchTask::generateNewSetups()";
  //do training for self
  vector<string> labelSeqInNewBurst;
  int lastSetNumber = setNumberOffset;
  
  //for each measurement point, create new set and pattern
  for (size_t i = 0; i < condition.getMeasuredPoints(); ++i)
  {       
    ++lastSetNumber;
    double specValue = condition.getSpecValueByIndex(i);
    
    theEquationManager.defineSet(lastSetNumber,specValue);
         
    string newCTIMCLEVLabelName = 
      defineSearchLabelName(burstPattern,specValue);

    //preparse labels to be called in burst.
    labelSeqInNewBurst.push_back(newCTIMCLEVLabelName);        
    labelSeqInNewBurst.insert(labelSeqInNewBurst.end(),
      normalSearchPatternVector.begin(),normalSearchPatternVector.end());
               
    if(!PatternManager::isPatternAvailable(newCTIMCLEVLabelName))
    {
      PatternManager::copyLabel(templatePatternOf_CLEV_CTIM, newCTIMCLEVLabelName);          
      if (!PatternManager::changeSetNumberForLabel(newCTIMCLEVLabelName,lastSetNumber,
        ctimclevCommand,mPortName))
      {
        throw Error(funcName,
          "there is no \""+ctimclevCommand+"\" defined in template pattern \""
            + templatePatternOf_CLEV_CTIM+"\".",
          funcName);
      }
    }
    else
    {
      throw Error(funcName,
        "label \"" + newCTIMCLEVLabelName + "\" is already created/loaded.",
        funcName);     
    }
  }
  
  const string& newBurstPattern = condition.getBurstName();
  if (mIsMultiPort)
  {
    map<string,string>::const_iterator iPortSync;
    map<string,vector<string> >::const_iterator iPortLabels;
    for (vector<string>::const_iterator iPort = mpInfo.ports.begin();
         iPort != mpInfo.ports.end() && 
           iPortSync != mpInfo.portSyncGroupMap.end() && 
           iPortLabels != mpInfo.portLabelsMap.end();
         ++iPort)
    { 
      iPortSync = mpInfo.portSyncGroupMap.find(*iPort);
      iPortLabels = mpInfo.portLabelsMap.find(*iPort);
      const string& syncGroup = iPortSync->second;
      if (*iPort == mPortName)
      {
        //use new labels which replace old labels for this target port
        PatternManager::createBurst(newBurstPattern,labelSeqInNewBurst,syncGroup,mPortName,false);
      }
      else
      {
        //use existing labels for this non-target port as original
        PatternManager::createBurst(newBurstPattern,iPortLabels->second,syncGroup,*iPort,false);
      }
    }
  }
  else
  {
    PatternManager::createBurst(newBurstPattern,labelSeqInNewBurst,"",mPortName);
  }
 
  DebugOut("++++++++++++"<<"create burst ["<<burstPattern<<"]"<<"++++++++++++");

  return lastSetNumber;
}

void
SetBasedSearchTask::prepareEquationSetup(EquationManager& theEquationManager)
{
  const static string funcName = "SetBasedSearchTask::prepareEquationSetup()";
  //to get target equation set number  
  int targetEquationNum = 1;
  istringstream eqIdStream(mSpecVar.mEquationSetId);
  eqIdStream >> targetEquationNum; 

  if (targetEquationNum <= 0)
  {
    throw Error(funcName,
      "please specify equation id number in spec value field",
      funcName);
  }
  
  //to get target set number
  int targetSetNum = 1;
  if (mSpecVar.mType == "LEV")
  {
    targetSetNum = EquationManager::getPrimaryLevelSetNum();
  }
  else
  {
    if (mIsMultiPort)
    {
      targetSetNum = EquationManager::getPrimaryTimingSetNum(mPortName);
    }
    else
    {
      targetSetNum = EquationManager::getPrimaryTimingSetNum();
    }
  }

  int numberOfUnusedSet = 0;
  int configuredSet = 0;
  if (mSpecVar.mType=="LEV")
  {
    configuredSet = theEquationManager.getConfiguredLevelSetNum();
    numberOfUnusedSet =  configuredSet - theEquationManager.getUsedLevelSetNum();
  }
  else
  {
    configuredSet = theEquationManager.getConfiguredTimingSetNum();
    numberOfUnusedSet = configuredSet - theEquationManager.getUsedTimingSetNum();
  }
  
  int requiredNewSet = 0;
  for (map<string, const SetBasedSearchCondition*>::const_iterator it = mBurstConditionMap.begin();
       it != mBurstConditionMap.end(); ++it)
  {
    requiredNewSet += it->second->getMeasuredPoints();
  }

  if (mSpecVar.mType=="LEV")
  {
    requiredNewSet = requiredNewSet * EquationManager::getSpecSetNumOfEquation(targetEquationNum);
  }
 
  if (requiredNewSet > numberOfUnusedSet)
  {
    ostringstream errorMsg;
    errorMsg << "the required sets are more than the unused: "
             << requiredNewSet << "(required sets)" 
             << " > "
             << numberOfUnusedSet << "(unused sets)"
             << " , "
             << configuredSet << "(configured sets).";
    throw Error(funcName,errorMsg.str(),funcName);
  }

  //configure equation manager
  theEquationManager.configEquationManager(mSetupPinlist,mSpecName,mSpecVar.mType);
 
  //upload and parse equation setup
  theEquationManager.doUploadAndParse(targetEquationNum,targetSetNum);  
}

void
SetBasedSearchTask::preparePatternSetup(
  const string& burstPattern,
  const string& actualTemplatePatternOf_CLEV_CTIM, 
  MultiPortInfo& mpInfo)
{
  const static string funcName = "SetBasedSearchTask::preparePatternSetup()";

  //check target burst pattern
  if (PatternManager::isPatternAvailable(burstPattern))
  {
    throw Error(funcName,
      "the new burst pattern \""+burstPattern+"\" is already created/loaded."
      "\nplease specify another name."
      ,funcName);
  }
 
  //check template pattern for changing set
  if (PatternManager::isPatternAvailable(actualTemplatePatternOf_CLEV_CTIM))
  {
    if (!PatternManager::isMainPattern(actualTemplatePatternOf_CLEV_CTIM))
    {
      throw Error(funcName,
        "the template pattern of calling CTIM/CLEV \""+actualTemplatePatternOf_CLEV_CTIM+"\" is not a main label.",
        funcName);
    }
  }
  else // to create
  {
    throw Error(funcName,
      "the template pattern of calling CTIM/CLEV \""+actualTemplatePatternOf_CLEV_CTIM+"\" is not available.",
      funcName);
  }

  //get multiport information (multi-port pattern works for level too.)
  if (mIsMultiPort)
  {
    mpInfo.mpPattern = Primary.getLabel(); 
    if (PatternManager::isPatternAvailable(mpInfo.mpPattern) && PatternManager::isMultiport(mpInfo.mpPattern))
    {     
      if (PatternManager::getPortsOfMPPattern(mpInfo.mpPattern,mpInfo.ports) > 0)
      {
        string syncGroup;
        vector<string> labels;
        for (vector<string>::iterator iPort = mpInfo.ports.begin(); iPort != mpInfo.ports.end(); ++iPort)
        {
          if (PatternManager::getMultiPortBurstInfo_ByPort(mpInfo.mpPattern,*iPort,labels,syncGroup) > 0)
          { 
            mpInfo.portLabelsMap.insert(make_pair(*iPort,labels));
            mpInfo.portSyncGroupMap.insert(make_pair(*iPort,syncGroup));
          }
          else
          {
            throw Error(funcName,
              "cannot get information of multiport pattern \""+mpInfo.mpPattern+"\".",
              funcName);
          }
        }
      }
      else
      {
        throw Error(funcName,
          "cannot get port names of multiport pattern \""+mpInfo.mpPattern+"\".",
          funcName);
      }
    }
    else
    {
      throw Error(funcName,"the multiport pattern \""+mpInfo.mpPattern+"\" is invalid.",
        funcName);
    }

    //check the port consistency between CTIM/CLEV pattern and target port(i.e. mPortName)
    string portOfTemplatePattern;
    PatternManager::getPortOfPattern(actualTemplatePatternOf_CLEV_CTIM,portOfTemplatePattern);

    if (mPortName.compare(portOfTemplatePattern) != 0)
    {
      throw Error(funcName,
        "port name of \"" +actualTemplatePatternOf_CLEV_CTIM+"\" ("+portOfTemplatePattern
        +") is not consistent with the port of spec variable (" + mPortName + ")",
        funcName);
    }
  }  
}

void
SetBasedSearchTask::doTraining(const string& templatePatternOf_CLEV_CTIM)
{  
  static string funcName = "SetBasedSearchTask::doTraining()";
  
  //setup pattern
  if (mIndexBurstMap.empty())
  {
    throw Error(funcName,
      "search contion is not defined yet for this set-based search task",
      funcName); 
  }  
  const string& highLevelBurstName = mIndexBurstMap[0];
  string actualTemplatePatternOf_CLEV_CTIM = templatePatternOf_CLEV_CTIM;

  vector<string> normalSearchPatternVector;
  MultiPortInfo mpInfo;
  preparePatternSetup(highLevelBurstName,templatePatternOf_CLEV_CTIM,mpInfo);
 
  if (mIsMultiPort)
  {
    map<string,vector<string> >::const_iterator it = mpInfo.portLabelsMap.find(mPortName);
    if (it != mpInfo.portLabelsMap.end())
    {
      normalSearchPatternVector = it->second;
    } 
    else
    {
      throw Error(funcName,
        "the port name is not defined in multi-port burst pattern \"" + mpInfo.mpPattern + "\"",
        funcName);
    }
  } 
  else 
  {
    string pattern = Primary.getLabel();
    if (!PatternManager::isMultiport(pattern))
    {
      normalSearchPatternVector.push_back(pattern);
    }
    else
    {
      throw Error(funcName,
        "primary label is multi-port pattern, please specify port name for the parameter of \"specVar\"",
        funcName);
    } 
  }

  //setup equation manager
  EquationManager theEquationManager;
  prepareEquationSetup(theEquationManager);
  int setNumberOffset = theEquationManager.getMaxSetNumOfCurrentEquationSet();
  
  //generate setups 
  string ctimclevCommand = (mSpecVar.mType=="LEV")?"CLEV":"CTIM";
  map<string, const SetBasedSearchCondition*>::const_iterator 
   itCondition = mBurstConditionMap.find(highLevelBurstName);
  if (itCondition != mBurstConditionMap.end())
  {
    const SetBasedSearchCondition* pCond = itCondition->second;
    setNumberOffset = generateNewSetups(*pCond,
      theEquationManager,
      highLevelBurstName,
      actualTemplatePatternOf_CLEV_CTIM,
      normalSearchPatternVector,
      ctimclevCommand,
      setNumberOffset,
      mpInfo);
  }
  else 
  {
    throw Error(funcName,
      "no such search condition with burst of \""+highLevelBurstName+"\"",funcName); 
  }

  //training for sub search 
  map<int,const string>::const_iterator itIndexBurst = mIndexBurstMap.begin();
  for(++itIndexBurst; itIndexBurst != mIndexBurstMap.end(); ++itIndexBurst)
  {
    const string& subBurstName = itIndexBurst->second;
    itCondition = mBurstConditionMap.find(subBurstName);
    if (itCondition != mBurstConditionMap.end())
    {
      const SetBasedSearchCondition* pCond = itCondition->second;
      setNumberOffset = generateNewSetups(*pCond,
        theEquationManager,
        subBurstName,
        actualTemplatePatternOf_CLEV_CTIM,
        normalSearchPatternVector,
        ctimclevCommand,
        setNumberOffset,
        mpInfo);
    }
    else 
    {
      throw Error(funcName,
        "no such search condition with burst of \""+subBurstName+"\"",funcName); 
    }
  } 
  //download modified level equation
  theEquationManager.downloadEquation();
 
  //flush primary label change
  Primary.label(highLevelBurstName);
  FLUSH();
}

const bool 
SetBasedSearchTask::getPassFail() const
{
  return mSearchResultOnAllSites.isPassedOnSite(CURRENT_SITE_NUMBER());  
}

double 
SetBasedSearchTask::getPassValue()const
{
  return mSearchResultOnAllSites.getPassValueOnSite(CURRENT_SITE_NUMBER());  
}

double 
SetBasedSearchTask::getFailValue()const
{
  return mSearchResultOnAllSites.getFailValueOnSite(CURRENT_SITE_NUMBER());
}

const SetBasedSearchCondition* 
SetBasedSearchTask::getSearchConditionByBurstName(const string& burst) const
{
  const SetBasedSearchCondition* pCond = 0;
  const static string 
    funcName = "SetBasedSearchTask::getSearchConditionByBurstName()"; 

  map<string, const SetBasedSearchCondition* >::const_iterator it = 
    mBurstConditionMap.find(burst);
  
  if (it != mBurstConditionMap.end())
  {
    pCond = it->second;
  }
  else
  {
    throw Error(funcName,
      "cannot find search condition by burst name \""+burst+"\"",
      funcName); 
  }
  
  return pCond;   
}

const SetBasedSearchCondition* 
SetBasedSearchTask::getSearchConditionBySite(const int site) const
{
  const SetBasedSearchCondition* pCond = 0;
  const static string funcName = "SetBasedSearchTask::getSearchConditionBySite()";
  map<int,const string>::const_iterator it = mSiteBurstMap.find(site);
  if (it != mSiteBurstMap.end())
  {
    pCond = getSearchConditionByBurstName(it->second);
  }
  
  if (pCond == 0)
  {
    ostringstream errorMsg;
    errorMsg << "cannot find search condition by site ["<<site<<"].";
    throw Error(funcName,errorMsg.str(),funcName);
  }
  
  return pCond;  
}

/*
 *----------------------------------------------------------------------*
 * Routine: doSearch
 *
 * Purpose: execute set-based search
 *
 *----------------------------------------------------------------------*
 * Description:
 *   judge results of 'result' with pass limits from 'param'
 * 
 *   INPUT:  param       - test parameters
 *           result      - result container
 *   OUTPUT: 
 *   RETURN: 
 * Note:
 *   this function must be called in ON_FIRST_INVOCATION_BEGIN/END block.
 *----------------------------------------------------------------------*
 */
void
SetBasedSearchTask::doSearch()
{
  mSearchResultOnAllSites.cleanUpAllResults();
  
  //firstly, execute with first-level search condition
  string fwAnswer;
  ostringstream firstRunCmdStr;
  
  if (mIsMultiPort)
  {
    //multiport case
    firstRunCmdStr << "DCRM OVEM,LMAP,,(@@)\n" << "FTST?\n";
  }
  else
  {
    firstRunCmdStr << "DCRM OVEM,LMAP,,(@)\n" << "FTST?\n";    
  }
  
  FOR_EACH_SITE_BEGIN();
    firstRunCmdStr << "PQFC " << CURRENT_SITE_NUMBER() << "\n"
      <<"ERMP? LMAP,0," << mpParentCondition->getMeasuredPoints()*2 
      << ",,(" << mPortName << ")\n";              
  FOR_EACH_SITE_END();
  
  //execute the first-level linear search
  FW_TASK (firstRunCmdStr.str(),fwAnswer);

  //get and process result for each site
  string::size_type offsetOfERMP = 0;
  FOR_EACH_SITE_BEGIN();
    offsetOfERMP = processResult(fwAnswer,CURRENT_SITE_NUMBER(),mpParentCondition,offsetOfERMP);      
  FOR_EACH_SITE_END();

  //do search for sub search objects if number of burst is more than 1.
  if (mIndexBurstMap.size() > 1) 
  {   
    ostringstream secondRunCmdStr;
    //set search pattern for each site
    secondRunCmdStr <<"SQSL \""<<mIndexBurstMap[0]<<"\"\n";
    FOR_EACH_SITE_BEGIN();
      int site = CURRENT_SITE_NUMBER();
      secondRunCmdStr << "SQSL \"" << mSiteBurstMap[site] <<"\","<<site<<"\n";
    FOR_EACH_SITE_END();
    
    secondRunCmdStr << "APRM CNL\n" << "FTST?\n";
    
    //query result commands
    FOR_EACH_SITE_BEGIN();
      int site = CURRENT_SITE_NUMBER();
      secondRunCmdStr<<"PQFC "<<site<<"\n"
        << "ERMP? LMAP,0,"
        << getSearchConditionBySite(site)->getMeasuredPoints()*2 
        << ",,(" << mPortName << ")\n";
    FOR_EACH_SITE_END();
   
    //execute all commands for sub search
    FW_TASK(secondRunCmdStr.str(),fwAnswer);

    //get and process result for each site
    offsetOfERMP = 0;
    FOR_EACH_SITE_BEGIN();
      int site = CURRENT_SITE_NUMBER();
      const SetBasedSearchCondition* pCond = getSearchConditionBySite(site);
      offsetOfERMP = processResult(fwAnswer,site,pCond,offsetOfERMP);        
    FOR_EACH_SITE_END();
  }
  //restore error map mode
  FW_TASK("DCRM OVEM,FCM,,(@@)\n");
}

    
string::size_type 
SetBasedSearchTask::processResult(const string& fwAnswer, 
  const int site, 
  const SetBasedSearchCondition* pCond, 
  const string::size_type offsetOfERMP)
{ 
  string::size_type returnPos = offsetOfERMP; 
  string::size_type bDataPos = fwAnswer.find("ERMP",offsetOfERMP);
  int bytes = 0;
  string data;
  if (bDataPos != string::npos) 
  {
    bDataPos = fwAnswer.find("#",bDataPos+4);
    istringstream lenOfData(fwAnswer.substr(bDataPos+1,1));
    int len;
    lenOfData>>len;
    bDataPos += 2;
    istringstream numOfBytes(fwAnswer.substr(bDataPos,len));

    numOfBytes>>bytes;
 
    //to read out the binay code of functional result of each labels.
    //0: pass, 1: fail
    bDataPos += len;
    data = fwAnswer.substr(bDataPos,bytes);
    //processResult(data,bytes,site,pCond); 
  } 
  
  returnPos += bDataPos;
  
  if (data.empty())
  {
    SetBasedSearchResult::SearchResult theResult;
    mSearchResultOnAllSites.setResultOnSite(site,theResult);
    mSiteBurstMap.insert(make_pair(site,pCond->getBurstName()));
    return returnPos;
  }
   
  /* because the CTIM/CLEV label is executed before search label 
   * and assume it doesn't contribute to functional result,
   * always process two bits (via value&0x01) at the same time.
   * STEPS: 
   *(1)process the first two highest bits of first byte, to know
   *   starting status of label result sequence.
   *(2)compare with the following each two bits, if result is different,
   *   transition is found.
   *(3)according to the starting status, find out the correct spec value 
   *   of passing label with correct CTIM/CLEV #, by the following equation:
   *   spec_value = mSpecValueVector[index-of-CTIM/CLEV-label/2] 
   */

  int indexOfTransitionInBurst = 0;
  size_t checkedPoints = 0;
  unsigned char status = data[0];
  unsigned char pf = (status>>6) & 0x01;
  
  SetBasedSearchResult::SearchResult theResult;
  theResult.isTransitionFound = false;
  theResult.isPassToFail = (pf == 0x00);
  
  /*
   * HOW TO find transition index of CTIM/CLEV label in the burst:
   * e.g. 
   * assume that the burst pattern consists of "CLEV,func,CLEV,func,..." label sequence
   * the test result:   "00 00 00 01"
   * index of labels:    01 23 45 67
   * ==>
   * transition index of 6 from equation of "byte*8 + (7-bit) -1 "
   * 
   */
  bool toStop = false;
  for(int byte = 0; byte < bytes && !toStop; ++byte)
  {
    unsigned char ch = data[byte];
    for (int i = 3; i >= 0; --i)
    {
      int bit = i*2;
      if (++checkedPoints > pCond->getMeasuredPoints())
      {
    	toStop = true;
    	break;
      }
      else if (pf != ((ch>>bit) & 0x01))            
      { 
        //index of CTIM/CLEV label, starting from zero   
        indexOfTransitionInBurst = byte*8 + (7-bit) -1 ;
        theResult.isTransitionFound = true;
        toStop = true;
        break;
      } //if transition happen
    } //for 4 2-bits in each byte
  } //for all bytes
  
  //record test status at current site
  if(theResult.isTransitionFound)
  {
    int passIndex = 0;
    int failIndex = 0;
    //the real index in SpecValueVector should be indexOfTransition/2
    if (theResult.isPassToFail)
    {
      passIndex = indexOfTransitionInBurst/2 - 1;
      failIndex = indexOfTransitionInBurst/2;
    }
    else
    {
      passIndex = indexOfTransitionInBurst/2;
      failIndex = indexOfTransitionInBurst/2 - 1;
    }
    theResult.passValue = pCond->getSpecValueByIndex(passIndex);
    theResult.failValue = pCond->getSpecValueByIndex(failIndex);

    //set lable for site    
    int subKey = generateSubSearchKeyByIndex(passIndex,failIndex);
    map<int , const string>::const_iterator itBurst = mIndexBurstMap.find(subKey);
    if (itBurst != mIndexBurstMap.end())
    {
      //means there are sub-search, and it will be applied to this site in next search.
      mSiteBurstMap.insert(make_pair(site,itBurst->second));
    }
    else
    {
      mSiteBurstMap.insert(make_pair(site,pCond->getBurstName()));
    }
  }
  else
  {
    /*in case of two-step, the final search result should be combinded together, as followed:
     *                  <CASE 1: current search- ALL PASS>
     * previouse search result:   F    P     |     P    F
     * current search result  :    PPPP      |      PPPP  
     * final result        :      FP         |         PF
     * 
     *                  <CASE 2: current search - ALL FAIL>
     * previouse search result:   F    P     |     P    F   
     * current search result  :    FFFF      |      FFFF          
     * final result        :          FP     |     PF    
     *   
     */
    if (pCond != mpParentCondition && mSearchResultOnAllSites.isPassedOnSite(site))
    {
      //the final search still is good
      theResult.isTransitionFound = true;
      if (mSearchResultOnAllSites.isPassToFailOnSite(site)) //P -> F in corase search
      {
         if (theResult.isPassToFail) //PPPP in fine search
         {
           theResult.passValue = pCond->getSpecValueByIndex(pCond->getMeasuredPoints()-1);
           theResult.failValue = mSearchResultOnAllSites.getFailValueOnSite(site);
         }
         else //FFFF in fine search
         {
           theResult.passValue = mSearchResultOnAllSites.getPassValueOnSite(site);
           theResult.failValue = pCond->getSpecValueByIndex(0);
         }
      }
      else // F -> P in corase search
      {
        if (theResult.isPassToFail) //PPPP in fine search
        {
          theResult.passValue = pCond->getSpecValueByIndex(0);
          theResult.failValue = mSearchResultOnAllSites.getFailValueOnSite(site);
        }
        else //FFFF in fine search
        {
          theResult.passValue = mSearchResultOnAllSites.getPassValueOnSite(site);
          theResult.failValue = pCond->getSpecValueByIndex(pCond->getMeasuredPoints()-1);
        }
      }
    }
    else
    {
      //record the burst of coarse search for this site
      mSiteBurstMap.insert(make_pair(site,pCond->getBurstName()));
      theResult.passValue = NAN;
      theResult.failValue = NAN;
    }
  }
  
  mSearchResultOnAllSites.setResultOnSite(site,theResult);
  
  //debug out
  DebugOut("search result for site["<<site<<"]:"
      <<"\ntransition was found: "<<(theResult.isTransitionFound?"yes":"no")
      <<"\ntransition index : "<<indexOfTransitionInBurst/2
      <<"\npass value: "<<theResult.passValue
      <<"\nfail value: "<<theResult.failValue);
  
  return returnPos;
}

};
