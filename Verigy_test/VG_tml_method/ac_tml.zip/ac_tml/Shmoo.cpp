/**
 * (c) Copyright 2011, Verigy Technologies, all rights reserved.
 *
 * Modification History:
 *
 *
 */

//for testmethod API interfaces
#include "mapi.hpp"
#include "AbstractShmoo.hpp"
using namespace std;

/**
 *----------------------------------------------------------------------*
 * @Testmethod Class: Shmoo
 *
 * @Purpose: 
 *
 *----------------------------------------------------------------------*
 * @Description:
 *
 * @Parameters:  1. string title :
 *                  used to display as the title in the graphic Shmoo Plot
 *               2. string parameterTypeX : 
 *                  the parameter type used on the X axis of the Shmoo.
 *                  its options are supported parameterTypes on X axis. Currently
 *                  supported parameter types are: 
 *                    SpecVariable, 
 *                    Bist Resource,
 *                    HX Resource,
 *                    HX Instrument. 
 *               3. testmethod::SpecVariable specX  
 *                  specifies the spec variable's name and its type {TIM or LEV} 
 *                  to be varied for the X axis
 *               4. string setupPinsX : optional
 *                  the selected spec resource for the X axis is only shifted
 *                  for these pins; default value is "@".
 *               5. string instrumentPinX
 *                  digital pin name connected to a HighSpeedExtension lane. This
 *                  parameter is only visible when parameterTypeX is HX Instrument.
 *               6. string resourceNameX
 *                  name of a BistAssist or HighSpeedExtension resource. This parameter
 *                  is only visbile when parameterTypeX is "Bist Resource" or "HX Resource".
 *               7. string propertyX 
 *                  properties of a Bist Assist/HighSpeedExtension board or resource, 
 *                  following properties are supported:
 *                    DriverLow
 *                    DriverHigh
 *                    ReceiverThreshold
 *                    TerminationVoltage
 *                    ModulationJitterAmplitude
 *                    ModulationFrequency
 *                    ModulationCommonModeAmplitude
 *                    DriverFineDelay (HighSpeedExtension only)
 *                    ReceiverFineDelay(HighSpeedExtension only)
 *                   This parameter is visbile only when parameterTypeX is Bist Resource,
 *                   HX Resource or HX Instrument.
 *               8. string unitX:
 *                  it is limited to following lists: Hz, kHz, MHz, mV, V, fs, ps, ns, us, ms, s
 *                  (In this way values are converted to SI units. e.g kHz => 1E3 Hz).
 *                  This parameter is visbile only when parameterTypeX is Bist Resource, 
 *                  HX Resource or HX Instrument.
 *               9. double startX
 *                   start value for the X axis.
 *               10.double stopX
 *                   stop value for the X axis.
 *               11. string stepX
 *                   defines the resolution of the resource on X axis. It can be expressed as:
 *                    "0.1"  the step width is 0.1.
 *                    "#10"  the totalStep are 10 and thus linearStep is 1 (linear mode).
 *                    "f#10" the totalStep are 10 and linearStep is 4(fast mode).
 *                    "#<20>/<2>" the totalStep is 20 and linearStep is 2(binary mode).
 *               12. string scaleX: 
 *                   Linear scale or logarithmic scale. 
 *                   Default:  linear scale.
 *               13. parameterTypeY
 *                   see parameterTypeX
 *               14. specY
 *                   see specX
 *               15. setupPinsY
 *                   see setuppinsX
 *               16. instrumentPinY
 *                   see instrumentPinX
 *               17. resourceNameY
 *                   see resourceNameX
 *               18. propertyY
 *                   see propertyX
 *               19. unitY
 *                   see unitX
 *               20. startY
 *                   see startX
 *               21. stopY
 *                   see stopX
 *               22. stepY
 *                   see stepY
 *               23. scaleY
 *                   see scaleX
 *               24. string resultPinlist
 *                   Defines a list of pins/pin groups that contribute to the pass/fail result
 *                   valid type : O,IO
 *               25. string testMode
 *                   The following test modes can be set:
 *                    pass/fail
 *                    first failing cycle
 *                    cycle error count
 *                    edge error cout
 *                   Default: pass/fail        
 *----------------------------------------------------------------------*
 */

class Shmoo: public AbstractShmoo
{

protected:

  /*X Axis*/
  string parameterTypeX;

  testmethod::SpecVariable specX;
  string setupPinsX;


  string instrumentPinX;
  string resourceNameX;
  string propertyX;
  string unitX;

  /*Y Axis*/
  string parameterTypeY;

  testmethod::SpecVariable specY;
  string setupPinsY; 

  string instrumentPinY;
  string resourceNameY;
  string propertyY;
  string unitY;

  string resultPins;
  string testMode;   

private:
  /* represents ShmooParameter on X axis.*/
  ShmooParameter* mpParameterX;
  /* represents ShmooParameter on Y axis.*/
  ShmooParameter* mpParameterY;
  /* indicate whether the shifted resource on X axis and y axis are both SpecVariable*/
  bool mIsAllSpec;
  /* used to change spec variables' value when mIsAllSpec is true*/
  ShmooSpec mShmooSpec;
  /* indicate shmoo measurement */
  ShmooMeasurement* mpMeasurement;

  /* general description*/
  string mDescription;
  /* description for X axis*/
  string mXAxisDescription;
  /* description for Y axis*/
  string mYAxisDescription;
  /* short name for X axis*/
  string mXAxisShortName;
  /* short name for Y axis*/
  string mYAxisShortName;
  /* unit for X axis*/
  string mXAxisUnit;
  /* unit for Y axis*/
  string mYAxisUnit;
  /* setup pins for X axis*/
  string mXAxisSetupPins;
  /* setup pins for Y axis*/
  string mYAxisSetupPins;
protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   *
   *Note: TestMethod API should not be used in this method.
   */
  virtual void initialize()
  {
    /*First call the initialize() in class AbstractShmoo to add parameters
     *common to all Shmoo.i.e. title, x.start, x.stop, x.step, x.scale, y.start, y.stop
     *y.step, and y.scale. So this line CANNOT be removed.
     */
    AbstractShmoo::initialize();
    addParameter("x.parameterType",
                 "string",
                 &parameterTypeX,
                 testmethod::TM_PARAMETER_INPUT)
      .setOptions(ShmooParameter::SPEC_VARIABLE + ':' 
                    + ShmooParameter::HX_INSTRUMENT + ':' + ShmooParameter::HX_RESOURCE)
      .setDefault(ShmooParameter::SPEC_VARIABLE);


    addParameter("x.spec", 
                 "SpecVariable",
                 &specX, 
                 testmethod::TM_PARAMETER_INPUT);
    addParameter("x.setupPins", 
                 "PinString", 
                 &setupPinsX, 
                 testmethod::TM_PARAMETER_INPUT)
      .setDefault("@")
      .setComment("the selected spec variable to be varied for the X axis");
   

    addParameter("x.instrumentPin",
                 "PinString", 
                 &instrumentPinX, 
                 testmethod::TM_PARAMETER_INPUT);
    addParameter("x.resourceName",
                 "string",
                 &resourceNameX, 
                testmethod::TM_PARAMETER_INPUT);

    addParameter("x.property",
                 "string", 
                 &propertyX, 
                 testmethod::TM_PARAMETER_INPUT)
      .setOptions(BistHxUtility::getInstance().getPropertyOptions())
      .setDefault(BistHxUtility::getInstance().getPropertyDefault());
    addParameter("x.unit",
                 "string", 
                 &unitX, 
                 testmethod::TM_PARAMETER_INPUT)
      .setOptions(BistHxUtility::getInstance().getUnitOptions(
                    BistHxUtility::getInstance().getPropertyDefault()))
      .setDefault("V")
      .setComment("For BIST/HX Resource or HX Instrument, the units are converted to SI units,\n"
                  "e.g kHz => 1E3 Hz.");

    addParameter("y.parameterType",
                 "string",
                 &parameterTypeY,
                 testmethod::TM_PARAMETER_INPUT)
      .setOptions(ShmooParameter::SPEC_VARIABLE + ':'  
                    + ShmooParameter::HX_INSTRUMENT + ':' + ShmooParameter::HX_RESOURCE)
      .setDefault(ShmooParameter::SPEC_VARIABLE);

    addParameter("y.spec", "SpecVariable", 
                 &specY, 
                 testmethod::TM_PARAMETER_INPUT);
    addParameter("y.setupPins", 
                 "PinString", 
                 &setupPinsY, 
                 testmethod::TM_PARAMETER_INPUT)
      .setDefault("@")
      .setComment("the selected spec variable to be varied for the Y axis");

    addParameter("y.instrumentPin",
                 "PinString", 
                 &instrumentPinY, 
                 testmethod::TM_PARAMETER_INPUT);
    addParameter("y.resourceName",
                 "string",
                 &resourceNameY, 
                 testmethod::TM_PARAMETER_INPUT);
    addParameter("y.property",
                 "string", 
                 &propertyY, 
                 testmethod::TM_PARAMETER_INPUT)
      .setOptions(BistHxUtility::getInstance().getPropertyOptions())
      .setDefault(BistHxUtility::getInstance().getPropertyDefault());
    addParameter("y.unit",
                 "string", 
                 &unitY, 
                 testmethod::TM_PARAMETER_INPUT)
      .setOptions(BistHxUtility::getInstance().getUnitOptions(
                    BistHxUtility::getInstance().getPropertyDefault()))
      .setDefault("V")
      .setComment("For BIST/HX Resource or HX Instrument, the units are converted to SI units,\n"
                  "e.g kHz => 1E3 Hz.");

    addParameter("resultPins",
                 "PinString",
                 &resultPins, 
                 testmethod::TM_PARAMETER_INPUT)
      .setDefault("@");
    addParameter("testMode",
                 "string",
                 &testMode,
                 testmethod::TM_PARAMETER_INPUT)
      .setOptions(
         FunctionalMeasurement::NORMAL_FUNCTIONAL_TEST_STRING
         + ":" + FunctionalMeasurement::FIRST_FAIL_CYCLE_STRING 
         + ":" + FunctionalMeasurement::CYCLE_ERROR_COUNT_STRING
         + ":" + FunctionalMeasurement::EDGE_ERROR_COUNT_STRING)
      .setDefault(FunctionalMeasurement::NORMAL_FUNCTIONAL_TEST_STRING);
  }

  /**
   *This method is called before shmoo runs. In general, it is used to save the
   *Software/HardWare status which may be changed by the method runAtPoint().
   */
  virtual void saveBeforeShmooRun()
  {
    processParameters();		
    if(mIsAllSpec)
    {
      SpecShmooParameter* pSpecParameterX = dynamic_cast<SpecShmooParameter*> (mpParameterX);
      SpecShmooParameter* pSpecParameterY = dynamic_cast<SpecShmooParameter*> (mpParameterY);
      if (pSpecParameterX != NULL)
      {
        mShmooSpec.setX(
          pSpecParameterX->getSpecName(),
          pSpecParameterX->getSpecType(),
          pSpecParameterX->getSetupPins());
      }
      else
      {
        cerr << "x-axis parameter is not available." << endl;
      }
      if (pSpecParameterY != NULL)
      {
        mShmooSpec.setY(
          pSpecParameterY->getSpecName(),
          pSpecParameterY->getSpecType(),
          pSpecParameterY->getSetupPins());
      }
      else
      {
        cerr << "y-axis parameter is not available." << endl;
      }
      mShmooSpec.setup();
      mXAxisSetupPins = pSpecParameterX->getSetupPins();
      mYAxisSetupPins = pSpecParameterY->getSetupPins();
      if(mXAxisSetupPins.length() > 0)
      {
        mXAxisSetupPins = "(" + mXAxisSetupPins + ")";
      }
      if(mYAxisSetupPins.length() > 0)
      {
        mYAxisSetupPins = "(" + mYAxisSetupPins + ")";
      }
    }
    else
    {
       mpParameterX->saveValue();
       mpParameterY->saveValue();
    }
    mpMeasurement->save();
    
    mXAxisDescription = mpParameterX->getDescription();
    mYAxisDescription = mpParameterY->getDescription();

    mXAxisShortName = mpParameterX->getShortName();
    mYAxisShortName = mpParameterY->getShortName();

    mXAxisUnit = mpParameterX->getUnit();
    mYAxisUnit = mpParameterY->getUnit();
  }

  /**
   *This method is called after shmoo runs. In general, it is used to restore the
   *Software/HardWare status which may have been changed by the method runAtPoint().
   */
  virtual void restoreAfterShmooRun() 
  {
    if(mIsAllSpec)
    {
      mShmooSpec.restore();
    }
    else
    {
      if (mpParameterX != NULL)
      {
        mpParameterX->restoreValue();
      }
      if(mpParameterY != NULL)
      {
        mpParameterY->restoreValue();
      }
    }

    if (mpMeasurement != NULL)
    {
      mpMeasurement->restore();
    }

    if(mpParameterX != NULL)
    {
      delete mpParameterX;
      mpParameterX = NULL;
    }
    if(mpParameterY != NULL)
    {
      delete mpParameterY;
      mpParameterY = NULL;
    }
    if(mpMeasurement != NULL)
    {
      delete mpMeasurement;
      mpMeasurement = NULL;
    }
  }

  /**
   *This function is invoked at every Shmoo Point. In this method, you should:
   * 1. change the resource at x axis to 'valueX'.
   * 2. change the resource at y axis to 'valueY'.
   * 3. do a Pass/Fail or Value measurement.
   */
  virtual ShmooCellResult runAtPoint(double valueX, double valueY) 
  {
    if(mIsAllSpec)
    {
      mShmooSpec.setValue(valueX, valueY);
    }
    else
    {
      mpParameterX->moveTo(valueX);
      mpParameterY->moveTo(valueY);
    }
    mpMeasurement->measure();
    return mpMeasurement->getResult(); 
  }

  virtual string getShortNameForXAxis() 
  {
    return mXAxisShortName;
  }

  virtual string getShortNameForYAxis() 
  {
    return mYAxisShortName;
  }

  virtual string getUnitForXAxis()
  {
    return mXAxisUnit;
  }

  virtual string getUnitForYAxis() 
  {
    return mYAxisUnit;
  } 

  virtual int getTpiViewerMode()
  {
    if(testMode == FunctionalMeasurement::FIRST_FAIL_CYCLE_STRING)
    {
      return TpiShmooViewer::FFCI_MODE;
    }
    else if(testMode == FunctionalMeasurement::CYCLE_ERROR_COUNT_STRING)
    {
      return TpiShmooViewer::CYCLE_ERCT_MODE;
    }
    return TpiShmooViewer::OTHER_MODE;
  }

  virtual string getXSetupPins()
  {
    return mXAxisSetupPins;
  }
  
  virtual string getYSetupPins()
  {
    return mYAxisSetupPins;
  }

 	

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   *
   *Note: TestMethod API should not be used in this method.
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    AbstractShmoo::postParameterChange(parameterIdentifier);
    postParameterChangeForXAxis(parameterIdentifier);
    postParameterChangeForYAxis(parameterIdentifier);
    postParameterChangeForMeasurement(parameterIdentifier);
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string  getComment() const
  {
     static string comment = _TML_VERSION;
     return comment;
  }
private:

  /**
   *-------------------------------------------------------------------------------------------------*
   * Routine: postParameterChangeForXAxis
   *
   * Description: do postParameter change for parameters on X Axis. This method 
   *    will be called in postParameterChange()   
   * It will do:
   *    1. visible/invisble handling
   *       a. when x.parameterType is "SpecVariable", "x.specName","x.specType", "x.setupPins"
   *          are visible.
   *       b. when x.parameterType is "Bist Resource" or "HX Resource", "x.resourceName", "x.property",
   *          "x.unit" are visible.
   *       c. when x.parameterType is "HX Instrument", "x.instrumentPin", "x.property", "x.unit" are visible.
   *    2. valid/invalid handling.
   *       a. x.parameterType should be "SpecVariable", "Bist Resource", "HX Resource" or "HX Instrument".
   *          otherwise, it is invalid.
   *       b. x.specName should not be empty when x.parameterType is "SpecVariable".   
   *       c. x.unit should be a valid unit for the given "x.property".E.g. When "x.property" is "DriverLow",
   *          x.unit should be mV or V.     
   *       d. x.property should be valid Bist/HX properties.    
   *       e. x.start should not be equal to x.stop. Otherwise, "x.start" and "x.stop" are both invalid.
   *       f. x.step will be invalid if it has syntax error.
   *       g. when x.scale is logarithmic, x.start and x.stop should be both negative or both positive.
   *          otherwise, "x.start", "x.stop", "x.scale" are invalid
   *       h. when x.scale is logarithmic, "x.step" should use step number rather than step width. 
   *          otherwise, "x.step" and "x.scale" are both invalid.
   *           
   *--------------------------------------------------------------------------------------------------*
   */
  void postParameterChangeForXAxis(const string& parameterIdentifier)
  {
    //visible/invisible handling
    if ( parameterIdentifier=="x.parameterType" )
    {
      //first set x.parameterType valid.
      getParameter("x.parameterType").setValid(true);
      getParameter("x.parameterType").setMessage("");      
      
      //first set all related parameters invisible.
      getParameter("x.spec").setVisible(false);
      getParameter("x.setupPins").setVisible(false);
      getParameter("x.instrumentPin").setVisible(false);
      getParameter("x.resourceName").setVisible(false);
      getParameter("x.property").setVisible(false);
      getParameter("x.unit").setVisible(false);    
 
      if ( parameterTypeX == ShmooParameter::SPEC_VARIABLE )
      {
        //set parameters related to "SpecVariable" visible.
        getParameter("x.spec").setVisible(true);
        getParameter("x.setupPins").setVisible(true);
      }

      else if ( parameterTypeX == ShmooParameter::HX_INSTRUMENT )
      {
        //set parameters related to "HX Instrument" visible.
        getParameter("x.instrumentPin").setVisible(true);
        getParameter("x.property").setVisible(true);
        getParameter("x.unit").setVisible(true);    
      }
      else if ( parameterTypeX == ShmooParameter::HX_RESOURCE ||
                parameterTypeX == ShmooParameter::BIST_RESOURCE)
      {
        //set parameters related to "HX/Bist Resource" visible.
        getParameter("x.resourceName").setVisible(true);
        getParameter("x.property").setVisible(true);
        getParameter("x.unit").setVisible(true);    
      }
      else 
      {
        //parameter x.parameterType is invalid.
        getParameter("x.parameterType").setValid(false);
        getParameter("x.parameterType").setMessage(
           string("currently, the change resource on x axis and y axis should be ")
             + ShmooParameter::SPEC_VARIABLE + ", " + ShmooParameter::BIST_RESOURCE + ", "
             + ShmooParameter::HX_INSTRUMENT + " or " + ShmooParameter::HX_RESOURCE + '!');
      }
    }
  
    //valid/invalid parameter handling for "SpecVariable"
    else if(parameterIdentifier == "x.spec" &&
            parameterTypeX == ShmooParameter::SPEC_VARIABLE)
    {
      getParameter("x.spec").setValid(true);
      getParameter("x.spec").setMessage("");
      if(CommonUtil::trim(specX.mName).empty())
      {
        getParameter("x.spec").setValid(false);
        getParameter("x.spec").setMessage("specName in x.spec cannot be empty!");
      }
    }
    //valid/invalid parameter handling for "Bist Resource", "HX Instrument" and "HX Resource"
    else if(parameterIdentifier == "x.property" &&
            (parameterTypeX == ShmooParameter::BIST_RESOURCE ||
             parameterTypeX == ShmooParameter::ShmooParameter::HX_INSTRUMENT ||
             parameterTypeX == ShmooParameter::HX_RESOURCE))
    {
      getParameter("x.property").setValid(true);
      getParameter("x.property").setMessage("");
      if(!BistHxUtility::getInstance().isValidProperty(propertyX))
      {
        getParameter("x.property").setValid(false);
        getParameter("x.property").setMessage("x.property is not a valid BIST/HX property!");
      }

      if(parameterTypeX == ShmooParameter::BIST_RESOURCE && 
         BistHxUtility::getInstance().isHighSpeedProperty(propertyX))
      {
        getParameter("x.property").setValid(false);
        getParameter("x.property").setMessage(
          "x.property is not a valid BIST property; Properties"
          " \"DriverFineDelay\" and \"ReceiverFineDelay\" are not supported by BIST!");
      }
    }
    //valid/invalid parameter handling for "x.unit"
    else if(parameterIdentifier == "x.unit" && 
            (parameterTypeX == ShmooParameter::BIST_RESOURCE ||
             parameterTypeX == ShmooParameter::ShmooParameter::HX_INSTRUMENT ||
             parameterTypeX == ShmooParameter::HX_RESOURCE))
    {
      getParameter("x.unit").setValid(true);
      getParameter("x.unit").setMessage("");
      if(BistHxUtility::getInstance().getUnitOptions(propertyX) != "")
      {
        getParameter("x.unit").setOptions(BistHxUtility::getInstance().getUnitOptions(propertyX));
      }
      if(!BistHxUtility::getInstance().isValidUnit(propertyX, unitX))
      {
         string msg = "x.unit is not a valid BIST/HX unit!";
         getParameter("x.unit").setValid(false);
         getParameter("x.unit").setMessage(msg);
      }
    }
  }

  /**
   *-------------------------------------------------------------------------------------------------*
   * Routine: postParameterChangeForYAxis
   * 
   * Desription: similar as PostParameterChangeForXAxis(),please see its description.
   *
   *--------------------------------------------------------------------------------------------------*
   */
  void postParameterChangeForYAxis(const string& parameterIdentifier)
  {
    if ( parameterIdentifier== "y.parameterType" )
    {
      getParameter("y.parameterType").setValid(true);
      getParameter("y.parameterType").setMessage("");

      getParameter("y.spec").setVisible(false);
      getParameter("y.setupPins").setVisible(false);
      getParameter("y.instrumentPin").setVisible(false);
      getParameter("y.resourceName").setVisible(false);
      getParameter("y.property").setVisible(false);
      getParameter("y.unit").setVisible(false);    
  
      if ( parameterTypeY == ShmooParameter::SPEC_VARIABLE )
      {
        getParameter("y.spec").setVisible(true);
        getParameter("y.setupPins").setVisible(true);
      }
      
      else if ( parameterTypeY == ShmooParameter::HX_INSTRUMENT )
      {
        getParameter("y.instrumentPin").setVisible(true);
        getParameter("y.property").setVisible(true);
        getParameter("y.unit").setVisible(true);    
      }
      else if ( parameterTypeY == ShmooParameter::HX_RESOURCE ||
                parameterTypeY == ShmooParameter::BIST_RESOURCE )
      {
        getParameter("y.resourceName").setVisible(true);
        getParameter("y.property").setVisible(true);
        getParameter("y.unit").setVisible(true);    
      }
      else 
      {
        getParameter("y.parameterType").setValid(false);
        getParameter("y.parameterType").setMessage(
           string("currently, the change resource on x axis and y axis should be ")
             + ShmooParameter::SPEC_VARIABLE + ", " + ShmooParameter::BIST_RESOURCE + ", "
             + ShmooParameter::HX_INSTRUMENT + " or " + ShmooParameter::HX_RESOURCE + '!');

      }
    }

    else if(parameterIdentifier == "y.spec" &&
            parameterTypeY == ShmooParameter::SPEC_VARIABLE)
    {
      getParameter("y.spec").setValid(true);
      getParameter("y.spec").setMessage("");
      if(CommonUtil::trim(specY.mName).empty())
      {
        getParameter("y.spec").setValid(false);
        getParameter("y.spec").setMessage("specName in y.spec cannot be empty!");
      }
    }
    else if(parameterIdentifier == "y.property"&&
            (parameterTypeY == ShmooParameter::BIST_RESOURCE ||
             parameterTypeY == ShmooParameter::ShmooParameter::HX_INSTRUMENT ||
             parameterTypeY == ShmooParameter::HX_RESOURCE))
    {
      getParameter("y.property").setValid(true);
      getParameter("y.property").setMessage("");
      if(!BistHxUtility::getInstance().isValidProperty(propertyY))
      {
        getParameter("y.property").setValid(false);
        getParameter("y.property").setMessage("y.property is not a valid BIST/HX property!");
      }
      if(parameterTypeY == ShmooParameter::BIST_RESOURCE && 
         BistHxUtility::getInstance().isHighSpeedProperty(propertyY))
      {
        getParameter("y.property").setValid(false);
        getParameter("y.property").setMessage(
          "y.property is not a valid BIST property; Properties"
          " \"DriverFineDelay\" and \"ReceiverFineDelay\" are not supported by BIST!");
      }
    }
    else if(parameterIdentifier == "y.unit" && 
            (parameterTypeY == ShmooParameter::BIST_RESOURCE ||
             parameterTypeY == ShmooParameter::ShmooParameter::HX_INSTRUMENT ||
             parameterTypeY == ShmooParameter::HX_RESOURCE))
    {
      getParameter("y.unit").setValid(true);
      getParameter("y.unit").setMessage("");
      if(BistHxUtility::getInstance().getUnitOptions(propertyY) != "")
      {
        getParameter("y.unit").setOptions(BistHxUtility::getInstance().getUnitOptions(propertyY));
      }
      if(!BistHxUtility::getInstance().isValidUnit(propertyY,unitY))
      {
         string msg = "y.unit is not a valid BIST/HX unit!"; 
         getParameter("y.unit").setValid(false);
         getParameter("y.unit").setMessage(msg);
      }
    }
  }

  /**
   *-------------------------------------------------------------------------------------------------*
   * Routine: postParameterChangeForMeasurement
   *
   * Description: do postParameter change for measurement. This method
   *    will be called in postParameterChange()
   */

  void postParameterChangeForMeasurement(const string& parameterIdentifier)
  {
    //testMode should be "pass/fail", "first failing cycle", "cycle error count"
    //"edge error count", "userPassFail" or "userValue".
    if(parameterIdentifier == "testMode")
    {
      getParameter("testMode").setValid(true);
      getParameter("testMode").setMessage("");
      if(testMode != FunctionalMeasurement::NORMAL_FUNCTIONAL_TEST_STRING &&
         testMode!= FunctionalMeasurement::FIRST_FAIL_CYCLE_STRING &&
         testMode != FunctionalMeasurement::CYCLE_ERROR_COUNT_STRING &&
         testMode != FunctionalMeasurement::EDGE_ERROR_COUNT_STRING)
      {
        string msg = "testMode should be "
          + FunctionalMeasurement::NORMAL_FUNCTIONAL_TEST_STRING
          + ", " + FunctionalMeasurement::FIRST_FAIL_CYCLE_STRING
          + ", " + FunctionalMeasurement::CYCLE_ERROR_COUNT_STRING
          + " or " + FunctionalMeasurement::EDGE_ERROR_COUNT_STRING
          + "!";
        getParameter("testMode").setValid(false);
        getParameter("testMode").setMessage(msg); 
      }
    }
  }

  /**
   * process the parameters and construct concrete mpShmooParameterX, 
   * mpShmooParameterY and mpMeasurement.
   */
  void processParameters()
  {
    mIsAllSpec = false;
    mpParameterX = NULL;
    mpParameterY = NULL;
    mpMeasurement = NULL;
    parameterTypeX = CommonUtil::trim(parameterTypeX);

    specX.mName = CommonUtil::trim(specX.mName);
    specX.mType = CommonUtil::trim(specX.mType);
    setupPinsX = CommonUtil::trim(setupPinsX);


    unitX = CommonUtil::trim(unitX);

    parameterTypeY = CommonUtil::trim(parameterTypeY);


    specY.mName = CommonUtil::trim(specY.mName);
    specY.mType = CommonUtil::trim(specY.mType);
    setupPinsY = CommonUtil::trim(setupPinsY);

    unitY = CommonUtil::trim(unitY);

    resultPins = CommonUtil::trim(resultPins);
    testMode = CommonUtil::trim(testMode);

    if(resultPins.empty())
    {
      resultPins = "@";
    }


    //create concrete ShmooParameter on X axis
    mpParameterX =  makeShmooParameter(
      parameterTypeX,
      specX,
      setupPinsX,
      instrumentPinX,
      resourceNameX,
      propertyX,
      unitX,
      true);

    //create concrete ShmooParameter on Y axis
    mpParameterY =  makeShmooParameter(
      parameterTypeY,
      specY,
      setupPinsY,
      instrumentPinY,
      resourceNameY,
      propertyY,
      unitY,
      false);
    //create concrete ShmooMeasurement
    mpMeasurement =  makeShmooMeasurement();
    
    if ( parameterTypeX == ShmooParameter::SPEC_VARIABLE && 
         parameterTypeY == ShmooParameter::SPEC_VARIABLE )
    {
      mIsAllSpec = true;
    }

  }

   /**
    * construct a concrete ShmooParameter object according to the specified
    * parameters.
    */
   ShmooParameter* makeShmooParameter(
     const string& parameterType,
     const testmethod::SpecVariable& spec,
     const string& setupPins,
     const string& instrumentPin,
     const string& resourceName,
     const string& property,
     const string& unit,
     bool isXAxis)
   {
      ShmooParameter *pParameter = NULL;
      string msg;
      string axisInfo;
      if(isXAxis)
      {
        axisInfo = "x.";
      }
      else
      {
        axisInfo = "y.";
      }

      if(parameterType == ShmooParameter::SPEC_VARIABLE)
      {
        checkSetupPinList(setupPins);
        TM::SPEC_TYPE specType = CommonUtil::convertStringToSearchType(spec.mType);
        pParameter = new SpecShmooParameter(
          spec.mUnit,
          spec.mName,
          setupPins,
          specType);
      }

      else if(parameterType == ShmooParameter::HX_INSTRUMENT)
      {
        pParameter = new HXInstrumentShmooParameter(
          unit,
          instrumentPin,
          property);
      }
      else if(parameterType == ShmooParameter::HX_RESOURCE)
      {
        pParameter = new HXResourceShmooParameter(
          unit,
          resourceName,
          property);
      }
      else
      {
         // should never occur
      }

      return pParameter;
   }

   ShmooMeasurement* makeShmooMeasurement()
   {
     checkResultPins();
     return new FunctionalMeasurement(testMode, resultPins);
   }

   void checkResultPins()
   {
    /*judge the result pin is 0,IO
    if not,it will throw an exception */

    if ( resultPins!= "@" )
    { /*if "@", skip checking ... */
      PinUtility.getDigitalPinNamesFromPinList(
        resultPins,
        TM::O_PIN|TM::IO_PIN,
        true,
        true);
    }
   }

  
  /*
   *----------------------------------------------------------------------*
   * Routine: ShmooTestMethod::checkSetupPinList
   *
   * Purpose: check whether the spec spec is I, O, IO, DPS pin
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note:
   *
   * Parameters:  string& pins : pinlist name
   *
   * Return Value: As long as there is a none I or O or IO or DPS pin throw error, or else
   *               return whether the pinlist includes DPS pin.
   *----------------------------------------------------------------------*
   */
  bool checkSetupPinList(const string& pins)
  {
    bool hasDpsPin = false;

    /*Default value,handled by the Firmware*/
    if(pins.empty()) 
    {
      return false;
    }
    string::size_type first = 0;
    string::size_type end;
    for(;;)
    {
      end = pins.find_first_of(",", first);
      string one_pin = pins.substr(first, end-first);
      try
      {
        /*throw an exception if not O,IO,I pin*/
        PinUtility.getDigitalPinNamesFromPinList(
          one_pin,
          TM::O_PIN|TM::IO_PIN|TM::I_PIN,
          true,
          true);
      }
      catch (ErrorInfo& e)
      {
        /*throw an exception if not I,O,IO,DPS pins*/
        try
        {
          PinUtility.getDpsPinNamesFromPinList(one_pin, true);
          hasDpsPin = true;
        }
        catch (ErrorInfo& e)
        {
          string api = "Check setup pin : ";
          string msg = "There is a pin["
            + one_pin
            +"] is not any kind of I,O,IO,DPS pin!";
          throw Error(api.c_str(), msg.c_str(), api.c_str());
        }
      }

      if(end == string::npos) 
      {
        break;
      }
      first = end + 1;
    }

    return hasDpsPin;
  }

  double getResultResolution()
  {
    return 1;
  }
 
  virtual string getXAxisDescription()
  {
    return mXAxisDescription;
  }

  virtual string getYAxisDescription()
  {
    return mYAxisDescription;
  }

  virtual string getTestMode()
  {
    return testMode;
  }

  virtual string getResultPins()
  {
    return resultPins;
  }


};
REGISTER_TESTMETHOD("AcTest.Shmoo", Shmoo);
