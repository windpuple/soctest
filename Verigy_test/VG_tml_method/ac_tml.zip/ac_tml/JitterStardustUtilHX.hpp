#ifndef INCLUDE_JITTERHISTOGRAMHX_H
#define INCLUDE_JITTERHISTOGRAMHX_H
#include <algorithm>
#include "CommonUtil.hpp"
#include "JitterUtilHX.hpp"

/******************************************************************************
 *                    jitter stardust test utility class 
 ******************************************************************************
 *@Description:
 * By setting up different parameters,users can make the jitter stardust
 * measurement in different conditions.
 *  pattern synchronization: find a passing pattern
 *  transtioon search on specified side(s): optimize the start of jitter data
 *                                          acquisition.
 *  data acquisition on specified side(s): sample the jitter data
 *  jitter histogram calculation on specified side(s): get the mean value of jitter
 *  data acquisiton on specified side(s): run function test to get
 *                                        pass/fail sequence
 *  calculate the frequency component of jitter.
 *
 * according the description,the whole process steps:
 * |----------------|     |------------|       |-------------|
 * |    pattern     |     | transition |       |     data    |
 * |synchronization |---->|  search    |------>| acquisition |
 * |   (optional)   |     | (optional) |       |    (must)   |
 * |----------------|     |------------|       |-------------|
 * |
 * |-------------------------------------------|
 * |
 * |----------------|     |---------------|       |-------------|
 * |      data      |     |      data     |       |     post    |
 * |     process    |---->|  acquisition  |------>|   process   |
 * |(mean of jitter)|     |(function test)|       | (frequency) |
 * |----------------|     |---------------|       |-------------|
 * 
 ******************************************************************************
 */ 
class JitterStardustUtilHX
{
public:
  /**
   *---------------------------------------------------------------------------
   *         test parameters containe
   *---------------------------------------------------------------------------
   */
  struct  JitterStardustParameter
  {
    //common parameter for jitter histogram, separation and stardust
    JitterUtilHX::JitterParameter commonParameter;
    //special parameters for jitter stardust
    INT errorMapStartCycle;
    INT acquisitionDepth;
    INT FFTWindow;
  };
  /**
   *----------------------------------------------------------------------------
   *         test limits container                                    
   *----------------------------------------------------------------------------
   */
  struct JitterStardustLimit
  {
    bool isLimitTableUsed;
    string testname;
    LIMIT frequencyLimit;
  } ;
  /**
   *---------------------------------------------------------------------------
   *         test results container
   *---------------------------------------------------------------------------
   */
  struct ResultData
  {
    // histogram data vector of left transition
    vector<INT> leftHistogramData;

    // histogram data vector of right transiton
    vector<INT> rightHistogramData;

    // the result of histogram on the left transition side
    JitterHistogramType leftHistogram;

    // the result of histogram on the right transition side
    JitterHistogramType rightHistogram;

    // pass/fail sequence data of left transition
    vector<INT> leftPFData;

    // pass/fail sequence data of right transition
    vector<INT> rightPFData;

    // the result of spectrum amplitude on the left transition side
    vector<DOUBLE> leftSpectrumAmplitude;

    // the result of frequency on the left transition side
    vector<DOUBLE> leftFrequency;

    // the result of spectrum amplitude on the right transition side
    vector<DOUBLE> rightSpectrumAmplitude;

    // the result of frequency on the right transition side
    vector<DOUBLE> rightFrequency;

    //--------------hx--------------
    ARRAY_I Emap;
    //INT_VECTOR ErrorMapVec;

    // initialize all stuffs to some defaults.
    void init()
    {
      leftHistogramData.clear();
      rightHistogramData.clear();
      leftHistogram.mean = 0.0;
      leftHistogram.rms = 0.0;
      leftHistogram.peak2peak = 0.0;
      leftHistogram.median = 0.0;
      leftHistogram.medist = 0.0;
      rightHistogram.mean = 0.0;
      rightHistogram.rms = 0.0;
      rightHistogram.peak2peak = 0.0;
      rightHistogram.median = 0.0;
      rightHistogram.medist = 0.0;
      leftSpectrumAmplitude.clear();
      leftFrequency.clear();
      rightSpectrumAmplitude.clear();
      rightFrequency.clear();
    }
    ResultData()
    {
      init();
    }
  };
  /**
   *---------------------------------------------------------------------------
   * @Struct: JitterStardustResult
   * 
   * @Purpose: container to store jitter measurement results
   *---------------------------------------------------------------------------
   * @Decription:
   *   This two-layered map contains result of test.The outside map contains
   *   every site's result.The inside map contains every pin's result.
   *   The outside map's key: INT is the index of site number
   *   The outside map's value:map<STRING,ResultData> is the result of the
   *   site which is indexed by key.
   *   The inside map's key: STRING is the pin's name.
   *   The inside map's value: ResultData is the result of the pin which is
   *   indexed by key.
   * @Note:
   *---------------------------------------------------------------------------
   */
  struct JitterStardustResultHX
  {
    map<INT,map<STRING, map<INT, ResultData> > > resultMap;

    JitterUtilHX::JitterDataHX jitterDataHX;

    void init()
    {
      jitterDataHX.init();
      resultMap.clear();
    }
  } ;
  /**
   *---------------------------------------------------------------------------
   *         public interfaces of jitter stardust  test
   *---------------------------------------------------------------------------
   */  

  static void processParameters(
                               const STRING& pinlist,
                               const DOUBLE UI_width_ns,
                               const DOUBLE start_ns,
                               const DOUBLE stop_ns,
                               const DOUBLE dataAcquStepWidth_ns,    

                               const STRING& autoSyncMode,
                               const DOUBLE autoSyncStepWidth_ns,
                               const STRING& transitionSearchMode,
                               const STRING& transition,

                               const INT errorMapStartCycle,
                               const INT acquisitionDepth,    
                               const STRING& FFTWindow,
                               const STRING& outputMode,

                               JitterStardustParameter& parameters,
                               JitterUtilHX::JitterDataHX& jitter_data_hx
                               );


  static void processLimit(const string& testname, JitterStardustLimit& testlimit);

  static void doMeasurement(
                           const JitterStardustParameter& parameters,
                           JitterStardustResultHX& results_hx);

  //-------------------------------------------------
  static void judgeAndDatalog(
                             const JitterStardustParameter& parameters,
                             const JitterStardustResultHX& results_hx,
                             const JitterStardustLimit & testlimit);

  static void reportToUI(
                        const JitterStardustParameter& parameters,
                        const JitterStardustResultHX& results_hx,
                        const STRING& output);
  //-------------------------------------------------
private:

  //---------------------------------------------
  static void HX_Error_Map_Acquire(
                                  const JitterStardustParameter& parameters,
                                  JitterStardustResultHX& results_hx,
                                  JitterUtilHX::TRANSITION active);        

  //---------------------------------------------  
  static void histogramCalculation(
                                  const JitterStardustParameter& parameters,
                                  JitterStardustResultHX& results_hx);

  static void histogramCalculation_qk(
                                     const JitterStardustParameter& parameters,
                                     JitterStardustResultHX& results_hx,
                                     JitterUtilHX::TRANSITION active);

  static void stardustCalculation(
                                 const JitterStardustParameter& parameters,
                                 JitterStardustResultHX& results_hx);

  static void stardustCalculation_qk(
                                    const JitterStardustParameter& parameters,
                                    JitterStardustResultHX& results_hx,
                                    JitterUtilHX::TRANSITION active);

  //---------------------------------------------
  static void applyPatternSyncValue(
                                   const JitterStardustParameter& parameters,
                                   JitterStardustResultHX& results_hx);

  static void printStardustCurve(const vector<DOUBLE>&,
                                 const vector<DOUBLE>&);

  static void printStardustValue(const vector<DOUBLE>&,
                                 const vector<DOUBLE>&);

  static void prepareDataForAnalyzer(const STRING&,
                                     const INT &,
                                     const vector<DOUBLE>&,
                                     const vector<DOUBLE>&,
                                     SCATTER_LOG &);
};

/**
 *-----------------------------------------------------------------------------
 * @Routine: processParameter
 *
 * @Purpose: parse input parameters and setup internal parameters
 *
 *-----------------------------------------------------------------------------
 * @Description:
 *   according user's input to fill out interal parameters
 * @Parameters:
 *   1.STRING& pinlist:
 *     Define a list of pins/pin groups the spec is shifted for.
 *     valid type :O,IO
 *   4.DOUBLE UI_width_ns:
 *     Bit time of test pattern.
 *     For example:2.5Gb/s -> 0.4ns
 *   5.DOUBLE start_ns:
 *     --if autoSyncMode is "OFF":start of Data Acquisition
 *     --if autoSyncMode is "ON" : start of linear Pattern
 *     Alignment Search
 *   6.DOUBLE stop_ns:
 *     --if autoSyncMode is "OFF":stop of Data Acquisition
 *     --if autoSyncMode is "ON" : stop of linear Pattern
 *     Alignment Search
 *   7.DOUBLE dataAcquStepWidth_ns:
 *     Step width for Data Acquisition
 *   9.STRING& autoSyncMode: {OFF | ON }
 *     Enabling of linear Pattern Alignment Search to find passing pattern.
 *       With ON option the spec variable will be reset to its
 *     original value after finishing the test.
 *       With OFF option linear Pattern Alignment Search to find
 *     passing pattern is disable.
 *       default is ON.
 *   10.DOUBLE autoSyncStepWidth_ns:
 *      Step width for AutoSync Search.
 *   11.STRING& transitionSearchMode:  {OFF | ON}
 *        With ON,Binary Search for Pass/Fail Transition of
 *      MIN_BER poit with maximum search range of one "UI_width"
 *      and resolution of dataAcquStepWidth_ns.
 *        With OFF,transiton search will not be made.
 *      default is ON.
 *   12.STRING& transition:  {LEFT | RIGHT | BOTH}
 *      Determine which side of bit transition will be searched
 *      if transitionSearchMode is ON and be acquired for jitter
 *      stardust calculation. If both autoSyncMode and
 *      transitionSearchMode are OFF,this parameter is not in
 *      effect,and users have to choose proper values of start
 *      and stop for acquisition based on the test requirement.
 *      default is LEFT.
 *   13.INT errorMapStartCycle:
 *      This parameter determines the start cycle within the test pattern
 *      where the data acquisition with error map starts.
 *   14.INT acquisitionDepth:
 *      this parameter determines how many samples will be acquired with
 *      the error map. The maximum recording size depends on whether the test
 *      processor error map or the large error map in the vector memory is
 *      used. Use numbers on a 2^x basis.
 *   15.STRING& FFTWindow: {Uniform,Hanning,Hamming,Blackman}
 *      windowing option for FFT.
 *   16.STRING& outputMode: {SUMMARY | DETAIL | ANALYSIS}
 *      This parameter is in effect only if output is set ReportUI.
 *      SUMMARY - a result table will be printed in the Report Window.
 *      DETAIL  - an ASCII plot of the Error Count and the stardust curve
 *                will be printed in report window.
 *      ANALYSIS - the jitter stardust data will be transfer to signal
 *                analyzer tool for display and debuggine.
 *      default is SUMMARY.
 *   17.JitterStardustParameter& parameters
 *      this parameter's type is output,we use user's input to
 *      fill out this parameter.
 * @Note:
 *-----------------------------------------------------------------------------
 */
void
JitterStardustUtilHX::processParameters(
                                       const STRING& pinlist,
                                       const DOUBLE  UI_width_ns,
                                       const DOUBLE  start_ns,
                                       const DOUBLE  stop_ns,
                                       const DOUBLE  dataAcquStepWidth_ns,
                                       const STRING& autoSyncMode,
                                       const DOUBLE  autoSyncStepWidth_ns,
                                       const STRING& transitionSearchMode,
                                       const STRING& transition,

                                       const INT     errorMapStartCycle,
                                       const INT     acquisitionDepth,
                                       const STRING& FFTWindow,
                                       const STRING& outputMode,
                                       JitterStardustParameter& parameters,
                                       JitterUtilHX::JitterDataHX& jitter_data_hx  
                                       )
{
  JitterUtilHX::JitterParameter& commonParameter = parameters.commonParameter;
  STRING tempString = CommonUtil::trim(pinlist);
  //JitterUtilHX::checkSetupPinlist(tempString);
  commonParameter.PinVector = JitterUtilHX::expandPinlistToPins(tempString);

  //--------------------------------------------  
  JitterUtilHX::HXPins_Parsing(commonParameter, jitter_data_hx);
  //--------------------------------------------

  if (UI_width_ns <= 0)
  {
    STRING api = "Check parameter UI_width_ns: ";
    STRING msg = "UI_width_ns should be greater than zero!";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }
  commonParameter.UI_width_ns = UI_width_ns;

  commonParameter.start_ns = start_ns;
  commonParameter.stop_ns = stop_ns;

  if (dataAcquStepWidth_ns <= 0)
  {
    STRING api = "Check parameter dataAcquStepWidth_ns: ";
    STRING msg = "dataAcquStepWidth_ns should be greater than zero!";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }
  commonParameter.dataAcquStepWidth_ns = dataAcquStepWidth_ns;

  tempString = CommonUtil::trim(autoSyncMode);
  if (tempString == "OFF")
  {
    commonParameter.autoSyncMode = JitterUtilHX::AUTOSYNC_OFF;
  }
  else if (tempString == "ON")
  {
    commonParameter.autoSyncMode = JitterUtilHX::AUTOSYNC_ON;
  }
  else
  {
    STRING api = "Check AUTOSYNC_MODE: ";
    STRING msg = "These is an unknow AUTOSYNC_MODE type.";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }

  if (autoSyncStepWidth_ns <= 0)
  {
    STRING api = "Check parameter autoSyncStepWidth_ns: ";
    STRING msg = "autoSyncStepWidth_ns should be greater than zero!";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }
  commonParameter.autoSyncStepWidth_ns = autoSyncStepWidth_ns;

  //---------
  tempString = CommonUtil::trim(transitionSearchMode); 
  if (tempString == "OFF")
  {
    commonParameter.transitionSearchMode = JitterUtilHX::TRANSITIONSEARCH_OFF;
  }
  else if (tempString == "ON")
  {
    commonParameter.transitionSearchMode = JitterUtilHX::TRANSITIONSEARCH_ON;
  }
  else
  {
    STRING api = "Check TRANSITIONSEARCH_MODE: ";
    STRING msg = "These is an unknow TRANSITIONSEARCH_MODE type.";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }

  //--------
  tempString = CommonUtil::trim(transition);
  if (tempString == "LEFT")
  {
    commonParameter.transition = JitterUtilHX::LEFT;
  }
  else if (tempString == "RIGHT")
  {
    commonParameter.transition = JitterUtilHX::RIGHT;
  }
  else if (tempString == "BOTH")
  {
    commonParameter.transition = JitterUtilHX::BOTH;
  }
  else
  {
    STRING api = "Check TRANSITION: ";
    STRING msg = "These is an unknow TRANSITION type.";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }

  //-------
  if (errorMapStartCycle <= 0)
  {
    STRING api = "Check parameter errorMapStartCycle: ";
    STRING msg = "errorMapStartCycle should be greater than zero!";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }
  parameters.errorMapStartCycle = errorMapStartCycle;

  //------
  if (acquisitionDepth <= 0)
  {
    STRING api = "Check parameter acquisitionDepth: ";
    STRING msg = "acquisitionDepth should be greater than zero!";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }
  parameters.acquisitionDepth = acquisitionDepth;

  tempString = CommonUtil::trim(FFTWindow); 
  if (tempString == "Uniform")
  {
    parameters.FFTWindow = RECT;
  }
  else if (tempString == "Hanning")
  {
    parameters.FFTWindow = HANNING;
  }
  else if (tempString == "Hamming")
  {
    parameters.FFTWindow = HAMMING;
  }
  else if (tempString == "Blackman")
  {
    parameters.FFTWindow = FBLACKMAN;
  }
  else
  {
    STRING api = "Check parameter FFTWindow: ";
    STRING msg = "There is no FFTWindow type!";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }

  tempString = CommonUtil::trim(outputMode);
  if (tempString == "SUMMARY")
  {
    commonParameter.outputMode = JitterUtilHX::OUTPUT_SUMMARY;
  }
  else if (tempString == "DETAIL")
  {
    commonParameter.outputMode = JitterUtilHX::OUTPUT_DETAIL;
  }
  else if (tempString == "ANALYSIS")
  {
    commonParameter.outputMode = JitterUtilHX::OUTPUT_ANALYSIS;
  }
  else
  {
    STRING api = "Check OUTPUT_MODE: ";
    STRING msg = "These is an unknow OUTPUT_MODE type.";
    throw Error(api.c_str(),msg.c_str(),api.c_str());
  }
}

/**
 *-----------------------------------------------------------------------------
 * @Routine: processLimit
 *
 * @Purpose: process Limit(s)
 *
 *-----------------------------------------------------------------------------
 * @Description:
 *   
 * @Note:
 *-----------------------------------------------------------------------------
 */
void
JitterStardustUtilHX::processLimit(const string& testname, JitterStardustLimit& testlimit)
{
  testlimit.testname = testname;
  //first, try to get limit from test table 
  string testsuiteName;
  GET_TESTSUITE_NAME(testsuiteName);
  TesttableLimitHelper ttlHelper(testsuiteName);
  if (ttlHelper.isLimitCsvFileLoad())
  {
    ttlHelper.getLimit(testlimit.testname, testlimit.frequencyLimit);
  }

  testlimit.isLimitTableUsed = ttlHelper.isAllInTable(); 

  //if not defined in test table, use testflow limit
  if (!testlimit.isLimitTableUsed)
  {
    testlimit.frequencyLimit = GET_LIMIT_OBJECT(testlimit.testname);
  }

  if (testlimit.frequencyLimit.unit().empty())
  {
    testlimit.frequencyLimit.unit("MHz");
  }
}
/**
 *-----------------------------------------------------------------------------
 * @Routine: doMeasurement
 *
 * @Purpose: execute measurement and store results
 *
 *-----------------------------------------------------------------------------
 * @Description:
 * 
 * @Parameters:
 *   INPUT:
 *        parameters--------------test parameters
 *   OUTPUT
 *        result------------------test result container
 *
 * @RETURN:
 * @NOTE:
 *  process steps:
 * |----------------|     |------------|       |-------------|
 * |    pattern     |     | transition |       |     data    |
 * |synchronization |---->|  search    |------>| acquisition |
 * |   (optional)   |     | (optional) |       |    (must)   |
 * |----------------|     |------------|       |-------------|
 *                                                    |
 *         -------------------------------------------|
 *         |
 * |----------------|     |---------------|       |-------------|
 * |      data      |     |      data     |       |     post    |
 * |     process    |---->|  acquisition  |------>|   process   |
 * |(mean of jitter)|     |(function test)|       | (frequency) |
 * |----------------|     |---------------|       |-------------|
 * 
 *-----------------------------------------------------------------------------
 */
void
JitterStardustUtilHX::doMeasurement(
                                   const JitterStardustParameter & parameters,
                                   JitterStardustResultHX& results_hx)
{
  ON_FIRST_INVOCATION_BEGIN();
  results_hx.init();
  CONNECT();
  FW_TASK("SQGB ACQF,0;");
  ON_FIRST_INVOCATION_END();

  const JitterUtilHX::JitterParameter& commonParameter = parameters.commonParameter;

  //=========================================================================
  // Quick way
  //=========================================================================
  /*
  if((commonParameter.autoSyncMode == JitterUtilHX::AUTOSYNC_OFF)      
    &&(commonParameter.transitionSearchMode == JitterUtilHX::TRANSITIONSEARCH_OFF)
    &&(0 == commonParameter.start_ns && 0 == commonParameter.stop_ns ))
  {		  
    //First coarse search to find Rising/Falling edge of clock signal
    JitterUtilHX::Coarse_Sync(
      parameters.commonParameter,
      results_hx.jitterDataHX,
      0.5);

    JitterUtilHX::HX_Error_Count_Acquire(
      parameters.commonParameter,
      results_hx.jitterDataHX,
      JitterUtilHX::LEFT);

    ON_FIRST_INVOCATION_BEGIN();

    histogramCalculation_qk(parameters,results_hx,JitterUtilHX::LEFT);

    HX_Error_Map_Acquire( parameters, results_hx, JitterUtilHX::LEFT);

    ON_FIRST_INVOCATION_END();

    stardustCalculation_qk(parameters,results_hx,JitterUtilHX::LEFT);

    return;
  } 
  */
  //===================================================================================


  // autoSync
  if (commonParameter.autoSyncMode == JitterUtilHX::AUTOSYNC_ON || 
      commonParameter.autoSyncMode == JitterUtilHX::AUTOSYNC_ON_KEEP_VALUE)
  {
    bool isEveryPinOfAllSitesFail = false;
    JitterUtilHX::hx_autoSync(parameters.commonParameter,
                              results_hx.jitterDataHX,
                              isEveryPinOfAllSitesFail);

    if (isEveryPinOfAllSitesFail)
    {
      return;
    }
  }
  // transition search
  if (commonParameter.transitionSearchMode == JitterUtilHX::TRANSITIONSEARCH_ON)
  {
    bool isEveryPinOfAllSitesFail = false;
    JitterUtilHX::hx_transitionSearch(parameters.commonParameter,
                                      results_hx.jitterDataHX,
                                      isEveryPinOfAllSitesFail);

    if (isEveryPinOfAllSitesFail)
    {
      return;
    }
  }
  //data acquisition
  JitterUtilHX::hx_dataAcquire(parameters.commonParameter,results_hx.jitterDataHX);

  // pre-process data and get error density signal data.
  ON_FIRST_INVOCATION_BEGIN();
  histogramCalculation(parameters,results_hx);


  if (commonParameter.transition == JitterUtilHX::LEFT|| 
      commonParameter.transition == JitterUtilHX::BOTH)
  {
    HX_Error_Map_Acquire( parameters, results_hx, JitterUtilHX::LEFT);
  }

  if (commonParameter.transition == JitterUtilHX::RIGHT|| 
      commonParameter.transition == JitterUtilHX::BOTH)
  {
    HX_Error_Map_Acquire( parameters, results_hx, JitterUtilHX::RIGHT);
  }

  ON_FIRST_INVOCATION_END(); 

  stardustCalculation(parameters,results_hx);

  // apply pattern synchronization value 
  ON_FIRST_INVOCATION_BEGIN();
  if (commonParameter.autoSyncMode == JitterUtilHX::AUTOSYNC_ON_KEEP_VALUE)
  {
    //applyPatternSyncValue(parameters,results);
  }
  ON_FIRST_INVOCATION_END();
}



/**
 *-----------------------------------------------------------------------------
 *@Routing: stardustCalculation
 *
 *@Purpose: calculate stardust value of every pin of every site
 *
 *-----------------------------------------------------------------------------
 *@Description:
 *  the function calculate the stardust value according to the testing
 *  result(pass/fail sequence data).
 *@Parameters: 
 *    INPUT:
 *      parameters---------test parameters
 *    INPUT and OUTPUT
 *      results------------test result container
 *@Return:
 *-----------------------------------------------------------------------------
 */
void
JitterStardustUtilHX::stardustCalculation(
                                         const JitterStardustParameter& parameters,
                                         JitterStardustResultHX& results_hx)
{
  const JitterUtilHX::JitterParameter& commonParameter = parameters.commonParameter;
  JitterUtilHX::JitterDataHX& commonResult = results_hx.jitterDataHX;

  INT siteNum = CURRENT_SITE_NUMBER();

  map<INT, map<STRING, map<INT, JitterUtilHX::SYNC_EDGE> > >::const_iterator site_it;
  map<STRING, map<INT, JitterUtilHX::SYNC_EDGE> >::const_iterator pin_it;
  map<INT, JitterUtilHX::SYNC_EDGE>::const_iterator lane_it;

  //left side
  if (commonParameter.transition == JitterUtilHX::LEFT || 
      commonParameter.transition == JitterUtilHX::BOTH)
  {
    site_it = commonResult.Sync_Result.find(siteNum);
    if (site_it != commonResult.Sync_Result.end())
    {
      for (pin_it = site_it->second.begin();
          pin_it != site_it->second.end();++pin_it)//for every pin
      {
        for (lane_it = pin_it->second.begin();
            lane_it != pin_it->second.end();++lane_it)//for every lane
        {
          if (lane_it->second.lastStatus == JitterUtilHX::LEFT_JITTER || 
              lane_it->second.lastStatus == JitterUtilHX::BOTH_JITTER)
          {
            DSP_JITTER_STARDUST(
                               results_hx.resultMap[site_it->first][pin_it->first][lane_it->first].leftPFData,
                               commonParameter.UI_width_ns,
                               results_hx.resultMap[site_it->first][pin_it->first][lane_it->first].leftSpectrumAmplitude,
                               results_hx.resultMap[site_it->first][pin_it->first][lane_it->first].leftFrequency,
                               parameters.FFTWindow);

          }//end if for separation calculation
        }//end for every lane
      }//end for every pin
    }//end for every site
  }//end if for left

  //right side
  if (commonParameter.transition == JitterUtilHX::RIGHT || 
      commonParameter.transition == JitterUtilHX::BOTH)
  {
    site_it = commonResult.Sync_Result.find(siteNum);
    if (site_it != commonResult.Sync_Result.end())
    {
      for (pin_it = site_it->second.begin();
          pin_it != site_it->second.end();++pin_it)//for every pin
      {
        for (lane_it = pin_it->second.begin();
            lane_it != pin_it->second.end();++lane_it)//for every lane
        {
          if (lane_it->second.lastStatus == JitterUtilHX::RIGHT_JITTER || 
              lane_it->second.lastStatus == JitterUtilHX::BOTH_JITTER)
          {
            DSP_JITTER_STARDUST(
                               results_hx.resultMap[site_it->first][pin_it->first][lane_it->first].rightPFData,
                               commonParameter.UI_width_ns,
                               results_hx.resultMap[site_it->first][pin_it->first][lane_it->first].rightSpectrumAmplitude,
                               results_hx.resultMap[site_it->first][pin_it->first][lane_it->first].rightFrequency,
                               parameters.FFTWindow);
          }//end if for separation calculation
        }//end for every lane
      }//end for every pin
    }//end for every site
  }//end if for right side

}


void
JitterStardustUtilHX::stardustCalculation_qk(
                                            const JitterStardustParameter& parameters,
                                            JitterStardustResultHX& results_hx,
                                            JitterUtilHX::TRANSITION active)
{
  const JitterUtilHX::JitterParameter& commonParameter = parameters.commonParameter;
  JitterUtilHX::JitterDataHX& commonResult = results_hx.jitterDataHX;

  INT siteNum = CURRENT_SITE_NUMBER();

  map<INT, map<STRING, map<INT, JitterUtilHX::SYNC_EDGE> > >::const_iterator site_it;
  map<STRING, map<INT, JitterUtilHX::SYNC_EDGE> >::const_iterator pin_it;
  map<INT, JitterUtilHX::SYNC_EDGE>::const_iterator lane_it;

  //left side
  if (JitterUtilHX::LEFT == active || JitterUtilHX::BOTH == active)
  {
    site_it = commonResult.Sync_Result.find(siteNum);
    if (site_it != commonResult.Sync_Result.end())
    {
      for (pin_it = site_it->second.begin();
          pin_it != site_it->second.end();++pin_it)//for every pin
      {
        for (lane_it = pin_it->second.begin();
            lane_it != pin_it->second.end();++lane_it)//for every lane
        {

          if (( lane_it->second.LeftSide_Stop - lane_it->second.LeftSide_Start ) > 1)
          {
            DSP_JITTER_STARDUST(
                               results_hx.resultMap[site_it->first][pin_it->first][lane_it->first].leftPFData,
                               commonParameter.UI_width_ns,
                               results_hx.resultMap[site_it->first][pin_it->first][lane_it->first].leftSpectrumAmplitude,
                               results_hx.resultMap[site_it->first][pin_it->first][lane_it->first].leftFrequency,
                               parameters.FFTWindow);
          }

        }//end for every lane
      }//end for every pin
    }//end for every site
  }//end if for left

  //right side
  if (commonParameter.transition == JitterUtilHX::RIGHT || 
      commonParameter.transition == JitterUtilHX::BOTH)
  {
    site_it = commonResult.Sync_Result.find(siteNum);
    if (site_it != commonResult.Sync_Result.end())
    {
      for (pin_it = site_it->second.begin();
          pin_it != site_it->second.end();++pin_it)//for every pin
      {
        for (lane_it = pin_it->second.begin();
            lane_it != pin_it->second.end();++lane_it)//for every lane
        {
          if (lane_it->second.lastStatus == JitterUtilHX::RIGHT_JITTER || 
              lane_it->second.lastStatus == JitterUtilHX::BOTH_JITTER)
          {
            if (( lane_it->second.RightSide_Stop - lane_it->second.RightSide_Start ) > 1)
            {
              DSP_JITTER_STARDUST(
                                 results_hx.resultMap[site_it->first][pin_it->first][lane_it->first].rightPFData,
                                 commonParameter.UI_width_ns,
                                 results_hx.resultMap[site_it->first][pin_it->first][lane_it->first].rightSpectrumAmplitude,
                                 results_hx.resultMap[site_it->first][pin_it->first][lane_it->first].rightFrequency,
                                 parameters.FFTWindow);
            }
          }//end if for separation calculation
        }//end for every lane
      }//end for every pin
    }//end for every site
  }//end if for right side

}

/**
 *-----------------------------------------------------------------------------
 *@Routing: histogramCalculation
 *
 *@Purpose: calculate histogram value of every pin of every site
 *
 *-----------------------------------------------------------------------------
 *@Description:
 *  the function calculate the histogram value according to the testing
 *  result(error count).
 *@Parameters: 
 *    INPUT:
 *      parameters---------test parameters
 *    INPUT and OUTPUT:
 *      results------------test result container
 *@Return:
 *-----------------------------------------------------------------------------
 */
void
JitterStardustUtilHX::histogramCalculation(
                                          const JitterStardustParameter& parameters,
                                          JitterStardustResultHX& results_hx)
{
  const JitterUtilHX::JitterParameter& commonParameter = parameters.commonParameter;
  JitterUtilHX::JitterDataHX& commonResult = results_hx.jitterDataHX;

  map<INT, map<STRING, map<INT, JitterUtilHX::SYNC_EDGE> > >::const_iterator site_it;
  map<STRING, map<INT, JitterUtilHX::SYNC_EDGE> >::const_iterator pin_it;
  map<INT, JitterUtilHX::SYNC_EDGE>::const_iterator lane_it;


  //left side
  if (commonParameter.transition == JitterUtilHX::LEFT || 
      commonParameter.transition == JitterUtilHX::BOTH)
  {
    for (site_it = commonResult.Sync_Result.begin();
        site_it != commonResult.Sync_Result.end();
        ++site_it)//for every site
    {
      for (pin_it = site_it->second.begin();
          pin_it != site_it->second.end();++pin_it)//for every pin  
      {
        for (lane_it = pin_it->second.begin();
            lane_it != pin_it->second.end();++lane_it)//for every lane
        {
          if (lane_it->second.lastStatus == JitterUtilHX::LEFT_JITTER || 
              lane_it->second.lastStatus == JitterUtilHX::BOTH_JITTER)
          {
            DOUBLE startValue = 0.0;
            if (commonParameter.transitionSearchMode == JitterUtilHX::TRANSITIONSEARCH_ON)
            {
              startValue = 
              commonResult.Sync_Result[site_it->first][pin_it->first][lane_it->first].leftTransitionVal;
            }
            else if (commonParameter.autoSyncMode == JitterUtilHX::AUTOSYNC_ON || 
                     commonParameter.autoSyncMode == JitterUtilHX::AUTOSYNC_ON_KEEP_VALUE)
            {
              startValue = 
              commonResult.Sync_Result[site_it->first][pin_it->first][lane_it->first].autoSyncVal;
            }
            else
            {
              startValue = commonParameter.start_ns;
            }
            DSP_JITTER_HISTOGRAM(
                                lane_it->second.leftErrorCount,
                                startValue,
                                -commonParameter.dataAcquStepWidth_ns,

                                results_hx.resultMap[site_it->first][pin_it->first][lane_it->first].leftHistogramData,
                                results_hx.resultMap[site_it->first][pin_it->first][lane_it->first].leftHistogram,

                                true);

          }//end if for jitter calculation
        }//end for every lane
      }//end for every pin
    }//end for every site
  }//end if for left

  //right side
  if (commonParameter.transition == JitterUtilHX::RIGHT || 
      commonParameter.transition == JitterUtilHX::BOTH)
  {
    for (site_it = commonResult.Sync_Result.begin();
        site_it != commonResult.Sync_Result.end();
        ++site_it)//for every site
    {
      for (pin_it = site_it->second.begin();
          pin_it != site_it->second.end();++pin_it)//for every pin
      {
        for (lane_it = pin_it->second.begin();
            lane_it != pin_it->second.end();++lane_it)//for every lane
        {
          if (lane_it->second.lastStatus == JitterUtilHX::RIGHT_JITTER || 
              lane_it->second.lastStatus == JitterUtilHX::BOTH_JITTER)
          {


            DOUBLE startValue = 0.0;
            if (commonParameter.transitionSearchMode == JitterUtilHX::TRANSITIONSEARCH_ON)
            {
              startValue = 
              commonResult.Sync_Result[site_it->first][pin_it->first][lane_it->first].rightTransitionVal;
            }
            else if (commonParameter.autoSyncMode == JitterUtilHX::AUTOSYNC_ON || 
                     commonParameter.autoSyncMode == JitterUtilHX::AUTOSYNC_ON_KEEP_VALUE)
            {
              startValue = 
              commonResult.Sync_Result[site_it->first][pin_it->first][lane_it->first].autoSyncVal;
            }
            else
            {
              startValue = commonParameter.start_ns;
            }
            DSP_JITTER_HISTOGRAM(
                                lane_it->second.rightErrorCount,
                                startValue,
                                commonParameter.dataAcquStepWidth_ns,
                                results_hx.resultMap[site_it->first][pin_it->first][lane_it->first].rightHistogramData,
                                results_hx.resultMap[site_it->first][pin_it->first][lane_it->first].rightHistogram,
                                true);

          }//end if for jitter calculation
        }//end for every lane
      }//end for every pin
    }//end for every site
  }//end if for right side
}

void
JitterStardustUtilHX::histogramCalculation_qk(
                                             const JitterStardustParameter& parameters,
                                             JitterStardustResultHX& results_hx,
                                             JitterUtilHX::TRANSITION active)
{
  const JitterUtilHX::JitterParameter& commonParameter = parameters.commonParameter;
  JitterUtilHX::JitterDataHX& commonResult = results_hx.jitterDataHX;

  map<INT, map<STRING, map<INT, JitterUtilHX::SYNC_EDGE> > >::const_iterator site_it;
  map<STRING, map<INT, JitterUtilHX::SYNC_EDGE> >::const_iterator pin_it;
  map<INT, JitterUtilHX::SYNC_EDGE>::const_iterator lane_it;

  for (site_it = commonResult.Sync_Result.begin();
      site_it != commonResult.Sync_Result.end();
      ++site_it)//for every site
  {
    for (pin_it = site_it->second.begin();
        pin_it != site_it->second.end();++pin_it)//for every pin
    {
      for (lane_it = pin_it->second.begin();
          lane_it != pin_it->second.end();++lane_it)//for every lane
      {
        if (JitterUtilHX::LEFT == active || JitterUtilHX::BOTH == active)
        {

          if (( lane_it->second.LeftSide_Stop - lane_it->second.LeftSide_Start ) > 1)
          {

            DSP_JITTER_HISTOGRAM(
                                lane_it->second.leftErrorCount,
                                0,
                                commonParameter.dataAcquStepWidth_ns,
                                results_hx.resultMap[site_it->first][pin_it->first][lane_it->first].leftHistogramData,
                                results_hx.resultMap[site_it->first][pin_it->first][lane_it->first].leftHistogram);
          }
        }
        if (JitterUtilHX::RIGHT == active || JitterUtilHX::BOTH == active)
        {

          if (( lane_it->second.RightSide_Stop - lane_it->second.RightSide_Start ) > 1)
          {

            DSP_JITTER_HISTOGRAM(
                                lane_it->second.rightErrorCount,
                                0,
                                commonParameter.dataAcquStepWidth_ns,
                                results_hx.resultMap[site_it->first][pin_it->first][lane_it->first].rightHistogramData,
                                results_hx.resultMap[site_it->first][pin_it->first][lane_it->first].rightHistogram);
          }
        }
      }//end for every lane
    }//end for every pin
  }//end for every site

}



/**
 *-----------------------------------------------------------------------------
 *@Routine: applyPatternSyncValue
 *
 *@Purpose: keep synchronization value
 *
 *-----------------------------------------------------------------------------
 *@Description:
 * if user sets the autoSyncMode parameter to ON_KEEP_VALUE, then the
 * synchronization value of the test pin will be keeped for the following
 * test suites.
 *
 *@Parameters:
 *    INPUT:
 *       Parameters------------test parameters
 *       results---------------result container
 *@RETURN:
 *-----------------------------------------------------------------------------
 */
void
JitterStardustUtilHX::applyPatternSyncValue(
                                           const JitterStardustParameter& parameters,
                                           JitterStardustResultHX& results_hx)
{
  return;
}

/**
 *-----------------------------------------------------------------------------
 * @Routine: judgeAndDatalog
 *
 * @Purpose: judge and put result into event datalog stream
 *
 *-----------------------------------------------------------------------------
 * @Description:
 *    judge result of 'results' with pass limit form 'testlimit'
 *
 * @Parameters:
 *   INPUT:  param---------------test parameters
 *           testLimit-----------test limit container
 *           result--------------result container
 *
 * @RETURN:
 *-----------------------------------------------------------------------------
 */
void
JitterStardustUtilHX::judgeAndDatalog(
                                     const JitterStardustParameter& parameters,
                                     const JitterStardustResultHX& results_hx,
                                     const JitterStardustLimit & testlimit)
{
  const JitterUtilHX::JitterParameter& commonParameter =
  parameters.commonParameter;
  INT siteNum = CURRENT_SITE_NUMBER();

  double factor = 1.0; 

  ARRAY_D leftFrequencyValues(commonParameter.PinVector.size());
  ARRAY_D rightFrequencyValues(commonParameter.PinVector.size());
  STRING_VECTOR::const_iterator it = commonParameter.PinVector.begin();
  STRING_VECTOR::const_iterator it_end = commonParameter.PinVector.end();

  map<INT,map<STRING, map<INT, ResultData> > > ::const_iterator site_it;
  map<STRING, map<INT, ResultData> >::const_iterator pin_it;
  map<INT, ResultData>::const_iterator lane_it;

  int pinIndex = 0;
  for (;it != it_end; ++it, ++pinIndex)
  {
    site_it = results_hx.resultMap.find(siteNum);
    // because setup error or other error, there is no result for this site.
    if (site_it == results_hx.resultMap.end())
    {
      STRING api = "JitterStardustUtil::judgeAndDatalog: ";
      STRING msg = "These is no result for this site.";
      throw Error(api.c_str(),msg.c_str(),api.c_str());
    }
    pin_it = site_it->second.find(*it);
    // because setup error or other error, there is no result for this site.
    if (pin_it == site_it->second.end())
    {
      STRING api = "JitterStardustUtil::judgeAndDatalog: ";
      STRING msg = "These is no result for this pin.";
      throw Error(api.c_str(),msg.c_str(),api.c_str());
    }

    //(results.jitterResult.commonResultMap.find(siteNum)->second.find(*it)->second.lastStatus
    JitterUtilHX::JitterDataHX jitterData_HX = 
    const_cast<JitterUtilHX::JitterDataHX&>(results_hx.jitterDataHX);

    for (int lane=0; lane<jitterData_HX.HXPIN_Resource[siteNum][*it].Lanes_Number; lane++)
    {

      switch (jitterData_HX.Sync_Result[siteNum][*it][lane].lastStatus)
      {
      case JitterUtilHX::LEFT_JITTER:
        leftFrequencyValues[pinIndex] = pin_it->second.find(lane)->second.leftFrequency[1] * factor;
        break;
      case JitterUtilHX::RIGHT_JITTER:
        rightFrequencyValues[pinIndex] = pin_it->second.find(lane)->second.rightFrequency[1] * factor;
        break;
      case JitterUtilHX::BOTH_JITTER:
        leftFrequencyValues[pinIndex] = pin_it->second.find(lane)->second.leftFrequency[1] * factor;
        rightFrequencyValues[pinIndex] = pin_it->second.find(lane)->second.rightFrequency[1] * factor;
        break;
      case JitterUtilHX::AUTOSYNC_FAIL:
      case JitterUtilHX::LEFT_TRANSITION_FAIL:
      case JitterUtilHX::RIGHT_TRANSITION_FAIL:
      case JitterUtilHX::BOTH_TRANSITION_FAIL:
      default:
        leftFrequencyValues[pinIndex] = NAN;
        rightFrequencyValues[pinIndex] = NAN;
        break;


      }//end for switch
    }//end for lane
  }//end for pinlist


  if (testlimit.isLimitTableUsed) //limit table way
  {
    switch (commonParameter.transition)
    {
    case JitterUtilHX::LEFT:
      TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
                                                            testlimit.testname, V93kLimits::tmLimits, leftFrequencyValues);
      break;
    case JitterUtilHX::RIGHT:
      TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
                                                            testlimit.testname, V93kLimits::tmLimits, rightFrequencyValues);
      break;
    case JitterUtilHX::BOTH:
      TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
                                                            testlimit.testname, V93kLimits::tmLimits, leftFrequencyValues);
      TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
                                                            testlimit.testname, V93kLimits::tmLimits, rightFrequencyValues);
      break;
    default:
      break;
    }
  }
  else // testflow limit way
  {
    switch (commonParameter.transition)
    {
    case JitterUtilHX::LEFT:
      TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
                                                              testlimit.testname, testlimit.frequencyLimit, leftFrequencyValues);
      break;
    case JitterUtilHX::RIGHT:
      TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
                                                              testlimit.testname, testlimit.frequencyLimit, rightFrequencyValues);
      break;
    case JitterUtilHX::BOTH:
      TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
                                                              testlimit.testname, testlimit.frequencyLimit, leftFrequencyValues);
      TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(commonParameter.PinVector,
                                                              testlimit.testname, testlimit.frequencyLimit, rightFrequencyValues);
      break;
    default:
      break;
    }//end for lane
  }//end for pinlist
}

/**
 *-----------------------------------------------------------------------------
 * @Routine: reportToUI
 *
 * @Purpose: output result to ui_report window
 *
 *-----------------------------------------------------------------------------
 * @Description:
 *   display:
 *       a) summary,just give the summary test result in ui_report
 *       b) detail,will give error count plot and stardust curve
 *       c) analysis,you can get stardust curve in signal analyzer
 *  @Parameters:
 *     INPUT:
 *        parameters---------------test parameters
 *        results------------------result container
 *        output-------------------"NONE" or "ReportUI"
 *  @RETURN:
 * 
 *  @Note:
 *   In every mode of the three display modes, you can get spectrum amplitude
 *   and frequency value in ui_report window.
 *-----------------------------------------------------------------------------
 */ 
void
JitterStardustUtilHX::reportToUI(
                                const JitterStardustParameter& parameters,
                                const JitterStardustResultHX& results_hx,
                                const STRING & output)
{
  if (output == "NONE")
  {
    return;
  }

  const JitterUtilHX::JitterParameter& commonParameter = parameters.commonParameter;

  STRING_VECTOR::const_iterator it = commonParameter.PinVector.begin();
  STRING_VECTOR::const_iterator it_end = commonParameter.PinVector.end();
  INT siteNum = CURRENT_SITE_NUMBER();

  map<INT,map<STRING, map<INT, ResultData> > > ::const_iterator site_it;
  map<STRING, map<INT, ResultData> >::const_iterator pin_it;
  map<INT, ResultData>::const_iterator lane_it;

  if (commonParameter.outputMode == JitterUtilHX::OUTPUT_SUMMARY)// summary mode
  {
    cout << "Jitter Test Summary:   " <<endl;
    cout << "site:                  " << siteNum << endl;
    for (;it != it_end; ++it)
    {
      site_it = results_hx.resultMap.find(siteNum);
      // because setup error or other error, there is no result for this site.
      if (site_it == results_hx.resultMap.end())
      {
        cout<<"Warning::There is no result fot this site: " 
        << siteNum <<endl;
        continue;
      }
      pin_it = site_it->second.find(*it);
      //because setup error or other errors,thers is no result for this pin.
      if (pin_it == site_it->second.end())
      {
        cout<<"Warning::There is no result for this pin: " << *it
        <<"in site: " << siteNum <<endl;
        continue;
      }


      // normal case
      JitterUtilHX::JitterDataHX jitterData_HX = 
      const_cast<JitterUtilHX::JitterDataHX&>(results_hx.jitterDataHX);

      for (int lane=0; lane<jitterData_HX.HXPIN_Resource[siteNum][*it].Lanes_Number; lane++)
      {
        switch (jitterData_HX.Sync_Result[siteNum][*it][lane].lastStatus)
        {
        case JitterUtilHX::LEFT_JITTER:
          cout << "Pins:                    " << *it <<endl
          //<< "lanes:                   " << lane <<endl
          << "Left Stardust Result:    " << endl;
          printStardustValue(pin_it->second.find(lane)->second.leftSpectrumAmplitude,
                             pin_it->second.find(lane)->second.leftFrequency);
          break;
        case JitterUtilHX::RIGHT_JITTER:
          cout << "Pins:                    " << *it <<endl
          //<< "lanes:                   " << lane <<endl
          << "Right Stardust Result:   " << endl;
          printStardustValue(pin_it->second.find(lane)->second.rightSpectrumAmplitude,
                             pin_it->second.find(lane)->second.rightFrequency);
          break;
        case JitterUtilHX::BOTH_JITTER:
          cout << "Pins:                    " << *it <<endl
          //<< "lanes:                   " << lane <<endl
          << "Left Stardust Result:    " << endl;
          printStardustValue(pin_it->second.find(lane)->second.leftSpectrumAmplitude,
                             pin_it->second.find(lane)->second.leftFrequency);
          cout << "Right Stardust Result:   " << endl;
          printStardustValue(pin_it->second.find(lane)->second.rightSpectrumAmplitude,
                             pin_it->second.find(lane)->second.rightFrequency);
          break;
        case JitterUtilHX::AUTOSYNC_FAIL:
          JitterUtilHX::printWaringMessage(siteNum,*it,lane);
          cout << "There is no pass pattern!" << endl;
          break;
        case JitterUtilHX::LEFT_TRANSITION_FAIL:
          JitterUtilHX::printWaringMessage(siteNum,*it,lane);
          cout << "There is no transition on left!" << endl;
          break;
        case JitterUtilHX::RIGHT_TRANSITION_FAIL:
          JitterUtilHX::printWaringMessage(siteNum,*it,lane);
          cout << "There is no transition on right!" << endl;
          break;
        case JitterUtilHX::BOTH_TRANSITION_FAIL:
          JitterUtilHX::printWaringMessage(siteNum,*it,lane);
          cout << "There is no transition for both sides!" << endl;
          break;
        default:
          throw Error("JitterStardustUtil::reportToUI",
                      "There is an unknown status for reportToUI!",
                      "JitterStardustUtil::reportToUI");
        }//end for switch
      }
    }//end for pinlist
  }//end for summary mode
  else if (commonParameter.outputMode == JitterUtilHX::OUTPUT_DETAIL)//detail mode
  {
    cout << "JItter Test Detail:  " << endl;
    cout << "site:                " << siteNum <<endl;
    for (;it != it_end; ++it)
    {
      site_it = results_hx.resultMap.find(siteNum);
      // because setup error or other error, there is no result for this site.
      if (site_it == results_hx.resultMap.end())
      {
        cout<<"Warning::There is no result fot this site: " 
        << siteNum <<endl;
        continue;
      }
      pin_it = site_it->second.find(*it);
      // because setup error or other error, there is no result for this pin.
      if (pin_it == site_it->second.end())
      {
        cout<<"Warning::There is no result for this pin: " << *it
        <<"in site: " << siteNum <<endl;
        continue;
      }

      // normal case 
      JitterUtilHX::JitterDataHX jitterData_HX = 
      const_cast<JitterUtilHX::JitterDataHX&>(results_hx.jitterDataHX);
      for (int lane=0; lane<jitterData_HX.HXPIN_Resource[siteNum][*it].Lanes_Number; lane++)
      {

        switch (jitterData_HX.Sync_Result[siteNum][*it][lane].lastStatus)
        {
        case JitterUtilHX::LEFT_JITTER:
          cout << "Pins:                   " << *it << endl
          //<< "lanes:                   " << lane <<endl
          << "Left Stardust Result:   " <<endl;
          printStardustValue(pin_it->second.find(lane)->second.leftSpectrumAmplitude,
                             pin_it->second.find(lane)->second.leftFrequency);

          cout << "Left Stardust Curve:    " << endl;
          printStardustCurve(pin_it->second.find(lane)->second.leftSpectrumAmplitude,
                             pin_it->second.find(lane)->second.leftFrequency);
          break;
        case JitterUtilHX::RIGHT_JITTER:
          cout << "Pins:                   " << *it << endl
          //<< "lanes:                   " << lane <<endl
          << "Right Stardust Result:  " <<endl;
          printStardustValue(pin_it->second.find(lane)->second.rightSpectrumAmplitude,
                             pin_it->second.find(lane)->second.rightFrequency);

          cout << "Right Sardust Curve:    " << endl;
          printStardustCurve(pin_it->second.find(lane)->second.rightSpectrumAmplitude,
                             pin_it->second.find(lane)->second.rightFrequency);
          break;
        case JitterUtilHX::BOTH_JITTER:
          cout << "Pins:                            " << *it << endl
          //<< "lanes:                   " << lane <<endl
          << "Left Stardust Result:   " <<endl;
          printStardustValue(pin_it->second.find(lane)->second.leftSpectrumAmplitude,
                             pin_it->second.find(lane)->second.leftFrequency);

          cout << "Left Stardust Curve:    " << endl;
          printStardustCurve(pin_it->second.find(lane)->second.leftSpectrumAmplitude,
                             pin_it->second.find(lane)->second.leftFrequency);

          cout << "Right Stardust Result:  " <<endl;
          printStardustValue(pin_it->second.find(lane)->second.rightSpectrumAmplitude,
                             pin_it->second.find(lane)->second.rightFrequency);

          cout << "Right Sardust Curve:    " << endl;
          printStardustCurve(pin_it->second.find(lane)->second.rightSpectrumAmplitude,
                             pin_it->second.find(lane)->second.rightFrequency);
          break;            
        case JitterUtilHX::AUTOSYNC_FAIL:
          JitterUtilHX::printWaringMessage(siteNum,*it,lane);
          cout << "There is no pass pattern!" << endl;
          break;
        case JitterUtilHX::LEFT_TRANSITION_FAIL:
          JitterUtilHX::printWaringMessage(siteNum,*it,lane);
          cout << "There is no transition on left!" << endl;
          break;
        case JitterUtilHX::RIGHT_TRANSITION_FAIL:
          JitterUtilHX::printWaringMessage(siteNum,*it,lane);
          cout << "There is no transition on right!" << endl;
          break;
        case JitterUtilHX::BOTH_TRANSITION_FAIL:
          JitterUtilHX::printWaringMessage(siteNum,*it,lane);
          cout << "There is no transition for both sides!" << endl;
          break;
        default:
          throw Error("JitterStardustUtil::reportToUI",
                      "There is an unknown status for reportToUI!",
                      "JitterStardustUtil::reportToUI");
        }
      }
    }
  }
  else // analysis mode
  {
    cout << "Jitter Test Analysis:    " << endl;
    cout << "site       :             " << siteNum << endl;
    for (;it != it_end; ++it)
    {
      site_it = results_hx.resultMap.find(siteNum);
      // because setup error or other error, there is no result for this site.
      if (site_it == results_hx.resultMap.end())
      {
        cout<<"Warning::There is no result fot this site: " << siteNum <<endl;
        continue;
      }
      pin_it = site_it->second.find(*it);
      // because setup error or other error, there is no result for this pin.
      if (pin_it == site_it->second.end())
      {
        cout<<"Warning::There is no result for this pin: " << *it
        <<"in site: " << siteNum <<endl;
        continue;
      }

      // normal case
      JitterUtilHX::JitterDataHX jitterData_HX = 
      const_cast<JitterUtilHX::JitterDataHX&>(results_hx.jitterDataHX);


      for (int lane=0; lane<jitterData_HX.HXPIN_Resource[siteNum][*it].Lanes_Number; lane++)
      {

        switch (jitterData_HX.Sync_Result[siteNum][*it][lane].lastStatus)
        {
        case JitterUtilHX::LEFT_JITTER:
          {
            SCATTER_LOG stardustWaveLeft;
            prepareDataForAnalyzer(pin_it->first,lane,
                                   pin_it->second.find(lane)->second.leftSpectrumAmplitude,
                                   pin_it->second.find(lane)->second.leftFrequency,
                                   stardustWaveLeft);
            PUT_DEBUG(*it,"LEFT STARDUST",stardustWaveLeft);
          }
          cout << "Pins:                   " << *it <<endl;
          //cout << "lanes:                  " << lane <<endl;
          cout << "Left Stardust Result:   " << endl;
          printStardustValue(pin_it->second.find(lane)->second.leftSpectrumAmplitude,
                             pin_it->second.find(lane)->second.leftFrequency);
          break;
        case JitterUtilHX::RIGHT_JITTER:
          {
            SCATTER_LOG stardustWaveRight;
            prepareDataForAnalyzer(pin_it->first,lane,
                                   pin_it->second.find(lane)->second.rightSpectrumAmplitude,
                                   pin_it->second.find(lane)->second.rightFrequency,
                                   stardustWaveRight);
            PUT_DEBUG(*it,"RIGHT STARDUST",stardustWaveRight);
          }
          cout << "Pins:                   " << *it <<endl;
          //cout << "lanes:                  " << lane <<endl;
          cout << "Right Stardust Result:  " << endl;
          printStardustValue(pin_it->second.find(lane)->second.rightSpectrumAmplitude,
                             pin_it->second.find(lane)->second.rightFrequency);
          break;
        case JitterUtilHX::BOTH_JITTER:
          {
            SCATTER_LOG stardustWaveLeft;
            prepareDataForAnalyzer(pin_it->first,lane,
                                   pin_it->second.find(lane)->second.leftSpectrumAmplitude,
                                   pin_it->second.find(lane)->second.leftFrequency,
                                   stardustWaveLeft);
            PUT_DEBUG(*it,"LEFT STARDUST",stardustWaveLeft);

            SCATTER_LOG stardustWaveRight;
            prepareDataForAnalyzer(pin_it->first,lane,
                                   pin_it->second.find(lane)->second.rightSpectrumAmplitude,
                                   pin_it->second.find(lane)->second.rightFrequency,
                                   stardustWaveRight);
            PUT_DEBUG(*it,"RIGHT STARDUST",stardustWaveRight);
          }
          cout << "Pins:                   " << *it <<endl;
          //cout << "lanes:                  " << lane <<endl;
          cout << "Left Stardust Result:   " << endl;
          printStardustValue(pin_it->second.find(lane)->second.leftSpectrumAmplitude,
                             pin_it->second.find(lane)->second.leftFrequency);
          cout << "Right Stardust Result:  " << endl;
          printStardustValue(pin_it->second.find(lane)->second.rightSpectrumAmplitude,
                             pin_it->second.find(lane)->second.rightFrequency);
          break;
        case JitterUtilHX::AUTOSYNC_FAIL:
          JitterUtilHX::printWaringMessage(siteNum,*it,lane);
          cout << ", there is no pass pattern!" << endl;
          break;
        case JitterUtilHX::LEFT_TRANSITION_FAIL:    
          JitterUtilHX::printWaringMessage(siteNum,*it,lane);
          cout << "There is no transition on left!" << endl;
          break;
        case JitterUtilHX::RIGHT_TRANSITION_FAIL:
          JitterUtilHX::printWaringMessage(siteNum,*it,lane);
          cout << "Tthere is no transition on right!" << endl;
          break;
        case JitterUtilHX::BOTH_TRANSITION_FAIL:
          JitterUtilHX::printWaringMessage(siteNum,*it,lane);
          cout << "There is no transition for both sides!" << endl;
          break;
        default:
          throw Error("JitterStardustUtil::reportToUI",
                      "There is an unknown status for reportToUI!",
                      "JitterStardustUtil::reportToUI");
        }
      }
    }
  }
}

/**
 *-----------------------------------------------------------------------------
 *@Routine: JitterStardustUtilHX::printStardustCurve
 *
 *@Purpose: print stardust curve to ui_report window
 *-----------------------------------------------------------------------------
 *@Parameters:
 *  spectrumAmp--------------spectrum amplitude
 *  frequency----------------frequency sequence
 * 
 *@Return:
 *-----------------------------------------------------------------------------
 */
void
JitterStardustUtilHX::printStardustCurve(const vector<DOUBLE>& spectrumAmp,
                                         const vector<DOUBLE>& frequency)
{
  unsigned int row = 32;
  if (row > spectrumAmp.size())
  {
    row = spectrumAmp.size();
  }

  //every line can out put 80 "*" most
  for (unsigned int index = 0;index < row; ++index)
  {
    DOUBLE reference = 0.0;
    if (spectrumAmp[0] != 0)
    {
      reference = spectrumAmp[index]/spectrumAmp[0];
    }
    INT bar = static_cast<INT>(reference *80);
    for (INT i=0;i < bar;++i)
    {
      cout << "*";
    }
    cout << endl;
  }
}

/**
 *-----------------------------------------------------------------------------
 *@Routine: JitterStardustUtilHX::printStardustValue
 *
 *@Purpose: print stardust value result to ui_report window
 *-----------------------------------------------------------------------------
 *@Parameters:
 *  spectrumAmp---------------spectrum amplitude
 *  frequency-----------------frequency sequence
 * 
 *@Return:
 *-----------------------------------------------------------------------------
 */
void
JitterStardustUtilHX::printStardustValue(const vector<DOUBLE>& spectrumAmp,
                                         const vector<DOUBLE>& frequency)
{
  unsigned int rowCounts = 20;
  if (rowCounts > spectrumAmp.size())
  {
    rowCounts = spectrumAmp.size();
  }
  cout << "The top " << rowCounts 
  << " spectrum amplitude and relevant frequency:"
  << endl;
  cout << setw(10) << "Number"
  << setw(25) << "spectrum amplitude"
  << setw(25) << "frequency[MHz]"
  << endl;
  for (unsigned int loop = 0; loop < rowCounts ; ++loop)
  {
    cout << setw(10) << loop
    << setw(25) << spectrumAmp[loop]
    << setw(20) << frequency[loop] * 1000 <<"[MHz]"
    << endl;
  }
}

/**
 *-----------------------------------------------------------------------------
 *@Routine: JitterStardustUtilHX::prepareDataForAnalyzer
 *
 *@Purpose: parepare specturm amplitude and frequency 
 *          sequence data for outputing to signal analyzer
 *-----------------------------------------------------------------------------
 *@Parameters:
 *  INPUT:
 *    pinName-------------------pin name
 *    spectrumAmp---------------spectrum amplitude
 *    frequency-----------------frequency sequence
 *  OUTPUT:
 *    dataForAnalyzer-----------specturm amplitude and frequency sequence data
 *                              for outputing to signal analyzer
 *@Return:
 *-----------------------------------------------------------------------------
 */

void
JitterStardustUtilHX::prepareDataForAnalyzer(
                                            const STRING & pinName,
                                            const INT & lane,
                                            const vector<DOUBLE>& spectrumAmp,
                                            const vector<DOUBLE>& frequency,
                                            SCATTER_LOG& dataForAnalyzer)
{
  unsigned int sizeOfArray = 32;
  if (sizeOfArray > spectrumAmp.size())
  {
    sizeOfArray = spectrumAmp.size();
  }
  ARRAY_D spectrumArray(sizeOfArray);
  ARRAY_D frequencyArray(sizeOfArray);
  for (unsigned int loop =0;loop < sizeOfArray;loop++)
  {
    spectrumArray[loop] = spectrumAmp[loop];
    frequencyArray[loop] = frequency[loop];
  }

  char buffer [33];
  sprintf(buffer, "%d", lane);

  dataForAnalyzer.xAxis(frequencyArray);
  dataForAnalyzer.xTitle("Frequency");
  dataForAnalyzer.xUnit("GHz");
  dataForAnalyzer.yAxis(spectrumArray);
  dataForAnalyzer.yTitle(pinName + buffer + " Stardust Data");
  dataForAnalyzer.yUnit("amplitude");
}

//--------------------------------------------------------------------------
//hx
//--------------------------------------------------------------------------

//error mapֻ�ǲ�һ��strobe����error count�Ǻܶ�strobe
void JitterStardustUtilHX::HX_Error_Map_Acquire(
                                               const JitterStardustParameter& parameters,
                                               JitterStardustResultHX& results_hx,
                                               JitterUtilHX::TRANSITION active)
{

  ERROR_MAP_TEST Freq_Emap(TM::XMODE_CYCLES);

  //JitterUtilHX::SYNC_EDGE Sync_Result;
  //JitterUtilHX::HXPIN_RESOURCE HXPIN_Resource;
  //ResultData Result_Data;
  INT siteNumber;
  INT BitStart;
  INT BitLength;

  JitterUtilHX::JitterDataHX jitter_data_hx = results_hx.jitterDataHX;

  const JitterUtilHX::JitterParameter& commonParameter = parameters.commonParameter;

  BitStart = parameters.errorMapStartCycle;
  BitLength = parameters.acquisitionDepth;

  STRING_VECTOR::const_iterator it = commonParameter.PinVector.begin();
  STRING_VECTOR::const_iterator it_end = commonParameter.PinVector.end();

  //----------------------------------------	
  FOR_EACH_SITE_BEGIN();
  siteNumber = CURRENT_SITE_NUMBER();
  it = commonParameter.PinVector.begin();
  it_end = commonParameter.PinVector.end();
  for (;it != it_end; ++it)
  {
    //----------------------------------------

    JitterUtilHX::HXPIN_RESOURCE& HXPIN_Resource = jitter_data_hx.HXPIN_Resource[siteNumber][*it];

    for (int lane=0; lane<HXPIN_Resource.Lanes_Number; lane++)
    {

      JitterUtilHX::SYNC_EDGE& Sync_Result = jitter_data_hx.Sync_Result[siteNumber][*it][lane];     

      //Get old delay of ReceiverFineDelay for future restore
      Sync_Result.dOldDelay = HIGHSPEEDEXTENSION_LANE(HXPIN_Resource.vBoardLane[lane]).getReceiverFineDelay();

      //Setup Errormap mode
      Freq_Emap.pin(HXPIN_Resource.vLSLanePins[lane]).setLocation(TM::RAM)
      .setRecordingMode(TM::PF)
      .setStartCycle(0);

      //Set strobe to specified position
      if (JitterUtilHX::LEFT == active)
      {
        HIGHSPEEDEXTENSION_LANE(HXPIN_Resource.vBoardLane[lane])
        .receiverFineDelay(results_hx.resultMap[siteNumber][*it][lane].leftHistogram.mean*1e-9);
      }
      if (JitterUtilHX::RIGHT == active)
      {
        HIGHSPEEDEXTENSION_LANE(HXPIN_Resource.vBoardLane[lane])
        .receiverFineDelay(results_hx.resultMap[siteNumber][*it][lane].rightHistogram.mean*1e-9);
      }
    }//end_lane

    //----------------------------------------
  }
  FOR_EACH_SITE_END();
  //----------------------------------------

  //Execute Test
  FUNCTIONAL_TEST();

  ARRAY_LL cycles;

  //----------------------------------------	
  FOR_EACH_SITE_BEGIN();
  siteNumber = CURRENT_SITE_NUMBER();
  it = commonParameter.PinVector.begin();
  it_end = commonParameter.PinVector.end();
  for (;it != it_end; ++it)
  {
    //----------------------------------------

    JitterUtilHX::HXPIN_RESOURCE& HXPIN_Resource = jitter_data_hx.HXPIN_Resource[siteNumber][*it];

    for (int lane=0; lane<HXPIN_Resource.Lanes_Number; lane++)
    {

      JitterUtilHX::SYNC_EDGE& Sync_Result = jitter_data_hx.Sync_Result[siteNumber][*it][lane];

      ResultData& Result_Data = results_hx.resultMap[siteNumber][*it][lane];

      //Initialieze Emap
      Result_Data.Emap.resize(BitLength);
      for (int i=0; i<BitLength; i++)
      {
        Result_Data.Emap[i]=0;
      }

      //Get actural emap result
      for (int i=0; i<HXPIN_Resource.MUX; i++)
      {
        Freq_Emap.pin(HXPIN_Resource.vLSPins[lane*HXPIN_Resource.MUX+i])
        .getFailingCyclesInRange(
                                BitStart/HXPIN_Resource.MUX, 
                                BitLength/HXPIN_Resource.MUX,
                                cycles);

        INT err_index=0;
        for (int j=0; j<cycles.size(); j++)
        {
          err_index=cycles[j]*HXPIN_Resource.MUX+i-BitStart;//4д�����У�Ҫ��mux���
          Result_Data.Emap[err_index]=1;
        }
        //if (isDebugAnalogOn) {
        /*cout<<"lane"<<lane<<"  "
        <<HXPIN_Resource.vLSPins[lane*HXPIN_Resource.MUX+i]
        <<" errorcount = "<<cycles.size()<<endl;*/
        //}
      }

      //Put value to Vector 
      if (JitterUtilHX::LEFT == active)
      {
        Result_Data.leftPFData.clear();
        for (int loop = 0; loop < Result_Data.Emap.size(); loop++)
        {
          Result_Data.leftPFData.push_back(Result_Data.Emap[loop]);
        }
      }
      if (JitterUtilHX::RIGHT == active)
      {
        Result_Data.rightPFData.clear();
        for (int loop = 0; loop < Result_Data.Emap.size(); loop++)
        {
          Result_Data.rightPFData.push_back(Result_Data.Emap[loop]);
        }
      }
      //Reset ReceiverFineDelay
      HIGHSPEEDEXTENSION_LANE(HXPIN_Resource.vBoardLane[lane])
      .receiverFineDelay(Sync_Result.dOldDelay);
    }//end_for_lane
    //----------------------------------------
  }
  FOR_EACH_SITE_END();
  //----------------------------------------
  return;
}



#endif /*INCLUDE_JITTERHISTOGRAM_H*/
