#ifndef DPSCONNECTIVITYUTIL_H_
#define DPSCONNECTIVITYUTIL_H_

#include "DpsConnectivityTestUtil.hpp"

typedef DpsConnectivityTestUtil::MeasurementResultContainer MeasurementResultContainer;
/***************************************************************************
 *                    dpsConnectivity test class 
 ***************************************************************************
 */
class DpsConnectivityTest
{
public:

/*
 *----------------------------------------------------------------------*
 *         test parameters container                                    *
 *----------------------------------------------------------------------*
 */
  struct DpsConnectivityTestParam
  {
    // original input parameters
    string dpsPins;
    string limitName;

    // new generated parameter for convenience
    TM::DCTEST_MODE testMode;
    vector<string> expandedDpsPins; //expanded and validated pins stored in Vector
    string testsuiteName;

    bool isLimitTableUsed; // if limit table is used
    
    // when user use limittable
    int    testNumber;
    string softBinNumberString;
    int    hardBinNumber;

    // initialize stuff to some defaults.
    void init()
    {
      dpsPins = "";
      isLimitTableUsed = false;
      limitName = "";
      testNumber = -1;
      softBinNumberString = "";
      hardBinNumber = -1;
      testMode = TM::GPF;
      expandedDpsPins.clear();
    } 

    // default constructor for intializing parameters
    DpsConnectivityTestParam()
    {
      init();
    }             
  };

  /*
  *----------------------------------------------------------------------*
  *         test results container                                       *
  *----------------------------------------------------------------------*
  */
  struct DpsConnectivityTestResult
  {
    /**
     * result container per Site
     * for current value, the unit is: A
     */
    MeasurementResultContainer dpsResult;

    // initialize all stuffs to some defaults.
    void init()
    {
      dpsResult.init();
    }

    // default constructor
    DpsConnectivityTestResult()
    {
      init();
    }
  };

/*
 *----------------------------------------------------------------------*
 *         public interfaces of DpsConnectivity test                          *
 *----------------------------------------------------------------------*
 */

/*
 *----------------------------------------------------------------------*
 * Routine: processParameter
 *
 * Purpose: parse input parameters and setup internal parameters
 *
 *----------------------------------------------------------------------*
 * Description:
 *   
 * Note:
 *----------------------------------------------------------------------*
 */  
  static void processParameters(const string& dpsPins,
                                const string& testName,
                                DpsConnectivityTestParam& param)
  {   
    // Init param
    param.init();
    
    // get the test mode and test suite name
    param.testMode = DpsConnectivityTestUtil::getMode();
    GET_TESTSUITE_NAME(param.testsuiteName);   
    
    // check whether limit table is used.
    TestTable* myTable = TestTable::getDefaultInstance();
    myTable->readCsvFile();
    param.isLimitTableUsed = myTable->isTmLimitsCsvFile();
    param.dpsPins = DpsConnectivityTestUtil::trim(dpsPins);
    param.limitName = DpsConnectivityTestUtil::trim(testName);
    param.expandedDpsPins = PinUtility.getDpsPinNamesFromPinList(dpsPins,true);

    if(param.isLimitTableUsed)
    {
      try
      {
        DpsConnectivityTestUtil::getLimitInfo(param.limitName,
                                              param.testsuiteName,
                                              param.testNumber,
                                              param.softBinNumberString,
                                              param.hardBinNumber);
      }
      catch (Error& e)
      {
        param.isLimitTableUsed = false;
      }
    }

  }

/*
 *----------------------------------------------------------------------*
 * Routine: doMeasurement
 *
 * Purpose: execute measurement by DPS and store results
 *
 *----------------------------------------------------------------------*
 * Description:
 *   INPUT:  param       - test parameters
 *           result      - result container
 *
 *   OUTPUT: 
 *   RETURN: 
 *----------------------------------------------------------------------*
 */
  static void doMeasurement(const DpsConnectivityTestParam& param,  
                            DpsConnectivityTestResult& result)
  {

    ON_FIRST_INVOCATION_BEGIN();
      // Init result
      result.init();
      DISCONNECT();
      executeAndGetResult(param, result.dpsResult);
    ON_FIRST_INVOCATION_END(); 
  }

/*
 *----------------------------------------------------------------------*
 * Routine: judgeAndDatalog
 *
 * Purpose: judge and put result into event datalog stream.
 *
 *----------------------------------------------------------------------*
 * Description:
 *   judge results of 'result' with pass limits from 'param'
 * 
 *   INPUT:  param       - test parameters
 *           result      - result container
 *           testname    - test name
 *   OUTPUT: 
 *   RETURN: 
 * Note:
 *----------------------------------------------------------------------*
 */  
  static void judgeAndDatalog(const DpsConnectivityTestParam& param, 
                              const DpsConnectivityTestResult& result)
  {
    vector<string>::size_type i = 0;
    bool isPass = true;
    bool ret = true;
    ARRAY_D resultArray;

    int nSiteNumber = CURRENT_SITE_NUMBER();
    if(param.isLimitTableUsed) // use limit table
    {
      switch ( param.testMode )
      {
      case TM::PVAL:  // same as PPF
      case TM::PPF:
        resultArray.resizeNoKeep(param.expandedDpsPins.size());
        for(; i < param.expandedDpsPins.size(); ++i)
        {
          isPass = result.dpsResult.getPinPassFail(param.expandedDpsPins[i],nSiteNumber);
          if(isPass)// for pass pin, in PPF mode, we will write 0.0 to MPR
          {
            resultArray[i] = 0.0;
          }
          else // for fail pin, in PPF mode, we will write 1.0 to MPR
          {
            resultArray[i] = 1.0;
          }
          ret = ret && isPass;
        }
        TESTSET().cont(TM::CONTINUE).testnumber(param.testNumber)
                                    .judgeAndLog_ParametricTest(
                                        param.expandedDpsPins,
                                        param.limitName,
                                        ret ? TM::Pass : TM::Fail,
                                        resultArray);             
        if(!ret && param.softBinNumberString.size() > 0)
        {
          SET_MULTIBIN(param.softBinNumberString,param.hardBinNumber);
        }

        break;

      case TM::GPF:
        isPass = result.dpsResult.getGlobalPassFail(nSiteNumber);
        TESTSET().cont(TM::CONTINUE).testnumber(param.testNumber)
                                    .judgeAndLog_ParametricTest(
                                               param.dpsPins,
                                               param.limitName, 
                                               isPass?TM::Pass : TM::Fail, 
                                               0.0);
        if(!isPass && param.softBinNumberString.size() > 0)
        {
          SET_MULTIBIN(param.softBinNumberString,param.hardBinNumber);
        }
        break;

      default:
        throw Error("DpsConnectivityTest::judgeAndDatalog",
                    "Unknown Test Mode!",
                    "DpsConnectivityTest::judgeAndDatalog");
        break;
      }// end switch
    }
    else // use testflow's limit
    {
      switch ( param.testMode )
      {
      case TM::PVAL:  // same as PPF
      case TM::PPF:
        resultArray.resizeNoKeep(param.expandedDpsPins.size());
        for(; i < param.expandedDpsPins.size(); ++i)
        {
          isPass = result.dpsResult.getPinPassFail(param.expandedDpsPins[i],nSiteNumber);
          if(isPass)// for pass pin, in PPF mode, we will write 0.0 to MPR
          {
            resultArray[i] = 0.0;
          }
          else // for fail pin, in PPF mode, we will write 1.0 to MPR
          {
            resultArray[i] = 1.0;
          }
          ret = ret && isPass;
        }
        TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                        param.expandedDpsPins,
                                        param.limitName,
                                        ret ? TM::Pass : TM::Fail,
                                        resultArray);

        break;

      case TM::GPF:
        isPass = result.dpsResult.getGlobalPassFail(nSiteNumber);
        TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                               param.dpsPins,
                                               param.limitName, 
                                               isPass?TM::Pass : TM::Fail, 
                                               0.0);
        break;

      default:
        throw Error("DpsConnectivityTest::judgeAndDatalog",
                    "Unknown Test Mode!",
                    "DpsConnectivityTest::judgeAndDatalog");
        break;
      }// end switch
    }
  }

/*
 *----------------------------------------------------------------------*
 * Routine: reportToUI
 *
 * Purpose: output result to UIWindow 
 *
 *----------------------------------------------------------------------*
 * Description:
 *   display: 
 *       a) results from result,
 *       b) pass range from pass limits of param,
 *       c) pass or fail
 * 
 *   INPUT:  param              - test parameters
 *           output             - "None" or "ReportUI" 
 *           result             - result container
 *   OUTPUT: 
 *   RETURN:  
 * Note:
 *----------------------------------------------------------------------*
 */ 
  static void reportToUI(const DpsConnectivityTestParam& param, 
                         const DpsConnectivityTestResult& result, 
                         const string& output)
  {
    if("ReportUI" != output)
    {
      return ;
    }

    int nSiteNumber = CURRENT_SITE_NUMBER();
    vector<string>::const_iterator it;
    bool isPass = true;

    cout << "DPS connectivity '" << param.testsuiteName << "'";
    cout << " Site: " << nSiteNumber << endl;


    switch ( param.testMode )
    {
    case TM::PVAL:  // same as PPF */
    case TM::PPF:
      for ( it = param.expandedDpsPins.begin(); it != param.expandedDpsPins.end(); ++it )
      {
        isPass = result.dpsResult.getPinPassFail( *it,nSiteNumber );
        DpsConnectivityTestUtil::datalogToWindow(*it, isPass );
      }
      break;

    case TM::GPF:
      isPass = result.dpsResult.getGlobalPassFail(nSiteNumber);
      DpsConnectivityTestUtil::datalogToWindow(param.testsuiteName, isPass);
      break;

    default:
      throw Error("DpsConnectivityTest:: reportToUI",
                  "Unknown Test Mode!",
                  "DpsConnectivityTest:: reportToUI");
      break;
    }/*end switch*/
  }
  
private:
  DpsConnectivityTest() {}//private constructor to prevent instantiation.
  
  static void executeAndGetResult(const DpsConnectivityTestParam& param,
                                  MeasurementResultContainer& dpsResult);
                 
  static void retrieveResult(const string&  fwAnswer,
                             const TM::DCTEST_MODE&  mode,
                             const vector<string>&    dpsPins,
                             MeasurementResultContainer& dpsResult);
                 
  static void retrieveResultForPPF(const string&   fwAnswer,
                                   const vector<string>&    dpsPins,
                                   MeasurementResultContainer& dpsResult);
};

/*
 *----------------------------------------------------------------------*
 * Routine: DpsConnectivityTest::executeAndGetResult
 *
 * Purpose: send firmwarm command and check
 *       DPS connectivity 
 *      (Force and Sense Connectivity Check)
 *----------------------------------------------------------------------*
 * Description:
 *
 * Note: 
 *   1. assume firmware command works fine.
 *   2. must be called inside ON_FIRST_INVOCATION_BEGIN/END block,
 *      because FOR_EACH_SITE_BEGIN/END block is used below.
 *----------------------------------------------------------------------*
 */
inline void DpsConnectivityTest::executeAndGetResult(
     const DpsConnectivityTestParam& param,
     MeasurementResultContainer& dpsResult)
{
  string fwQuery = "";
  string fwAnswer = "";
  char stringOfSiteNumber[5] = "\0";

  switch (param.testMode)
  {
  case TM::PPF:
  case TM::PVAL: // consider PVAL as PPF for 'PDMM?'
    FOR_EACH_SITE_BEGIN();
      fwQuery += "NOOP?,,,\n";// distinguish every site for firmware paser.
      snprintf(stringOfSiteNumber,5,"%4d", CURRENT_SITE_NUMBER());
      // set focus site
      fwQuery += "PQFC ";
      fwQuery += stringOfSiteNumber ;
      fwQuery += "\n";
      // create fw command for checking dps status
      fwQuery += "PDMM? FO_SE, (" + param.dpsPins + ")\n";
    FOR_EACH_SITE_END();
    break;
  case TM::GPF:
    fwQuery += "PDMM? FO_SE, (" + param.dpsPins + ")\nPRLT? ALL\n";
    break;
  default:
    throw Error("DpsConnectivityTest::executeAndGetResult",
                "Unknown execute mode.",
                "DpsConnectivityTest::executeAndGetResult");
    break; 
  }

  // send query command and get answer
  FW_TASK( fwQuery, fwAnswer );

  // get and record results
  retrieveResult(fwAnswer,param.testMode,param.expandedDpsPins,dpsResult);
}

/*
 *----------------------------------------------------------------------*
 * Routine: DpsConnectivityTest::retrieveResult
 *
 * Purpose: retrieve and record the result of Dps Connectivity. 
 *               
 *----------------------------------------------------------------------*
 * Description:  
 *
 * Note: 
 *   assume firmware command works fine.
 *       
 *----------------------------------------------------------------------*
 */
inline void DpsConnectivityTest::retrieveResult(
     const string&           fwAnswer,
     const TM::DCTEST_MODE&  mode,
     const vector<string>&   dpsPins,
     MeasurementResultContainer& dpsResult)
{
  switch ( mode )
  {
  case TM::PPF:
  case TM::PVAL: 
    retrieveResultForPPF(fwAnswer,dpsPins,dpsResult);
    break;
  case TM::GPF:
    DpsConnectivityTestUtil::parseAndRecordPRLTResult(fwAnswer,dpsResult);
    break;
  default:
    throw Error("DpsConnectivityTest::retrieveResult",
                "Unknown execute mode.",
                "DpsConnectivityTest::retrieveResult");
    break; 
  }
}

/*
 *----------------------------------------------------------------------*
 * Routine: DpsConnectivityTest::retrieveResultForPPF
 *
 * Purpose: retrieve and record the result of Dps Connectivity for PPF
 *               
 *----------------------------------------------------------------------*
 * Description:  
 *
 * Note: 
 *   1. assume firmware command works fine.
 *   2. must be called inside ON_FIRST_INVOCATION_BEGIN/END block,
 *      because FOR_EACH_SITE_BEGIN/END block is used below.    
 *----------------------------------------------------------------------*
 */
inline void DpsConnectivityTest::retrieveResultForPPF(
     const string&           fwAnswer,
     const vector<string>&    dpsPins,
     MeasurementResultContainer& dpsResult)
{
/*
 ***********************************
 * To analyze the query result:
 * examples of the answer string :
 * PDMM FO_SE,,POS,P,(Vcc)
 * PDMM FO_SE,,NEG,P,(Vcc)
 * PDMM FO_SE,,POS,F,(Vee)
 * PDMM FO_SE,,NEG,P,(Vee)
 ***********************************
 */

  string::size_type i = 0;
  string::size_type position = 0;

  // retrieve and record results for each site
  FOR_EACH_SITE_BEGIN();
    int nSiteNumber = CURRENT_SITE_NUMBER();
    string resToken = "";
    bool isPass = true;       // define for per pin result
    bool bGlobalResult = true; // define for global result
  
    position = fwAnswer.find("NOOP",position);

    for ( vector<string>::const_iterator it = dpsPins.begin();
        it != dpsPins.end(); ++it )
    {
      i = position;
      // get POS&NEG results for each pin
      isPass = true;
      for ( int j = 0;  j < 2;  ++j )
      {
        i = fwAnswer.find( *it, i+5 );
        if ( i == string::npos )
        {  //exceptional case: no response for this dps pin
          throw Error( "DpsConnectivityTest::retrieveResultForPPF",
                       "Unexpected result from FW answer." ,
                       "DpsConnectivityTest::retrieveResultForPPF");
        }
        resToken = fwAnswer.substr( i-3,1 );
        /*
         * To get Pass or Fail:
         * apply 'relational and' to positive and negative results
         * for the total result of the specified pin.
         */
        isPass = isPass && 
                 ( ((resToken == "P") || (resToken == "p"))?true:false);
      }        
      // update GPF result
      if ( (!isPass) )
      {
        bGlobalResult = false;
      }
      dpsResult.setPinPassFail( *it,isPass,nSiteNumber);
    }// end of for-loop
  
    position = i;
    // set global result for the site
    dpsResult.setGlobalPassFail(bGlobalResult,nSiteNumber);
  FOR_EACH_SITE_END();
}

#endif /*DPSCONNECTIVITYTEST_H_*/
