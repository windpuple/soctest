#ifndef DPSSTATUSTESTUTIL_HPP_
#define DPSSTATUSTESTUTIL_HPP_
class DpsStatusTestUtil
{
public:
  /*
   *---------------------------------------------------------------------*
   *MeasurementResultContainer:
   *  This class is used to hold and output
   *  global or per pin result: pass/fail, values.
   *---------------------------------------------------------------------*
   *  Notes:
   *  If the results of all sites are cached in Testmethod, not in
   *  TestmethodAPI, this class can store results for each specific site.
   *
   *  Typical use case is to directly use firmware commands to test and get
   *  result for all sites in Testmethod, then use this class to store and
   *  retrieve result for all sites.
   *---------------------------------------------------------------------*
   */
  struct MeasurementResultContainer
  {
    MeasurementResultContainer()
    {
      init();
    };
    ~MeasurementResultContainer() {};
    void setGlobalPassFail(bool isPass,int siteNumber = 0 )
    {
      mMultiSiteGlobalPassFail[siteNumber] = isPass;
    };
    void setPinPassFail(const string& pin,bool isPass,int siteNumber = 0)
    {
      mMultiSitePinPassFail[siteNumber][pin]= isPass;
    };
    void setPinsValue(const string& pins,double value,int siteNumber = 0)
    {
      mMultiSitePinsValue[siteNumber][pins]= value;
    };
    bool getGlobalPassFail(int siteNumber = 0) const
    {
      map< int,bool >::const_iterator it =
                          mMultiSiteGlobalPassFail.find(siteNumber);
      if ( it != mMultiSiteGlobalPassFail.end() )
      {
        return it->second;
      }
      else
      {
        throw Error("MeasurementResultContainer::getGlobalPassFail",
                    "No global result for this site!",
                    "MeasurementResultContainer::getGlobalPassFail");
      }
    };
    bool getPinPassFail(const string& pin,int siteNumber = 0) const
    {
      map< int,map<string,bool> >::const_iterator it =
                                      mMultiSitePinPassFail.find(siteNumber);

      // get the result of the specified site
      if ( it != mMultiSitePinPassFail.end() )
      {
        const map< string,bool >& tmpPinResult = it->second;
        map< string,bool >::const_iterator itPinResult = tmpPinResult.find(pin);

        // get the result of the specified pin
        if ( itPinResult != tmpPinResult.end() )
        {
          return itPinResult->second;
        }
        else
        {
          throw Error("MeasurementResultContainer::getPinPassFail",
                      "No result for this pin: "+pin+".",
                      "MeasurementResultContainer::getPinPassFail");
        }
      }
      else
      {
        throw Error("MeasurementResultContainer::getPinPassFail",
                    "No per pin result for this site!",
                    "MeasurementResultContainer::getPinPassFail");
      }
    };
    double getPinsValue(const string& pins,int siteNumber = 0) const
    {
      map< int,map<string,double> >::const_iterator it =
                                      mMultiSitePinsValue.find(siteNumber);

      // get the result of the specified site
      if ( it != mMultiSitePinsValue.end() )
      {
        const map< string,double >& tmpPinResult = it->second;
        map< string,double >::const_iterator itPinResult = tmpPinResult.find(pins);

        //* get the result of the specified pins
        if ( itPinResult != tmpPinResult.end() )
        {
          return itPinResult->second;
        }
        else
        {
          throw Error("MeasurementResultContainer::getPinsValue",
                      "No result for this pin(s): "+pins+".",
                      "MeasurementResultContainer::getPinsValue");
        }
      }
      else
      {
        throw Error("MeasurementResultContainer::getPinsValue",
                    "No result for this site!",
                    "MeasurementResultContainer::getPinsValue");
      }
    };

    void init()
    {
      mMultiSitePinsValue.clear();
      mMultiSitePinPassFail.clear();
      mMultiSiteGlobalPassFail.clear();
    };
  private:

    /*
     *********************************************
     * Record value for pin(s) per site, e.g.
     *   mMultiSitePinsValue[1] = {"I/O1",2.50}
     *   mMultiSitePinsValue[1] = {"I/O0",1.30}
     *   mMultiSitePinsValue[2] = {"I/O1",2.52}
     *   mMultiSitePinsValue[2] = {"I/O0",1.33}
     *********************************************
     */
    map< INT,map< STRING,DOUBLE > > mMultiSitePinsValue;

    /*
     *********************************************
     * Record pass/fail for each pin per site, e.g.
     *   TRUE: pass; FALSE: fail.
     *   mMultiSitePinPassFail[1] = {"Vcc",FALSE}
     *   mMultiSitePinPassFail[1] = {"Vee",FALSE}
     *   mMultiSitePinPassFail[2] = {"Vcc",TRUE}
     *   mMultiSitePinPassFail[2] = {"Vee",FALSE}
     *********************************************
     */
    map< INT,map< STRING,Boolean > > mMultiSitePinPassFail;
    /*
     *********************************************
     * Record global pass/fail per site, e.g.
     *   TRUE: pass; FALSE: fail.
     *   mMultiSiteGlobalPassFail[1] = TRUE
     *   mMultiSiteGlobalPassFail[2] = FALSE
     *********************************************
     */
    map< INT, Boolean > mMultiSiteGlobalPassFail;

  };
  
  /*
   *----------------------------------------------------------------------*
   * Routine: getLimitInfo
   *
   * Purpose: get test limit information from limit table
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note:
   *
   *----------------------------------------------------------------------*
   */
  
  static void getLimitInfo(const string& testName,
                           const string& testsuite,
                           int& testNumber,
                           string& softBinNumberString,
                           int& hardBinNumber)
  {
    string key = testName;
    if(!testsuite.empty())
    {
      key = testsuite + ":" + key;
    }

    V93kLimits::TMLimits::LimitInfo limitInfo =
                        V93kLimits::tmLimits.getLimit(key);
    testNumber = limitInfo.TestNumber;
    softBinNumberString = limitInfo.BinsNumString;
    hardBinNumber = limitInfo.BinhNum;
    return ;
  }  
  
  /*
   *----------------------------------------------------------------------*
   * Routine: getMode
   *
   * Purpose: define to use PVAL|PPF|GPF according test suite flag
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note:
   *
   *----------------------------------------------------------------------*
   */
  static TM::DCTEST_MODE getMode()
  {
    string testSuiteName = "";

    int valueOnPass = 0;
    int perPinOnPass = 0;
    int valueOnFail = 0;
    int perPinOnFail = 0;

    GET_TESTSUITE_NAME(testSuiteName);
    GET_TESTSUITE_FLAG(testSuiteName, "value_on_pass",   &valueOnPass);
    GET_TESTSUITE_FLAG(testSuiteName, "value_on_fail",   &valueOnFail);
    GET_TESTSUITE_FLAG(testSuiteName, "per_pin_on_pass", &perPinOnPass);
    GET_TESTSUITE_FLAG(testSuiteName, "per_pin_on_fail", &perPinOnFail);

    if ( 1 == valueOnPass || 1 == valueOnFail )
    {
      return TM::PVAL;
    }
    else if ( 1 == perPinOnPass || 1 == perPinOnFail )
    {
      return TM::PPF;
    }

    return TM::GPF;
  }


  /*
   *----------------------------------------------------------------------*
   * Routine: trim
   *
   * Purpose: get rid of head and tail space of input
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note:
   *
   * Return Value: new string
   *----------------------------------------------------------------------*
   */
  static string trim(const string& str)
  {
    int iStart = 0;
    int iStop = 0;
    int i = 0;
    int length = static_cast<int>( str.length());

    for(i=0;i< length;i++)
    {
      if(str[i] != ' ')
      {
        iStart = i;
        break;
      }
    }

    for(i=length-1;i>=0;i--)
    {
      if(str[i] != ' ')
      {
        iStop = i+1;
        break;
      }
    }

    return str.substr(iStart,iStop-iStart);
  }
  /*
   *----------------------------------------------------------------------*
   * Routine: datalogToWindow
   *
   * Purpose: print datalog To report Window
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note:
   *   this protoype only for TM::PPF
   *----------------------------------------------------------------------*
   */
  static void datalogToWindow(const string& pin, const bool bPass)
  {
    ostringstream buf;
    buf << left << setw(16) << pin;
    cout << buf.str() << "\t";
    cout << (bPass? "P": "F") <<endl;
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: parseListOfString
   *
   * Purpose: parse one string to a string vector
   *
   *----------------------------------------------------------------------*
   * Description:
   *    e.g.    the original string is:
   *                "pin1,pin2,pin3,pin4"
   *            and the delimiter char is: ';'
   *    yields the following string vector results:
   *                "pin1", "pin2" , "pin3", "pin4"
   *
   *
   *----------------------------------------------------------------------*
   */
  static void parseListOfString(const string& originalString,
                                vector<string>& stringVec,
                                const char delimiter = ',')
  {
    if(originalString.empty())
    {
      stringVec.clear();
      return;
    }
    string::size_type pos1 = 0, pos2 = 0;
    string tmp;
    pos1 = originalString.find(delimiter, 0);
    if(pos1 != string::npos)
    {
      tmp = originalString.substr(0,pos1);
      stringVec.push_back(trim(tmp));
    }
    pos2 = pos1;
    pos1 = originalString.find(delimiter,pos2 + 1);
    while (pos1 != string::npos)
    {
      tmp = originalString.substr(pos2 + 1, pos1 - pos2 -1 );
      stringVec.push_back(trim(tmp));
      pos2 = pos1;
      pos1 = originalString.find(delimiter, pos2 + 1);
    }
    tmp = originalString.substr(pos2 + 1,originalString.length() - pos2 - 1);
    stringVec.push_back(trim(tmp));
    return;
  }


  /*
   *----------------------------------------------------------------------*
   * Routine: parseAndRecordPRLTResult
   *
   * Purpose: parse and record test results by PRLT
   *
   *----------------------------------------------------------------------*
   * Description:
   *      support multi-site.
   *
   * Note:
   *
   *----------------------------------------------------------------------*
   */
  static void parseAndRecordPRLTResult(
      const string&           fwAnswer,
      MeasurementResultContainer& measResult)
  {
   /*
    ************************************
    * Analyze the query result
    * examples of the answer string:
    * (1) PRLT ALL, "PF0"
    ************************************
    */

    string::size_type  iPosOne = 0;
    iPosOne = fwAnswer.find( "PRLT" );
    iPosOne = fwAnswer.find( '"',iPosOne+5 );

    // retrieve and record results for each site
    FOR_EACH_SITE_BEGIN();
      string resToken = "";
      int nSite = CURRENT_SITE_NUMBER();
      bool bGlobalResult = true; // define for global result

      // retrieve the result of checking states
      resToken = fwAnswer[iPosOne+nSite];
      //get pass/fail
      bGlobalResult = ( (resToken == "P") || (resToken == "p") )?true:false;
      // set global result for the site
      measResult.setGlobalPassFail(bGlobalResult,nSite);
    FOR_EACH_SITE_END();
  }
private:
  DpsStatusTestUtil() {} //private constructor to prevent instantiation.
};

#endif /* DPSSTATUSTESTUTIL_HPP_ */
