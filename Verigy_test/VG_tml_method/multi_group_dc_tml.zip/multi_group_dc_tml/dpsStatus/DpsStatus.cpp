/**
 * (c) Copyright 2011, Verigy Technologies, all rights reserved.
 *
 * Modification History:
 *
 *
 */

//for testmethod framework interfaces
#include "testmethod.hpp"
//for testmethod API interfaces
#include "mapi.hpp"

#include "DpsStatusTest.hpp"

 /**
  *----------------------------------------------------------------------*
  * @testmethod class: DpsStatus
  *
  * @Purpose: DPS Status testing
  *
  *----------------------------------------------------------------------*
  * @Description:
  *   string dpsPins:           {@ | pinlist}
  *     Name of dps pins to be tested
  *   string constantCurrent    { ON| OFF}
  *     check whether dps is in constant current state.
  *   string unregulated        { ON| OFF}
  *     check whether dps is in unregulated state.
  *   string overVoltage        { ON| OFF}
  *     check whether dps is in over voltage state.
  *   string overPowerTemp      { ON| OFF}
  *     check whether dps is in over power/over temperature state.
  *   string testName:
  *     Name of limit
  *   string output:            {ReportUI | None}
  *     Print message or not. 
  *     ReportUI - for debug mode
  *     None - for production mode
  *
  * @Note:
  *
  *----------------------------------------------------------------------*
  */

class DpsStatus: public testmethod::TestMethod
{
protected:
  string  dpsPins;
  string  constantCurrent;
  string  unregulated;
  string  overVoltage;
  string  overPowerTemp;
  string  testName;
  string  output;

  bool isParameterChanged;

  // Assume all sites' parameters are the same
  DpsStatusTest::DpsStatusTestParam param;

protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    addParameter("dpsPins",
                 "PinString",
                 &dpsPins)
      .setDefault("@")
      .setComment("dps pins or dcScale pins in DPS mode need to be tested");
    addParameter("constantCurrent",
                 "string",
                 &constantCurrent)
      .setDefault("OFF")
      .setOptions("ON:OFF")
      .setComment("there are two options: \n"
                  "ON: check constant current state. \n"
                  "OFF: doesn't check constant current state.");
    addParameter("unregulated",
                 "string",
                 &unregulated)
      .setDefault("OFF")
      .setOptions("ON:OFF")
      .setComment("there are two options: \n"
                  "ON: check unregulated state. \n"
                  "OFF: doesn't check unregulated state.");
    addParameter("overVoltage",
                 "string",
                 &overVoltage)
      .setDefault("OFF")
      .setOptions("ON:OFF")
      .setComment("there are two options: \n"
                  "ON: check over voltage state. \n"
                  "OFF: doesn't check unregulated state.");
    addParameter("overPowerTemp",
                 "string",
                 &overPowerTemp)
      .setDefault("OFF")
      .setOptions("ON:OFF")
      .setComment("there are two options: \n"
                  "ON: check over power/ over temperature state. \n"
                  "OFF: doesn't check over power/ over temperature state.");
    addParameter("testName",
                 "string",
                 &testName)
       .setComment("name of limit");
    addParameter("output",
                 "string",
                 &output)
      .setDefault("None")
      .setOptions("ReportUI:None")
      .setComment("print information on UI window");

    isParameterChanged = true;
  }
  
  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
    static DpsStatusTest::DpsStatusTestResult result;
   
    ON_FIRST_INVOCATION_BEGIN();
      /*
       * Process all parameters needed in test. Actually this function is
       * called once under multisite because all input parameters should be
       * the same through all sites. The processed parameters are stored into
       * the static variable 'param' for later reference on all sites.
       */   
      if(isParameterChanged)
      {
        DpsStatusTest::processParameters(dpsPins,
                                         constantCurrent,
                                         unregulated,
                                         overVoltage,
                                         overPowerTemp,
                                         testName,
                                         param);
        isParameterChanged = false;
      }
    ON_FIRST_INVOCATION_END();
     
    /*
     * Execute measurement with the specified 'param' and store results 
     * into the 'result'. The multisite handling, i.e. 
     * ON_FIRST_INVOCATION block are executed inside this function.
     */
    DpsStatusTest::doMeasurement(param,result);
   
    /*
     * Judge and datalog based on the 'result'. This function uses
     * testsuite name as test name, so if you'd like to use your own
     * test names for judgement and datalogging it's needed to modify
     * this funciton or create new one.
     */
    DpsStatusTest::judgeAndDatalog(param,result);
   
    /*
     * Output contents of the 'result' to Report Window if specified by
     * the "output" parameter.
     */
    DpsStatusTest::reportToUI(param,result,output);     
  
    return ;
  }
  
  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   *
   *Note: TestMethod API should not be used in this method.
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    isParameterChanged = true;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string  getComment() const
  {
     static string comment = "version: tml_7.1.2_2.1.4";
     return comment;
  }
};

REGISTER_TESTMETHOD("DcTest.DpsStatus", DpsStatus);
