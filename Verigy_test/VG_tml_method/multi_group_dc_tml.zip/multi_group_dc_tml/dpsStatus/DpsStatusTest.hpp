#ifndef DPSSTATUSUTIL_H_
#define DPSSTATUSUTIL_H_

#include "DpsStatusTestUtil.hpp"

typedef DpsStatusTestUtil::MeasurementResultContainer MeasurementResultContainer;

/***************************************************************************
 *                    dpsStatus test class 
 ***************************************************************************
 */
class DpsStatusTest
{
public:

  enum DpsStatus
  {
    CONSTANT_CURRENT  = 0x02,
    UNREGULATED       = 0x04,
    OVER_VOLTAGE      = 0x08,
    OVER_POWER_TEMP   = 0x30
  };

/*
 *----------------------------------------------------------------------*
 *         test parameters container                                    *
 *----------------------------------------------------------------------*
 */
  struct DpsStatusTestParam
  {
    // original input parameters
    string dpsPins;
    string constantCurrent;
    string unregulated;
    string overVoltage;
    string overPowerTemp;
    string limitName;

    // new generated parameter for convenience
    vector<string> expandedPins;  // expanded and validated pins stored in Vector
    TM::DCTEST_MODE testMode;
    string testsuiteName;
    
    bool isLimitTableUsed; // if limit table is used
    
    // when user use limittable
    int  testNumber;
    string softBinNumberString;
    int hardBinNumber;

    // initialize stuff to some defaults.
    void init()
    {
      dpsPins = "";
      isLimitTableUsed = false;
      testNumber = -1;
      softBinNumberString = "";
      hardBinNumber = -1;
      expandedPins.clear();
      testMode = TM::GPF;
    } 

    // default constructor for intializing parameters*/
    DpsStatusTestParam()
    {
      init();
    }     
  };

  /*
   *----------------------------------------------------------------------*
   *         test results container                                       *
   *----------------------------------------------------------------------*
   */
  struct DpsStatusTestResult
  {
    /**
     * result container per Site
     * for voltage value, the unit is: A
     */
    MeasurementResultContainer dpsResult;

    // initialize all stuffs to some defaults.
    void init()
    {
      dpsResult.init();
    }

    // default constructor
    DpsStatusTestResult()
    {
      init();
    }
  };

/*
 *----------------------------------------------------------------------*
 *         public interfaces of DpsStatus dc test                          *
 *----------------------------------------------------------------------*
 */

/*
 *----------------------------------------------------------------------*
 * Routine: processParameter
 *
 * Purpose: parse input parameters and setup internal parameters
 *
 *----------------------------------------------------------------------*
 * Description:
 *   
 * Note:
 *----------------------------------------------------------------------*
 */
  static void processParameters(const string& dpsPins,
                                const string& constantCurrent,
                                const string& unregulated,
                                const string& overVoltage,
                                const string& overPowerTemp,
                                const string& testName,
                                DpsStatusTestParam& param)
  {
    // init param
    param.init();
    // get the test mode and test suite name
    param.testMode = DpsStatusTestUtil::getMode();
    GET_TESTSUITE_NAME(param.testsuiteName);
    
    // check whether limit table is used.
    TestTable* myTable = TestTable::getDefaultInstance();
    myTable->readCsvFile();
    param.isLimitTableUsed = myTable->isTmLimitsCsvFile();

    param.dpsPins = DpsStatusTestUtil::trim(dpsPins);
    param.expandedPins = PinUtility.getDpsPinNamesFromPinList(dpsPins,true);
    param.constantCurrent = DpsStatusTestUtil::trim(constantCurrent);
    param.unregulated = DpsStatusTestUtil::trim(unregulated);
    param.overVoltage = DpsStatusTestUtil::trim(overVoltage);
    param.overPowerTemp = DpsStatusTestUtil::trim(overPowerTemp);
    param.limitName = DpsStatusTestUtil::trim(testName);
    
    if(param.isLimitTableUsed)
    {
      try
      {
        DpsStatusTestUtil::getLimitInfo(param.limitName,
                                        param.testsuiteName,
                                        param.testNumber,
                                        param.softBinNumberString,
                                        param.hardBinNumber);
      }
      catch (Error& e)
      {
        param.isLimitTableUsed = false;
      }
    }
  };

/*
 *----------------------------------------------------------------------*
 * Routine: doMeasurement
 *
 * Purpose: execute measurement by DPS and store results
 *
 *----------------------------------------------------------------------*
 * Description:
 *   INPUT:  param       - test parameters
 *           result      - result container
 *
 *   OUTPUT: 
 *   RETURN: 
 *----------------------------------------------------------------------*
 */
  static void doMeasurement(const DpsStatusTestParam& param, 
                            DpsStatusTestResult& result)
  {
    ON_FIRST_INVOCATION_BEGIN();
      // init result
      result.init();
      CONNECT();
      executeAndGetResult(param.constantCurrent,
                          param.unregulated,
                          param.overVoltage,
                          param.overPowerTemp,
                          param.expandedPins,
                          param.testMode,
                          result.dpsResult);
    ON_FIRST_INVOCATION_END();



  }

/*
 *----------------------------------------------------------------------*
 * Routine: judgeAndDatalog
 *
 * Purpose: judge and put result into event datalog stream.
 *
 *----------------------------------------------------------------------*
 * Description:
 *   judge results of 'result' with pass limits from 'param'
 * 
 *   INPUT:  param       - test parameters
 *           result      - result container
 *           testname    - test name
 *   OUTPUT: 
 *   RETURN: 
 * Note:
 *----------------------------------------------------------------------*
 */
  static void judgeAndDatalog(const DpsStatusTestParam& param, 
                              const DpsStatusTestResult& result)
  {
    vector<string>::size_type i = 0;
    bool isPass = true;
    bool ret = true;
    ARRAY_D resultArray;

    int nSiteNumber = CURRENT_SITE_NUMBER();

    if(param.isLimitTableUsed) // use limit table
    {
      switch ( param.testMode )
      {
      case TM::PVAL:  //  same as PPF
      case TM::PPF:
        resultArray.resizeNoKeep(param.expandedPins.size());
        for(; i < param.expandedPins.size(); ++i)
        {
          isPass = result.dpsResult.getPinPassFail(param.expandedPins[i],nSiteNumber);
          if(isPass)// for pass pin, in PPF mode, we will write 0.0 to MPR
          {
            resultArray[i] = 0.0;
          }
          else // for fail pin, in PPF mode, we will write 1.0 to MPR
          {
            resultArray[i] = 1.0;
          }
          ret = ret && isPass;
        }
        TESTSET().cont(TM::CONTINUE).testnumber(param.testNumber)
                                    .judgeAndLog_ParametricTest(
                                        param.expandedPins,
                                        param.limitName,
                                        ret ? TM::Pass : TM::Fail,
                                        resultArray);
        if(!ret && param.softBinNumberString.size() > 0)
        {
          SET_MULTIBIN(param.softBinNumberString,param.hardBinNumber);
        }

        break;

      case TM::GPF:
        isPass = result.dpsResult.getGlobalPassFail(nSiteNumber);
        TESTSET().cont(TM::CONTINUE).testnumber(param.testNumber)
                                    .judgeAndLog_ParametricTest(
                                                   param.dpsPins,
                                                   param.limitName, 
                                                   isPass?TM::Pass : TM::Fail, 
                                                   0.0);
        if(!isPass && param.softBinNumberString.size() > 0)
        {
          SET_MULTIBIN(param.softBinNumberString,param.hardBinNumber);
        }
        break;

      default:
        throw Error("DpsStatusTest::judgeAndDatalog",
                    "Unknown Test Mode!",
                    "DpsStatusTest::judgeAndDatalog");
        break;
      }// end switch
    }
    else // use testflow's limit
    {
      switch ( param.testMode )
      {
      case TM::PVAL:  //  same as PPF
      case TM::PPF:
        resultArray.resizeNoKeep(param.expandedPins.size());
        for(; i < param.expandedPins.size(); ++i)
        {
          isPass = result.dpsResult.getPinPassFail(param.expandedPins[i],nSiteNumber);
          if(isPass)// for pass pin, in PPF mode, we will write 0.0 to MPR
          {
            resultArray[i] = 0.0;
          }
          else // for fail pin, in PPF mode, we will write 1.0 to MPR
          {
            resultArray[i] = 1.0;
          }
          ret = ret && isPass;
        }
        TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                        param.expandedPins,
                                        param.limitName,
                                        ret ? TM::Pass : TM::Fail,
                                        resultArray);

        break;

      case TM::GPF:
        isPass = result.dpsResult.getGlobalPassFail(nSiteNumber);
        TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                                   param.dpsPins,
                                                   param.limitName, 
                                                   isPass?TM::Pass : TM::Fail, 
                                                   0.0);
        break;

      default:
        throw Error("DpsStatusTest::judgeAndDatalog",
                    "Unknown Test Mode!",
                    "DpsStatusTest::judgeAndDatalog");
        break;
      }// end switch
    }
  }

/*
 *----------------------------------------------------------------------*
 * Routine: reportToUI
 *
 * Purpose: output result to UIWindow 
 *
 *----------------------------------------------------------------------*
 * Description:
 *   display: 
 *       a) results from result,
 *       b) pass range from pass limits of param,
 *       c) pass or fail
 * 
 *   INPUT:  param              - test parameters
 *           output             - "None" or "ReportUI" 
 *           result             - result container
 *   OUTPUT: 
 *   RETURN:  
 * Note:
 *----------------------------------------------------------------------*
 */ 
  static void reportToUI(const DpsStatusTestParam& param, 
                         const DpsStatusTestResult& result, 
                         const string& output)
  {
    if("ReportUI" != output)
    {
      return;
    }
    vector<string>::const_iterator it;
    bool isPass = true;

    int nSiteNumber = CURRENT_SITE_NUMBER();

    cout << "DPS status '" << param.testsuiteName << "'";
    cout << " Site: " << nSiteNumber << endl;

    switch ( param.testMode )
    {
    case TM::PVAL:  // same as PPF
    case TM::PPF:
      for ( it = param.expandedPins.begin(); it != param.expandedPins.end(); ++it )
      {
        isPass = result.dpsResult.getPinPassFail(*it, nSiteNumber );
        DpsStatusTestUtil::datalogToWindow(*it, isPass );
      }
      break;

    case TM::GPF:
      isPass = result.dpsResult.getGlobalPassFail(nSiteNumber);
      DpsStatusTestUtil::datalogToWindow(param.testsuiteName, isPass);
      break;

    default:
      throw Error("DpsStatusTest::reportToUI",
                  "Unknown Test Mode!",
                  "DpsStatusTest::reportToUI");
      break;
    }// end switch
  }
  
private:
  DpsStatusTest() {} //private constructor to prevent instantiation.
  
  static void executeAndGetResult(
                 const string&           constantCurrent,
                 const string&           unregulated,
                 const string&           overVoltage,
                 const string&           overPowerTemp,
                 const vector<string>&    dpsPins,
                 const TM::DCTEST_MODE&  mode,
                 MeasurementResultContainer& dpsResult);
                            
  static void retrieveResult(
                 const string&           fwAnswer,
                 const TM::DCTEST_MODE&  mode,
                 const int               sizeOfDpsPins,
                 MeasurementResultContainer& dpsResult);
                                       
  static void retrieveResultForPPF(
                 const string&           fwAnswer,
                 const int               sizeOfDpsPins,
                 MeasurementResultContainer& dpsResult);
};
/*
 *----------------------------------------------------------------------*
 * Routine: DpsStatusTest::executeAndGetResult
 *
 * Purpose: send firmware command to check the 
 *               DPS pins status.
 *----------------------------------------------------------------------*
 * Description:  
 *
 * Note: 
 *   1. assume firmware command works fine.
 *   2. must be called inside ON_FIRST_INVOCATION_BEGIN/END block,
 *      because FOR_EACH_SITE_BEGIN/END block is used below.     
 *----------------------------------------------------------------------*
 */
inline void DpsStatusTest::executeAndGetResult(
                                   const string&           constantCurrent,
                                   const string&           unregulated,
                                   const string&           overVoltage,
                                   const string&           overPowerTemp,
                                   const vector<string>&    dpsPins,
                                   const TM::DCTEST_MODE&  mode,
                                   MeasurementResultContainer& dpsResult)
{


  // check the state option
  int commandCodeOfCheckDpsStatus = 0;

  if ("ON" == constantCurrent )
  {
    commandCodeOfCheckDpsStatus |= CONSTANT_CURRENT;
  }

  if ("ON" == unregulated )
  {
    commandCodeOfCheckDpsStatus |= UNREGULATED;
  }

  if ("ON" == overVoltage )
  {
    commandCodeOfCheckDpsStatus |= OVER_VOLTAGE;
  }

  if ("ON" == overPowerTemp )
  {
    commandCodeOfCheckDpsStatus |= OVER_POWER_TEMP;
  }

  char stringOfCommandCode[3] = "\0";
  snprintf(stringOfCommandCode,3,"%2d",commandCodeOfCheckDpsStatus);

  string fwQuery = "";
  string fwAnswer = "";
  char stringOfSiteNumber[5] = "\0";
  string dpsPinsString = PinUtility.createPinListFromPinNames(dpsPins);
  switch ( mode )
  {
  case TM::PPF:
  case TM::PVAL: // consider PVAL as PPF for 'PSAS?'
    FOR_EACH_SITE_BEGIN();
      snprintf(stringOfSiteNumber,5,"%4d", CURRENT_SITE_NUMBER());
      // set focus site
      fwQuery += "PQFC ";
      fwQuery += stringOfSiteNumber ;
      fwQuery += "\n";
      // create fw command for checking dps status
      fwQuery += "PSAS? ";      
      fwQuery += stringOfCommandCode;
      fwQuery += ",(" + dpsPinsString + ")\n";
    FOR_EACH_SITE_END();
    break;
  case TM::GPF:
    fwQuery += "PSAS? ";      
    fwQuery += stringOfCommandCode;
    fwQuery += ",(" + dpsPinsString + ")\nPRLT? ALL\n";
    break;
  default:
    throw Error("DpsStatusTest::executeAndGetResult",
                "Unknown execute mode.",
                "DpsStatusTest::executeAndGetResult");
    break; 
  }

  // send query command and get answer
  FW_TASK( fwQuery, fwAnswer );

  // get and record results
  retrieveResult(fwAnswer,mode,dpsPins.size(),dpsResult);
}

/*
 *----------------------------------------------------------------------*
 * Routine: DpsStatusTest::retrieveResult
 *
 * Purpose: retrieve and record the result of Dps Status. 
 *               
 *----------------------------------------------------------------------*
 * Description:  
 *
 * Note: 
 *   assume firmware command works fine.
 *       
 *----------------------------------------------------------------------*
 */
inline void DpsStatusTest::retrieveResult(
                                   const string&           fwAnswer,
                                   const TM::DCTEST_MODE&  mode,
                                   const int               sizeOfDpsPins,
                                   MeasurementResultContainer& dpsResult)
{
  switch ( mode )
  {
  case TM::PPF:
  case TM::PVAL: 
    retrieveResultForPPF(fwAnswer,sizeOfDpsPins,dpsResult);
    break;
  case TM::GPF:
    DpsStatusTestUtil::parseAndRecordPRLTResult(fwAnswer,dpsResult);
    break;
  default:
    throw Error("DpsStatusTest::retrieveResult",
                "Unknown execute mode.",
                "DpsStatusTest::retrieveResult");
    break; 
  }
}

/*
 *----------------------------------------------------------------------*
 * Routine: DpsStatusTest::retrieveResultForPPF
 *
 * Purpose: retrieve and record the result of Dps Status for PPF mode.
 *               
 *----------------------------------------------------------------------*
 * Description:  
 *
 * Note: 
 *   1. assume firmware command works fine.
 *   2. must be called inside ON_FIRST_INVOCATION_BEGIN/END block,
 *      because FOR_EACH_SITE_BEGIN/END block is used below.     
 *----------------------------------------------------------------------*
 */
inline void DpsStatusTest::retrieveResultForPPF(
                                   const string&           fwAnswer,
                                   const int               sizeOfDpsPins,
                                   MeasurementResultContainer& dpsResult)
{
/*
 *************************************
 * To analyze the query result.
 * examples of the answer string :
 * (1) PSAS F,(Vcc,Vee,Vdd)\n
 * (2) PSAS P,(Vcc)\nPSAS? F,(Vee)\n
 *************************************
 */

  string::size_type i = 0;
  string::size_type j = 0;
  i = fwAnswer.find( "PSAS",i );

  // retrieve and record results for each site
  FOR_EACH_SITE_BEGIN();    
    string resToken = "";
    int siteNumber = CURRENT_SITE_NUMBER();
    bool isPass = true;       // define for per pin result
    bool bGlobalResult = true; // define for global result
  
    //use it to stop parsing result for each site
    int numberOfPins = sizeOfDpsPins;
  
    while ( (i != string::npos) && (numberOfPins > 0) )
    {
      //retrieve the result of checking states
      i = fwAnswer.find( ',',i+5 );
      resToken = fwAnswer[i-1];
  
      // get pass/fail
      isPass = ( (resToken == "P") || (resToken == "p") )?true:false;
  
      // update GPF result
      if ( (!isPass) )
      {
        bGlobalResult = false;
      }
  
      i = fwAnswer.find( '(',i+1 );
      if (string::npos == i)
      {
        break;
      }
      ++i; // point to the starting letter following the '('
      j = fwAnswer.find( ')',i+1 );
      if (string::npos == j)
      {
        break;
      }
  
      // retrieve the pin name
      resToken = fwAnswer.substr( i,j-i );
  
      // Parse this substring and record the results
      vector<string> vectorOfPinNames;
      vectorOfPinNames.clear();
      DpsStatusTestUtil::parseListOfString( resToken,vectorOfPinNames);
      for ( vector<string>::const_iterator it = vectorOfPinNames.begin();
          it != vectorOfPinNames.end(); ++it )
      {
        dpsResult.setPinPassFail( *it,isPass,siteNumber );
        --numberOfPins;
      }
      // try to get the next line starting with 'PSAS'
      i = fwAnswer.find( "PSAS",j+1 );
    }
    //  set global result for the site
    dpsResult.setGlobalPassFail( bGlobalResult,siteNumber );

  FOR_EACH_SITE_END();

}
#endif /*DPSSTATUS_H_*/
