#ifndef OPERATINGCURRENTUTIL_H_
#define OPERATINGCURRENTUTIL_H_

#include "OperatingCurrentTestUtil.hpp"

typedef OperatingCurrentTestUtil::MeasurementResultContainer MeasurementResultContainer;

/***************************************************************************
 *                    operatingCurrent test class 
 ***************************************************************************
 */  
class OperatingCurrentTest
{
public:

/*
 *----------------------------------------------------------------------*
 *         test parameters container                                    *
 *----------------------------------------------------------------------*
 */ 
  struct OperatingCurrentTestParam
  {
    // original input parameters
    vector<string>  dpsPinsVec;
    vector<int>     samplesVec;
    vector<double>  delayTimeVec;
    vector<string>  terminationVec;
    vector<LIMIT>   limitVec;
    vector<string>  limitNameVec;

    // new generated parameter for convenience
    TM::DCTEST_MODE testMode;
    vector<vector<string> >  expandedDpsPinsVec; //expanded and validated Dps pins stored in Vector
    
    string testsuiteName;
    vector<bool> isMeasuredVec;
    vector<bool>  terminationOnGroupsVec;
    vector<bool>  terminationOffGroupsVec;
    bool hasTerminationOnGroups;
    bool hasTerminationOffGroups;
    bool isLimitTableUsed;
    bool isLimitAppliedForAllGroups;
    
    // initialize stuff to some defaults.
    void init()
    {
      dpsPinsVec.clear();
      samplesVec.clear();
      delayTimeVec.clear();
      terminationVec.clear();
      limitVec.clear();
      limitNameVec.clear();
     
      expandedDpsPinsVec.clear();
      isMeasuredVec.clear();
      terminationOnGroupsVec.clear();
      terminationOffGroupsVec.clear();
      hasTerminationOnGroups = false;
      hasTerminationOffGroups = false;
      isLimitTableUsed = false;
      isLimitAppliedForAllGroups = false;
      testMode = TM::GPF;
    }

    // default constructor for intializing parameters
    OperatingCurrentTestParam()
    {
      init();
    }
  };
  
  

 /*
  *----------------------------------------------------------------------*
  *         test results container                                       *
  *----------------------------------------------------------------------*
  */
  struct OperatingCurrentTestResult
  {
    /**
     * result container per site:
     * for value, the unit is: A
     */
    vector<MeasurementResultContainer> dpsResultVec;

    // initialize all stuffs to some defaults.
    void init()
    {
      dpsResultVec.clear();
    }

    // default constructor
    OperatingCurrentTestResult()
    {
      init();
    }
  };

/*
 *----------------------------------------------------------------------*
 *         public interfaces of OperatingCurrent  test                  *
 *----------------------------------------------------------------------*
 */

/*
 *----------------------------------------------------------------------*
 * Routine: processParameter
 *
 * Purpose: parse input parameters and setup internal parameters
 *
 *----------------------------------------------------------------------*
 * Description:
 *   
 * Note:
 *----------------------------------------------------------------------*
 */
  static void processParameters(const string& dpsPins,
                                const string& samples,
                                const string& delayTime_ms,
                                const string& termination,
                                const string& testName,
                                OperatingCurrentTestParam& param)
  {
    // init parameters
    param.init();

    GET_TESTSUITE_NAME(param.testsuiteName);
    param.testMode = OperatingCurrentTestUtil::getMode();

    /**
     *this map is used to store the relationship: pin group instrument
     * map< string, string>
     *        |         |
     *        |         |
     *     pinName   groupName
     *
     * we use this map to check that whether there are the same pin exist
     * in different groups or not.
     */
    map<string, string> pinAndGroupMap;

    // check whether limit table is used.
    TesttableLimitHelper testtableHelper(param.testsuiteName);

    vector<string> testNameVec;
    OperatingCurrentTestUtil::parseListOfString(dpsPins,param.dpsPinsVec);
    OperatingCurrentTestUtil::parseListOfInt(samples,param.samplesVec);
    OperatingCurrentTestUtil::parseListOfDouble(delayTime_ms,param.delayTimeVec);
    OperatingCurrentTestUtil::parseListOfString(termination,param.terminationVec);
    OperatingCurrentTestUtil::parseListOfString(testName,testNameVec);

    vector<string>::size_type groupSize = param.dpsPinsVec.size();
    if(groupSize == 0)
    {
      throw Error("OperatingCurrentTest::processParameters()",
                  "the pinlist groups can not be empty.",
                  "OperatingCurrentTest::processParameters()");
    }

    OperatingCurrentTestUtil::checkParameter(groupSize,
                                             param.samplesVec.size(),
                                             "samples",
                                             param.samplesVec);
    OperatingCurrentTestUtil::checkParameter(groupSize,
                                             param.delayTimeVec.size(),
                                             "delayTime_ms",
                                             param.delayTimeVec);
    OperatingCurrentTestUtil::checkParameter(groupSize,
                                             param.terminationVec.size(),
                                             "termination",
                                             param.terminationVec);

    if(param.dpsPinsVec.size() != testNameVec.size())
    {
      if(testNameVec.size() != 1)
      {
        stringstream errMsg;
        errMsg <<"the number of pinlist groups is " << param.dpsPinsVec.size() <<endl
               <<"the number of testName groups is " << testNameVec.size() <<endl
               <<"So the testName groups don't match pinlist groups." <<endl;
        throw Error("OperatingCurrentTest::processParameters()",
                    errMsg.str(),
                    "OperatingCurrentTest::processParameters()");
      }
      else
      {
        param.isLimitAppliedForAllGroups = true;
        for(vector<string>::size_type i = 1; i < param.dpsPinsVec.size(); i++)
        {
          testNameVec.push_back(testNameVec[0]);
        }
      }
    }

    pair<map<string, string>::iterator, bool> ret;
    for(vector<string>::size_type i = 0; i < param.dpsPinsVec.size(); i++)
    {
      bool isThisGroupNotCommented = ('#' != param.dpsPinsVec[i][0]);
      vector<string> expandedPins;
      if(isThisGroupNotCommented)
      {
        expandedPins = PinUtility.getDpsPinNamesFromPinList(param.dpsPinsVec[i],true);
        // check the duplicate pins
        for (vector<string>::size_type index = 0; index < expandedPins.size(); index++)
        {
          ret = pinAndGroupMap.insert(make_pair(expandedPins[index], param.dpsPinsVec[i]));
          if (!ret.second)
          {
            stringstream errMsg;
            errMsg << "In the group: " << param.dpsPinsVec[i]<< endl
                   << "   and the group: " << ret.first->second << endl
                   << "There are the same pin: "
                   << expandedPins[index] << endl;
            throw Error("OperatingCurrentTest::processParameters",
                        errMsg.str(),
                        "OperatingCurrentTest::processParameters");
          }
        }

        param.isMeasuredVec.push_back(true);
      }
      else
      {
        param.isMeasuredVec.push_back(false);
      }
      param.expandedDpsPinsVec.push_back(expandedPins);

      if(isThisGroupNotCommented)
      {
        if("ON" == param.terminationVec[i])
        {
          param.hasTerminationOnGroups = true;
          param.terminationOnGroupsVec.push_back(true);
          param.terminationOffGroupsVec.push_back(false);
        }
        else if("OFF" == param.terminationVec[i])
        {
          param.hasTerminationOffGroups = true;
          param.terminationOffGroupsVec.push_back(true);
          param.terminationOnGroupsVec.push_back(false);
        }
        else
        {
          stringstream errMsg;
          errMsg <<"For the " << i+1 << " group setup parameter, termination: "
                 <<param.terminationVec[i] << " is invalid."<<endl
                 <<"termination can only be the following options: ON  OFF" <<endl;
          throw Error("OperatingCurrentTest::processParamters()",
                      errMsg.str(),
                      "OperatingCurrentTest::processParamters()");
        }
      }
      else
      {
        param.terminationOnGroupsVec.push_back(false);
        param.terminationOffGroupsVec.push_back(false);
      }

      LIMIT limit;
      param.limitNameVec.push_back(testNameVec[i]);
      
      OperatingCurrentTestUtil::getLimitInfo(testNameVec[i],i,
                                             limit,
                                             testtableHelper);
      param.limitVec.push_back(limit);
    }

    param.isLimitTableUsed = testtableHelper.isAllInTable();
  }
  


/*
 *----------------------------------------------------------------------*
 * Routine: doMeasurement
 *
 * Purpose: execute measurement by DPS and store results
 *
 *----------------------------------------------------------------------*
 * Description:
 *   INPUT:  param       - test parameters
 *           testLimit   - test limit container
 *           result      - result container
 *
 *   OUTPUT: 
 *   RETURN: 
 *----------------------------------------------------------------------*
 */      
  static void doMeasurement(const OperatingCurrentTestParam& param, 
                            OperatingCurrentTestResult& result)
  {
    DPS_TASK dpsTaskForTerminationOff;
    DPS_TASK dpsTaskForTerminationOn;
    string strTermPins;

    ON_FIRST_INVOCATION_BEGIN();

      CONNECT();

      if(param.hasTerminationOnGroups)
      {
        SQGB::theSequencer().run(TM::ENDLESS_PATTERN_LOOP);

        OperatingCurrentTestUtil::dpsInstrumentCurrentMeasurement(
            param.dpsPinsVec,
            param.terminationOnGroupsVec,
            param.delayTimeVec,
            param.samplesVec,
            param.limitVec,
            param.testMode,
            dpsTaskForTerminationOn);

        if ( !SQGB::theSequencer().isRunning() )
        {
          throw Error("OperatingCurrentTest::doMeasurement()",
                      "The Sequencer is stopped when measuring!",
                      "OperatingCurrentTest::doMeasurement()");
        }

        SQGB::theSequencer().abort();
      }

      if(param.hasTerminationOffGroups)
      {
        strTermPins = OperatingCurrentTestUtil::getTerminatedPins();
        OperatingCurrentTestUtil::disconnectPins(strTermPins);

        SQGB::theSequencer().run(TM::ENDLESS_PATTERN_LOOP);

        OperatingCurrentTestUtil::dpsInstrumentCurrentMeasurement(
            param.dpsPinsVec,
            param.terminationOffGroupsVec,
            param.delayTimeVec,
            param.samplesVec,
            param.limitVec,
            param.testMode,
            dpsTaskForTerminationOff);


        if ( !SQGB::theSequencer().isRunning() )
        {
          throw Error("OperatingCurrentTest::doMeasurement()",
                      "The Sequencer is stopped when measuring!",
                      "OperatingCurrentTest::doMeasurement()");
        }

        SQGB::theSequencer().abort();

        OperatingCurrentTestUtil::connectPins(strTermPins);
      }

    ON_FIRST_INVOCATION_END();

    if(param.hasTerminationOnGroups)
    {
      OperatingCurrentTestUtil::dpsMeasurementCurrentGetResult(
          param.dpsPinsVec,
          param.terminationOnGroupsVec,
          param.expandedDpsPinsVec,
          param.testMode,
          dpsTaskForTerminationOn,
          result.dpsResultVec);
    }
    if(param.hasTerminationOffGroups)
    {
      OperatingCurrentTestUtil::dpsMeasurementCurrentGetResult(
          param.dpsPinsVec,
          param.terminationOffGroupsVec,
          param.expandedDpsPinsVec,
          param.testMode,
          dpsTaskForTerminationOff,
          result.dpsResultVec);
    }

  }  

  /*
  *----------------------------------------------------------------------*
  * Routine: judgeAndDatalog
  *
  * Purpose: judge and put result into event datalog stream.
  *
  *----------------------------------------------------------------------*
  * Description:
  *   judge results of 'result' with pass limits from 'param'
  * 
  *   INPUT:  param       - test parameters
  *           testLimit   - test limit container
  *           result      - result container
  *   OUTPUT: 
  *   RETURN: 
  * Note:
  *----------------------------------------------------------------------*
  */ 
  static void judgeAndDatalog(const OperatingCurrentTestParam& param,
                              const OperatingCurrentTestResult& result)
  {
    bool hasBined = false;
    if (param.isLimitTableUsed)
    {
      if(!param.isLimitAppliedForAllGroups)
      {
        OperatingCurrentTestUtil::judgeAndLogUtil(param.isMeasuredVec,
                                                  param.dpsPinsVec,
                                                  param.expandedDpsPinsVec,
                                                  param.limitVec,
                                                  param.limitNameVec,
                                                  result.dpsResultVec,
                                                  param.testMode,
                                                  param.testsuiteName,
                                                  true,
                                                  hasBined);
      }
      else // one limit is applied for all groups
      {
        OperatingCurrentTestUtil::judgeAndLogUtilForAllGroups(
                param.isMeasuredVec,
                param.dpsPinsVec,
                param.expandedDpsPinsVec,
                param.limitVec,
                param.limitNameVec,
                result.dpsResultVec,
                param.testMode,
                param.testsuiteName,
                true,
                hasBined);
      }
    }
    else // use testflow's limit
    {
      if(!param.isLimitAppliedForAllGroups)
      {
        OperatingCurrentTestUtil::judgeAndLogUtil(param.isMeasuredVec,
                                                  param.dpsPinsVec,
                                                  param.expandedDpsPinsVec,
                                                  param.limitVec,
                                                  param.limitNameVec,
                                                  result.dpsResultVec,
                                                  param.testMode,
                                                  param.testsuiteName,
                                                  false,
                                                  hasBined);
      }
      else // one limit is applied for all groups
      {
        OperatingCurrentTestUtil::judgeAndLogUtilForAllGroups(
                param.isMeasuredVec,
                param.dpsPinsVec,
                param.expandedDpsPinsVec,
                param.limitVec,
                param.limitNameVec,
                result.dpsResultVec,
                param.testMode,
                param.testsuiteName,
                false,
                hasBined);
      }
    }
  }


  /*
  *----------------------------------------------------------------------*
  * Routine: reportToUI
  *
  * Purpose: output result to UIWindow 
  *
  *----------------------------------------------------------------------*
  * Description:
  *   display: 
  *       a) results from result,
  *       b) pass range from pass limits of param,
  *       c) pass or fail
  * 
  *   INPUT:  param              - test parameters
  *           output             - "None" or "ReportUI" 
  *           result             - result container
  *   OUTPUT: 
  *   RETURN:  
  * Note:
  *----------------------------------------------------------------------*
  */ 
  static void reportToUI(const OperatingCurrentTestParam& param, 
                         const OperatingCurrentTestResult& result, 
                         const STRING& output)
  {
    if ( output != "ReportUI" )
    {
      return;
    }

    cout << "operating current '" << param.testsuiteName << "'";
    cout << " Site: " << CURRENT_SITE_NUMBER() << endl;


    bool isPass = true;
    vector<string>::const_iterator it;
    
    const vector<MeasurementResultContainer> &resultVec = result.dpsResultVec;

    for(vector<string>::size_type i = 0; i < param.dpsPinsVec.size(); i++)
    {
      if(param.isMeasuredVec[i])
      {
        switch ( param.testMode )
        {
        case TM::PVAL:

          for ( it = param.expandedDpsPinsVec[i].begin();
                it != param.expandedDpsPinsVec[i].end();
                it++ )
          {
            double dVal = resultVec[i].getPinsValue((*it));
            OperatingCurrentTestUtil::datalogToWindow(
                                        *it,
                                        dVal,
                                        param.limitVec[i]);
          }
          break;

        case TM::PPF:

          for ( it=param.expandedDpsPinsVec[i].begin();
                it!=param.expandedDpsPinsVec[i].end();
                it++ )
          {
            isPass = resultVec[i].getPinPassFail((*it));
            OperatingCurrentTestUtil::datalogToWindow(*it, isPass);
          }
          break;

        case TM::GPF:
          isPass = resultVec[i].getGlobalPassFail();
          OperatingCurrentTestUtil::datalogToWindow(param.testsuiteName, isPass);
          break;

        default:
          throw Error("OperatingCurrentTest::CurrentReportUI",
                      "Unknown Test Mode",
                      "OperatingCurrentTest::CurrentReportUI");
        }// end -switch
      }
    }

  }
private:
  OperatingCurrentTest() {} //private constructor to prevent instantiation.

};

#endif /*OPERATINGCURRENTTEST_H_*/

