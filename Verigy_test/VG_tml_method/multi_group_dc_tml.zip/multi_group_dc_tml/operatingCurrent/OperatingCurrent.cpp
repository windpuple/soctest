/**
 * (c) Copyright 2011, Verigy Technologies, all rights reserved.
 *
 * Modification History:
 *
 *
 */

//for testmethod framework interfaces
#include "testmethod.hpp"
//for testmethod API interfaces
#include "mapi.hpp"

#include "OperatingCurrentTest.hpp"
/**
 *----------------------------------------------------------------------*
 * @testmethod class: OperatingCurrent()
 *
 * @Purpose: operating current
 *----------------------------------------------------------------------*
 *
 * @Description: test method program for operating current 
 *              by utilizing DPS_TASK API
 *
 * @Input Parameters:
 *     string dpsPins      :  {@ | DPS pin}
 *       DPS pin(s).
 *     string samples
 *       The samples for DPS  measurement. default is 4. 
 *       This must be positve integer.
 *     string delayTime_ms     :  {ms}
 *       extra delay time between sequence starting 
 *       and the measurement occured. The base unit is ms.
 *     string termination :  {ON | OFF}
 *       "ON" for measurement with termination 
 *       "OFF" for no termination
 *     string testName
 *       Name of limit(s). 
 *
 *     string  output      :  {NONE | ReportUI} 
 *       Print message or not.
 *       ReportUI - for debug mode
 *       None - for production mode
 *  
 * @ Note:
 *-----------------------------------------------------------------------*
 */

class OperatingCurrent: public testmethod::TestMethod
{
protected:
  string  dpsPins;
  string  samples;
  string  delayTime_ms;
  string  termination;
  string  testName;
  string  output;

  bool isParameterChanged;

  // Assume all sites' parameters  are the same
  OperatingCurrentTest::OperatingCurrentTestParam param;

protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    addParameter("dpsPins",
                 "PinString",
                 &dpsPins)
      .setDefault("@")
      .setComment("dps pins or dcScale pins in DPS mode need to be tested");
    addParameter("samples",
                 "string",
                 &samples)
      .setDefault("4")
      .setComment("samples for dps measurement");
    addParameter("delayTime_ms",
                 "string",
                 &delayTime_ms)
      .setDefault("0")
      .setComment("delay time before measurement, e.g. 1[ms]");
    addParameter("termination",
                 "string",
                 &termination)
      .setDefault("OFF")
      .setComment("there are two options: ON  OFF \n");
    addParameter("testName",
                 "string",
                 &testName)
      .setComment("Name of limit(s).");
    addParameter("output",
                 "string",
                 &output)
      .setDefault("None")
      .setOptions("ReportUI:None");

    isParameterChanged = true;
  }
  
  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
    OperatingCurrentTest::OperatingCurrentTestResult result;
    
    ON_FIRST_INVOCATION_BEGIN();
      /*
       * Process all parameters needed in test. Actually this function is
       * called once under multisite because all input parameters should be
       * the same through all sites. The processed parameters are stored into
       * the static variable 'param' for later reference on all sites.
       */   
      if(isParameterChanged)
      {
        OperatingCurrentTest::processParameters(dpsPins,
                                                samples,
                                                delayTime_ms,
                                                termination,
                                                testName,
                                                param);
        isParameterChanged = false;
      }
    ON_FIRST_INVOCATION_END();
   
    /*
     * Execute measurement with the specified 'param' and store results 
     * into the 'result'. The multisite handling, i.e.
     * ON_FIRST_INVOCATION block are executed inside this function.
     */
    OperatingCurrentTest::doMeasurement(param, result);
   
    /*
     * Judge and datalog based on the 'result'. This function uses
     * testsuite name as test name, so if you'd like to use your own
     * test names for judgement and datalogging it's needed to modify
     * this funciton or create new one.
     */
    OperatingCurrentTest::judgeAndDatalog(param,result);
   
    /*
     * Output contents of the 'result' to Report Window if specified by
     * the "output" parameter.
     */
    OperatingCurrentTest::reportToUI(param,result,output);
    return ;
  }
  
  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   *
   *Note: TestMethod API should not be used in this method.
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    isParameterChanged = true;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string  getComment() const
  {
     static string comment = "version: tml_7.1.2_2.1.4";
     return comment;
  }
};

REGISTER_TESTMETHOD("DcTest.OperatingCurrent", OperatingCurrent);
