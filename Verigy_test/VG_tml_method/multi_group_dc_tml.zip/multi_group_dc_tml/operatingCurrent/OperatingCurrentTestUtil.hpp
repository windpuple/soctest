#ifndef OPERATINGCURRENTTESTUTIL_HPP_
#define OPERATINGCURRENTTESTUTIL_HPP_

#include "testmethod.hpp"

/**
 * try to get all required test names from test table
 * record valid test name and invalid test name
 */
class TesttableLimitHelper
{
  private:
    std::vector<std::string> mTestnameNotInTable;
    std::vector<std::string> mTestnameInTable;
    std::string mTestsuiteName;
    bool mIsLimitCsvFileLoad;
  public:
    explicit TesttableLimitHelper(const string& testsuitename)
      :mTestsuiteName(testsuitename),mIsLimitCsvFileLoad(false)
    {
      TestTable* pLimitTable = TestTable::getDefaultInstance();
      pLimitTable->readCsvFile();
      mIsLimitCsvFileLoad = pLimitTable->isTmLimitsCsvFile();

      mTestnameNotInTable.clear();
      mTestnameInTable.clear();
    }

    ~TesttableLimitHelper()
    {
    }

    const std::vector<std::string>& getInvalidTestnames()
    {
      return mTestnameNotInTable;
    }

    const std::vector<std::string>& getValidTestnames()
    {
      return mTestnameInTable;
    }

    //return if all test names are valid in CSV file
    const bool isAllInTable()
    {
      return (mIsLimitCsvFileLoad &&
              !mTestnameInTable.empty() &&
              mTestnameNotInTable.empty());
    }

    const bool isLimitCsvFileLoad()
    {
      return mIsLimitCsvFileLoad;
    }

    /**
     * for the current testsuite, the method try to get the limit object from test table
     * by the specified test name (i.e. name for limit).
     * @param:
     *    testname: the specific test name defined for the testsuite
     *    toLimit: the target limit object defined in test table
     * @note:
     *   1) if the test name is defined in test table,
     *      the target limit object is got from table;
     *      otherwise, the limit object is untouched as it is.
     *   2) exceptional case:
     *      a) if the csv file is not loaded, exception is thrown.
     *
     *      b) if there are multiple limits needed for this testsuite,
     *      and only if some testname are valid but others are NOT valid,
     *      one exception is thrown out!
     */
    void getLimit(const std::string& testname, LIMIT& toLimit)throw(Error)
    {
      if (!mIsLimitCsvFileLoad)
      {
        throw Error("TesttableLimitHelper",
          "no limit CSV file is loaded!",
          "TesttableLimitHelper");
      }

      try
      {
        V93kLimits::TMLimits::LimitInfo& limitInfo =
          V93kLimits::tmLimits.getLimit(mTestsuiteName,testname);

        toLimit = limitInfo.TEST_API_LIMIT;
        mTestnameInTable.push_back(testname);
      }
      catch (Error& e)
      {
        mTestnameNotInTable.push_back(testname);
      }

      //confiliction: some limits are valid but others are not
      if (!mTestnameInTable.empty() && !mTestnameNotInTable.empty())
      {
        throw Error("TesttableLimitHelper",
          "[testsuite: \""+mTestsuiteName+"\"]: test name \""+testname
          +"\" is not found in test table!");
      }
    }
}; //class TesttableLimitHelper

class OperatingCurrentTestUtil
{
public:
  /*
   *---------------------------------------------------------------------*
   *MeasurementResultContainer:
   *  This class is used to hold and output
   *  global or per pin result: pass/fail, values.
   *---------------------------------------------------------------------*
   *  Notes:
   *  If the results of all sites are cached in Testmethod, not in
   *  TestmethodAPI, this class can store results for each specific site.
   *
   *  Typical use case is to directly use firmware commands to test and get
   *  result for all sites in Testmethod, then use this class to store and
   *  retrieve result for all sites.
   *---------------------------------------------------------------------*
   */
  struct MeasurementResultContainer
  {
    MeasurementResultContainer()
    {
      init();
    };
    ~MeasurementResultContainer() {};
    void setGlobalPassFail(bool isPass,int siteNumber = 0 )
    {
      mMultiSiteGlobalPassFail[siteNumber] = isPass;
    };
    void setPinPassFail(const string& pin,bool isPass,int siteNumber = 0)
    {
      mMultiSitePinPassFail[siteNumber][pin]= isPass;
    };
    void setPinsValue(const string& pins,double value,int siteNumber = 0)
    {
      mMultiSitePinsValue[siteNumber][pins]= value;
    };
    bool getGlobalPassFail(int siteNumber = 0) const
    {
      map< int,bool >::const_iterator it =
                          mMultiSiteGlobalPassFail.find(siteNumber);
      if ( it != mMultiSiteGlobalPassFail.end() )
      {
        return it->second;
      }
      else
      {
        throw Error("MeasurementResultContainer::getGlobalPassFail",
                    "No global result for this site!",
                    "MeasurementResultContainer::getGlobalPassFail");
      }
    };
    bool getPinPassFail(const string& pin,int siteNumber = 0) const
    {
      map< int,map<string,bool> >::const_iterator it =
                                      mMultiSitePinPassFail.find(siteNumber);

      // get the result of the specified site
      if ( it != mMultiSitePinPassFail.end() )
      {
        const map< string,bool >& tmpPinResult = it->second;
        map< string,bool >::const_iterator itPinResult = tmpPinResult.find(pin);

        // get the result of the specified pin
        if ( itPinResult != tmpPinResult.end() )
        {
          return itPinResult->second;
        }
        else
        {
          throw Error("MeasurementResultContainer::getPinPassFail",
                      "No result for this pin: "+pin+".",
                      "MeasurementResultContainer::getPinPassFail");
        }
      }
      else
      {
        throw Error("MeasurementResultContainer::getPinPassFail",
                    "No per pin result for this site!",
                    "MeasurementResultContainer::getPinPassFail");
      }
    };
    double getPinsValue(const string& pins,int siteNumber = 0) const
    {
      map< int,map<string,double> >::const_iterator it =
                                      mMultiSitePinsValue.find(siteNumber);

      // get the result of the specified site
      if ( it != mMultiSitePinsValue.end() )
      {
        const map< string,double >& tmpPinResult = it->second;
        map< string,double >::const_iterator itPinResult = tmpPinResult.find(pins);

        //* get the result of the specified pins
        if ( itPinResult != tmpPinResult.end() )
        {
          return itPinResult->second;
        }
        else
        {
          throw Error("MeasurementResultContainer::getPinsValue",
                      "No result for this pin(s): "+pins+".",
                      "MeasurementResultContainer::getPinsValue");
        }
      }
      else
      {
        throw Error("MeasurementResultContainer::getPinsValue",
                    "No result for this site!",
                    "MeasurementResultContainer::getPinsValue");
      }
    };

    void init()
    {
      mMultiSitePinsValue.clear();
      mMultiSitePinPassFail.clear();
      mMultiSiteGlobalPassFail.clear();
    };
  private:

    /*
     *********************************************
     * Record value for pin(s) per site, e.g.
     *   mMultiSitePinsValue[1] = {"I/O1",2.50}
     *   mMultiSitePinsValue[1] = {"I/O0",1.30}
     *   mMultiSitePinsValue[2] = {"I/O1",2.52}
     *   mMultiSitePinsValue[2] = {"I/O0",1.33}
     *********************************************
     */
    map< INT,map< STRING,DOUBLE > > mMultiSitePinsValue;

    /*
     *********************************************
     * Record pass/fail for each pin per site, e.g.
     *   TRUE: pass; FALSE: fail.
     *   mMultiSitePinPassFail[1] = {"Vcc",FALSE}
     *   mMultiSitePinPassFail[1] = {"Vee",FALSE}
     *   mMultiSitePinPassFail[2] = {"Vcc",TRUE}
     *   mMultiSitePinPassFail[2] = {"Vee",FALSE}
     *********************************************
     */
    map< INT,map< STRING,Boolean > > mMultiSitePinPassFail;
    /*
     *********************************************
     * Record global pass/fail per site, e.g.
     *   TRUE: pass; FALSE: fail.
     *   mMultiSiteGlobalPassFail[1] = TRUE
     *   mMultiSiteGlobalPassFail[2] = FALSE
     *********************************************
     */
    map< INT, Boolean > mMultiSiteGlobalPassFail;

  };

  /*
   *----------------------------------------------------------------------*
   * Routine: getMode
   *
   * Purpose: define to use PVAL|PPF|GPF according test suite flag
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note:
   *
   *----------------------------------------------------------------------*
   */
  static TM::DCTEST_MODE getMode()
  {
    string testSuiteName = "";

    int valueOnPass = 0;
    int perPinOnPass = 0;
    int valueOnFail = 0;
    int perPinOnFail = 0;

    GET_TESTSUITE_NAME(testSuiteName);
    GET_TESTSUITE_FLAG(testSuiteName, "value_on_pass",   &valueOnPass);
    GET_TESTSUITE_FLAG(testSuiteName, "value_on_fail",   &valueOnFail);
    GET_TESTSUITE_FLAG(testSuiteName, "per_pin_on_pass", &perPinOnPass);
    GET_TESTSUITE_FLAG(testSuiteName, "per_pin_on_fail", &perPinOnFail);

    if ( 1 == valueOnPass || 1 == valueOnFail )
    {
      return TM::PVAL;
    }
    else if ( 1 == perPinOnPass || 1 == perPinOnFail )
    {
      return TM::PPF;
    }

    return TM::GPF;
  }


  /*
   *----------------------------------------------------------------------*
   * Routine: trim
   *
   * Purpose: get rid of head and tail space of input
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note:
   *
   * Return Value: new string
   *----------------------------------------------------------------------*
   */
  static string trim(const string& str)
  {
    int iStart = 0;
    int iStop = 0;
    int i = 0;
    int length = static_cast<int>(str.length());

    for(i=0;i< length;i++)
    {
      if(str[i] != ' ')
      {
        iStart = i;
        break;
      }
    }

    for(i=length-1;i>=0;i--)
    {
      if(str[i] != ' ')
      {
        iStop = i+1;
        break;
      }
    }

    return str.substr(iStart,iStop-iStart);
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: datalogToWindow
   *
   * Purpose: print datalog To report Window
   *
   *----------------------------------------------------------------------*
   * Description:
   *   this prototype only for TM::PVAL
   * Note:
   *   measuredValue and limit parameter always use default unit,
   *       that's, "A" for current, "V" for voltage.
   *----------------------------------------------------------------------*
   */
  static void datalogToWindow(const string& pin,
                              const double  measuredValue,
                              const LIMIT&  limit)
  {
    string PFjudge = limit.pass(measuredValue)?"P":"F";
    string opl_str, oph_str;

    double lowVal  = 0.0,highVal = 0.0;
    TM::COMPARE lowCmp = TM::NA, highCmp = TM::NA;
    limit.get(lowCmp, lowVal, highCmp, highVal);

    double factor = 1.0;
    if(!(limit.unit().empty()))
    {
      testmethod::SpecValue specValue;
      specValue.setBaseUnit("A");
      specValue.inputValueUnit("1[A]");
      factor = specValue.getValueAsTargetUnit(limit.unit());
    }
    lowVal = lowVal * factor;
    highVal = highVal * factor;

    switch (lowCmp)
    {
      case TM::GT:
        opl_str = "< ";
        break;

      case TM::GE:
        opl_str = "<=";
        break;

      case TM::NA:
        opl_str = "";
        break;

      default:
        throw Error("OperatingCurrentTestUtil::datalogToWindow",
                    "Unknown Compare Mode of opl",
                    "OperatingCurrentTestUtil::datalogToWindow");

    }
    switch (highCmp)
    {
      case TM::LT:
        oph_str = "< ";
        break;

      case TM::LE:
        oph_str = "<=";
        break;

      case TM::NA:
        oph_str = "";
        break;

      default:
        throw Error("OperatingCurrentTestUtil::datalogToWindow",
                    "Unknown Compare Mode of opl",
                    "OperatingCurrentTestUtil::datalogToWindow");

    }

    ostringstream buf;
    buf << left << setw(16) << pin;
    cout << buf.str() << '\t';

    // value of lower limit
    if ( opl_str != "" )
    {
      cout << "min:";
      printValue(lowVal, FALSE);
      cout << '\t' << opl_str << '\t';
    }

    // measured value
    printValue(measuredValue,TRUE);
    cout << '\t';

    // value of higher limit
    if ( oph_str != "" )
    {
      cout << oph_str << '\t' << "max:";
      printValue(highVal, FALSE);
      cout << '\t';
    }

    // Pass or Fail Info
    cout << PFjudge <<endl;
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: datalogToWindow
   *
   * Purpose: print datalog To report Window
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note:
   *   this protoype only for TM::PPF
   *----------------------------------------------------------------------*
   */
  static void datalogToWindow(const string& pin, const bool bPass)
  {
    ostringstream buf;
    buf << left << setw(16) << pin;
    cout << buf.str() << "\t";
    cout << (bPass? "P": "F") <<endl;
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: printValue
   *
   * Purpose: print result value
   *
   *----------------------------------------------------------------------*
   *
   * Note:
   *      the parameter "val" always use default unit, that's, "A" for
   *      current, "V" for voltage.
   *----------------------------------------------------------------------*
   */
  static void printValue(double val,const bool bFormat)
  {
    double dVal = val * 1e6;

    if ( bFormat )
    {
      ostringstream buf;
      buf << setprecision(10) << dVal << " uA";
      cout << right << setw(14) << buf.str() << '\t' << left;
    }
    else
    {
      cout << right << setw(10) << dVal << " uA"  << left;
    }
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: parseListOfString
   *
   * Purpose: parse one string to a string vector
   *
   *----------------------------------------------------------------------*
   * Description:
   *    e.g.    the original string is:
   *                "pin1,(pin2,pin3),pin4"
   *            and the delimiter char is: ','
   *    yields the following string vector results:
   *                "pin1", "pin2,pin3", "pin4"
   *
   *
   *----------------------------------------------------------------------*
   */
  static void parseListOfString(const string& originalString,
                                vector<string>& stringVec,
                                const char delimiter = ',',
                                const bool isParenthesesSupported = false)
  {
    if(originalString.empty())
    {
      stringVec.clear();
      return;
    }
    bool isWithinParentheses = false;
    bool isLeftParenthesesExist = false;
    string word;
    const char* str = originalString.c_str();

    for ( int i = 0 ; *(str+i) != 0 ; ++i )
    {
      char ch = str[i];

      if( ch == delimiter )
      {
        if ( isWithinParentheses && isParenthesesSupported )
        {
          word += ch;
        }
        else 
        {
          stringVec.push_back(trim(word));
          word = "";
        }
      }
      else if (isParenthesesSupported && ch == '(')
      {
        isWithinParentheses = true;
        isLeftParenthesesExist = true;
      }
      else if (isParenthesesSupported && ch == ')') 
      {
        isWithinParentheses = false;
        if(!isLeftParenthesesExist)
        { 
          throw Error("OperatingCurrentTestUtil::parseListOfString",
                      "the parentheses mismatch.The correct format is like:()",
                      "OperatingCurrentTestUtil::parseListOfString");
        }
        isLeftParenthesesExist = false;
      }
      else 
      {
        word += ch;
      }
    }

    if(isLeftParenthesesExist)
    {
      throw Error("OperatingCurrentTestUtil::parseListOfString",
                  "the parentheses mismatch.The correct format is like:()",
                  "OperatingCurrentTestUtil::parseListOfString");    
    }  
    stringVec.push_back(trim(word));

    return;
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: parseListOfDouble
   *
   * Purpose: parse one string to a double vector
   *
   *----------------------------------------------------------------------*
   * Description:
   *    e.g.    the original string is:
   *                "1.5,2.8,5.6"
   *            and the delimiter char is: ','
   *    yields the following double vector results:
   *                "1.5", "2.8", "5.6"
   *
   *
   *----------------------------------------------------------------------*
   */
  static void parseListOfDouble(const string& originalString,
                                vector<double>& doubleVec,
                                const char delimiter = ',')
  {
    if(originalString.empty())
    {
      doubleVec.clear();
      return;
    }
    
    string word;
    double tempValue;
    const char* str = originalString.c_str();

    for ( int i = 0 ; *(str+i) != 0 ; ++i )
    {
      char ch = str[i];
      if( ch == delimiter )
      {
        string tempString = trim(word);
        if(tempString.empty())
        {
          doubleVec.push_back(0.0);
        }
        else
        {
          istringstream stream(word);
          stream >> tempValue;
          doubleVec.push_back(tempValue);
        }
        word = "";
      }
      else 
      {
        word += ch;
      }
    }
    
    string tempString = trim(word);
    if(tempString.empty())
    {
      doubleVec.push_back(0.0);
    }
    else
    {
      istringstream stream(word);
      stream >> tempValue;
      doubleVec.push_back(tempValue);
    }
    return;    
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: parseListOfInt
   *
   * Purpose: parse one string to an integer vector
   *
   *----------------------------------------------------------------------*
   * Description:
   *    e.g.    the original string is:
   *                "1,2,5"
   *            and the delimiter char is: ';'
   *    yields the following integer vector results:
   *                "1", "2", "5"
   *
   *
   *----------------------------------------------------------------------*
   */
  static void parseListOfInt(const string& originalString,
                             vector<int>& intVec,
                             const char delimiter = ',')
  {
    if(originalString.empty())
    {
      intVec.clear();
      return;
    }
    
    string word;
    int tempValue;
    const char* str = originalString.c_str();

    for ( int i = 0 ; *(str+i) != 0 ; ++i )
    {
      char ch = str[i];
      if( ch == delimiter )
      {
        string tempString = trim(word);
        if(tempString.empty())
        {
          intVec.push_back(0);
        }
        else
        {
          istringstream stream(word);
          stream >> tempValue;
          intVec.push_back(tempValue);
        }
        word = "";
      }
      else 
      {
        if(!isdigit(ch))
        {
          throw Error("OperatingCurrentTestUtil::parseListOfInt",
                      ch + " is not a digit character",
                      "OperatingCurrentTestUtil::parseListOfInt");         
        }
        word += ch;
      }
    }
    
    string tempString = trim(word);
    if(tempString.empty())
    {
      intVec.push_back(0);
    }
    else
    {
      istringstream stream(word);
      stream >> tempValue;
      intVec.push_back(tempValue);
    }
    return;    
  }


  
  /*
   *----------------------------------------------------------------------*
   * Routine: getLimitInfo
   *
   * Purpose: get limit, test number,soft bin, hard bin information
   *          from limit table or get limit infomation from testflow 
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note:
   *
   *----------------------------------------------------------------------*
   */
  static void getLimitInfo(
      const string& testName,
      const int groupNumber,
      LIMIT& limit,
      TesttableLimitHelper& testtableHelper)
  {
    TM::COMPARE lowCmp = TM::NA,highCmp = TM::NA;
    double lowVal = 0.0, highVal = 0.0;

    if(testtableHelper.isLimitCsvFileLoad())
    {
      testtableHelper.getLimit(testName,limit);
    }

    if(!testtableHelper.isAllInTable())
    {
      // this API has some issue, it converts the value according
      // to the unit, but it doesn't set the correct unit
      // e.g.  0 uA  <<  limit << 20uA, using this API to get the limit
      // the lowValue of this limit is 0
      // the highValue of this limit is 0.00002
      // but the current unit of this limit still is uA.
      limit = GET_LIMIT_OBJECT(testName);
      if(!(limit.unit().empty()))
      {
        limit.unit("A");
      }
    }

    limit.get(lowCmp,lowVal,highCmp,highVal);

    if ( lowCmp == TM::NA || highCmp == TM::NA )
    {
      throw Error("OperatingCurrentTestUtil::getLimitInfo",
                  testName + " is not specified",
                  "OperatingCurrentTestUtil::getLimitInfo");
    }

    string unitInLimit = limit.unit();
    if(unitInLimit.empty())
    {
      limit.low(lowCmp, lowVal * 1e-6);
      limit.high(highCmp, highVal * 1e-6);
      limit.unit("A");
    }
    else
    {
      testmethod::SpecValue specValue;
      specValue.setBaseUnit("A");
      specValue.inputValueUnit("1[A]");
      double factor = specValue.getValueAsTargetUnit(unitInLimit);
      limit.low(lowCmp,lowVal / factor);
      limit.high(highCmp,highVal / factor);
      limit.unit("A");
    }
    return;
  }
 
  /*
   *----------------------------------------------------------------------*
   * Routine: getTerminatedPins
   *
   * Purpose: Create a pinlist of terminated pins
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note:
   *
   *----------------------------------------------------------------------*
   */
  static string getTerminatedPins()
  {
    string fwAnswer = "";
    string terminatedPins = "";
    string::size_type i = 0;
    string::size_type j = 0;

    /* get answer */
    FW_TASK ( "TERM? PRM,(@)\n", fwAnswer );

    /* parse answer */
    i = fwAnswer.find ("TERM");
    while ( i != string::npos )
    {
       i = fwAnswer.find (',', i + 5);
       i += 1;

       switch ( fwAnswer[i] )
       {
         case 'T':
         case 'A':
         case 'C':
           i = fwAnswer.find ('(', i);
           i += 1;
           j = fwAnswer.find (')', i);

           if ( terminatedPins.length() == 0 )
           {
             terminatedPins = fwAnswer.substr(i,j-i);
           }
           else
           {
             terminatedPins += ',' + fwAnswer.substr(i,j-i);
           }
           break;

         default: // Just skip other types of answer
           break;
       }

       i = fwAnswer.find ("TERM", i);
    }

    return terminatedPins;
  }


  /*
   *----------------------------------------------------------------------*
   * Routine: disconnectPins
   *
   * Purpose: disconnect pins specified in pinlist
   *
   *----------------------------------------------------------------------*
   * Description:
   *   only disconnect pins for enabled sites
   * Note:
   *   please refer to RLYC command
   *----------------------------------------------------------------------*
   */

  static void disconnectPins(const string& pinlist)
  {

    if ( pinlist.length() != 0 )
    {
      string disco;
      string enabledSites;
      GET_ENABLED_SITES(enabledSites);
      disco = "PSFC \"" + enabledSites + "\"\n";
      disco += "RLYC IDLE,OFF,(" + pinlist + ")\n PSFC ALL\n";

      FW_TASK (disco);
    }
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: connectPins
   *
   * Purpose: connect pins specified in pinlist
   *
   *----------------------------------------------------------------------*
   * Description:
   *   only connect pins for enabled sites
   * Note:
   *   please refer to RLYC command
   *----------------------------------------------------------------------*
   */
  static void connectPins(const string& pinlist)
  {
    if ( pinlist.length() != 0)
    {
      string con;
      string enabledSites;
      GET_ENABLED_SITES(enabledSites);
      con = "PSFC \"" + enabledSites + "\"\n";
      con += "RLYC AC,OFF,(" + pinlist + ")\n PSFC ALL\n";

      FW_TASK (con);
    }
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: parameterCheck
   *
   * Purpose: check whether parameter groups match
   *
   *----------------------------------------------------------------------*
   *
   * Note:
   *
   *----------------------------------------------------------------------*
   */
  template <class T>
  static void checkParameter(const unsigned int lSize,
                             const unsigned int rSize,
                             const string& parameter,
                             vector<T>& valueVec )
  {
    if(lSize != rSize)
    {
      if(rSize != 1)
      {
        stringstream errMsg;
        errMsg <<"the number of pinlist groups is " << lSize <<endl
               <<"the number of " << parameter << " groups is " << rSize <<endl
               <<"So the " << parameter << " groups don't match pinlist groups." <<endl;
        throw Error("OperationCurrentTestUtil::checkParameter()",
                    errMsg.str(),
                    "OperationCurrentTestUtil::checkParameter()");
      }
      else
      {
        for(vector<string>::size_type i = 1; i < lSize; i++)
        {
          valueVec.push_back(valueVec[0]);
        }
      }
    }
  }


  /*
   *----------------------------------------------------------------------*
   * Routine: judgeAndLogUtil
   *
   * Purpose: utility function for judgement and data log.
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note:
   *
   *----------------------------------------------------------------------*
   */
  static void judgeAndLogUtil(
    const vector<bool>& isMeasuredVec,
    const vector<string> &pinlistVec,
    const vector<vector<string> > &expandedPinsVec,
    const vector<LIMIT> &limitVec,
    const vector<string> &limitNameVec,
    const vector<MeasurementResultContainer> &resultVec,
    const TM::DCTEST_MODE& mode,
    const string& testsuiteName,
    const bool isLimitTableUsed,
    bool& hasBined)
  {
    vector<string>::size_type j = 0;
    bool isPass = true;
    bool ret = true;
    ARRAY_D resultArray;

    V93kLimits::TMLimits::LimitInfo limitInfo;
    double factor = 1.0;

    for(vector<string>::size_type i = 0; i < pinlistVec.size(); ++i)
    {
      // restore it for every group
      ret = true;
      if (isMeasuredVec[i]) // judge and datalog low level measurement
      {
        if(isLimitTableUsed)
        {
          limitInfo = V93kLimits::tmLimits.getLimit(testsuiteName + ":" + limitNameVec[i]);
        }
        switch ( mode )
        {
        case TM::PVAL:
          resultArray.resizeNoKeep(expandedPinsVec[i].size());

          if(isLimitTableUsed)
          {
            testmethod::SpecValue specValue;
            if( (limitInfo.Units).find('A') != string::npos)
            {
              specValue.setBaseUnit("A");
              specValue.inputValueUnit("1[A]");
              factor = specValue.getValueAsTargetUnit(limitInfo.Units);
            }
            else if(limitInfo.Units.empty())
            {
              factor = 1e6;
            }
            else
            {
              stringstream errMsg;
              errMsg << "the unit: " << limitInfo.Units << " is not a valid unit." <<endl
                     << "current the valid units are: mA,uA..." <<endl;
              throw Error("OperatingCurrentTestUtil::judgeAndLogUtil",
                          errMsg.str(),
                          "OperatingCurrentTestUtil::judgeAndLogUtil");
            }
          }
          for ( j = 0; j< expandedPinsVec[i].size(); ++j )
          {
            resultArray[j] = resultVec[i].getPinsValue(expandedPinsVec[i][j]) * factor;
          }

          if(isLimitTableUsed)
          {
            TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                          expandedPinsVec[i],
                                          limitNameVec[i],
                                          V93kLimits::tmLimits,
                                          resultArray);
          }
          else
          {
            TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                            expandedPinsVec[i],
                                            limitNameVec[i],
                                            limitVec[i],
                                            resultArray);
          }
          break;

        case TM::PPF:
          resultArray.resizeNoKeep(expandedPinsVec[i].size());
          for (j = 0; j < expandedPinsVec[i].size(); ++j )
          {
            isPass = resultVec[i].getPinPassFail(expandedPinsVec[i][j]);
            if(isPass) // for pass pin, in PPF mode, we will write 0.0 to MPR
            {
              resultArray[j] = 0.0;
            }
            else // for fail pin, in PPF mode, we will write 1.0 to MPR
            {
              resultArray[j] = 1.0;
            }
            ret = isPass && ret;
          }

          if(isLimitTableUsed)
          {
            TESTSET().cont(TM::CONTINUE).testnumber(limitInfo.TestNumber)
                                        .judgeAndLog_ParametricTest(
                                            expandedPinsVec[i],
                                            limitNameVec[i],
                                            ret ? TM::Pass : TM::Fail,
                                            resultArray);
            if(!ret && !hasBined && limitInfo.BinsNumString.size() > 0)
            {
              hasBined = true;
              SET_MULTIBIN(limitInfo.BinsNumString,limitInfo.BinhNum);
            }
          }
          else
          {
            TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                            expandedPinsVec[i],
                                            limitNameVec[i],
                                            ret ? TM::Pass : TM::Fail,
                                            resultArray);
          }
          break;

        case TM::GPF:
          isPass = resultVec[i].getGlobalPassFail();
          if(isLimitTableUsed)
          {
            TESTSET().cont(TM::CONTINUE).testnumber(limitInfo.TestNumber)
                                        .judgeAndLog_ParametricTest(
                                            pinlistVec[i],
                                            limitNameVec[i],
                                            isPass ? TM::Pass : TM::Fail,
                                            0.0);

            if(!isPass && !hasBined && limitInfo.BinsNumString.size() > 0)
            {
              hasBined = true;
              SET_MULTIBIN(limitInfo.BinsNumString,limitInfo.BinhNum);
            }
          }
          else
          {
            TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                            pinlistVec[i],
                                            limitNameVec[i],
                                            isPass ? TM::Pass : TM::Fail,
                                            0.0);
          }
          break;
        default:
          throw Error("OperatingCurrentTestUtil::judgeAndLogUtil",
                      "Unknown Test Mode",
                      "OperatingCurrentTestUtil::judgeAndLogUtil");
        } // end switch
      } // end if:
    }// end for every group
  }
  /*
   *----------------------------------------------------------------------*
   * Routine: judgeAndLogUtilForAllGroups
   *
   * Purpose: judgement and data log.for: one limit is applied for all groups
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note:
   *
   *----------------------------------------------------------------------*
   */
  static void judgeAndLogUtilForAllGroups(
    const vector<bool>& isMeasuredVec,
    const vector<string> &pinlistVec,
    const vector<vector<string> > &expandedPinsVec,
    const vector<LIMIT> &limitVec,
    const vector<string> &limitNameVec,
    const vector<MeasurementResultContainer> &resultVec,
    const TM::DCTEST_MODE& mode,
    const string& testsuiteName,
    const bool isLimitTableUsed,
    bool& hasBined)
  {
    vector<string>::size_type j = 0;
    bool isPass = true;
    bool ret = true;
    ARRAY_D resultArray;

    int sizeOfArray = 0;
    vector<string> pinVec;
    string allPinlist;

    for(vector<string>::size_type i = 0; i < expandedPinsVec.size(); ++i)
    {
      if(isMeasuredVec[i])
      {
        sizeOfArray += expandedPinsVec[i].size();
      }
    } // end for: every group

    V93kLimits::TMLimits::LimitInfo limitInfo;
    if(isLimitTableUsed)
    {
      limitInfo = V93kLimits::tmLimits.getLimit(testsuiteName + ":" + limitNameVec[0]);
    }
    int index = 0;
    double factor = 1.0;

    switch(mode)
    {
    case TM::PVAL:
      resultArray.resizeNoKeep(sizeOfArray);

      if(isLimitTableUsed)
      {
        testmethod::SpecValue specValue;
        if( (limitInfo.Units).find('A') != string::npos)
        {
          specValue.setBaseUnit("A");
          specValue.inputValueUnit("1[A]");
          factor = specValue.getValueAsTargetUnit(limitInfo.Units);
        }
        else if(limitInfo.Units.empty())
        {
          factor = 1e6;
        }
        else
        {
          stringstream errMsg;
          errMsg << "the unit: " << limitInfo.Units << " is not a valid unit." <<endl
                 << "current the valid units are: mA,uA..." <<endl;
          throw Error("OperatingCurrentTestUtil::judgeAndLogUtil",
                      errMsg.str(),
                      "OperatingCurrentTestUtil::judgeAndLogUtil");
        }
      }

      for(vector<string>::size_type i = 0; i < expandedPinsVec.size(); ++i)
      {
        if(isMeasuredVec[i])
        {
          for (j = 0; j < expandedPinsVec[i].size(); ++j)
          {
            resultArray[index] = resultVec[i].getPinsValue(expandedPinsVec[i][j]);
            resultArray[index] = resultArray[index] * factor;
            pinVec.push_back(expandedPinsVec[i][j]);
            index++;
          }
        }
      }// end for: every group

      if(isLimitTableUsed)
      {
        if(pinVec.size() > 0)
        {
          TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                        pinVec,
                                        limitNameVec[0],
                                        V93kLimits::tmLimits,
                                        resultArray);
        }
      }
      else // use test flow's limits
      {
        if(pinVec.size() > 0)
        {
          TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                        pinVec,
                                        limitNameVec[0],
                                        limitVec[0],
                                        resultArray);
        }
      }

      break;

    case TM::PPF:
      resultArray.resizeNoKeep(sizeOfArray);
      for(vector<string>::size_type i = 0; i < expandedPinsVec.size(); ++i)
      {
        if(isMeasuredVec[i])
        {
          for(j = 0; j < expandedPinsVec[i].size(); ++j)
          {
            isPass = resultVec[i].getPinPassFail(expandedPinsVec[i][j]);
            if(isPass) // for pass pin, in PPF mode, we will write 0.0 to MPR
            {
              resultArray[index] = 0.0;
            }
            else // for fail pin, in PPF mode, we will write 1.0 to MPR
            {
              resultArray[index] = 1.0;
            }
            ret = isPass && ret;
            pinVec.push_back(expandedPinsVec[i][j]);
            index++;
          }
        }
      } // end for: every group

      if(isLimitTableUsed)
      {
        if(pinVec.size() > 0)
        {
          TESTSET().cont(TM::CONTINUE).testnumber(limitInfo.TestNumber)
                                      .judgeAndLog_ParametricTest(
                                          pinVec,
                                          limitNameVec[0],
                                          ret ? TM::Pass : TM::Fail,
                                          resultArray);
        }
        if(!hasBined && !ret && limitInfo.BinsNumString.size() > 0)
        {
          hasBined = true;
          SET_MULTIBIN(limitInfo.BinsNumString,limitInfo.BinhNum);
        }
      }
      else // use test flow's limits
      {
        if(pinVec.size() > 0)
        {
          TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                          pinVec,
                                          limitNameVec[0],
                                          ret ? TM::Pass : TM::Fail,
                                          resultArray);
        }
      }
      break;

    case TM::GPF:
      for(vector<string>::size_type i = 0; i < expandedPinsVec.size(); ++i)
      {
        if(isMeasuredVec[i])
        {
          ret = ret && resultVec[i].getGlobalPassFail();
          allPinlist = allPinlist + pinlistVec[i] + ",";
        }
      }

      if(isLimitTableUsed)
      {
        if(!allPinlist.empty())
        {
          allPinlist = allPinlist.substr(0,allPinlist.length() -1);
          TESTSET().cont(TM::CONTINUE).testnumber(limitInfo.TestNumber)
                                      .judgeAndLog_ParametricTest(
                                          allPinlist,
                                          limitNameVec[0],
                                          ret ? TM::Pass : TM::Fail,
                                          0.0);
        }
        if(!hasBined && !ret && limitInfo.BinsNumString.size() > 0)
        {
          hasBined = true;
          SET_MULTIBIN(limitInfo.BinsNumString,limitInfo.BinhNum);
        }
      }
      else // use test flow's limits
      {
        if(!allPinlist.empty())
        {
          allPinlist = allPinlist.substr(0,allPinlist.length() -1);
          TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                          allPinlist,
                                          limitNameVec[0],
                                          ret ? TM::Pass : TM::Fail,
                                          0.0);
        }
      }

      break;
    default:
      throw Error("OperatingCurrentTestUtil::judgeAndLogUtilForAllGroups",
                  "Unknown Test Mode",
                  "OperatingCurrentTestUtil::judgeAndLogUtilForAllGroups");

    } // end switch
  }


  static void dpsInstrumentCurrentMeasurement(
      const vector<string>& pinlistVec,
      const vector<bool>&   isMeasuredVec,
      const vector<double>& waitTimeVec,
      const vector<int>&    samplesVec,
      const vector<LIMIT>&  limitVec,
      const TM::DCTEST_MODE& testMode,
      DPS_TASK&  dpsTask)
  {
    // for Parallel execute mode
    double waitTime = 0.0;

    for(vector<string>::size_type i = 0; i < pinlistVec.size(); i++)
    {
      if(isMeasuredVec[i])
      {
        dpsTask.pin(pinlistVec[i]).limits(limitVec[i]);
        dpsTask.samples(samplesVec[i]);
        if(waitTime < waitTimeVec[i])
        {
          waitTime = waitTimeVec[i];
        }
      }
    }

    dpsTask.wait(waitTime ms);
    dpsTask.execMode(testMode);

    dpsTask.execute();
  };

  static void dpsMeasurementCurrentGetResult(
      const vector<string>& pinlistVec,
      const vector<bool>&   isMeasuredVec,
      const vector<vector<string> >& expandedPinsVec,
      const TM::DCTEST_MODE& testMode,
      const DPS_TASK&    dpsTask,
      vector<MeasurementResultContainer>& resultVec)
  {
    // get test result
    MeasurementResultContainer everyGroupResult;
    for(vector<string>::size_type i = 0; i < pinlistVec.size(); i++)
    {
      if(resultVec.size() <= i)
      {
        everyGroupResult.init();
        resultVec.push_back(everyGroupResult);
      }
      
      if(isMeasuredVec[i])
      {
        vector<string>::size_type  j = 0;
        bool isPass = true;

        switch ( testMode )
        {
        case TM::PVAL:
          for ( j = 0; j < expandedPinsVec[i].size(); j++ )
          {
            isPass = dpsTask.getPassFail(expandedPinsVec[i][j]);
            double dMeasValue = dpsTask.getValue(expandedPinsVec[i][j]);

            resultVec[i].setPinPassFail(expandedPinsVec[i][j],isPass);
            resultVec[i].setPinsValue(expandedPinsVec[i][j],dMeasValue);
          }
          break;

        case TM::PPF:
          for ( j = 0; j < expandedPinsVec[i].size(); j++ )
          {
            isPass = dpsTask.getPassFail(expandedPinsVec[i][j]);
            resultVec[i].setPinPassFail(expandedPinsVec[i][j],isPass);
          }
          break;

        case TM::GPF:
          isPass = dpsTask.getPassFail();
          resultVec[i].setGlobalPassFail(isPass);
          break;

        default:
          throw Error("OperatingCurrentTestUtil::dpsMeasurementCurrentGetResult",
                      "Unknown Measure Mode",
                      "OperatingCurrentTestUtil::dpsMeasurementCurrentGetResult");
        }
      }
    }
  };
private:
  OperatingCurrentTestUtil() {} //private constructor to prevent instantiation.
};

#endif /* OPERATINGCURRENTTESTUTIL_HPP_ */
