/**
 * (c) Copyright 2011, Verigy Technologies, all rights reserved.
 *
 * Modification History:
 *
 *
 */

//for testmethod framework interfaces
#include "testmethod.hpp"
//for testmethod API interfaces
#include "mapi.hpp"

#include "GeneralPMUTest.hpp"
/**
 *----------------------------------------------------------------------*
 * @testmethod class: GeneralPMU
 *
 * @Purpose: general PMU testing
 *
 *----------------------------------------------------------------------*
 * @Description:
 *   ppmu instrument parameter
 *   string ppmuUsed:            {YES | NO }
 *     indicate whether use ppmu to do test or not.
 *   string ppmuPinlist:              {@ | pinlist}
 *     Name of pins to be tested
 *     Valid pins: I,O,IO type ditigal pins.
 *   string ppmuForceMode:            {VOLT | CURR}
 *     VOLT - VFIM
 *     CURR - IFVM
 *   string ppmuForceValue             {mV | uA}
 *     Value of force voltage (for VFIM test), the unit is mV.
 *     Value of force current (for IFVM test), the unit is uA.
 *   string ppmuMeasureMode:          {PAR | SER}
 *     PAR - parallel
 *     SER - serial
 *   string ppmuPrecharge             {ON | OFF}
 *     Enable precharging or not
 *   string ppmuPrechargeVoltage_mV       {mV}
 *     Value of precharging voltage, the unit is mV.
 *   string ppmuRelaySwitchMode:      {DEFAULT(BBM) | MBB | PARALLEL}
 *     In case of no termination:
 *     BBM - Break before Make: Open AC,PMU and DC relay, then open
 *           AC relay, Close PMU and open DC relay relay.
 *     MBB - Make before break: Close PMU relay, then Open AC relay
 *     PARALLEL: Open AC relay and Close PMU relay in parallel
 *   string ppmuSettlingTime_ms           {ms}
 *     Value of settling time, the unit is ms.
 *   string ppmuTermination           {ON | OFF}
 *     The test is performed with or without termination
 *   string ppmuTestName
 *     Name of limit(s). 
 * 
 *   spmu instrument parameter
 *   string spmuUsed:            {YES | NO }
 *     indicate whether use spmu to do test or not.
 *   string spmuPinlist:              {@ | pinlist}
 *     Name of pins to be tested
 *     Valid pins: all digital pins.
 *   string spmuForceMode:            {VOLT | CURR}
 *     VOLT - VFIM
 *     CURR - IFVM
 *   string spmuForceValue             {mV | uA}
 *     Value of force voltage (for VFIM test), the unit is mV.
 *     Value of force current (for IFVM test), the unit is uA.
 *   string spmuMeasureMode:          {PAR | SER}
 *     PAR - parallel
 *     SER - serial
 *   string spmuClampValue              {uA | mV}
 *     Value of clamp current (VFIM test), the unit is uA.
 *     Value of clamp voltage (IFVM test), the unit is mV.
 *   string spmuPrecharge             {ON | OFF}
 *     Enable precharging or not
 *   string spmuPrechargeVoltage_mV       {mV}
 *     Value of precharging voltage, the unit is mV.
 *   string spmuRelaySwitchMode:      {NTBBM | NTMBB}
 *     In case of no termination:
 *      NTBBM - Non-terminated,Break before Make(open AC relay, then close PMU relay)
 *      NTMBB - Non-terminated,Make before break(close PMU relay, then open AC relay)
 *   string spmuSettlingTime_ms           {ms}
 *     Value of settling time, the unit is ms.
 *   string spmuTermination           {ON | OFF}
 *     The test is performed with or without termination
 *   string spmuTestName
 *     Name of limit(s).
 *
 *   analog pmu instrument parameter
 *   string mcxUsed:            {YES | NO }
 *     indicate whether use analog pmu to do test or not.
 *   string mcxPinlist:              {@ | pinlist}
 *     Name of pins to be tested
 *     Valid pins: all analog pins.
 *   string mcxForceMode:            {VOLT | CURR}
 *     VOLT - VFIM
 *     CURR - IFVM
 *   string mcxForceValue             {mV | uA}
 *     Value of force voltage (for VFIM test), the unit is mV.
 *     Value of force current (for IFVM test), the unit is uA.
 *   string mcxMeasureMode:          {PAR | SER}
 *     PAR - parallel
 *     SER - serial
 *   string mcxPrecharge             {ON | OFF}
 *     Enable precharging or not
 *   string mcxPrechargeVoltage_mV       {mV}
 *     Value of precharging voltage, the unit is mV.
 *   string mcxSettlingTime_ms           {ms}
 *     Value of settling time, the unit is ms.
 *   string mcxTermination           {ON | OFF}
 *     The test is performed with or without termination
 *   string mcxTestName
 *     Name of limit(s).
 * 
 *   dc scale instrument parameter in SIG mode
 *   string dcScaleSIGUsed:            {YES | NO }
 *     indicate whether use dc scale instrument in SIG mode to do test or not.
 *   string dcScaleSIGPinlist:              {@ | pinlist}
 *     Name of pins to be tested
 *     Valid pins: all dc scale pins in SIG mode.
 *   string dcScaleSIGForceMode:            {VOLT | CURR}
 *     VOLT - VFIM
 *     CURR - IFVM
 *   string dcScaleSIGForceValue             {mV | uA}
 *     Value of force voltage (for VFIM test), the unit is mV.
 *     Value of force current (for IFVM test), the unit is uA.
 *   string dcScaleSIGMeasureMode:          {PAR | SER}
 *     PAR - parallel
 *     SER - serial
 *   string dcScaleSIGPrecharge             {ON | OFF}
 *     Enable precharging or not
 *   string dcScaleSIGPrechargeVoltage_mV       {mV}
 *     Value of precharging voltage, the unit is mV.
 *   string dcScaleSIGRelaySwitchMode:      {NTBBM | NTMBB}
 *     In case of no termination:
 *      NTBBM - Non-terminated,Break before Make(open AC relay, then close PMU relay)
 *      NTMBB - Non-terminated,Make before break(close PMU relay, then open AC relay)
 *   string dcScaleSIGSettlingTime_ms           {ms}
 *     Value of settling time, the unit is ms.
 *   string dcScaleSIGTermination           {ON | OFF}
 *     The test is performed with or without termination
 *   string dcScaleSIGTestName
 *     Name of limit(s).
 * 
 *   boardADC instrument parameter
 *   string boardADCUsed:            {YES | NO }
 *     indicate whether use boardADC to do test or not.
 *   string boardADCPinlist:              {@ | pinlist}
 *     Name of pins to be tested
 *     Valid pins: all digital pins.
 *   string boardADCRelaySwitchMode:      {NTBBM | NTMBB}
 *     In case of no termination:
 *      NTBBM - Non-terminated,Break before Make(open AC relay, then close PMU relay)
 *      NTMBB - Non-terminated,Make before break(close PMU relay, then open AC relay)
 *   string boardADCSettlingTime_ms           {ms}
 *     Value of settling time, the unit is ms.
 *   string spmuTermination           {ON | OFF}
 *     The test is performed with or without termination
 *   string boardADCTestName
 *     Name of limit(s).
 *
 *   common parameters
 *   string testerState           {CONNECTED | DISCONNECTED | UNCHANGED}
 *     Tester state for measurement
 *   string preFunction:          {NO | ALL | ToStopVEC | ToStopCYC}
 *     Select mode of executing the functional pre-test
 *   int stopVec:
 *     Number of stop vector. When select ToStopVEC,this parameter
 *     has effect. It doesn't support multi-port pattern.
 *   string stopCyc:
 *     Number of stop cycle. When select ToStopCYC, thes parameter
 *     has effect. For single port pattern, the format of input value is like: 12
 *     For multi-port pattern, the format is like 12@portName.
 *   string  checkFunctionalResult : {ON | OFF}
 *     the functional test shall contribute to
 *     the overall test result,
 *     OFF is for not.
 *   string output:               {ReportUI | None}
 *     Print message or not. 
 *     ReportUI - for debug mode
 *     None - for production mode
 *
 * @Note:
 *
 *----------------------------------------------------------------------*
 */

class GeneralPMU: public testmethod::TestMethod
{
protected:
  // ppmu parameter
  string  ppmuUsed;
  string  ppmuPinlist;
  string  ppmuForceMode;
  string  ppmuForceValue;
  string  ppmuMeasureMode;
  string  ppmuPrecharge;
  string  ppmuPrechargeVoltage_mV;
  string  ppmuRelaySwitchMode;
  string  ppmuSettlingTime_ms;
  string  ppmuTermination;
  string  ppmuTestName;

  // spmu parameter
  string  spmuUsed;
  string  spmuPinlist;
  string  spmuForceMode;
  string  spmuForceValue;
  string  spmuMeasureMode;
  string  spmuClampValue;
  string  spmuPrecharge;
  string  spmuPrechargeVoltage_mV;
  string  spmuRelaySwitchMode;
  string  spmuSettlingTime_ms;
  string  spmuTermination;
  string  spmuTestName;

  // mcx-pmu parameter
  string  mcxUsed;
  string  mcxPinlist;
  string  mcxForceMode;
  string  mcxForceValue;
  string  mcxMeasureMode;
  string  mcxPrecharge;
  string  mcxPrechargeVoltage_mV;
  string  mcxSettlingTime_ms;
  string  mcxTermination;
  string  mcxTestName;

  // dc scale pin in SIG model
  string  dcScaleSIGUsed;
  string  dcScaleSIGPinlist;
  string  dcScaleSIGForceMode;
  string  dcScaleSIGForceValue;
  string  dcScaleSIGPrecharge;
  string  dcScaleSIGPrechargeVoltage_mV;
  string  dcScaleSIGSettlingTime_ms;
  string  dcScaleSIGMeasureMode;
  string  dcScaleSIGRelaySwitchMode;
  string  dcScaleSIGClampValue;
  string  dcScaleSIGTestName;

  // boardADC parameter
  string  boardADCUsed;
  string  boardADCPinlist;
  string  boardADCRelaySwitchMode;
  string  boardADCSettlingTime_ms;
  string  boardADCTermination;
  string  boardADCTestName;

  // common parameter
  string  testerState;
  string  preFunction;
  int  stopVec;
  string  stopCyc; // to support multi-port, this parameter format like: 13@port2
  string  checkFunctionalResult;
  string  output;

  bool isParameterChanged;

  // Assume all sites' parameters are the same
  GeneralPMUTest::GeneralPMUTestParam param;
protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    // parameters for PPMU
    addParameter("UsePPMU",
                 "string",
                 &ppmuUsed)
      .setDefault("YES")
      .setOptions("YES:NO");
    addParameter("UsePPMU.pinlist",
                 "PinString",
                 &ppmuPinlist)
      .setDefault("");
    addParameter("UsePPMU.forceMode",
                 "string",
                 &ppmuForceMode)
      .setDefault("VOLT")
      .setComment("Options: VOLT: force voltage\nCURR: force current");
    addParameter("UsePPMU.forceValue",
                 "string",
                 &ppmuForceValue)
      .setDefault("3800")
      .setComment("force value for current or voltage\n"
                  "the unit for current is uA\n"
                  "the unit for voltage is mV");
    addParameter("UsePPMU.measureMode",
                 "string",
                 &ppmuMeasureMode)
      .setDefault("PAR")
      .setComment("options: PAR  SER\n PAR - parallel; SER - serial");
    addParameter("UsePPMU.precharge",
                 "string",
                 &ppmuPrecharge)
      .setDefault("OFF")
      .setComment("options: ON  OFF");
    addParameter("UsePPMU.prechargeVoltage_mV",
                 "string",
                 &ppmuPrechargeVoltage_mV)
      .setDefault("0.0")
      .setComment("precharge PPMU for measurement");
    addParameter("UsePPMU.relaySwitchMode",
                 "string",
                 &ppmuRelaySwitchMode)
      .setDefault("DEFAULT(BBM)")
      .setComment("options: DEFAULT(BBM)  MBB  PARALLEL \n"
                  "only 'PARALLEL' with unterminated works for PS400 pin.\n"
                  "DEFAULT(BBM) - Break before Make(open AC relay, then close PMU relay)\n"
                  "MBB - Make before break(close PMU relay, then open AC relay)\n"
                  "PARALLEL - open AC relay and close PMU relay in parallel");
    addParameter("UsePPMU.settlingTime_ms",
                 "string",
                 &ppmuSettlingTime_ms)
      .setDefault("0")
      .setComment("settling time before measurement");
    addParameter("UsePPMU.termination",
                 "string",
                 &ppmuTermination)
      .setDefault("OFF")
      .setComment("Options: ON  OFF");
    addParameter("UsePPMU.testName",
                 "string",
                 &ppmuTestName)
      .setComment("Name of limit(s).");

    // parameters for SPMU
    addParameter("UseSPMU",
                 "string",
                 &spmuUsed)
      .setDefault("NO")
      .setOptions("YES:NO");
    addParameter("UseSPMU.pinlist",
                 "PinString",
                 &spmuPinlist)
      .setDefault("");
    addParameter("UseSPMU.forceMode",
                 "string",
                 &spmuForceMode)
      .setDefault("VOLT")
      .setComment("Options: VOLT: force voltage\nCURR: force current");
    addParameter("UseSPMU.forceValue",
                 "string",
                 &spmuForceValue)
      .setDefault("3800")
      .setComment("force value for current or voltage\n"
                  "the unit for current is uA\n"
                  "the unit for voltage is mV");
    addParameter("UseSPMU.measureMode",
                 "string",
                 &spmuMeasureMode)
      .setDefault("PAR")
      .setComment("options: PAR  SER\n PAR - parallel; SER - serial");
    addParameter("UseSPMU.clampValue",
                 "string",
                 &spmuClampValue)
      .setDefault("0")
      .setComment("spmu clamp value for current or voltage.\n"
                  "for current, the unit is uA. \n"
                  "for voltage, the unit is mV");
    addParameter("UseSPMU.precharge",
                 "string",
                 &spmuPrecharge)
      .setDefault("OFF")
      .setComment("options: ON  OFF");
    addParameter("UseSPMU.prechargeVoltage_mV",
                 "string",
                 &spmuPrechargeVoltage_mV)
      .setDefault("0.0")
      .setComment("precharge SPMU for measurement");
    addParameter("UseSPMU.relaySwitchMode",
                 "string",
                 &spmuRelaySwitchMode)
      .setDefault("NTBBM")
      .setComment("options: NTBBM  NTMBB \n"
                  "NTBBM - Non-terminated,Break before Make(open AC relay, then close PMU relay)\n"
                  "NTMBB - Non-terminated,Make before break(close PMU relay, then open AC relay)");
    addParameter("UseSPMU.settlingTime_ms",
                 "string",
                 &spmuSettlingTime_ms)
      .setDefault("0")
      .setComment("settling time before measurement");
    addParameter("UseSPMU.termination",
                 "string",
                 &spmuTermination)
      .setDefault("OFF")
      .setComment("Options: ON  OFF");
    addParameter("UseSPMU.testName",
                 "string",
                 &spmuTestName)
      .setComment("Name of limit(s).");


    // parameters for MCX-PMU
    addParameter("UseMCX-PMU",
                 "string",
                 &mcxUsed)
      .setDefault("NO")
      .setOptions("YES:NO");
    addParameter("UseMCX-PMU.pinlist",
                 "PinString",
                 &mcxPinlist)
      .setDefault("");
    addParameter("UseMCX-PMU.forceMode",
                 "string",
                 &mcxForceMode)
      .setDefault("VOLT")
      .setComment("Options: VOLT: force voltage\nCURR: force current");
    addParameter("UseMCX-PMU.forceValue",
                 "string",
                 &mcxForceValue)
      .setDefault("3800")
      .setComment("force value for current or voltage\n"
                  "the unit for current is uA\n"
                  "the unit for voltage is mV");
    addParameter("UseMCX-PMU.measureMode",
                 "string",
                 &mcxMeasureMode)
      .setDefault("PAR")
      .setComment("options: PAR  SER\n PAR - parallel; SER - serial");
    addParameter("UseMCX-PMU.precharge",
                 "string",
                 &mcxPrecharge)
      .setDefault("OFF")
      .setComment("when the force mode is VOLT, this parameter has effect. options: ON  OFF");
    addParameter("UseMCX-PMU.prechargeVoltage_mV",
                 "string",
                 &mcxPrechargeVoltage_mV)
      .setDefault("0.0")
      .setComment("precharge MCX-PMU for current measurement");
    addParameter("UseMCX-PMU.settlingTime_ms",
                 "string",
                 &mcxSettlingTime_ms)
      .setDefault("0")
      .setComment("settling time before measurement");
    addParameter("UseMCX-PMU.termination",
                 "string",
                 &mcxTermination)
      .setDefault("OFF")
      .setComment("Options: ON  OFF");
    addParameter("UseMCX-PMU.testName",
                 "string",
                 &mcxTestName)
      .setComment("Name of limit(s).");


    // parameters for dc scale pin in SIG mode
    addParameter("UseDcScaleSIG",
                 "string",
                 &dcScaleSIGUsed)
      .setDefault("NO")
      .setOptions("YES:NO");
    addParameter("UseDcScaleSIG.pinlist",
                 "PinString",
                 &dcScaleSIGPinlist)
      .setDefault("");
    addParameter("UseDcScaleSIG.forceMode",
                 "string",
                 &dcScaleSIGForceMode)
      .setDefault("VOLT")
      .setComment("Options: VOLT: force voltage\nCURR: force current");
    addParameter("UseDcScaleSIG.forceValue",
                 "string",
                 &dcScaleSIGForceValue)
      .setDefault("3800")
      .setComment("force value for current or voltage\n"
                  "the unit for current is uA\n"
                  "the unit for voltage is mV");
    addParameter("UseDcScaleSIG.measureMode",
                 "string",
                 &dcScaleSIGMeasureMode)
      .setDefault("PAR")
      .setComment("options: PAR  SER\n PAR - parallel; SER - serial");
    addParameter("UseDcScaleSIG.clampValue",
                 "string",
                 &dcScaleSIGClampValue)
      .setDefault("0")
      .setComment("dcScaleSIG clamp value for current or voltage.\n"
                  "for current, the unit is uA. \n"
                  "for voltage, the unit is mV");
    addParameter("UseDcScaleSIG.precharge",
                 "string",
                 &dcScaleSIGPrecharge)
      .setDefault("OFF")
      .setComment("options: ON  OFF");
    addParameter("UseDcScaleSIG.prechargeVoltage_mV",
                 "string",
                 &dcScaleSIGPrechargeVoltage_mV)
      .setDefault("0.0")
      .setComment("precharge SPMU for measurement");
    addParameter("UseDcScaleSIG.relaySwitchMode",
                 "string",
                 &dcScaleSIGRelaySwitchMode)
      .setDefault("NO")
      .setComment("options: NO  NT\n"
                  "NO - No relay action \n"
                  "NT - Only have effect for dcScale pins in PMU mode\n");
    addParameter("UseDcScaleSIG.settlingTime_ms",
                 "string",
                 &dcScaleSIGSettlingTime_ms)
      .setDefault("0")
      .setComment("settling time before measurement");
    addParameter("UseDcScaleSIG.testName",
                 "string",
                 &dcScaleSIGTestName)
      .setComment("Name of limit(s).");

    // parameters for BoardADC
    addParameter("UseBoardADC",
                 "string",
                 &boardADCUsed)
      .setDefault("NO")
      .setOptions("YES:NO");
    addParameter("UseBoardADC.pinlist",
                 "PinString",
                 &boardADCPinlist)
      .setDefault("");
    addParameter("UseBoardADC.relaySwitchMode",
                 "string",
                 &boardADCRelaySwitchMode)
      .setDefault("NTBBM")
      .setComment("options: NTBBM  NTMBB \n"
                  "NTBBM - Non-terminated,Break before Make(open AC relay, then close PMU relay)\n"
                  "NTMBB - Non-terminated,Make before break(close PMU relay, then open AC relay)");
    addParameter("UseBoardADC.settlingTime_ms",
                 "string",
                 &boardADCSettlingTime_ms)
      .setDefault("0")
      .setComment("settling time before measurement");
    addParameter("UseBoardADC.termination",
                 "string",
                 &boardADCTermination)
      .setDefault("OFF")
      .setComment("Options: ON  OFF");
    addParameter("UseBoardADC.testName",
                 "string",
                 &boardADCTestName)
      .setComment("Name of limit(s).");


    // common parameter
    addParameter("testerState",
                 "string",
                 &testerState)
      .setDefault("CONNECTED")
      .setOptions("CONNECTED:DISCONNECTED:UNCHANGED");
    addParameter("preFunction",
                 "string",
                 &preFunction)
      .setDefault("NO")
      .setOptions("NO:ALL:ToStopVEC:ToStopCYC");
    addParameter("stopVec",
                 "int",
                 &stopVec)
      .setDefault("0")
      .setComment("Number of stop vector.\n"
                  "When select ToStopVec, this parameter has effect.\n"
                  "It doesn't support multi-port pattern.");
    addParameter("stopCyc",
                 "string",
                 &stopCyc)
      .setComment("Number of stop cycle. \n"
                  "When select ToStopCYC, thes parameter has effect. \n"
                  "For single port pattern, the format of input value is like: 12 \n"
                  "For multi-port pattern, the format is like 12@portName.");
    addParameter("checkFunction",
                 "string",
                 &checkFunctionalResult)
      .setDefault("OFF")
      .setOptions("ON:OFF")
      .setComment("determine whether the functional test result \n"
                  "shall contribute to the overall test result");

    addParameter("output",
                 "string",
                 &output)
      .setDefault("None")
      .setOptions("ReportUI:None");

    isParameterChanged = true;
  }
  
  /**
   *This test is invoked per site.
   */
  virtual void run()
  {

    static GeneralPMUTest::GeneralPMUTestResult result;
    
    ON_FIRST_INVOCATION_BEGIN();
      /*
       * Process all parameters needed in test. Actually this function is
       * called once under multisite because all input parameters should be
       * the same through all sites. The processed parameters are stored into
       * the static variable 'param' for later reference on all sites.
       */
      if(isParameterChanged)
      {
        GeneralPMUTest::processParameters(ppmuUsed,
                                          ppmuPinlist,
                                          ppmuForceMode,
                                          ppmuForceValue,
                                          ppmuMeasureMode,
                                          ppmuPrecharge,
                                          ppmuPrechargeVoltage_mV,
                                          ppmuRelaySwitchMode,
                                          ppmuSettlingTime_ms,
                                          ppmuTermination,
                                          ppmuTestName,

                                          spmuUsed,
                                          spmuPinlist,
                                          spmuForceMode,
                                          spmuForceValue,
                                          spmuMeasureMode,
                                          spmuClampValue,
                                          spmuPrecharge,
                                          spmuPrechargeVoltage_mV,
                                          spmuRelaySwitchMode,
                                          spmuSettlingTime_ms,
                                          spmuTermination,
                                          spmuTestName,

                                          mcxUsed,
                                          mcxPinlist,
                                          mcxForceMode,
                                          mcxForceValue,
                                          mcxMeasureMode,
                                          mcxPrecharge,
                                          mcxPrechargeVoltage_mV,
                                          mcxSettlingTime_ms,
                                          mcxTermination,
                                          mcxTestName,

                                          dcScaleSIGUsed,
                                          dcScaleSIGPinlist,
                                          dcScaleSIGForceMode,
                                          dcScaleSIGForceValue,
                                          dcScaleSIGMeasureMode,
                                          dcScaleSIGClampValue,
                                          dcScaleSIGPrecharge,
                                          dcScaleSIGPrechargeVoltage_mV,
                                          dcScaleSIGRelaySwitchMode,
                                          dcScaleSIGSettlingTime_ms,
                                          dcScaleSIGTestName,

                                          boardADCUsed,
                                          boardADCPinlist,
                                          boardADCRelaySwitchMode,
                                          boardADCSettlingTime_ms,
                                          boardADCTermination,
                                          boardADCTestName,

                                          testerState,
                                          preFunction,
                                          stopVec,
                                          stopCyc,
                                          checkFunctionalResult,

                                          param);
        isParameterChanged = false;
      }
      
    ON_FIRST_INVOCATION_END();
     
    /*
     * Execute measurement with the specified 'param' and store results 
     * into the 'result'. The multisite handling, i.e.
     * ON_FIRST_INVOCATION block are executed inside this function.
     */
    GeneralPMUTest::doMeasurement(param,result);
    
    /*
     * Judge and datalog based on the 'result'. This function uses
     * testsuite name as test name, so if you'd like to use your own
     * test names for judgement and datalogging it's needed to modify
     * this funciton or create new one.
     */
    GeneralPMUTest::judgeAndDatalog(param,result);
    
    /*
     * Output contents of the 'result' to Report Window if specified by
     * the "output" parameter.
     */
    GeneralPMUTest::reportToUI(param,result,output);
  
    return ;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   *
   *Note: TestMethod API should not be used in this method.
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    isParameterChanged = true;
    if("UsePPMU" == parameterIdentifier)
    {
      bool toVisible = ("YES" == ppmuUsed);
      getParameter("UsePPMU.pinlist").setVisible(toVisible);
      getParameter("UsePPMU.forceMode").setVisible(toVisible);
      getParameter("UsePPMU.forceValue").setVisible(toVisible);
      getParameter("UsePPMU.measureMode").setVisible(toVisible);
      getParameter("UsePPMU.precharge").setVisible(toVisible);
      getParameter("UsePPMU.prechargeVoltage_mV").setVisible(toVisible);
      getParameter("UsePPMU.relaySwitchMode").setVisible(toVisible);
      getParameter("UsePPMU.settlingTime_ms").setVisible(toVisible);
      getParameter("UsePPMU.termination").setVisible(toVisible);
      getParameter("UsePPMU.testName").setVisible(toVisible);
    }
    else if("UseSPMU" == parameterIdentifier)
    {
      bool toVisible = ("YES" == spmuUsed);
      getParameter("UseSPMU.pinlist").setVisible(toVisible);
      getParameter("UseSPMU.forceMode").setVisible(toVisible);
      getParameter("UseSPMU.forceValue").setVisible(toVisible);
      getParameter("UseSPMU.measureMode").setVisible(toVisible);
      getParameter("UseSPMU.precharge").setVisible(toVisible);
      getParameter("UseSPMU.prechargeVoltage_mV").setVisible(toVisible);
      getParameter("UseSPMU.relaySwitchMode").setVisible(toVisible);
      getParameter("UseSPMU.clampValue").setVisible(toVisible);
      getParameter("UseSPMU.settlingTime_ms").setVisible(toVisible);
      getParameter("UseSPMU.termination").setVisible(toVisible);
      getParameter("UseSPMU.testName").setVisible(toVisible);
    }
    else if("UseMCX-PMU" == parameterIdentifier)
    {
      bool toVisible = ("YES" == mcxUsed);
      getParameter("UseMCX-PMU.pinlist").setVisible(toVisible);
      getParameter("UseMCX-PMU.forceMode").setVisible(toVisible);
      getParameter("UseMCX-PMU.forceValue").setVisible(toVisible);
      getParameter("UseMCX-PMU.measureMode").setVisible(toVisible);
      getParameter("UseMCX-PMU.precharge").setVisible(toVisible);
      getParameter("UseMCX-PMU.prechargeVoltage_mV").setVisible(toVisible);
      getParameter("UseMCX-PMU.settlingTime_ms").setVisible(toVisible);
      getParameter("UseMCX-PMU.termination").setVisible(toVisible);
      getParameter("UseMCX-PMU.testName").setVisible(toVisible);
    }
    else if("UseDcScaleSIG" == parameterIdentifier)
    {
      bool toVisible = ("YES" == dcScaleSIGUsed);
      getParameter("UseDcScaleSIG.pinlist").setVisible(toVisible);
      getParameter("UseDcScaleSIG.forceMode").setVisible(toVisible);
      getParameter("UseDcScaleSIG.forceValue").setVisible(toVisible);
      getParameter("UseDcScaleSIG.measureMode").setVisible(toVisible);
      getParameter("UseDcScaleSIG.precharge").setVisible(toVisible);
      getParameter("UseDcScaleSIG.prechargeVoltage_mV").setVisible(toVisible);
      getParameter("UseDcScaleSIG.relaySwitchMode").setVisible(toVisible);
      getParameter("UseDcScaleSIG.clampValue").setVisible(toVisible);
      getParameter("UseDcScaleSIG.settlingTime_ms").setVisible(toVisible);
      getParameter("UseDcScaleSIG.testName").setVisible(toVisible);
    }
    else if("UseBoardADC" == parameterIdentifier)
    {
      bool toVisible = ("YES" == boardADCUsed);
      getParameter("UseBoardADC.pinlist").setVisible(toVisible);
      getParameter("UseBoardADC.relaySwitchMode").setVisible(toVisible);
      getParameter("UseBoardADC.settlingTime_ms").setVisible(toVisible);
      getParameter("UseBoardADC.termination").setVisible(toVisible);
      getParameter("UseBoardADC.testName").setVisible(toVisible);
    }
    else if ("testerState" == parameterIdentifier)
    {
      bool toVisible = ("CONNECTED" == testerState);
      getParameter("preFunction").setVisible(toVisible);
      getParameter("checkFunction").setVisible(toVisible);
      getParameter("stopVec").setVisible(toVisible);
      getParameter("stopCyc").setVisible(toVisible);
    }
    else if("preFunction" == parameterIdentifier)
    {  
      if("DISCONNECTED" == testerState || "UNCHANGED" == testerState)
      {
        getParameter("preFunction").setVisible(false);
        getParameter("checkFunction").setVisible(false);
        getParameter("stopVec").setVisible(false);
        getParameter("stopCyc").setVisible(false);
      }
      else if("ToStopVEC" == preFunction)
      {
        getParameter("checkFunction").setVisible(true);
        getParameter("stopVec").setVisible(true);
        getParameter("stopCyc").setVisible(false);
      }
      else if("ToStopCYC" == preFunction)
      {
        getParameter("checkFunction").setVisible(true);
        getParameter("stopVec").setVisible(false);
        getParameter("stopCyc").setVisible(true);
      }
      else if("ALL" == preFunction)
      {
        getParameter("checkFunction").setVisible(true);
        getParameter("stopVec").setVisible(false);
        getParameter("stopCyc").setVisible(false);
      }
      else if("NO" == preFunction)
      {
        getParameter("checkFunction").setVisible(false);
        getParameter("stopVec").setVisible(false);
        getParameter("stopCyc").setVisible(false);

      }
    }
    else if("stopCyc" == parameterIdentifier)
    {
      if(getParameter("stopCyc").isVisible())
      {
        if(stopCyc.empty())
        {
          getParameter("stopCyc").setValid(false);
        }
        else
        {
          getParameter("stopCyc").setValid(true);
        }        
      }
    }
    return ;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string  getComment() const
  {
     static string comment = "version: tml_7.1.2_2.1.4";
     return comment;
  }
};

REGISTER_TESTMETHOD("DcTest.GeneralPMU", GeneralPMU);
