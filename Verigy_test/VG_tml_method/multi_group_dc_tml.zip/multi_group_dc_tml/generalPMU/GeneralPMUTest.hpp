#ifndef GENERALPMUUTIL_H_
#define GENERALPMUUTIL_H_

#include "GeneralPMUTestUtil.hpp"

typedef GeneralPMUTestUtil::MeasurementResultContainer MeasurementResultContainer;

/***************************************************************************
 *                    generalPMU test class 
 ***************************************************************************
 */
class GeneralPMUTest
{
public:

  /*
   *----------------------------------------------------------------------*
   *         test parameters container                                    *
   *----------------------------------------------------------------------*
   */
  struct GeneralPMUTestParam
  {
    string ppmuUsed;
    // original input parameters
    vector<string> ppmuPinlistVec;
    vector<double> ppmuForceValueVec;
    vector<string> ppmuMeasureModeVec; // Parallel,Serial
    vector<string> ppmuPrechargeVec;
    vector<double> ppmuPrechargeVoltageVec;
    vector<string> ppmuRelaySwitchModeVec;
    vector<double> ppmuSettlingTimeVec;
    vector<string> ppmuTerminationVec;
    vector<LIMIT>  ppmuLimitVec;
    vector<string> ppmuLimitNameVec;

    // new generated parameter for convenience
    vector<bool> ppmuIsCurrentMeasureVec;
    vector<bool> ppmuIsVoltageMeasureVec;
    vector<vector<string> > ppmuExpandedPinsVec; // expanded and validated pins stored in Vector
    vector<bool> ppmuIsHvPinGroupVec;    //true, if the pin in this group are all HV pins.
    
    bool ppmuHasCurrentMeasure;
    bool ppmuHasVoltageMeasure;
    bool isPPMULimitAppliedForAllGroups;

    string spmuUsed;
    // original input parameters
    vector<string> spmuPinlistVec;
    vector<double> spmuForceValueVec;
    vector<string> spmuMeasureModeVec; // Parallel,Serial
    vector<double> spmuClampValueVec;
    vector<string> spmuPrechargeVec;
    vector<double> spmuPrechargeVoltageVec;
    vector<string> spmuRelaySwitchModeVec;
    vector<double> spmuSettlingTimeVec;
    vector<string> spmuTerminationVec;
    vector<LIMIT>  spmuLimitVec;
    vector<string> spmuLimitNameVec;

    // new generated parameter for convenience
    vector<bool> spmuIsCurrentMeasureVec;
    vector<bool> spmuIsVoltageMeasureVec;
    vector<vector<string> > spmuExpandedPinsVec; // expanded and validated pins stored in Vector
    
    bool spmuHasCurrentMeasure;
    bool spmuHasVoltageMeasure;
    bool isSPMULimitAppliedForAllGroups;

    string mcxUsed;
    // original input parameters
    vector<string> mcxPinlistVec;
    vector<double> mcxForceValueVec;
    vector<string> mcxMeasureModeVec; // Parallel,Serial
    vector<string> mcxPrechargeVec;
    vector<double> mcxPrechargeVoltageVec;
    vector<double> mcxSettlingTimeVec;
    vector<string> mcxTerminationVec;
    vector<LIMIT>  mcxLimitVec;
    vector<string> mcxLimitNameVec;

    // new generated parameter for convenience
    vector<bool> mcxIsCurrentMeasureVec;
    vector<bool> mcxIsVoltageMeasureVec;
    vector<vector<string> > mcxExpandedPinsVec; // expanded and validated pins stored in Vector
    
    bool mcxHasCurrentMeasure;
    bool mcxHasVoltageMeasure;
    bool isMCXLimitAppliedForAllGroups;

    string dcScaleSIGUsed;
    // original input parameters
    vector<string> dcScaleSIGPinlistVec;
    vector<double> dcScaleSIGForceValueVec;
    vector<string> dcScaleSIGMeasureModeVec; // Parallel,Serial
    vector<double> dcScaleSIGClampValueVec;
    vector<string> dcScaleSIGPrechargeVec;
    vector<double> dcScaleSIGPrechargeVoltageVec;
    vector<string> dcScaleSIGRelaySwitchModeVec;
    vector<double> dcScaleSIGSettlingTimeVec;
    vector<LIMIT> dcScaleSIGLimitVec;
    vector<string> dcScaleSIGLimitNameVec;

    // new generated parameter for convenience
    vector<bool> dcScaleSIGIsCurrentMeasureVec;
    vector<bool> dcScaleSIGIsVoltageMeasureVec;
    vector<vector<string> > dcScaleSIGExpandedPinsVec; // expanded and validated pins stored in Vector
    
    bool dcScaleSIGHasCurrentMeasure;
    bool dcScaleSIGHasVoltageMeasure;
    bool isDCScaleSIGLimitAppliedForAllGroups;

    string boardADCUsed;
    // original input parameters
    vector<string> boardADCPinlistVec;
    vector<string> boardADCRelaySwitchModeVec;
    vector<double> boardADCSettlingTimeVec;
    vector<string> boardADCTerminationVec;
    vector<LIMIT>  boardADCLimitVec;
    vector<string> boardADCLimitNameVec;

    // new generated parameter for convenience
    vector<bool> boardADCIsVoltageMeasureVec;
    vector<vector<string> > boardADCExpandedPinsVec; // expanded and validated pins stored in Vector
    vector<bool> boardADCIsHvPinGroupVec;            //true, if the pin in this group are all HV pins.
    bool boardADCHasVoltageMeasure;
    bool isBoardADCLimitAppliedForAllGroups;

    // common parameters
    string testerState;
    string preFunction;
    int stopVec;
    int stopCyc;
    string portName;
    string checkFunctionalResult;

    // new generated parameter for convenience
    string testsuiteName; // current testsuite name
    TM::DCTEST_MODE testMode; //current test mode

    bool isLimitTableUsed; // if limit table is used
    
    //initialize stuff to some defaults.
    void init()
    {
      ppmuUsed = "YES";
      ppmuPinlistVec.clear();
      ppmuForceValueVec.clear();
      ppmuMeasureModeVec.clear();
      ppmuPrechargeVec.clear();
      ppmuPrechargeVoltageVec.clear();
      ppmuRelaySwitchModeVec.clear();
      ppmuSettlingTimeVec.clear();
      ppmuTerminationVec.clear();
      ppmuLimitVec.clear();
      ppmuLimitNameVec.clear();
      ppmuIsCurrentMeasureVec.clear();
      ppmuIsVoltageMeasureVec.clear();
      ppmuExpandedPinsVec.clear();
      ppmuIsHvPinGroupVec.clear();
      ppmuHasCurrentMeasure = false;
      ppmuHasVoltageMeasure = false;
      isPPMULimitAppliedForAllGroups = false;

      spmuUsed = "NO";
      spmuPinlistVec.clear();
      spmuForceValueVec.clear();
      spmuMeasureModeVec.clear();
      spmuClampValueVec.clear();
      spmuPrechargeVec.clear();
      spmuPrechargeVoltageVec.clear();
      spmuRelaySwitchModeVec.clear();
      spmuSettlingTimeVec.clear();
      spmuTerminationVec.clear();
      spmuLimitVec.clear();
      spmuLimitNameVec.clear();
      spmuIsCurrentMeasureVec.clear();
      spmuIsVoltageMeasureVec.clear();
      spmuExpandedPinsVec.clear();
      spmuHasCurrentMeasure = false;
      spmuHasVoltageMeasure = false;
      isSPMULimitAppliedForAllGroups = false;

      mcxUsed = "NO";
      mcxPinlistVec.clear();
      mcxForceValueVec.clear();
      mcxMeasureModeVec.clear();
      mcxPrechargeVec.clear();
      mcxPrechargeVoltageVec.clear();
      mcxSettlingTimeVec.clear();
      mcxTerminationVec.clear();
      mcxLimitVec.clear();
      mcxLimitNameVec.clear();
      mcxIsCurrentMeasureVec.clear();
      mcxIsVoltageMeasureVec.clear();
      mcxExpandedPinsVec.clear();
      mcxHasCurrentMeasure = false;
      mcxHasVoltageMeasure = false;
      isMCXLimitAppliedForAllGroups = false;

      dcScaleSIGUsed = "NO";
      dcScaleSIGPinlistVec.clear();
      dcScaleSIGForceValueVec.clear();
      dcScaleSIGMeasureModeVec.clear();
      dcScaleSIGClampValueVec.clear();
      dcScaleSIGPrechargeVec.clear();
      dcScaleSIGPrechargeVoltageVec.clear();
      dcScaleSIGRelaySwitchModeVec.clear();
      dcScaleSIGSettlingTimeVec.clear();
      dcScaleSIGLimitVec.clear();
      dcScaleSIGLimitNameVec.clear();
      dcScaleSIGIsCurrentMeasureVec.clear();
      dcScaleSIGIsVoltageMeasureVec.clear();
      dcScaleSIGExpandedPinsVec.clear();
      dcScaleSIGHasCurrentMeasure = false;
      dcScaleSIGHasVoltageMeasure = false;
      isDCScaleSIGLimitAppliedForAllGroups = false;

      boardADCUsed = "NO";
      boardADCPinlistVec.clear();
      boardADCRelaySwitchModeVec.clear();
      boardADCSettlingTimeVec.clear();
      boardADCTerminationVec.clear();
      boardADCLimitVec.clear();
      boardADCLimitNameVec.clear();
      boardADCIsVoltageMeasureVec.clear();
      boardADCExpandedPinsVec.clear();
      boardADCIsHvPinGroupVec.clear();
      boardADCHasVoltageMeasure = false;
      isBoardADCLimitAppliedForAllGroups = false;

      testerState = "";
      testsuiteName = "";
      preFunction = "NO";
      stopVec = 0;
      stopCyc = 0;
      portName = "";
      checkFunctionalResult = "";
      testMode = TM::GPF; 
      isLimitTableUsed = false;
    }

    /*default constructor for intializing parameters*/
    GeneralPMUTestParam()
    {
      init();
    }
  };

  /*
   *----------------------------------------------------------------------*
   *         test results container                                       *
   *----------------------------------------------------------------------*
   */
  struct GeneralPMUTestResult
  {
    /*result container 
     *for current value, the unit is: A
     *for voltage value, the unit is: V
     */
    vector<MeasurementResultContainer> ppmuMeasureResultVec;

    vector<MeasurementResultContainer> spmuMeasureResultVec;

    vector<MeasurementResultContainer> mcxMeasureResultVec;

    vector<MeasurementResultContainer> dcScaleSIGMeasureResultVec;

    vector<MeasurementResultContainer> boardADCMeasureResultVec;

    bool funcResult; //true: PASS, false: FAIL

    /*initialize all stuffs to some defaults.*/
    void init()
    {
      ppmuMeasureResultVec.clear();
      spmuMeasureResultVec.clear();
      mcxMeasureResultVec.clear();
      dcScaleSIGMeasureResultVec.clear();
      boardADCMeasureResultVec.clear();
      funcResult =  true;
    }

    /*default constructor*/
    GeneralPMUTestResult()
    {
      init();
    }
  };

  /*
   *----------------------------------------------------------------------*
   *         public interfaces of General PMU test                        *
   *----------------------------------------------------------------------*
   */

  /*
   *----------------------------------------------------------------------*
   * Routine: processParameter
   *
   * Purpose: parse input parameters and setup internal parameters
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note:
   *----------------------------------------------------------------------*
   */
  static void processParameters(
      const string& ppmu_used,
      const string& ppmuPinlist,
      const string& ppmuForceMode,
      const string& ppmuForceValue,
      const string& ppmuMeasureMode,
      const string& ppmuPrecharge,
      const string& ppmuPrechargeVoltage_mV,
      const string& ppmuRelaySwitchMode,
      const string& ppmuSettlingTime_ms,
      const string& ppmuTermination,
      const string& ppmuTestName,

      const string& spmu_used,
      const string& spmuPinlist,
      const string& spmuForceMode,
      const string& spmuForceValue,
      const string& spmuMeasureMode,
      const string& spmuClampValue_mV,
      const string& spmuPrecharge,
      const string& spmuPrechargeVoltage_mV,
      const string& spmuRelaySwitchMode,
      const string& spmuSettlingTime_ms,
      const string& spmuTermination,
      const string& spmuTestName,

      const string& mcx_used,
      const string& mcxPinlist,
      const string& mcxForceMode,
      const string& mcxForceValue,
      const string& mcxMeasureMode,
      const string& mcxPrecharge,
      const string& mcxPrechargeVoltage_mV,
      const string& mcxSettlingTime_ms,
      const string& mcxTermination,
      const string& mcxTestName,

      const string& dcScaleSIG_used,
      const string& dcScaleSIGPinlist,
      const string& dcScaleSIGForceMode,
      const string& dcScaleSIGForceValue,
      const string& dcScaleSIGMeasureMode,
      const string& dcScaleSIGClampValue_mV,
      const string& dcScaleSIGPrecharge,
      const string& dcScaleSIGPrechargeVoltage_mV,
      const string& dcScaleSIGRelaySwitchMode,
      const string& dcScaleSIGSettlingTime_ms,
      const string& dcScaleSIGTestName,

      const string& boardADC_used,
      const string& boardADCPinlist,
      const string& boardADCRelaySwitchMode,
      const string& boardADCSettlingTime_ms,
      const string& boardADCTermination,
      const string& boardADCTestName,

      const string& testerState,
      const string& preFunction,
      const int stopVec,
      const string& stopCyc,
      const string& checkFunctionalResult,

      GeneralPMUTestParam& param)
  {
    // initial parameters
    param.init();

    //get the test suite name and test mode
    GET_TESTSUITE_NAME(param.testsuiteName);
    param.testMode = GeneralPMUTestUtil::getMode();

    /**
     *this map is used to store the relationship: pin group instrument
     * map< string, pair<string,string> >
     *        |            |        |
     *        |            |        |
     *     pinName     groupName  InstrumentName
     *
     * we use this map to check that whether there are the same pin exist
     * in different groups or not.
     */
    map<string, pair<string, string> > pinAndGroupMap;

    // check whether limit table is used.
    TesttableLimitHelper testtableHelper(param.testsuiteName);

    string tempString = GeneralPMUTestUtil::trim(ppmu_used);
    if ("YES" == tempString || "NO" == tempString)
    {
      param.ppmuUsed = tempString;
    }
    else
    {
      throw Error("GeneralPMUTest::processParameters()",
                  "UsePPMU must be YES or NO",
                  "GeneralPMUTest::processParameters()");
    }

    tempString = GeneralPMUTestUtil::trim(spmu_used);
    if ("YES" == tempString || "NO" == tempString)
    {
      param.spmuUsed = tempString;
    }
    else
    {
      throw Error("GeneralPMUTest::processParameters()",
                  "UseSPMU must be YES or NO",
                  "GeneralPMUTest::processParameters()");
    }

    tempString = GeneralPMUTestUtil::trim(mcx_used);
    if ("YES" == tempString || "NO" == tempString)
    {
      param.mcxUsed = tempString;
    }
    else
    {
      throw Error("GeneralPMUTest::processParameters()",
                  "UseMCX-PMU must be YES or NO",
                  "GeneralPMUTest::processParameters()");
    }

    tempString = GeneralPMUTestUtil::trim(dcScaleSIG_used);
    if ("YES" == tempString || "NO" == tempString)
    {
      param.dcScaleSIGUsed = tempString;
    }
    else
    {
      throw Error("GeneralPMUTest::processParameters()",
                  "UseDCScaleSIG must be YES or NO",
                  "GeneralPMUTest::processParameters()");
    }

    tempString = GeneralPMUTestUtil::trim(boardADC_used);
    if ("YES" == tempString || "NO" == tempString)
    {
      param.boardADCUsed = tempString;
    }
    else
    {
      throw Error("GeneralPMUTest::processParameters()",
                  "UseBoardADC must be YES or NO",
                  "GeneralPMUTest::processParameters()");
    }

    if ("YES" == param.ppmuUsed)
    {
      vector<string> ppmuForceModeVec;
      vector<string> ppmuTestNameVec;

      GeneralPMUTestUtil::parseListOfString(ppmuPinlist, param.ppmuPinlistVec);
      GeneralPMUTestUtil::parseListOfString(ppmuForceMode, ppmuForceModeVec);
      GeneralPMUTestUtil::parseListOfDouble(ppmuForceValue, param.ppmuForceValueVec);
      GeneralPMUTestUtil::parseListOfString(ppmuMeasureMode, param.ppmuMeasureModeVec);
      GeneralPMUTestUtil::parseListOfString(ppmuPrecharge, param.ppmuPrechargeVec);
      GeneralPMUTestUtil::parseListOfDouble(ppmuPrechargeVoltage_mV,
                                            param.ppmuPrechargeVoltageVec);
      GeneralPMUTestUtil::parseListOfString(ppmuRelaySwitchMode,
                                            param.ppmuRelaySwitchModeVec);
      GeneralPMUTestUtil::parseListOfDouble(ppmuSettlingTime_ms,
                                            param.ppmuSettlingTimeVec);
      GeneralPMUTestUtil::parseListOfString(ppmuTermination, param.ppmuTerminationVec);
      GeneralPMUTestUtil::parseListOfString(ppmuTestName, ppmuTestNameVec);

      vector<string>::size_type groupSize = param.ppmuPinlistVec.size();
      if (groupSize == 0)
      {
        throw Error("GeneralPMUTest::processParameters()",
                    "PPMU: the pinlist groups can not be empty.",
                    "GeneralPMUTest::processParameters()");
      }

      GeneralPMUTestUtil::checkParameter(groupSize,
                                         ppmuForceModeVec.size(),
                                         "PPMU",
                                         "forceMode",
                                         ppmuForceModeVec);
      GeneralPMUTestUtil::checkParameter(groupSize,
                                         param.ppmuForceValueVec.size(),
                                         "PPMU",
                                         "forceValue",
                                         param.ppmuForceValueVec);
      GeneralPMUTestUtil::checkParameter(groupSize,
                                         param.ppmuMeasureModeVec.size(),
                                         "PPMU",
                                         "measureMode",
                                         param.ppmuMeasureModeVec);
      GeneralPMUTestUtil::checkParameter(groupSize,
                                         param.ppmuPrechargeVec.size(),
                                         "PPMU",
                                         "precharge",
                                         param.ppmuPrechargeVec);
      GeneralPMUTestUtil::checkParameter(groupSize,
                                         param.ppmuPrechargeVoltageVec.size(),
                                         "PPMU",
                                         "prechargeVoltage_mV",
                                         param.ppmuPrechargeVoltageVec);
      GeneralPMUTestUtil::checkParameter(groupSize,
                                         param.ppmuRelaySwitchModeVec.size(),
                                         "PPMU",
                                         "relaySwitchMode",
                                         param.ppmuRelaySwitchModeVec);
      GeneralPMUTestUtil::checkParameter(groupSize,
                                         param.ppmuTerminationVec.size(),
                                         "PPMU",
                                         "termination",
                                         param.ppmuTerminationVec);
      GeneralPMUTestUtil::checkParameter(groupSize,
                                         param.ppmuSettlingTimeVec.size(),
                                         "PPMU",
                                         "settlingTime_ms",
                                         param.ppmuSettlingTimeVec);

      if (param.ppmuPinlistVec.size() != ppmuTestNameVec.size())
      {
        if (ppmuTestNameVec.size() != 1)
        {
          stringstream errMsg;
          errMsg << "PPMU: the number of pinlist groups is "
                 << param.ppmuPinlistVec.size() << endl
                 << "      the number of testName groups is "
                 << ppmuTestNameVec.size() << endl
                 << "So the testName groups don't match pinlist groups." << endl;
          throw Error("GeneralPMUTest::processParameters()",
                      errMsg.str(),
                      "GeneralPMUTest::processParameters()");
        }
        else
        {
          param.isPPMULimitAppliedForAllGroups = true;
          for (vector<string>::size_type i = 1; i < param.ppmuPinlistVec.size(); i++)
          {
            ppmuTestNameVec.push_back(ppmuTestNameVec[0]);
          }
        }
      }

      // the following three variables is used for checking duplicate pins
      pair<map<string, pair<string, string> >::iterator, bool> ret;
      pair<string, string> groupAndInstrument;
      const string instrumentType = "PPMUInstrument";

      // the following variables are used to store info of HV pins
      vector<long unsigned int>  ppmuHvPinGroupIndexlist;
      vector<vector<string> > ppmuHvExpandedPinsVec;

      ppmuHvPinGroupIndexlist.clear();
      ppmuHvExpandedPinsVec.clear();

      param.ppmuIsHvPinGroupVec.resize(param.ppmuPinlistVec.size());

      for (vector<string>::size_type i = 0; i < param.ppmuPinlistVec.size(); i++)
      {
        param.ppmuIsHvPinGroupVec[i] = false;
        /*
         *********************************************************
         * Validate and expand pin names from input pinlist,
         * and meanwhile it detects DC pins,
         * if any DC pins exist, it throws an error.
         *********************************************************
         */
        bool isThisGroupNotCommented = ('#' != param.ppmuPinlistVec[i][0]);
        vector<string> expandedPins;
        if (isThisGroupNotCommented)
        {
          expandedPins = PinUtility.getDigitalPinNamesFromPinList(
                  param.ppmuPinlistVec[i],
                  TM::I_PIN | TM::O_PIN | TM::IO_PIN,
                  true,
                  true);

          // For checking HV pins
          vector<string> hvPinVector, nonHvPinVector;
          hvPinVector.clear();
          nonHvPinVector.clear();

          // check the duplicate pins
          for (vector<string>::size_type index = 0; index < expandedPins.size(); index++)
          {
            groupAndInstrument = make_pair(param.ppmuPinlistVec[i], instrumentType);
            ret = pinAndGroupMap.insert(make_pair(expandedPins[index], groupAndInstrument));
            if (!ret.second)
            {
              stringstream errMsg;
              errMsg << "In the PPMUInstrument group: " << param.ppmuPinlistVec[i]<< endl
                     << "   and " << ret.first->second.second << " group: "
                     << ret.first->second.first << endl
                     << "There are the same pin: "
                     << expandedPins[index] << endl;
              throw Error("GeneralPMUTest::processParameters",
                          errMsg.str(),
                          "GeneralPMUTest::processParameters");
            }

            if(GeneralPMUTestUtil::isHvPin(expandedPins[index]))
            {
            	hvPinVector.push_back(expandedPins[index]);
            }
            else
            {
            	nonHvPinVector.push_back(expandedPins[index]);
            }
          }

          if(hvPinVector.size() > 0)
          {
            if(hvPinVector.size() == expandedPins.size())
            {
              param.ppmuIsHvPinGroupVec[i] = true;
            }
            else
            {
            	//non HV pins.
            	param.ppmuIsHvPinGroupVec[i] = false;
            	expandedPins.clear();
            	expandedPins = nonHvPinVector;
            	param.ppmuPinlistVec[i] = PinUtility.createPinListFromPinNames(nonHvPinVector);

            	//Keep the index and expandedPins of HV pins, to create the
            	//new HV group later.
            	ppmuHvExpandedPinsVec.push_back(hvPinVector);
            	ppmuHvPinGroupIndexlist.push_back(i);
            }
          }
          else
          {
            param.ppmuIsHvPinGroupVec[i] = false;
          }
        }
        (param.ppmuExpandedPinsVec).push_back(expandedPins);
      }

      // create the new pinlist and its test properties
      if (ppmuHvPinGroupIndexlist.size() > 0)
      {
        vector<string> tmpPinlistVec, tmpForceModeVec, tmpMeasureMode,
                       tmpPreChargeVec, tmpRelaySwitchMode, tmpTerminationVec,
                       tmpTestNameVec;
        vector<double> tmpForceValueVec, tmpPreChargeVoltageVec, tmpSettlingTimeVec;
        vector<vector<string> >tmpExpandedPinsVec;
        vector<bool> tmpIsHVPinsVec;
        for(vector<string>::size_type  i = 0; i< param.ppmuPinlistVec.size(); i++)
        {
          tmpPinlistVec.push_back(param.ppmuPinlistVec[i]);
          tmpForceModeVec.push_back(ppmuForceModeVec[i]);
          tmpForceValueVec.push_back(param.ppmuForceValueVec[i]);
          tmpMeasureMode.push_back(param.ppmuMeasureModeVec[i]);
          tmpPreChargeVec.push_back(param.ppmuPrechargeVec[i]);
          tmpPreChargeVoltageVec.push_back(param.ppmuPrechargeVoltageVec[i]);
          tmpRelaySwitchMode.push_back(param.ppmuRelaySwitchModeVec[i]);
          tmpSettlingTimeVec.push_back(param.ppmuSettlingTimeVec[i]);
          tmpTerminationVec.push_back(param.ppmuTerminationVec[i]);
          tmpTestNameVec.push_back(ppmuTestNameVec[i]);
          tmpExpandedPinsVec.push_back(param.ppmuExpandedPinsVec[i]);
          tmpIsHVPinsVec.push_back(param.ppmuIsHvPinGroupVec[i]);

          vector<long unsigned int>::iterator it = find(ppmuHvPinGroupIndexlist.begin(), ppmuHvPinGroupIndexlist.end(), i);
          if (it != ppmuHvPinGroupIndexlist.end())
          {
            long unsigned int index = it - ppmuHvPinGroupIndexlist.begin();
            tmpPinlistVec.push_back(PinUtility.createPinListFromPinNames(ppmuHvExpandedPinsVec[index]));
            tmpForceModeVec.push_back(ppmuForceModeVec[i]);
            tmpForceValueVec.push_back(param.ppmuForceValueVec[i]);
            tmpMeasureMode.push_back(param.ppmuMeasureModeVec[i]);
            tmpPreChargeVec.push_back(param.ppmuPrechargeVec[i]);
            tmpPreChargeVoltageVec.push_back(param.ppmuPrechargeVoltageVec[i]);
            tmpRelaySwitchMode.push_back(param.ppmuRelaySwitchModeVec[i]);
            tmpSettlingTimeVec.push_back(param.ppmuSettlingTimeVec[i]);
            tmpTerminationVec.push_back(param.ppmuTerminationVec[i]);
            tmpTestNameVec.push_back(ppmuTestNameVec[i]);
            tmpExpandedPinsVec.push_back(ppmuHvExpandedPinsVec[index]);
            tmpIsHVPinsVec.push_back(true);
          }
        }

        param.ppmuPinlistVec.swap(tmpPinlistVec);
        ppmuForceModeVec.swap(tmpForceModeVec);
        param.ppmuForceValueVec.swap(tmpForceValueVec);
        param.ppmuMeasureModeVec.swap(tmpMeasureMode);
        param.ppmuPrechargeVec.swap(tmpPreChargeVec);
        param.ppmuPrechargeVoltageVec.swap(tmpPreChargeVoltageVec);
        param.ppmuRelaySwitchModeVec.swap(tmpRelaySwitchMode);
        param.ppmuSettlingTimeVec.swap(tmpSettlingTimeVec);
        param.ppmuTerminationVec.swap(tmpTerminationVec);
        ppmuTestNameVec.swap(tmpTestNameVec);
        param.ppmuExpandedPinsVec.swap(tmpExpandedPinsVec);
        param.ppmuIsHvPinGroupVec.swap(tmpIsHVPinsVec);
      }

      for (vector<string>::size_type i = 0; i < param.ppmuPinlistVec.size(); i++)
      {
    	bool isThisGroupNotCommented = ('#' != param.ppmuPinlistVec[i][0]);
        if ("CURR" == ppmuForceModeVec[i])
        {
          if (isThisGroupNotCommented)
          {
            param.ppmuIsCurrentMeasureVec.push_back(false);
            param.ppmuIsVoltageMeasureVec.push_back(true);
            param.ppmuHasVoltageMeasure = true;
          }
          else
          {
            param.ppmuIsCurrentMeasureVec.push_back(false);
            param.ppmuIsVoltageMeasureVec.push_back(false);
          }
        }
        else if ("VOLT" == ppmuForceModeVec[i])
        {
          if (isThisGroupNotCommented)
          {
            param.ppmuIsCurrentMeasureVec.push_back(true);
            param.ppmuIsVoltageMeasureVec.push_back(false);
            param.ppmuHasCurrentMeasure = true;
          }
          else
          {
            param.ppmuIsCurrentMeasureVec.push_back(false);
            param.ppmuIsVoltageMeasureVec.push_back(false);
          }
        }
        else if(isThisGroupNotCommented)
        {
          stringstream errMsg;
          errMsg << "PPMU: for the " << i + 1 << " group setup parameter, forceMode: "
                 << ppmuForceModeVec[i] << " is invalid." << endl
                 << "forceMode can only be the following options: CURR  VOLT" << endl;
          throw Error("GeneralPMUTest::processParamters()",
                      errMsg.str(),
                      "GeneralPMUTest::processParamters()");
        }

        if (param.ppmuMeasureModeVec[i] != "PAR" &&
            param.ppmuMeasureModeVec[i] != "SER")
        {
          stringstream errMsg;
          errMsg << "PPMU: for the " << i + 1 << " group setup parameter, measureMode: "
                 << param.ppmuMeasureModeVec[i] << " is invalid." << endl
                 << "measureMode can only be the following options: PAR  SER" << endl;
          throw Error("GeneralPMUTest::processParamters()",
                      errMsg.str(),
                      "GeneralPMUTest::processParamters()");
        }
        if (param.ppmuPrechargeVec[i] != "ON" &&
            param.ppmuPrechargeVec[i] != "OFF")
        {
          stringstream errMsg;
          errMsg << "PPMU: for the " << i + 1 << " group setup parameter, precharge: "
                 << param.ppmuPrechargeVec[i] << " is invalid." << endl
                 << "precharge can only be the following options: ON  OFF" << endl;
          throw Error("GeneralPMUTest::processParamters()",
                      errMsg.str(),
                      "GeneralPMUTest::processParamters()");
        }
        if (param.ppmuRelaySwitchModeVec[i] != "DEFAULT(BBM)" &&
            param.ppmuRelaySwitchModeVec[i] != "MBB"          &&
            param.ppmuRelaySwitchModeVec[i] != "PARALLEL")
        {
          stringstream errMsg;
          errMsg << "PPMU: for the " << i + 1
                 << " group setup parameter, relaySwitchMode: "
                 << param.ppmuRelaySwitchModeVec[i] << " is invalid." << endl
                 << "relaySwitchMode can only be the following options: DEFAULT(BBM) MBB PARALLEL"
                 << endl;
          throw Error("GeneralPMUTest::processParamters()",
                      errMsg.str(),
                      "GeneralPMUTest::processParamters()");
        }

        if (param.ppmuTerminationVec[i] != "ON" &&
            param.ppmuTerminationVec[i] != "OFF")
        {
          stringstream errMsg;
          errMsg << "PPMU: for the " << i + 1 << " group setup parameter, termination: "
                 << param.ppmuTerminationVec[i] << " is invalid." << endl
                 << "termination can only be the following options: ON  OFF" << endl;
          throw Error("GeneralPMUTest::processParamters()",
                      errMsg.str(),
                      "GeneralPMUTest::processParamters()");
        }

        LIMIT limit;
        param.ppmuLimitVec.push_back(limit);
        param.ppmuLimitNameVec.push_back(ppmuTestNameVec[i]);

        GeneralPMUTestUtil::getLimitInfo(ppmuTestNameVec[i],i,
                                         ppmuForceModeVec[i],
                                         param.ppmuLimitVec[i],
                                         testtableHelper);
      }
    }

    if ("YES" == param.spmuUsed)
    {
      vector<string> spmuForceModeVec;
      vector<string> spmuTestNameVec;

      GeneralPMUTestUtil::parseListOfString(spmuPinlist, param.spmuPinlistVec);
      GeneralPMUTestUtil::parseListOfString(spmuForceMode, spmuForceModeVec);
      GeneralPMUTestUtil::parseListOfDouble(spmuForceValue, param.spmuForceValueVec);
      GeneralPMUTestUtil::parseListOfString(spmuMeasureMode, param.spmuMeasureModeVec);
      GeneralPMUTestUtil::parseListOfDouble(spmuClampValue_mV, param.spmuClampValueVec);
      GeneralPMUTestUtil::parseListOfString(spmuPrecharge, param.spmuPrechargeVec);
      GeneralPMUTestUtil::parseListOfDouble(spmuPrechargeVoltage_mV,
                                            param.spmuPrechargeVoltageVec);
      GeneralPMUTestUtil::parseListOfString(spmuRelaySwitchMode,
                                            param.spmuRelaySwitchModeVec);
      GeneralPMUTestUtil::parseListOfDouble(spmuSettlingTime_ms,
                                            param.spmuSettlingTimeVec);
      GeneralPMUTestUtil::parseListOfString(spmuTermination, param.spmuTerminationVec);
      GeneralPMUTestUtil::parseListOfString(spmuTestName, spmuTestNameVec);

      vector<string>::size_type groupSize = param.spmuPinlistVec.size();
      if (groupSize == 0)
      {
        throw Error("GeneralPMUTest::processParameters()",
                    "SPMU: the pinlist groups can not be empty.",
                    "GeneralPMUTest::processParameters()");
      }

      GeneralPMUTestUtil::checkParameter(groupSize,
                                         spmuForceModeVec.size(),
                                         "SPMU",
                                         "forceMode",
                                         spmuForceModeVec);
      GeneralPMUTestUtil::checkParameter(groupSize,
                                         param.spmuForceValueVec.size(),
                                         "SPMU",
                                         "forceValue",
                                         param.spmuForceValueVec);
      GeneralPMUTestUtil::checkParameter(groupSize,
                                         param.spmuMeasureModeVec.size(),
                                         "SPMU",
                                         "measureMode",
                                         param.spmuMeasureModeVec);
      GeneralPMUTestUtil::checkParameter(groupSize,
                                         param.spmuClampValueVec.size(),
                                         "SPMU",
                                         "clampValue",
                                         param.spmuClampValueVec);
      GeneralPMUTestUtil::checkParameter(groupSize,
                                         param.spmuPrechargeVec.size(),
                                         "SPMU",
                                         "precharge",
                                         param.spmuPrechargeVec);
      GeneralPMUTestUtil::checkParameter(groupSize,
                                         param.spmuPrechargeVoltageVec.size(),
                                         "SPMU",
                                         "prechargeVoltage_mV",
                                         param.spmuPrechargeVoltageVec);
      GeneralPMUTestUtil::checkParameter(groupSize,
                                         param.spmuRelaySwitchModeVec.size(),
                                         "SPMU",
                                         "relaySwitchMode",
                                         param.spmuRelaySwitchModeVec);
      GeneralPMUTestUtil::checkParameter(groupSize,
                                         param.spmuTerminationVec.size(),
                                         "SPMU",
                                         "termination",
                                         param.spmuTerminationVec);
      GeneralPMUTestUtil::checkParameter(groupSize,
                                         param.spmuSettlingTimeVec.size(),
                                         "SPMU",
                                         "settlingTime_ms",
                                         param.spmuSettlingTimeVec);

      if (param.spmuPinlistVec.size() != spmuTestNameVec.size())
      {
        if (spmuTestNameVec.size() != 1)
        {
          stringstream errMsg;
          errMsg << "SPMU: the number of pinlist groups is "
                 << param.spmuPinlistVec.size() << endl
                 << "      the number of testName groups is " 
                 << spmuTestNameVec.size() << endl
                 << "So the testName groups don't match pinlist groups." << endl;
          throw Error("GeneralPMUTest::processParameters()",
                      errMsg.str(),
                      "GeneralPMUTest::processParameters()");
        }
        else
        {
          param.isSPMULimitAppliedForAllGroups = true;
          for (vector<string>::size_type i = 1; i < param.spmuPinlistVec.size(); i++)
          {
            spmuTestNameVec.push_back(spmuTestNameVec[0]);
          }
        }
      }

      // the following three variables is used for checking duplicate pins
      pair<map<string, pair<string, string> >::iterator, bool> ret;
      pair<string, string> groupAndInstrument;
      const string instrumentType = "SPMUInstrument";
      for (vector<string>::size_type i = 0; i < param.spmuPinlistVec.size(); i++)
      {
        /*
         *********************************************************
         * Validate and expand pin names from input pinlist,
         * and meanwhile it detects DC pins.
         *********************************************************
         */
        bool isThisGroupNotCommented = ('#' != param.spmuPinlistVec[i][0]);
        vector<string> expandedPins;
        if (isThisGroupNotCommented)
        {
          expandedPins = PinUtility.getDigitalPinNamesFromPinList(
                  param.spmuPinlistVec[i],
                  TM::I_PIN | TM::O_PIN | TM::IO_PIN | TM::DC_PIN,
                  true,
                  true);
          // check the duplicate pins
          for (vector<string>::size_type index = 0; index < expandedPins.size(); index++)
          {
            groupAndInstrument = make_pair(param.spmuPinlistVec[i], instrumentType);
            ret = pinAndGroupMap.insert(make_pair(expandedPins[index], groupAndInstrument));
            if (!ret.second)
            {
              stringstream errMsg;
              errMsg << "In the SPMUInstrument group: " << param.spmuPinlistVec[i]<< endl
                     << "   and " << ret.first->second.second << " group: "
                     << ret.first->second.first << endl
                     << "There are the same pin: "
                     << expandedPins[index] << endl;
              throw Error("GeneralPMUTest::processParameters",
                          errMsg.str(),
                          "GeneralPMUTest::processParameters");
            }

            //HV pin cann't perform spmu test
            if (GeneralPMUTestUtil::isHvPin(expandedPins[index]))
            {
              stringstream errMsg;
              errMsg << "In the SPMUInstrument group: "
                     << param.spmuPinlistVec[i] << endl
                     << "There is high voltage pin: "
                     << expandedPins[index] << endl;
              throw Error("GeneralPMUTest::processParameters",
                  errMsg.str(),
                  "GeneralPMUTest::processParameters");
            }
          }
        }
        (param.spmuExpandedPinsVec).push_back(expandedPins);

        if ("CURR" == spmuForceModeVec[i])
        {
          if (isThisGroupNotCommented)
          {
            param.spmuIsCurrentMeasureVec.push_back(false);
            param.spmuIsVoltageMeasureVec.push_back(true);
            param.spmuHasVoltageMeasure = true;
          }
          else
          {
            param.spmuIsCurrentMeasureVec.push_back(false);
            param.spmuIsVoltageMeasureVec.push_back(false);
          }
        }
        else if ("VOLT" == spmuForceModeVec[i])
        {
          if (isThisGroupNotCommented)
          {
            param.spmuIsCurrentMeasureVec.push_back(true);
            param.spmuIsVoltageMeasureVec.push_back(false);
            param.spmuHasCurrentMeasure = true;
          }
          else
          {
            param.spmuIsCurrentMeasureVec.push_back(false);
            param.spmuIsVoltageMeasureVec.push_back(false);
          }
        }
        else if(isThisGroupNotCommented)
        {
          stringstream errMsg;
          errMsg << "SPMU: for the " << i + 1
                 << " group setup parameter, forceMode: "
                 << spmuForceModeVec[i] << " is invalid." << endl
                 << "forceMode can only be the following options: CURR  VOLT"
                 << endl;
          throw Error("GeneralPMUTest::processParamters()",
                      errMsg.str(),
                      "GeneralPMUTest::processParamters()");
        }

        if (param.spmuMeasureModeVec[i] != "PAR" &&
            param.spmuMeasureModeVec[i] != "SER")
        {
          stringstream errMsg;
          errMsg << "SPMU: for the " << i + 1
                 << " group setup parameter, measureMode: "
                 << param.spmuMeasureModeVec[i] << " is invalid." << endl
                 << "measureMode can only be the following options: PAR  SER"
                 << endl;
          throw Error("GeneralPMUTest::processParamters()",
                      errMsg.str(),
                     "GeneralPMUTest::processParamters()");
        }
        if (param.spmuPrechargeVec[i] != "ON" &&
            param.spmuPrechargeVec[i] != "OFF")
        {
          stringstream errMsg;
          errMsg << "SPMU: for the " << i + 1
                 << " group setup parameter, precharge: "
                 << param.spmuPrechargeVec[i] << " is invalid." << endl
                 << "precharge can only be the following options: ON  OFF"
                 << endl;
          throw Error("GeneralPMUTest::processParamters()",
                      errMsg.str(),
                      "GeneralPMUTest::processParamters()");
        }
        if (param.spmuRelaySwitchModeVec[i] != "NTBBM" &&
            param.spmuRelaySwitchModeVec[i] != "NTMBB")
        {
          stringstream errMsg;
          errMsg << "SPMU: for the " << i + 1
                 << " group setup parameter, relaySwitchMode: "
                 << param.spmuRelaySwitchModeVec[i] << " is invalid." << endl
                 << "relaySwitchMode can only be the following options: NTBBM  NTMBB"
                 << endl;
          throw Error("GeneralPMUTest::processParamters()",
                      errMsg.str(),
                     "GeneralPMUTest::processParamters()");
        }
        if (param.spmuTerminationVec[i] != "ON" &&
            param.spmuTerminationVec[i] != "OFF")
        {
          stringstream errMsg;
          errMsg << "SPMU: for the " << i + 1
                 << " group setup parameter, termination: "
                 << param.spmuTerminationVec[i] << " is invalid." << endl
                 << "termination can only be the following options: ON  OFF"
                 << endl;
          throw Error("GeneralPMUTest::processParamters()",
                      errMsg.str(),
                      "GeneralPMUTest::processParamters()");
        }

        LIMIT limit;
        param.spmuLimitVec.push_back(limit);
        param.spmuLimitNameVec.push_back(spmuTestNameVec[i]);

        GeneralPMUTestUtil::getLimitInfo(spmuTestNameVec[i], i,
                                         spmuForceModeVec[i],
                                         param.spmuLimitVec[i],
                                         testtableHelper);
      }
    }

    if ("YES" == param.mcxUsed)
    {
      vector<string> mcxForceModeVec;
      vector<string> mcxTestNameVec;

      GeneralPMUTestUtil::parseListOfString(mcxPinlist, param.mcxPinlistVec);
      GeneralPMUTestUtil::parseListOfString(mcxForceMode, mcxForceModeVec);
      GeneralPMUTestUtil::parseListOfDouble(mcxForceValue, param.mcxForceValueVec);
      GeneralPMUTestUtil::parseListOfString(mcxMeasureMode, param.mcxMeasureModeVec);
      GeneralPMUTestUtil::parseListOfString(mcxPrecharge, param.mcxPrechargeVec);
      GeneralPMUTestUtil::parseListOfDouble(mcxPrechargeVoltage_mV,
                                            param.mcxPrechargeVoltageVec);
      GeneralPMUTestUtil::parseListOfDouble(mcxSettlingTime_ms, param.mcxSettlingTimeVec);
      GeneralPMUTestUtil::parseListOfString(mcxTermination, param.mcxTerminationVec);
      GeneralPMUTestUtil::parseListOfString(mcxTestName, mcxTestNameVec);

      vector<string>::size_type groupSize = param.mcxPinlistVec.size();
      if (groupSize == 0)
      {
        throw Error("GeneralPMUTest::processParameters()",
                    "MCX-PMU: the pinlist groups can not be empty.",
                    "GeneralPMUTest::processParameters()");
      }

      GeneralPMUTestUtil::checkParameter(groupSize,
                                         mcxForceModeVec.size(),
                                         "MCX-PMU",
                                         "forceMode",
                                         mcxForceModeVec);
      GeneralPMUTestUtil::checkParameter(groupSize,
                                         param.mcxForceValueVec.size(),
                                         "MCX-PMU",
                                         "forceValue",
                                         param.mcxForceValueVec);
      GeneralPMUTestUtil::checkParameter(groupSize,
                                         param.mcxMeasureModeVec.size(),
                                         "MCX-PMU",
                                         "measureMode",
                                         param.mcxMeasureModeVec);
      GeneralPMUTestUtil::checkParameter(groupSize,
                                         param.mcxPrechargeVec.size(),
                                         "MCX-PMU",
                                         "precharge",
                                         param.mcxPrechargeVec);
      GeneralPMUTestUtil::checkParameter(groupSize,
                                         param.mcxPrechargeVoltageVec.size(),
                                         "MCX-PMU",
                                         "prechargeVoltage_mV",
                                         param.mcxPrechargeVoltageVec);
      GeneralPMUTestUtil::checkParameter(groupSize,
                                         param.mcxTerminationVec.size(),
                                         "MCX-PMU",
                                         "termination",
                                         param.mcxTerminationVec);
      GeneralPMUTestUtil::checkParameter(groupSize,
                                         param.mcxSettlingTimeVec.size(),
                                         "MCX-PMU",
                                         "settlingTime_ms",
                                         param.mcxSettlingTimeVec);

      if (param.mcxPinlistVec.size() != mcxTestNameVec.size())
      {
        if (mcxTestNameVec.size() != 1)
        {
          stringstream errMsg;
          errMsg << "MCX-PMU: the number of pinlist groups is "
                 << param.mcxPinlistVec.size() << endl
                 << "      the number of testName groups is "
                 << mcxTestNameVec.size() << endl
                 << "So the testName groups don't match pinlist groups." << endl;
          throw Error("GeneralPMUTest::processParameters()",
                      errMsg.str(),
                      "GeneralPMUTest::processParameters()");
        }
        else
        {
          param.isMCXLimitAppliedForAllGroups = true;
          for (vector<string>::size_type i = 1; i < param.mcxPinlistVec.size(); i++)
          {
            mcxTestNameVec.push_back(mcxTestNameVec[0]);
          }
        }
      }

      // the following three variables is used for checking duplicate pins
      pair<map<string, pair<string, string> >::iterator, bool> ret;
      pair<string, string> groupAndInstrument;
      const string instrumentType = "MCX-PMUInstrument";
      for (vector<string>::size_type i = 0; i < param.mcxPinlistVec.size(); i++)
      {
        bool isThisGroupNotCommented = ('#' != param.mcxPinlistVec[i][0]);
        vector<string> expandedPins;
        if (isThisGroupNotCommented)
        {
          GeneralPMUTestUtil::parseListOfString(param.mcxPinlistVec[i], expandedPins, ',');
          // check the duplicate pins
          for (vector<string>::size_type index = 0; index < expandedPins.size(); index++)
          {
            groupAndInstrument = make_pair(param.mcxPinlistVec[i], instrumentType);
            ret = pinAndGroupMap.insert(make_pair(expandedPins[index], groupAndInstrument));
            if (!ret.second)
            {
              stringstream errMsg;
              errMsg << "In the MCX-PMUInstrument group: " << param.mcxPinlistVec[i]<< endl
                     << "   and " << ret.first->second.second << " group: "
                     << ret.first->second.first << endl
                     << "There are the same pin: "
                     << expandedPins[index] << endl;
              throw Error("GeneralPMUTest::processParameters",
                          errMsg.str(),
                          "GeneralPMUTest::processParameters");
            }
          }
        }
        param.mcxExpandedPinsVec.push_back(expandedPins);

        if ("CURR" == mcxForceModeVec[i])
        {
          if (isThisGroupNotCommented)
          {
            param.mcxIsCurrentMeasureVec.push_back(false);
            param.mcxIsVoltageMeasureVec.push_back(true);
            param.mcxHasVoltageMeasure = true;
          }
          else
          {
            param.mcxIsCurrentMeasureVec.push_back(false);
            param.mcxIsVoltageMeasureVec.push_back(false);
          }
        }
        else if ("VOLT" == mcxForceModeVec[i])
        {
          if (isThisGroupNotCommented)
          {
            param.mcxIsCurrentMeasureVec.push_back(true);
            param.mcxIsVoltageMeasureVec.push_back(false);
            param.mcxHasCurrentMeasure = true;
          }
          else
          {
            param.mcxIsCurrentMeasureVec.push_back(false);
            param.mcxIsVoltageMeasureVec.push_back(false);
          }
        }
        else if(isThisGroupNotCommented)
        {
          stringstream errMsg;
          errMsg << "MCX-PMU: for the " << i + 1
                 << " group setup parameter, forceMode: "
                 << mcxForceModeVec[i] << " is invalid." << endl
                 << "forceMode can only be the following options: CURR  VOLT" << endl;
          throw Error("GeneralPMUTest::processParamters()",
                      errMsg.str(),
                      "GeneralPMUTest::processParamters()");
        }

        if (param.mcxMeasureModeVec[i] != "PAR" &&
            param.mcxMeasureModeVec[i] != "SER")
        {
          stringstream errMsg;
          errMsg << "MCX-PMU: for the " << i + 1
                 << " group setup parameter, measureMode: "
                 << param.mcxMeasureModeVec[i]
                 << " is invalid." << endl
                 << "measureMode can only be the following options: PAR  SER" << endl;
          throw Error("GeneralPMUTest::processParamters()",
                      errMsg.str(),
                      "GeneralPMUTest::processParamters()");
        }
        if (param.mcxPrechargeVec[i] != "ON" &&
            param.mcxPrechargeVec[i] != "OFF")
        {
          stringstream errMsg;
          errMsg << "MCX-PMU: for the " << i + 1
                 << " group setup parameter, precharge: "
                 << param.mcxPrechargeVec[i] << " is invalid." << endl
                 << "precharge can only be the following options: ON  OFF" << endl;
          throw Error("GeneralPMUTest::processParamters()",
                      errMsg.str(),
                      "GeneralPMUTest::processParamters()");
        }

        if (param.mcxTerminationVec[i] != "ON" &&
            param.mcxTerminationVec[i] != "OFF")
        {
          stringstream errMsg;
          errMsg << "MCX-PMU: for the " << i + 1
                 << " group setup parameter, termination: "
                 << param.mcxTerminationVec[i] << " is invalid." << endl
                 << "termination can only be the following options: ON  OFF" << endl;
          throw Error("GeneralPMUTest::processParamters()",
                      errMsg.str(),
                      "GeneralPMUTest::processParamters()");
        }

        LIMIT limit;
        param.mcxLimitVec.push_back(limit);
        param.mcxLimitNameVec.push_back(mcxTestNameVec[i]);

        GeneralPMUTestUtil::getLimitInfo(mcxTestNameVec[i], i,
                                         mcxForceModeVec[i],
                                         param.mcxLimitVec[i],
                                         testtableHelper);
      }
    }

    if ("YES" == param.dcScaleSIGUsed)
    {
      vector<string> dcScaleSIGForceModeVec;
      vector<string> dcScaleSIGTestNameVec;

      GeneralPMUTestUtil::parseListOfString(dcScaleSIGPinlist, param.dcScaleSIGPinlistVec);
      GeneralPMUTestUtil::parseListOfString(dcScaleSIGForceMode, dcScaleSIGForceModeVec);
      GeneralPMUTestUtil::parseListOfDouble(dcScaleSIGForceValue,
                                            param.dcScaleSIGForceValueVec);
      GeneralPMUTestUtil::parseListOfString(dcScaleSIGMeasureMode,
                                            param.dcScaleSIGMeasureModeVec);
      GeneralPMUTestUtil::parseListOfDouble(dcScaleSIGClampValue_mV,
                                            param.dcScaleSIGClampValueVec);
      GeneralPMUTestUtil::parseListOfString(dcScaleSIGPrecharge,
                                            param.dcScaleSIGPrechargeVec);
      GeneralPMUTestUtil::parseListOfDouble(dcScaleSIGPrechargeVoltage_mV,
                                            param.dcScaleSIGPrechargeVoltageVec);
      GeneralPMUTestUtil::parseListOfString(dcScaleSIGRelaySwitchMode,
                                            param.dcScaleSIGRelaySwitchModeVec);
      GeneralPMUTestUtil::parseListOfDouble(dcScaleSIGSettlingTime_ms,
                                            param.dcScaleSIGSettlingTimeVec);
      GeneralPMUTestUtil::parseListOfString(dcScaleSIGTestName, dcScaleSIGTestNameVec);

      vector<string>::size_type groupSize = param.dcScaleSIGPinlistVec.size();
      if (groupSize == 0)
      {
        throw Error("GeneralPMUTest::processParameters()",
                    "DcScaleSIG: the pinlist groups can not be empty.",
                    "GeneralPMUTest::processParameters()");
      }

      GeneralPMUTestUtil::checkParameter(groupSize,
                                         dcScaleSIGForceModeVec.size(),
                                         "DcScaleSIG",
                                         "forceMode",
                                         dcScaleSIGForceModeVec);
      GeneralPMUTestUtil::checkParameter(groupSize,
                                         param.dcScaleSIGForceValueVec.size(),
                                         "DcScaleSIG",
                                         "forceValue",
                                         param.dcScaleSIGForceValueVec);
      GeneralPMUTestUtil::checkParameter(groupSize,
                                         param.dcScaleSIGMeasureModeVec.size(),
                                         "DcScaleSIG",
                                         "measureMode",
                                         param.dcScaleSIGMeasureModeVec);
      GeneralPMUTestUtil::checkParameter(groupSize,
                                         param.dcScaleSIGClampValueVec.size(),
                                         "DcScaleSIG",
                                         "clampValue",
                                         param.dcScaleSIGClampValueVec);
      GeneralPMUTestUtil::checkParameter(groupSize,
                                         param.dcScaleSIGPrechargeVec.size(),
                                         "DcScaleSIG",
                                         "precharge",
                                         param.dcScaleSIGPrechargeVec);
      GeneralPMUTestUtil::checkParameter(groupSize,
                                         param.dcScaleSIGPrechargeVoltageVec.size(),
                                         "DcScaleSIG",
                                         "prechargeVoltage_mV",
                                         param.dcScaleSIGPrechargeVoltageVec);
      GeneralPMUTestUtil::checkParameter(groupSize,
                                         param.dcScaleSIGRelaySwitchModeVec.size(),
                                         "DcScaleSIG",
                                         "relaySwitchMode",
                                         param.dcScaleSIGRelaySwitchModeVec);
      GeneralPMUTestUtil::checkParameter(groupSize,
                                         param.dcScaleSIGSettlingTimeVec.size(),
                                         "DcScaleSIG",
                                         "settlingTime_ms",
                                         param.dcScaleSIGSettlingTimeVec);

      if (param.dcScaleSIGPinlistVec.size() != dcScaleSIGTestNameVec.size())
      {
        if (dcScaleSIGTestNameVec.size() != 1)
        {
          stringstream errMsg;
          errMsg << "DcScaleSIG: the number of pinlist groups is "
                 << param.dcScaleSIGPinlistVec.size() << endl
                 << "      the number of testName groups is "
                 << dcScaleSIGTestNameVec.size() << endl 
                 << "So the testName groups don't match pinlist groups." << endl;
          throw Error("GeneralPMUTest::processParameters()",
                      errMsg.str(),
                      "GeneralPMUTest::processParameters()");
        }
        else
        {
          param.isDCScaleSIGLimitAppliedForAllGroups = true;
          for (vector<string>::size_type i = 1; i < param.dcScaleSIGPinlistVec.size(); i++)
          {
            dcScaleSIGTestNameVec.push_back(dcScaleSIGTestNameVec[0]);
          }
        }
      }

      // the following three variables is used for checking duplicate pins
      pair<map<string, pair<string, string> >::iterator, bool> ret;
      pair<string, string> groupAndInstrument;
      const string instrumentType = "DCScaleSIGInstrument";
      for (vector<string>::size_type i = 0; i < param.dcScaleSIGPinlistVec.size(); i++)
      {
        bool isThisGroupNotCommented = ('#' != param.dcScaleSIGPinlistVec[i][0]);
        vector<string> expandedPins;
        if (isThisGroupNotCommented)
        {
          expandedPins = PinUtility.getDigitalPinNamesFromPinList(
                  param.dcScaleSIGPinlistVec[i],
                  TM::DC_PIN,
                  true,
                  true);
          // check the duplicate pins
          for (vector<string>::size_type index = 0; index < expandedPins.size(); index++)
          {
            groupAndInstrument = make_pair(param.dcScaleSIGPinlistVec[i], instrumentType);
            ret = pinAndGroupMap.insert(make_pair(expandedPins[index], groupAndInstrument));
            if (!ret.second)
            {
              stringstream errMsg;
              errMsg << "In the DCScaleSIGInstrument group: "
                     << param.dcScaleSIGPinlistVec[i] << endl
                     << "   and " << ret.first->second.second
                     << " group: " << ret.first->second.first << endl
                     << "There are the same pin: " << expandedPins[index] << endl;
              throw Error("GeneralPMUTest::processParameters",
                          errMsg.str(),
                          "GeneralPMUTest::processParameters");
            }
          }
        }
        param.dcScaleSIGExpandedPinsVec.push_back(expandedPins);

        if ("CURR" == dcScaleSIGForceModeVec[i])
        {
          if (isThisGroupNotCommented)
          {
            param.dcScaleSIGIsCurrentMeasureVec.push_back(false);
            param.dcScaleSIGIsVoltageMeasureVec.push_back(true);
            param.dcScaleSIGHasVoltageMeasure = true;
          }
          else
          {
            param.dcScaleSIGIsCurrentMeasureVec.push_back(false);
            param.dcScaleSIGIsVoltageMeasureVec.push_back(false);
          }
        }
        else if ("VOLT" == dcScaleSIGForceModeVec[i])
        {
          if (isThisGroupNotCommented)
          {
            param.dcScaleSIGIsCurrentMeasureVec.push_back(true);
            param.dcScaleSIGIsVoltageMeasureVec.push_back(false);
            param.dcScaleSIGHasCurrentMeasure = true;
          }
          else
          {
            param.dcScaleSIGIsCurrentMeasureVec.push_back(false);
            param.dcScaleSIGIsVoltageMeasureVec.push_back(false);
          }
        }
        else if(isThisGroupNotCommented)
        {
          stringstream errMsg;
          errMsg << "DcScaleSIG: for the " << i + 1
                 << " group setup parameter, forceMode: " << dcScaleSIGForceModeVec[i]
                 << " is invalid." << endl
                 << "forceMode can only be the following options: CURR  VOLT" << endl;
          throw Error("GeneralPMUTest::processParamters()",
                      errMsg.str(),
                      "GeneralPMUTest::processParamters()");
        }

        if (param.dcScaleSIGMeasureModeVec[i] != "PAR" &&
            param.dcScaleSIGMeasureModeVec[i] != "SER")
        {
          stringstream errMsg;
          errMsg << "DcScaleSIG: for the " << i + 1
                 << " group setup parameter, measureMode: "
                 << param.dcScaleSIGMeasureModeVec[i] << " is invalid." << endl
                 << "measureMode can only be the following options: PAR  SER" << endl;
          throw Error("GeneralPMUTest::processParamters()",
                      errMsg.str(),
                      "GeneralPMUTest::processParamters()");
        }
        if (param.dcScaleSIGPrechargeVec[i] != "ON" && 
            param.dcScaleSIGPrechargeVec[i] != "OFF")
        {
          stringstream errMsg;
          errMsg << "DcScaleSIG: for the " << i + 1
                 << " group setup parameter, precharge: " 
                 << param.dcScaleSIGPrechargeVec[i] << " is invalid." << endl
                 << "precharge can only be the following options: ON  OFF" << endl;
          throw Error("GeneralPMUTest::processParamters()",
                      errMsg.str(),
                      "GeneralPMUTest::processParamters()");
        }
        if (param.dcScaleSIGRelaySwitchModeVec[i] != "NT" &&
            param.dcScaleSIGRelaySwitchModeVec[i] != "NO")
        {
          stringstream errMsg;
          errMsg << "DcScaleSIG: for the " << i + 1
                 << " group setup parameter, relaySwitchMode: "
                 << param.dcScaleSIGRelaySwitchModeVec[i] << " is invalid." << endl
                 << "relaySwitchMode can only be the following options: NT NO" << endl;
          throw Error("GeneralPMUTest::processParamters()",
                      errMsg.str(),
                      "GeneralPMUTest::processParamters()");
        }

        LIMIT limit;
        param.dcScaleSIGLimitVec.push_back(limit);
        param.dcScaleSIGLimitNameVec.push_back(dcScaleSIGTestNameVec[i]);

        GeneralPMUTestUtil::getLimitInfo(dcScaleSIGTestNameVec[i],i,
                                         dcScaleSIGForceModeVec[i],
                                         param.dcScaleSIGLimitVec[i],
                                         testtableHelper);
      }
    }

    if ("YES" == param.boardADCUsed)
    {
      vector<string> boardADCTestNameVec;

      GeneralPMUTestUtil::parseListOfString(boardADCPinlist, param.boardADCPinlistVec);
      GeneralPMUTestUtil::parseListOfString(boardADCRelaySwitchMode,
                                            param.boardADCRelaySwitchModeVec);
      GeneralPMUTestUtil::parseListOfDouble(boardADCSettlingTime_ms,
                                            param.boardADCSettlingTimeVec);
      GeneralPMUTestUtil::parseListOfString(boardADCTermination,
                                            param.boardADCTerminationVec);
      GeneralPMUTestUtil::parseListOfString(boardADCTestName, boardADCTestNameVec);

      vector<string>::size_type groupSize = param.boardADCPinlistVec.size();
      if (groupSize == 0)
      {
        throw Error("GeneralPMUTest::processParameters()",
                    "BoardADC: the pinlist groups can not be empty.",
                    "GeneralPMUTest::processParameters()");
      }

      GeneralPMUTestUtil::checkParameter(groupSize,
                                         param.boardADCRelaySwitchModeVec.size(),
                                         "BoardADC",
                                         "relaySwitchMode",
                                         param.boardADCRelaySwitchModeVec);
      GeneralPMUTestUtil::checkParameter(groupSize,
                                         param.boardADCTerminationVec.size(),
                                         "BoardADC",
                                         "termination",
                                         param.boardADCTerminationVec);
      GeneralPMUTestUtil::checkParameter(groupSize,
                                         param.boardADCSettlingTimeVec.size(),
                                         "BoardADC",
                                         "settlingTime_ms",
                                         param.boardADCSettlingTimeVec);

      if (param.boardADCPinlistVec.size() != boardADCTestNameVec.size())
      {
        if (boardADCTestNameVec.size() != 1)
        {
          stringstream errMsg;
          errMsg << "BoardADC: the number of pinlist groups is "
                 << param.boardADCPinlistVec.size() << endl
                 << "      the number of testName groups is "
                 << boardADCTestNameVec.size() <<endl
                 << "So the testName groups don't match pinlist groups." << endl;
          throw Error("GeneralPMUTest::processParameters()",
                      errMsg.str(),
                      "GeneralPMUTest::processParameters()");
        }
        else
        {
          param.isBoardADCLimitAppliedForAllGroups = true;
          for (vector<string>::size_type i = 1; i < param.boardADCPinlistVec.size(); i++)
          {
            boardADCTestNameVec.push_back(boardADCTestNameVec[0]);
          }
        }
      }

      // the following three variables is used for checking duplicate pins
      pair<map<string, pair<string, string> >::iterator, bool> ret;
      pair<string, string> groupAndInstrument;
      const string instrumentType = "BoardADCInstrument";

      // the following variables are used to store info of HV pins
      vector<long unsigned int>  boardADCHvPinGroupIndexList;
      vector<vector<string> > boardADCExpandedHvPinsVec;

      boardADCHvPinGroupIndexList.clear();
      boardADCExpandedHvPinsVec.clear();

      param.boardADCIsHvPinGroupVec.resize(param.boardADCPinlistVec.size());
      for (vector<string>::size_type i = 0; i < param.boardADCPinlistVec.size(); i++)
      {
        param.boardADCIsHvPinGroupVec[i] = false;
        bool isThisGroupNotCommented = ('#' != param.boardADCPinlistVec[i][0]);
        vector<string> expandedPins;
        if (isThisGroupNotCommented)
        {
          expandedPins = PinUtility.getDigitalPinNamesFromPinList(
                  param.boardADCPinlistVec[i],
                  TM::I_PIN | TM::O_PIN | TM::IO_PIN,
                  true,
                  true);

          //Split HV pin and nonHV pin.
          vector<string> hvPinVector, nonHvPinVector;
          hvPinVector.clear();
          nonHvPinVector.clear();

          // check the duplicate pins
          for (vector<string>::size_type index = 0; index < expandedPins.size(); index++)
          {
            groupAndInstrument = make_pair(param.boardADCPinlistVec[i], instrumentType);
            ret = pinAndGroupMap.insert(make_pair(expandedPins[index], groupAndInstrument));
            if (!ret.second)
            {
              stringstream errMsg;
              errMsg << "In the BoardADCInstrument group: "
                     << param.boardADCPinlistVec[i] << endl << "   and "
                     << ret.first->second.second << " group: " << ret.first->second.first
                     << endl << "There are the same pin: " << expandedPins[index] << endl;
              throw Error("GeneralPMUTest::processParameters",
                          errMsg.str(),
                          "GeneralPMUTest::processParameters");
            }

            if(GeneralPMUTestUtil::isHvPin(expandedPins[index]))
            {
            	hvPinVector.push_back(expandedPins[index]);
            }
            else
            {
            	nonHvPinVector.push_back(expandedPins[index]);
            }

          }
          //adapt hv and nonHv pins
          if(hvPinVector.size() > 0)
          {
            if(hvPinVector.size() == expandedPins.size())
            {
              param.boardADCIsHvPinGroupVec[i] = true;
            }
            else
            {
              param.boardADCIsHvPinGroupVec[i] = false;
              expandedPins.clear();
              expandedPins = nonHvPinVector;
              param.boardADCPinlistVec[i] = PinUtility.createPinListFromPinNames(nonHvPinVector);

              //Keep the index and expandedPins of HV pins, to create the
              //new HV group later.
              boardADCExpandedHvPinsVec.push_back(hvPinVector);
              boardADCHvPinGroupIndexList.push_back(i);
            }
          }
          else
          {
            param.boardADCIsHvPinGroupVec[i] = false;
          }

        }
        (param.boardADCExpandedPinsVec).push_back(expandedPins);
      }

      // create the new pinlist and its test properties
      if (boardADCHvPinGroupIndexList.size() > 0)
      {
        vector<string> tmpPinlistVec, tmpRelaySwitchModeVec,
                       tmpTerminationVec, tmpTestNameVec;
        vector<double> tmpSettlingTimeVec;
        vector<vector<string> >tmpExpandedPinsVec;
        vector<bool> tmpIsHVPinsVec;
        for(vector<string>::size_type  i = 0; i< param.boardADCPinlistVec.size(); i++)
        {
          tmpPinlistVec.push_back(param.boardADCPinlistVec[i]);
          tmpRelaySwitchModeVec.push_back(param.boardADCRelaySwitchModeVec[i]);
          tmpSettlingTimeVec.push_back(param.boardADCSettlingTimeVec[i]);
          tmpTerminationVec.push_back(param.boardADCTerminationVec[i]);
          tmpTestNameVec.push_back(boardADCTestNameVec[i]);
          tmpExpandedPinsVec.push_back(param.boardADCExpandedPinsVec[i]);
          tmpIsHVPinsVec.push_back(param.boardADCIsHvPinGroupVec[i]);

          vector<long unsigned int>::iterator it = find(boardADCHvPinGroupIndexList.begin(), boardADCHvPinGroupIndexList.end(), i);
          if (it != boardADCHvPinGroupIndexList.end())
          {
            long unsigned int index = it - boardADCHvPinGroupIndexList.begin();
            tmpPinlistVec.push_back(PinUtility.createPinListFromPinNames(boardADCExpandedHvPinsVec[index]));
            tmpRelaySwitchModeVec.push_back(param.boardADCRelaySwitchModeVec[i]);
            tmpSettlingTimeVec.push_back(param.boardADCSettlingTimeVec[i]);
            tmpTerminationVec.push_back(param.boardADCTerminationVec[i]);
            tmpTestNameVec.push_back(boardADCTestNameVec[i]);
            tmpExpandedPinsVec.push_back(boardADCExpandedHvPinsVec[index]);
            tmpIsHVPinsVec.push_back(true);
          }
        }
        param.boardADCPinlistVec.swap(tmpPinlistVec);
        param.boardADCRelaySwitchModeVec.swap(tmpRelaySwitchModeVec);
        param.boardADCSettlingTimeVec.swap(tmpSettlingTimeVec);
        param.boardADCTerminationVec.swap(tmpTerminationVec);
        boardADCTestNameVec.swap(tmpTestNameVec);
        param.boardADCExpandedPinsVec.swap(tmpExpandedPinsVec);
        param.boardADCIsHvPinGroupVec.swap(tmpIsHVPinsVec);
      }

      for (vector<string>::size_type i = 0; i < param.boardADCPinlistVec.size(); i++)
      {
        bool isThisGroupNotCommented = ('#' != param.boardADCPinlistVec[i][0]);


        if (param.boardADCRelaySwitchModeVec[i] != "NTBBM" &&
            param.boardADCRelaySwitchModeVec[i] != "NTMBB")
        {
          stringstream errMsg;
          errMsg << "BoardADC: for the " << i + 1
                 << " group setup parameter, relaySwitchMode: "
                 << param.boardADCRelaySwitchModeVec[i] << " is invalid." << endl
                 << "relaySwitchMode can only be the following options: NTBBM  NTMBB"
                 << endl;
          throw Error("GeneralPMUTest::processParamters()",
                      errMsg.str(),
                      "GeneralPMUTest::processParamters()");
        }
        if (param.boardADCTerminationVec[i] != "ON" &&
            param.boardADCTerminationVec[i] != "OFF")
        {
          stringstream errMsg;
          errMsg << "BoardADC: for the " << i + 1
                 << " group setup parameter, termination: "
                 << param.boardADCTerminationVec[i] << " is invalid." << endl
                 << "termination can only be the following options: ON  OFF" << endl;
          throw Error("GeneralPMUTest::processParamters()",
                      errMsg.str(),
                      "GeneralPMUTest::processParamters()");
        }

        LIMIT limit;
        param.boardADCLimitVec.push_back(limit);
        param.boardADCLimitNameVec.push_back(boardADCTestNameVec[i]);
        GeneralPMUTestUtil::getLimitInfo(boardADCTestNameVec[i],i,
                                         "CURR",
                                         param.boardADCLimitVec[i],
                                         testtableHelper);

        if (isThisGroupNotCommented)
        {
          param.boardADCIsVoltageMeasureVec.push_back(true);
          param.boardADCHasVoltageMeasure = true;
        }
        else
        {
          param.boardADCIsVoltageMeasureVec.push_back(false);
        }
      }
    }
    

    // common parameters
    param.testerState = GeneralPMUTestUtil::trim(testerState);
    if (param.testerState != "CONNECTED" &&
        param.testerState  != "DISCONNECTED" &&
        param.testerState != "UNCHANGED")
    {
      throw Error("GeneralPMUTest::processParamters()",
          "Wrong Connect state. The state options can only be:CONNECTED  CONNECTED  UNCHANGED",
          "GeneralPMUTest::processParamters()");
    }
    if("CONNECTED" == param.testerState)
    {
      param.preFunction = GeneralPMUTestUtil::trim(preFunction);
      if (param.preFunction != "ALL" && 
          param.preFunction != "NO" && 
          param.preFunction != "ToStopVEC" &&
          param.preFunction != "ToStopCYC")
      {
        throw Error("GeneralPMUTest::processParamters()",
            "Wrong Pretest type. The type options can only be: ALL NO ToStopVEC ToStopCYC",
            "GeneralPMUTest::processParamters()");
      }
      else if(param.preFunction != "NO")
      {
        param.checkFunctionalResult = GeneralPMUTestUtil::trim(checkFunctionalResult);
      }

      if ("ToStopVEC" == param.preFunction)
      {
        param.stopVec = stopVec;
      }
      else if ("ToStopCYC" == param.preFunction)
      {
        string portData;
        GeneralPMUTestUtil::splitPortDataAndPortName(stopCyc,portData,param.portName,false);
        param.stopCyc = GeneralPMUTestUtil::string2Long(portData, "stopCyc");
      }
    }

    param.isLimitTableUsed = testtableHelper.isAllInTable();
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: doMeasurement
   *
   * Purpose: execute measurement by PMU and store results
   *
   *----------------------------------------------------------------------*
   * Description:
   *   INPUT:  param       - test parameters
   *           testLimit   - test limit container
   *           result      - result container
   *
   *   OUTPUT:
   *   RETURN:
   *----------------------------------------------------------------------*
   */
  static void doMeasurement(
      const GeneralPMUTestParam& param,
      GeneralPMUTestResult& result)
  {
    bool needSetSequencerOff = false;
    ON_FIRST_INVOCATION_BEGIN();
    /* to eliminate side-effect of sequencer's state after PPMU-paralle measurement,
     * after PPMU-parallel(FlexDC) measurement. we should do:
     * if connectState==DISCONNECT,
     *    must set: needSetSequencerOff = TRUE
     * if connectState==UNCHANGED and the state of sequencer is OFF,
     *    must set: needSetSequencerOff = TRUE
     * otherwise needSetSequencerOff = FALSE.
     * The result is TRUE, that means to set sequencer to OFF state.
     */
    if (param.testerState == "CONNECTED")
    {
      CONNECT();
      if ("ALL" == param.preFunction)
      {
        Sequencer.reset();
        FUNCTIONAL_TEST();
      }
      else if ("ToStopVEC" == param.preFunction)
      {
        Sequencer.stopVector(param.stopVec);
        FUNCTIONAL_TEST();
      }
      else if ("ToStopCYC" == param.preFunction)
      {
        if (param.portName.empty())
        {
          Sequencer.stopCycle(param.stopCyc);
        }
        else
        {
          Sequencer.stopCycle(param.stopCyc, param.portName);
        }
        FUNCTIONAL_TEST();
      }
      else // param.preFunction == "NO"
      {
        //  Do nothing here.
      }
    }
    else if (param.testerState == "DISCONNECTED")
    {
      DISCONNECT();
      needSetSequencerOff = true;
    }
    else // param.testerState == "UNCHANGED"
    {
      string fwAnswer;
      FW_TASK("SQST?\n", fwAnswer);
      if (fwAnswer.find("OFF", 5) != string::npos)
      {
        needSetSequencerOff = true;
      }
    }
    ON_FIRST_INVOCATION_END();
    if(param.preFunction != "NO")
    {
      //record functional result
      result.funcResult = GET_FUNCTIONAL_RESULT();
    }

    SPMU_TASK spForceON;
    SPMU_TASK spMeasure;
    SPMU_TASK spForceOFF;
    PPMU_MEASURE ppmuMeasure;
    HV_DC_TASK ppmuHvMeasure;
    HV_DC_TASK boardADCHvMeasure;

    bool hasParallelGroupForPpmuMeasure = false;
    bool hasParallelGroupForSpmuTask = false;
    bool hasParallelGroupForPpmuHvMeasure = false;
    bool hasParallelGroupForBoardADCHvTask = false;

    ON_FIRST_INVOCATION_BEGIN();
    PPMU_SETTING ppmuSettingStep1, ppmuSettingStep2;
    PPMU_RELAY ppmuRelayStep1, ppmuRelayStep2;
    PPMU_RELAY ppmuRelayRestoreStep1, ppmuRelayRestoreStep2;
    PPMU_CLAMP ppmuClampOn, ppmuClampOff;
    TASK_LIST taskList;

    if (param.ppmuHasCurrentMeasure)
    {
      GeneralPMUTestUtil::ppmuInstrumentCurrentMeasurementSetup(
          param.ppmuPinlistVec,
          param.ppmuIsCurrentMeasureVec,
          param.ppmuForceValueVec,
          param.ppmuPrechargeVec,
          param.ppmuPrechargeVoltageVec,
          param.ppmuSettlingTimeVec,
          param.ppmuMeasureModeVec,
          param.ppmuRelaySwitchModeVec,
          param.ppmuTerminationVec,
          param.ppmuLimitVec,
          param.ppmuIsHvPinGroupVec,
          param.testMode,
          param.testerState,
          ppmuSettingStep1,
          ppmuSettingStep2,
          ppmuRelayStep1,
          ppmuRelayStep2,
          ppmuRelayRestoreStep1,
          ppmuRelayRestoreStep2,
          ppmuMeasure,
          ppmuHvMeasure,
          hasParallelGroupForPpmuMeasure,
          hasParallelGroupForPpmuHvMeasure);
    }
    if (param.ppmuHasVoltageMeasure)
    {
      GeneralPMUTestUtil::ppmuInstrumentVoltageMeasurementSetup(
          param.ppmuPinlistVec,
          param.ppmuIsVoltageMeasureVec,
          param.ppmuForceValueVec,
          param.ppmuPrechargeVec,
          param.ppmuPrechargeVoltageVec,
          param.ppmuSettlingTimeVec,
          param.ppmuMeasureModeVec,
          param.ppmuRelaySwitchModeVec,
          param.ppmuTerminationVec,
          param.ppmuLimitVec,
          param.ppmuIsHvPinGroupVec,
          param.testMode,
          param.testerState,
          ppmuSettingStep1,
          ppmuClampOn,
          ppmuClampOff,
          ppmuRelayStep1,
          ppmuRelayStep2,
          ppmuRelayRestoreStep1,
          ppmuRelayRestoreStep2,
          ppmuMeasure,
          ppmuHvMeasure,
          hasParallelGroupForPpmuMeasure,
          hasParallelGroupForPpmuHvMeasure);
    }

    if (param.spmuHasCurrentMeasure)
    {
      GeneralPMUTestUtil::spmuInstrumentCurrentMeasurementSetup(
          param.spmuPinlistVec,
          param.spmuIsCurrentMeasureVec,
          param.spmuForceValueVec,
          param.spmuMeasureModeVec,
          param.spmuClampValueVec,
          param.spmuPrechargeVec,
          param.spmuPrechargeVoltageVec,
          param.spmuSettlingTimeVec,
          param.spmuRelaySwitchModeVec,
          param.spmuTerminationVec,
          param.spmuLimitVec,
          param.testMode,
          spForceON,
          spMeasure,
          spForceOFF,
          hasParallelGroupForSpmuTask);
    }
    if (param.spmuHasVoltageMeasure)
    {
      GeneralPMUTestUtil::spmuInstrumentVoltageMeasurementSetup(
          param.spmuPinlistVec,
          param.spmuIsVoltageMeasureVec,
          param.spmuForceValueVec,
          param.spmuMeasureModeVec,
          param.spmuClampValueVec,
          param.spmuPrechargeVec,
          param.spmuPrechargeVoltageVec,
          param.spmuSettlingTimeVec,
          param.spmuRelaySwitchModeVec,
          param.spmuTerminationVec,
          param.spmuLimitVec,
          param.testMode,
          spForceON,
          spMeasure,
          spForceOFF,
          hasParallelGroupForSpmuTask);
    }

    if (param.dcScaleSIGHasCurrentMeasure)
    {
      GeneralPMUTestUtil::DCScaleSIGInstrumentCurrentMeasurementSetup(
          param.dcScaleSIGPinlistVec,
          param.dcScaleSIGIsCurrentMeasureVec,
          param.dcScaleSIGForceValueVec,
          param.dcScaleSIGMeasureModeVec,
          param.dcScaleSIGClampValueVec,
          param.dcScaleSIGPrechargeVec,
          param.dcScaleSIGPrechargeVoltageVec,
          param.dcScaleSIGSettlingTimeVec,
          param.dcScaleSIGRelaySwitchModeVec,
          param.dcScaleSIGLimitVec,
          param.testMode,
          spForceON,
          spMeasure,
          spForceOFF,
          hasParallelGroupForSpmuTask);
    }
    if (param.dcScaleSIGHasVoltageMeasure)
    {
      GeneralPMUTestUtil::DCScaleSIGInstrumentVoltageMeasurementSetup(
          param.dcScaleSIGPinlistVec,
          param.dcScaleSIGIsVoltageMeasureVec,
          param.dcScaleSIGForceValueVec,
          param.dcScaleSIGMeasureModeVec,
          param.dcScaleSIGClampValueVec,
          param.dcScaleSIGPrechargeVec,
          param.dcScaleSIGPrechargeVoltageVec,
          param.dcScaleSIGSettlingTimeVec,
          param.dcScaleSIGRelaySwitchModeVec,
          param.dcScaleSIGLimitVec,
          param.testMode,
          spForceON,
          spMeasure,
          spForceOFF,
          hasParallelGroupForSpmuTask);
    }

    if (param.boardADCHasVoltageMeasure)
    {
      GeneralPMUTestUtil::boardADCInstrumentVoltageMeasurementSetup(
          param.boardADCPinlistVec,
          param.boardADCIsVoltageMeasureVec,
          param.boardADCSettlingTimeVec,
          param.boardADCRelaySwitchModeVec,
          param.boardADCTerminationVec,
          param.boardADCLimitVec,
          param.boardADCIsHvPinGroupVec,
          param.testMode,
          spForceON,
          spMeasure,
          spForceOFF,
          boardADCHvMeasure, 
          hasParallelGroupForSpmuTask,
          hasParallelGroupForBoardADCHvTask);
    }

    if (hasParallelGroupForPpmuMeasure && hasParallelGroupForSpmuTask)
    {
      taskList.add(ppmuSettingStep1)
              .add(ppmuClampOn)
              .add(ppmuRelayStep1)
              .add(ppmuRelayStep2)
              .add(ppmuClampOff)
              .add(ppmuSettingStep2)
              .add(spForceON);

      //HV tests should be put before PPMU_MEASURE
      if (hasParallelGroupForPpmuHvMeasure)
      {
        taskList.add(ppmuHvMeasure);
      }
      if (hasParallelGroupForBoardADCHvTask)
      {
        taskList.add(boardADCHvMeasure);
      }

      taskList.add(ppmuMeasure)
              .add(ppmuRelayRestoreStep1)
              .add(ppmuRelayRestoreStep2)
              .add(spMeasure)
              .add(spForceOFF);
    }
    else if (hasParallelGroupForPpmuMeasure)
    {
      taskList.add(ppmuSettingStep1)
              .add(ppmuClampOn)
              .add(ppmuRelayStep1)
              .add(ppmuRelayStep2)
              .add(ppmuClampOff)
              .add(ppmuSettingStep2);

      //HV tests should be put before PPMU_MEASURE
      if (hasParallelGroupForPpmuHvMeasure)
      {
        taskList.add(ppmuHvMeasure);
      }
      if (hasParallelGroupForBoardADCHvTask)
      {
        taskList.add(boardADCHvMeasure);
      }

      taskList.add(ppmuMeasure)
              .add(ppmuRelayRestoreStep1)
              .add(ppmuRelayRestoreStep2);
    }
    else if (param.ppmuHasVoltageMeasure && hasParallelGroupForSpmuTask)
    {
      taskList.add(ppmuSettingStep1)
              .add(ppmuClampOn)
              .add(spForceON);

      if (hasParallelGroupForPpmuHvMeasure)
      {
        taskList.add(ppmuHvMeasure);
      }
      if (hasParallelGroupForBoardADCHvTask)
      {
        taskList.add(boardADCHvMeasure);
      }

      taskList.add(spMeasure)
              .add(spForceOFF);
    }
    else if (param.ppmuHasCurrentMeasure && hasParallelGroupForSpmuTask)
    {
      taskList.add(ppmuSettingStep1)
              .add(spForceON);

      if (hasParallelGroupForPpmuHvMeasure)
      {
        taskList.add(ppmuHvMeasure);
      }
      if (hasParallelGroupForBoardADCHvTask)
      {
        taskList.add(boardADCHvMeasure);
      }

      taskList.add(spMeasure)
              .add(spForceOFF);
    }
    else if (hasParallelGroupForSpmuTask)
    {
      taskList.add(spForceON);

      if (hasParallelGroupForPpmuHvMeasure)
      {
        taskList.add(ppmuHvMeasure);
      }
      if (hasParallelGroupForBoardADCHvTask)
      {
        taskList.add(boardADCHvMeasure);
      }

      taskList.add(spMeasure)
              .add(spForceOFF);
    }
    else if (param.ppmuHasVoltageMeasure)
    {
      taskList.add(ppmuSettingStep1)
              .add(ppmuClampOn);

      if (hasParallelGroupForPpmuHvMeasure)
      {
        taskList.add(ppmuHvMeasure);
      }
      if (hasParallelGroupForBoardADCHvTask)
      {
        taskList.add(boardADCHvMeasure);
      }
    }
    else if (param.ppmuHasCurrentMeasure)
    {
      taskList.add(ppmuSettingStep1);

      if (hasParallelGroupForPpmuHvMeasure)
      {
        taskList.add(ppmuHvMeasure);
      }
      if (hasParallelGroupForBoardADCHvTask)
      {
        taskList.add(boardADCHvMeasure);
      }
    }
    else if (hasParallelGroupForPpmuHvMeasure || hasParallelGroupForBoardADCHvTask)
    {
      if (hasParallelGroupForPpmuHvMeasure)
      {
        taskList.add(ppmuHvMeasure);
      }
      if (hasParallelGroupForBoardADCHvTask)
      {
        taskList.add(boardADCHvMeasure);
      }
    }

    taskList.execute();
    ON_FIRST_INVOCATION_END();

    //HV tests are performed before non HV tests.
    if (param.ppmuHasCurrentMeasure)
    {
      GeneralPMUTestUtil::ppmuCurrentHvMeasurementUpdateTestResult(
          param.ppmuPinlistVec,
          param.ppmuIsCurrentMeasureVec,
          param.ppmuForceValueVec,
          param.ppmuPrechargeVec,
          param.ppmuPrechargeVoltageVec,
          param.ppmuSettlingTimeVec,
          param.ppmuMeasureModeVec,
          param.ppmuRelaySwitchModeVec,
          param.ppmuTerminationVec,
          param.ppmuLimitVec,
          param.ppmuExpandedPinsVec,
          param.testMode,
          ppmuHvMeasure,
          param.ppmuIsHvPinGroupVec,
          result.ppmuMeasureResultVec);
    }
    if (param.ppmuHasVoltageMeasure)
    {
      GeneralPMUTestUtil::ppmuVoltageHvMeasurementUpdateTestResult(
          param.ppmuPinlistVec,
          param.ppmuIsVoltageMeasureVec,
          param.ppmuForceValueVec,
          param.ppmuPrechargeVec,
          param.ppmuPrechargeVoltageVec,
          param.ppmuSettlingTimeVec,
          param.ppmuMeasureModeVec,
          param.ppmuRelaySwitchModeVec,
          param.ppmuTerminationVec,
          param.ppmuLimitVec,
          param.ppmuExpandedPinsVec,
          param.testMode,
          ppmuHvMeasure,
          param.ppmuIsHvPinGroupVec,
          result.ppmuMeasureResultVec);
    }

    //non HV tests
    if (param.mcxHasCurrentMeasure)
    {
      GeneralPMUTestUtil::mcxInstrumentCurrentMeasurement(
          param.mcxPinlistVec,
          param.mcxIsCurrentMeasureVec,
          param.mcxForceValueVec,
          param.mcxMeasureModeVec,
          param.mcxPrechargeVec,
          param.mcxPrechargeVoltageVec,
          param.mcxSettlingTimeVec,
          param.mcxTerminationVec,
          param.mcxLimitVec,
          param.mcxExpandedPinsVec,
          param.testMode,
          result.mcxMeasureResultVec);
    }
    if (param.mcxHasVoltageMeasure)
    {
      GeneralPMUTestUtil::mcxInstrumentVoltageMeasurement(
          param.mcxPinlistVec,
          param.mcxIsVoltageMeasureVec,
          param.mcxForceValueVec,
          param.mcxMeasureModeVec,
          param.mcxSettlingTimeVec,
          param.mcxTerminationVec,
          param.mcxLimitVec,
          param.mcxExpandedPinsVec,
          param.testMode,
          result.mcxMeasureResultVec);
    }
    
    if (param.ppmuHasCurrentMeasure)
    {
      GeneralPMUTestUtil::ppmuCurrentMeasurementUpdateTestResult(
          param.ppmuPinlistVec,
          param.ppmuIsCurrentMeasureVec,
          param.ppmuForceValueVec,
          param.ppmuPrechargeVec,
          param.ppmuPrechargeVoltageVec,
          param.ppmuSettlingTimeVec,
          param.ppmuMeasureModeVec,
          param.ppmuRelaySwitchModeVec,
          param.ppmuTerminationVec,
          param.ppmuLimitVec,
          param.ppmuExpandedPinsVec,
          param.testMode,
          ppmuMeasure,
          param.ppmuIsHvPinGroupVec,
          param.testerState,
          result.ppmuMeasureResultVec);
    }
    if (param.ppmuHasVoltageMeasure)
    {
      GeneralPMUTestUtil::ppmuVoltageMeasurementUpdateTestResult(
          param.ppmuPinlistVec,
          param.ppmuIsVoltageMeasureVec,
          param.ppmuForceValueVec,
          param.ppmuPrechargeVec,
          param.ppmuPrechargeVoltageVec,
          param.ppmuSettlingTimeVec,
          param.ppmuMeasureModeVec,
          param.ppmuRelaySwitchModeVec,
          param.ppmuTerminationVec,
          param.ppmuLimitVec,
          param.ppmuExpandedPinsVec,
          param.testMode,
          ppmuMeasure,
          param.ppmuIsHvPinGroupVec,
          param.testerState,
          result.ppmuMeasureResultVec);
    }

    if (param.spmuHasCurrentMeasure)
    {
      GeneralPMUTestUtil::spmuCurrentMeasurementUpdateTestResult(
          param.spmuPinlistVec,
          param.spmuIsCurrentMeasureVec,
          param.spmuForceValueVec,
          param.spmuMeasureModeVec,
          param.spmuClampValueVec,
          param.spmuPrechargeVec,
          param.spmuPrechargeVoltageVec,
          param.spmuSettlingTimeVec,
          param.spmuRelaySwitchModeVec,
          param.spmuTerminationVec,
          param.spmuLimitVec,
          param.spmuExpandedPinsVec,
          param.testMode,
          spMeasure,
          result.spmuMeasureResultVec);
    }
    if (param.spmuHasVoltageMeasure)
    {
      GeneralPMUTestUtil::spmuVoltageMeasurementUpdateTestResult(
          param.spmuPinlistVec,
          param.spmuIsVoltageMeasureVec,
          param.spmuForceValueVec,
          param.spmuMeasureModeVec,
          param.spmuClampValueVec,
          param.spmuPrechargeVec,
          param.spmuPrechargeVoltageVec,
          param.spmuSettlingTimeVec,
          param.spmuRelaySwitchModeVec,
          param.spmuTerminationVec,
          param.spmuLimitVec,
          param.spmuExpandedPinsVec,
          param.testMode,
          spMeasure,
          result.spmuMeasureResultVec);
    }

    if (param.dcScaleSIGHasCurrentMeasure)
    {
      GeneralPMUTestUtil::DCScaleSIGMeasurementCurrentUpdateTestResult(
          param.dcScaleSIGPinlistVec,
          param.dcScaleSIGIsCurrentMeasureVec,
          param.dcScaleSIGForceValueVec,
          param.dcScaleSIGMeasureModeVec,
          param.dcScaleSIGClampValueVec,
          param.dcScaleSIGPrechargeVec,
          param.dcScaleSIGPrechargeVoltageVec,
          param.dcScaleSIGSettlingTimeVec,
          param.dcScaleSIGRelaySwitchModeVec,
          param.dcScaleSIGLimitVec,
          param.dcScaleSIGExpandedPinsVec,
          param.testMode,
          spMeasure,
          result.dcScaleSIGMeasureResultVec);
    }
    if (param.dcScaleSIGHasVoltageMeasure)
    {
      GeneralPMUTestUtil::DCScaleSIGMeasurementVoltageUpdateTestResult(
          param.dcScaleSIGPinlistVec,
          param.dcScaleSIGIsVoltageMeasureVec,
          param.dcScaleSIGForceValueVec,
          param.dcScaleSIGMeasureModeVec,
          param.dcScaleSIGClampValueVec,
          param.dcScaleSIGPrechargeVec,
          param.dcScaleSIGPrechargeVoltageVec,
          param.dcScaleSIGSettlingTimeVec,
          param.dcScaleSIGRelaySwitchModeVec,
          param.dcScaleSIGLimitVec,
          param.dcScaleSIGExpandedPinsVec,
          param.testMode,
          spMeasure,
          result.dcScaleSIGMeasureResultVec);
    }

    if (param.boardADCHasVoltageMeasure)
    {
      GeneralPMUTestUtil::boardADCVoltageMeasurementUpdateTestResult(
          param.boardADCPinlistVec,
          param.boardADCIsVoltageMeasureVec,
          param.boardADCExpandedPinsVec,
          param.testMode,
          spMeasure,
          param.boardADCIsHvPinGroupVec,
          boardADCHvMeasure,
          result.boardADCMeasureResultVec);
    }

    ON_FIRST_INVOCATION_BEGIN();
    if (needSetSequencerOff)
    {
      FW_TASK("SQST OFF\n");
    }
    ON_FIRST_INVOCATION_END();
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: judgeAndDatalog
   *
   * Purpose: judge and put result into event datalog stream.
   *
   *----------------------------------------------------------------------*
   * Description:
   *   judge results of 'result' with pass limits from 'param'
   *
   *   INPUT:  param       - test parameters
   *           testLimit   - test limit container
   *           result      - result container
   *   OUTPUT:
   *   RETURN:
   * Note:
   *----------------------------------------------------------------------*
   */
  static void judgeAndDatalog(
      const GeneralPMUTestParam& param,
      const GeneralPMUTestResult& result)
  {
    bool hasBined = false;
    if ("YES" == param.ppmuUsed)
    {
      GeneralPMUJudgeAndLogUtil(
          param.ppmuIsCurrentMeasureVec,
          param.ppmuIsVoltageMeasureVec,
          param.ppmuPinlistVec,
          param.ppmuExpandedPinsVec,
          param.ppmuLimitVec,
          param.ppmuLimitNameVec,
          result.ppmuMeasureResultVec,
          param.testMode,
          param.testsuiteName,
          param.isPPMULimitAppliedForAllGroups,
          param.isLimitTableUsed,
          hasBined);
    }

    if ("YES" == param.spmuUsed)
    {
      GeneralPMUJudgeAndLogUtil(
          param.spmuIsCurrentMeasureVec,
          param.spmuIsVoltageMeasureVec,
          param.spmuPinlistVec,
          param.spmuExpandedPinsVec,
          param.spmuLimitVec,
          param.spmuLimitNameVec,
          result.spmuMeasureResultVec,
          param.testMode,
          param.testsuiteName,
          param.isSPMULimitAppliedForAllGroups,
          param.isLimitTableUsed,
          hasBined);
    }

    if ("YES" == param.mcxUsed)
    {
      GeneralPMUJudgeAndLogUtil(
          param.mcxIsCurrentMeasureVec,
          param.mcxIsVoltageMeasureVec,
          param.mcxPinlistVec,
          param.mcxExpandedPinsVec,
          param.mcxLimitVec,
          param.mcxLimitNameVec,
          result.mcxMeasureResultVec,
          param.testMode,
          param.testsuiteName,
          param.isMCXLimitAppliedForAllGroups,
          param.isLimitTableUsed,
          hasBined,
          true);
    }

    if ("YES" == param.dcScaleSIGUsed)
    {
      GeneralPMUJudgeAndLogUtil(
          param.dcScaleSIGIsCurrentMeasureVec,
          param.dcScaleSIGIsVoltageMeasureVec,
          param.dcScaleSIGPinlistVec,
          param.dcScaleSIGExpandedPinsVec,
          param.dcScaleSIGLimitVec,
          param.dcScaleSIGLimitNameVec,
          result.dcScaleSIGMeasureResultVec,
          param.testMode,
          param.testsuiteName,
          param.isDCScaleSIGLimitAppliedForAllGroups,
          param.isLimitTableUsed,
          hasBined);
    }

    if ("YES" == param.boardADCUsed)
    {
      vector<bool> isCurrentMeasureVec(param.boardADCIsVoltageMeasureVec.size());
      for(vector<string>::size_type i = 0;
          i < param.boardADCIsVoltageMeasureVec.size();
          ++i)
      {
        isCurrentMeasureVec[i] = false;
      }
      GeneralPMUJudgeAndLogUtil(
          isCurrentMeasureVec,
          param.boardADCIsVoltageMeasureVec,
          param.boardADCPinlistVec,
          param.boardADCExpandedPinsVec,
          param.boardADCLimitVec,
          param.boardADCLimitNameVec,
          result.boardADCMeasureResultVec,
          param.testMode,
          param.testsuiteName,
          param.isBoardADCLimitAppliedForAllGroups,
          param.isLimitTableUsed,
          hasBined);
    }

    if(param.checkFunctionalResult == "ON")
    {
      //Log functional result for whole test.
      TESTSET().cont(TM::CONTINUE)
               .judgeAndLog_ParametricTest(param.testsuiteName,
                                           "FUNCTIONAL TEST ",
                                           result.funcResult?TM::Pass:TM::Fail,
                                           0.0);
    }
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: reportToUI
   *
   * Purpose: output result to UIWindow
   *
   *----------------------------------------------------------------------*
   * Description:
   *   display:
   *       a) results from result,
   *       b) pass range from pass limits of param,
   *       c) pass or fail
   *
   *   INPUT:  param              - test parameters
   *           testLimit          - test limit container
   *           output             - "None" or "ReportUI"
   *           result             - result container
   *   OUTPUT:
   *   RETURN:
   * Note:
   *----------------------------------------------------------------------*
   */
  static void reportToUI(
      const GeneralPMUTestParam& param,
      const GeneralPMUTestResult& result,
      const STRING& output)
  {
    if ("ReportUI" != output)
    {
      return;
    }

    cout << "General PMU Test '" << param.testsuiteName << "'";
    cout << " Site: " << CURRENT_SITE_NUMBER() << endl;

    if ("YES" == param.ppmuUsed)
    {
      GeneralPMUReportToUIUtil(
          param.ppmuIsCurrentMeasureVec,
          param.ppmuIsVoltageMeasureVec,
          param.ppmuPinlistVec,
          param.ppmuExpandedPinsVec,
          param.ppmuLimitVec,
          result.ppmuMeasureResultVec,
          param.testMode,
          param.testsuiteName,
          output);
    }

    if ("YES" == param.spmuUsed)
    {
      GeneralPMUReportToUIUtil(
          param.spmuIsCurrentMeasureVec,
          param.spmuIsVoltageMeasureVec,
          param.spmuPinlistVec,
          param.spmuExpandedPinsVec,
          param.spmuLimitVec,
          result.spmuMeasureResultVec,
          param.testMode,
          param.testsuiteName,
          output);
    }

    if ("YES" == param.mcxUsed)
    {
      GeneralPMUReportToUIUtil(
          param.mcxIsCurrentMeasureVec,
          param.mcxIsVoltageMeasureVec,
          param.mcxPinlistVec,
          param.mcxExpandedPinsVec,
          param.mcxLimitVec,
          result.mcxMeasureResultVec,
          param.testMode,
          param.testsuiteName,
          output,
          true);
    }

    if ("YES" == param.dcScaleSIGUsed)
    {
      GeneralPMUReportToUIUtil(
          param.dcScaleSIGIsCurrentMeasureVec,
          param.dcScaleSIGIsVoltageMeasureVec,
          param.dcScaleSIGPinlistVec,
          param.dcScaleSIGExpandedPinsVec,
          param.dcScaleSIGLimitVec,
          result.dcScaleSIGMeasureResultVec,
          param.testMode,
          param.testsuiteName,
          output);
    }

    if ("YES" == param.boardADCUsed)
    {
      vector<bool> isCurrentMeasureVec(param.boardADCIsVoltageMeasureVec.size());
      for(vector<string>::size_type i = 0;
          i < param.boardADCIsVoltageMeasureVec.size();
          ++i)
      {
        isCurrentMeasureVec[i] = false;
      }

      GeneralPMUReportToUIUtil(
          isCurrentMeasureVec,
          param.boardADCIsVoltageMeasureVec,
          param.boardADCPinlistVec,
          param.boardADCExpandedPinsVec,
          param.boardADCLimitVec,
          result.boardADCMeasureResultVec,
          param.testMode,
          param.testsuiteName,
          output);
    }
  }

private:
  GeneralPMUTest()
  {
  }//private constructor to prevent instantiation.



  static void GeneralPMUJudgeAndLogUtil(
      const vector<bool> &isCurrentMeasuredVec,
      const vector<bool> &isVoltageMeasuredVec,
      const vector<string> &pinlistVec,
      const vector<vector<string> > &expandedPinsVec,
      const vector<LIMIT> &limitVec,
      const vector<string> &limitNameVec,
      const vector<MeasurementResultContainer> &resultVec,
      const TM::DCTEST_MODE& mode,
      const string& testsuiteName,
      const bool isLimitAppliedForAllGroups,
      const bool isLimitTableUsed,
      bool& hasBined,
      const bool isLegacyAPIUsed = false)
  {
    int siteNumber = 0;
    if(isLegacyAPIUsed)
    {
      siteNumber = CURRENT_SITE_NUMBER();
    }

    if(isLimitTableUsed) // use limit table
    {
      V93kLimits::TMLimits::LimitInfo limitInfo;
      if(!isLimitAppliedForAllGroups)
      {
        GeneralPMUTestUtil::judgeAndLogUtil(isCurrentMeasuredVec,
                                            isVoltageMeasuredVec,
                                            pinlistVec,
                                            expandedPinsVec,
                                            limitVec,
                                            limitNameVec,
                                            resultVec,
                                            mode,
                                            testsuiteName,
                                            true,
                                            siteNumber,
                                            hasBined);
      }
      else // one limit applied for all groups
      {
        GeneralPMUTestUtil::judgeAndLogUtilForAllGroups(isCurrentMeasuredVec,
                                                        isVoltageMeasuredVec,
                                                        pinlistVec,
                                                        expandedPinsVec,
                                                        limitVec,
                                                        limitNameVec,
                                                        resultVec,
                                                        mode,
                                                        testsuiteName,
                                                        true,
                                                        siteNumber,
                                                        hasBined);
      }
    }
    else // use testflow's limit
    {
      if(!isLimitAppliedForAllGroups)
      {
        GeneralPMUTestUtil::judgeAndLogUtil(isCurrentMeasuredVec,
                                            isVoltageMeasuredVec,
                                            pinlistVec,
                                            expandedPinsVec,
                                            limitVec,
                                            limitNameVec,
                                            resultVec,
                                            mode,
                                            testsuiteName,
                                            false,
                                            siteNumber,
                                            hasBined);
      }
      else // one limit applied for all groups
      {
        GeneralPMUTestUtil::judgeAndLogUtilForAllGroups(isCurrentMeasuredVec,
                                                        isVoltageMeasuredVec,
                                                        pinlistVec,
                                                        expandedPinsVec,
                                                        limitVec,
                                                        limitNameVec,
                                                        resultVec,
                                                        mode,
                                                        testsuiteName,
                                                        false,
                                                        siteNumber,
                                                        hasBined);
      }
    }
  }


  static void GeneralPMUReportToUIUtil(
      const vector<bool> &isCurrentMeasuredVec,
      const vector<bool> &isVoltageMeasuredVec,
      const vector<string> &pinlistVec,
      const vector<vector<string> > &expandedPinsVec,
      const vector<LIMIT> &limitVec,
      const vector<MeasurementResultContainer> &resultVec,
      const TM::DCTEST_MODE& mode,
      const string& testsuiteName,
      const string& output,
      const bool isLegacyAPIUsed = false)
  {
    if ("ReportUI" != output)
    {
      return;
    }
    vector<string>::size_type j = 0;
    bool bPass = true;

    int siteNumber = 0;
    if(isLegacyAPIUsed)
    {
      siteNumber = CURRENT_SITE_NUMBER();
    }

    for (string::size_type i = 0; i < expandedPinsVec.size(); i++)
    {
      if (isCurrentMeasuredVec[i])
      {
        //report measurement result to UI window
        switch (mode)
        {
        case TM::PVAL:
          for (j = 0; j < expandedPinsVec[i].size(); ++j)
          {
            double dMeasValue = resultVec[i].getPinsValue(expandedPinsVec[i][j],siteNumber);
            GeneralPMUTestUtil::datalogToWindow(
                expandedPinsVec[i][j],
                dMeasValue,
                limitVec[i],
                "uA");
          }
          break;

        case TM::PPF:
          for (j = 0; j < expandedPinsVec[i].size(); ++j)
          {
            bPass = resultVec[i].getPinPassFail(expandedPinsVec[i][j],siteNumber);
            GeneralPMUTestUtil::datalogToWindow(expandedPinsVec[i][j], bPass);
          }
          break;

        case TM::GPF:
          bPass = resultVec[i].getGlobalPassFail(siteNumber);
          GeneralPMUTestUtil::datalogToWindow(testsuiteName, bPass);
          break;

        default:
          throw Error("GeneralPMUTest::GeneralPMUReportToUIUtil",
                      "Unknown Test Mode",
                      "GeneralPMUTest::GeneralPMUReportToUIUtil");
        }// end switch
      }

      if (isVoltageMeasuredVec[i])
      {
        //report measurement result to UI window
        switch (mode)
        {
        case TM::PVAL:
          for (j = 0; j < expandedPinsVec[i].size(); ++j)
          {
            double dMeasValue = resultVec[i].getPinsValue(expandedPinsVec[i][j],siteNumber);
            GeneralPMUTestUtil::datalogToWindow(
                expandedPinsVec[i][j],
                dMeasValue,
                limitVec[i],
                "mV");
          }
          break;

        case TM::PPF:
          for (j = 0; j < expandedPinsVec[i].size(); ++j)
          {
            bPass = resultVec[i].getPinPassFail(expandedPinsVec[i][j],siteNumber);
            GeneralPMUTestUtil::datalogToWindow(expandedPinsVec[i][j], bPass);
          }
          break;

        case TM::GPF:
          bPass = resultVec[i].getGlobalPassFail(siteNumber);
          GeneralPMUTestUtil::datalogToWindow(testsuiteName, bPass);
          break;

        default:
          throw Error("GeneralPMUTest::GeneralPMUReportToUIUtil",
                      "Unknown Test Mode",
                      "GeneralPMUTest::GeneralPMUReportToUIUtil");
        }// end switch
      }
    }
  }

};

#endif /*GENERALPMUTEST_H_*/
