#ifndef PRODUCTIONIDDQUTIL_H_
#define PRODUCTIONIDDQUTIL_H_

#include "ProductionIddqTestUtil.hpp"

typedef ProductionIddqTestUtil::MeasurementResultContainer MeasurementResultContainer;
typedef ProductionIddqTestUtil::ProductionIddqTestResult ProductionIddqTestResult;

/***************************************************************************
 *                    productionIddq test class 
 ***************************************************************************
 */  
class ProductionIddqTest
{
public:

/*
 *----------------------------------------------------------------------*
 *         test parameters container                                    *
 *----------------------------------------------------------------------*
 */ 
  struct ProductionIddqTestParam
  {
    // original input parameters
    vector<string> dpsPinsVec;
    vector<string> disconnectPinsVec;
    vector<double> settlingTimeVec;
    vector<int>    samplesVec;
    vector<string> gangedModeVec;
    vector<LIMIT>  limitVec;
    vector<string> limitNameVec;
    string stopMode;
    string strStopVecCycNum;
    string checkFunctional;

    // new generated parameter for convenience
    vector<vector<string> > expandedDpsPinsVec; // expanded and validated pins stored in Vector
    
    vector<bool> isMeasuredVec;
    
    TM::DCTEST_MODE testMode;
    string testsuiteName;        // current testsuite name
    vector<int> vectorOrCycleNumberToStopSequnecer;// integer vector of stop vector/cycle number
    string portName;
    bool isDisconnectPinsForAllGroups;
    bool isLimitTableUsed;
    bool isLimitAppliedForAllGroups;

    // initialize stuff to some defaults.
    void init()
    {
      dpsPinsVec.clear();
      disconnectPinsVec.clear();
      settlingTimeVec.clear();
      samplesVec.clear();
      gangedModeVec.clear();
      limitVec.clear();
      limitNameVec.clear();
      expandedDpsPinsVec.clear();
      isMeasuredVec.clear();
      vectorOrCycleNumberToStopSequnecer.clear();
      isDisconnectPinsForAllGroups = false;
      isLimitTableUsed = false;
      isLimitAppliedForAllGroups = false;

      stopMode = "UNKNOWN";
      testMode = TM::GPF;
    }

    // default constructor for intializing parameters
    ProductionIddqTestParam()
    {
      init();
    }
  };
  

/*
 *----------------------------------------------------------------------*
 *         public interfaces of production iddq test                    *
 *----------------------------------------------------------------------*
 */

/*
 *----------------------------------------------------------------------*
 * Routine: processParameter
 *
 * Purpose: parse input parameters and setup internal parameters
 *
 *----------------------------------------------------------------------*
 * Description:
 *   
 * Note:
 *----------------------------------------------------------------------*
 */
  static void processParameters(const string& dpsPins,
                                const string& disconnectPins,
                                const string& settlingTime_ms,
                                const string& samples,
                                const string& gandedMode,
                                const string& testName,
                                const string& stopMode,
                                const string& strStopVecCycNum,
                                const string& checkFunctional,
                                ProductionIddqTestParam& param)
  {
    // init parameters
    param.init();

    param.testMode = ProductionIddqTestUtil::getMode();
    GET_TESTSUITE_NAME(param.testsuiteName);

    /**
     *this map is used to store the relationship: pin group instrument
     * map< string, string>
     *        |         |
     *        |         |
     *     pinName   groupName
     *
     * we use this map to check that whether there are the same pin exist
     * in different groups or not.
     */
    map<string, string> pinAndGroupMap;

    // check whether limit table is used.
    TesttableLimitHelper testtableHelper(param.testsuiteName);

    vector<string> testNameVec;

    ProductionIddqTestUtil::parseListOfString(dpsPins,param.dpsPinsVec);
    ProductionIddqTestUtil::parseListOfString(disconnectPins,param.disconnectPinsVec);
    ProductionIddqTestUtil::parseListOfDouble(settlingTime_ms,param.settlingTimeVec);
    ProductionIddqTestUtil::parseListOfInt(samples,param.samplesVec);
    ProductionIddqTestUtil::parseListOfString(gandedMode,param.gangedModeVec);
    ProductionIddqTestUtil::parseListOfString(testName,testNameVec);


    vector<string>::size_type groupSize = param.dpsPinsVec.size();
    if(groupSize == 0)
    {
      throw Error("ProductionIddqTest::processParameters()",
                  "the dpsPins groups can not be empty.",
                  "ProductionIddqTest::processParameters()");
    }

    if(groupSize != param.disconnectPinsVec.size())
    {
      // support disconnect pins are empty
      if(param.disconnectPinsVec.size() != 1 &&
         param.disconnectPinsVec.size() != 0)
      {
        stringstream errMsg;
        errMsg <<"the number of pinlist groups is " << groupSize <<endl
               <<"the number of disconnectPins groups is "
               << param.disconnectPinsVec.size() <<endl
               <<"So the disconnectPins groups don't match pinlist groups." <<endl;
        throw Error("ProductionIddqTest::processParameters()",
                    errMsg.str(),
                    "ProductionIddqTest::processParameters()");
      }
      else
      {
        param.isDisconnectPinsForAllGroups = true;
        if(param.disconnectPinsVec.size() == 0)
        {
          param.disconnectPinsVec.push_back("");
        }
      }
    }

    ProductionIddqTestUtil::checkParameter(groupSize,
                                           param.settlingTimeVec.size(),
                                           "settlingTime_ms",
                                           param.settlingTimeVec);
    ProductionIddqTestUtil::checkParameter(groupSize,
                                           param.samplesVec.size(),
                                           "samples",
                                           param.samplesVec);
    ProductionIddqTestUtil::checkParameter(groupSize,
                                           param.gangedModeVec.size(),
                                           "gangedMode",
                                           param.gangedModeVec);

    if(param.dpsPinsVec.size() != testNameVec.size())
    {
      if(testNameVec.size() != 1)
      {
        stringstream errMsg;
        errMsg <<"the number of pinlist groups is "
               << param.dpsPinsVec.size() <<endl
               <<"the number of testName groups is "
               <<testNameVec.size() <<endl
               <<"So the testName groups don't match pinlist groups." <<endl;
        throw Error("ProductionIddqTest::processParameters()",
                    errMsg.str(),
                    "ProductionIddqTest::processParameters()");
      }
      else
      {
        param.isLimitAppliedForAllGroups = true;
        for(vector<string>::size_type i = 1; i < param.dpsPinsVec.size(); i++)
        {
          testNameVec.push_back(testNameVec[0]);
        }
      }
    }

    /*
     *********************************************************
     * Validate disconnectPins if it's not empty,
     * and meanwhile it detects DC pins,
     * if any DC pins exist, it throws an error.
     *********************************************************
     */
    if(param.isDisconnectPinsForAllGroups && !param.disconnectPinsVec[0].empty())
    {
      PinUtility.getDigitalPinNamesFromPinList(param.disconnectPinsVec[0],
                                               TM::I_PIN|TM::O_PIN|TM::IO_PIN,
                                               true, // check missing pins
                                               true  // check mismatched-type pins
                                               );
    }

    pair<map<string, string>::iterator, bool> ret;
    for(vector<string>::size_type i = 0; i < param.dpsPinsVec.size(); i++)
    {
      vector<string> expandedPins;
      bool isThisGroupNotCommented = ('#' != param.dpsPinsVec[i][0]);
      if(isThisGroupNotCommented)
      {
        expandedPins = PinUtility.getDpsPinNamesFromPinList(param.dpsPinsVec[i],true);
        // check the duplicate pins
        for (vector<string>::size_type index = 0; index < expandedPins.size(); index++)
        {
          ret = pinAndGroupMap.insert(make_pair(expandedPins[index], param.dpsPinsVec[i]));
          if (!ret.second)
          {
            stringstream errMsg;
            errMsg << "In the group: " << param.dpsPinsVec[i]<< endl
                   << "   and the group: " << ret.first->second << endl
                   << "There are the same pin: "
                   << expandedPins[index] << endl;
            throw Error("ProductionIddqTest::processParameters",
                        errMsg.str(),
                        "ProductionIddqTest::processParameters");
          }
        }
      }
      param.expandedDpsPinsVec.push_back(expandedPins);

      if(isThisGroupNotCommented)
      {
        /*
         *********************************************************
         * Validate disconnectPins if it's not empty,
         * and meanwhile it detects DC pins,
         * if any DC pins exist, it throws an error.
         *********************************************************
         */
        if (!param.isDisconnectPinsForAllGroups && !param.disconnectPinsVec[i].empty() )
        {
          PinUtility.getDigitalPinNamesFromPinList(param.disconnectPinsVec[i],
                                                   TM::I_PIN|TM::O_PIN|TM::IO_PIN,
                                                   true, // check missing pins
                                                   true  // check mismatched-type pins
                                                   );
        }

        if("ON" != param.gangedModeVec[i] &&
           "OFF" != param.gangedModeVec[i])
        {
          stringstream errMsg;
          errMsg <<"For the " << i+1 << " group setup parameter, gangedMode: "
                 <<param.gangedModeVec[i] << " is invalid."<<endl
                 <<"gangedMode can only be the following options: ON  OFF" <<endl;
          throw Error("ProductionIddqTest::processParamters()",
                      errMsg.str(),
                      "ProductionIddqTest::processParamters()");
        }

        if(param.settlingTimeVec[i] < 0.0)
        {
          stringstream errMsg;
          errMsg <<"For the " << i+1 << " group setup parameter, settlingTime: "
                 <<param.settlingTimeVec[i] << " is invalid."<<endl
                 <<"settlingTime must be postive!" <<endl;
          throw Error("ProductionIddqTest::processParamters()",
                      errMsg.str(),
                      "ProductionIddqTest::processParamters()");
        }

        LIMIT limit;
        param.limitNameVec.push_back(testNameVec[i]);

        ProductionIddqTestUtil::getLimitInfo(testNameVec[i],i,
                                             limit,
                                             testtableHelper);
        param.limitVec.push_back(limit);
        param.isMeasuredVec.push_back(true);
      }
      else
      {
        LIMIT limit;
        param.limitVec.push_back(limit);
        if(0 == i)
        {
          param.limitNameVec.push_back(testNameVec[i]);

          ProductionIddqTestUtil::getLimitInfo(testNameVec[i],i,
                                               limit,
                                               testtableHelper);
        }
        param.limitVec.push_back(limit);
        param.isMeasuredVec.push_back(false);
      }

    }
     
    param.checkFunctional = ProductionIddqTestUtil::trim(checkFunctional);
    param.isLimitTableUsed = testtableHelper.isAllInTable();

    /*
     * Convert string of stop number into integer array.
     */

    param.stopMode = ProductionIddqTestUtil::trim(stopMode);
    string strStopVecCycNumber = ProductionIddqTestUtil::trim(strStopVecCycNum);
    string portData;
    if(strStopVecCycNumber.empty())
    {
      if (param.stopMode != "NO")
      {
        /*
         * If input of vector/cycle number is empty, change the stopMode
         * to "ALL" in order to run to end of the label.
         */
        param.stopMode = "ALL";
      }
      param.vectorOrCycleNumberToStopSequnecer.push_back(0);
    }
    else
    {
      ProductionIddqTestUtil::splitPortDataAndPortName(strStopVecCycNumber,portData,param.portName,false);
      ProductionIddqTestUtil::parseListOfInt(portData,param.vectorOrCycleNumberToStopSequnecer,',');
    }
  }  
  

/*
 *----------------------------------------------------------------------*
 * Routine: doMeasurement
 *
 * Purpose: execute measurement by DPS and store results
 *
 *----------------------------------------------------------------------*
 * Description:
 *   INPUT:  param       - test parameters
 *           result      - result container
 *
 *   OUTPUT: 
 *   RETURN: 
 *----------------------------------------------------------------------*
 */
  static void doMeasurement(const ProductionIddqTestParam& param, 
                            ProductionIddqTestResult& result)
  {
    int stopNumSize = param.vectorOrCycleNumberToStopSequnecer.size();
    
    // init result
    result.init();
    result.dpsResultVec.resize(stopNumSize);
    result.funcResultVec.resize(stopNumSize);

    ON_FIRST_INVOCATION_BEGIN();

      // firstly try to connect
      CONNECT();
    ON_FIRST_INVOCATION_END();


    if(param.isDisconnectPinsForAllGroups)
    {
      DPS_TASK dpsTask;

      ON_FIRST_INVOCATION_BEGIN();
        // setup dpsTask
        ProductionIddqTestUtil::dpsInstrumentCurrentMeasurementSetupForMultiGroup(
            param.dpsPinsVec,
            param.isMeasuredVec,
            param.settlingTimeVec,
            param.samplesVec,
            param.gangedModeVec,
            param.limitVec,
            param.testMode,
            dpsTask);
      ON_FIRST_INVOCATION_END();

      /**
       * Do Measurements:
       * Measure the current at different specified vector or cycle.
       */
      for (int index = 0; index < stopNumSize; ++index )
      {
        ON_FIRST_INVOCATION_BEGIN();
          // set sequencer's stop mode and run functional test
          ProductionIddqTestUtil::functionalPreTest(
              param.stopMode,
              param.vectorOrCycleNumberToStopSequnecer[index],
              param.portName);
        ON_FIRST_INVOCATION_END();
        // check functional test result
        if ("ON" == param.checkFunctional)
        {
          result.funcResultVec[index] = GET_FUNCTIONAL_RESULT();
        }
  
        ON_FIRST_INVOCATION_BEGIN();
          // disconnect pins before measurement, if any
          ProductionIddqTestUtil::disconnectPins(param.disconnectPinsVec[0]);

          // do current measurement using dps task
          dpsTask.execute();
        ON_FIRST_INVOCATION_END();

        // get measurement results
        ProductionIddqTestUtil::dpsMeasurementCurrentGetResultForMultiGroup(
            param.dpsPinsVec,
            param.isMeasuredVec,
            param.gangedModeVec,
            param.expandedDpsPinsVec,
            param.testMode,
            dpsTask,
            result.dpsResultVec[index]);
        ON_FIRST_INVOCATION_BEGIN();
          ProductionIddqTestUtil::connectPins(param.disconnectPinsVec[0]);
        ON_FIRST_INVOCATION_END() ;
      }
    }
    else
    {
      for(vector<string>::size_type i = 0; i < param.disconnectPinsVec.size(); i++)
      {
        if(!param.isMeasuredVec[i])
        {
          continue;
        }
        DPS_TASK dpsTask;
        ON_FIRST_INVOCATION_BEGIN();
          // setup dpsTask
          ProductionIddqTestUtil::dpsInstrumentCurrentMeasurementSetup(
              param.dpsPinsVec[i],
              param.settlingTimeVec[i],
              param.samplesVec[i],
              param.gangedModeVec[i],
              param.limitVec[i],
              param.testMode,
              dpsTask);
        ON_FIRST_INVOCATION_END();

        /**
         * Do Measurements:
         * Measure the current at different specified vector or cycle.
         */
        for (int index = 0; index < stopNumSize; ++index )
        {
          ON_FIRST_INVOCATION_BEGIN();
            // set sequencer's stop mode and run functional test
            ProductionIddqTestUtil::functionalPreTest(
                param.stopMode,
                param.vectorOrCycleNumberToStopSequnecer[index],
                param.portName);
          ON_FIRST_INVOCATION_END();
          // check functional test result
          if ("ON" == param.checkFunctional)
          {
            result.funcResultVec[index] = GET_FUNCTIONAL_RESULT();
          }

          ON_FIRST_INVOCATION_BEGIN();
            // disconnect pins before measurement, if any
            ProductionIddqTestUtil::disconnectPins(param.disconnectPinsVec[i]);

            // do current measurement using dps task
            dpsTask.execute();
          ON_FIRST_INVOCATION_END();

          // get measurement results
          vector<MeasurementResultContainer> &resultVec = result.dpsResultVec[index];
          MeasurementResultContainer everyGroupResult;
          if(resultVec.size() <= i)
          {
            everyGroupResult.init();
            resultVec.push_back(everyGroupResult);
          }
          ProductionIddqTestUtil::dpsMeasurementCurrentGetResult(
              param.expandedDpsPinsVec[i],
              param.testMode,
              dpsTask,
              resultVec[i],
              param.gangedModeVec[i]);
          ON_FIRST_INVOCATION_BEGIN();
            ProductionIddqTestUtil::connectPins(param.disconnectPinsVec[i]);
          ON_FIRST_INVOCATION_END() ;
        }
      }
    }
    
    if("ToStopVEC" == param.stopMode || "ToStopCYC" == param.stopMode)
    {
      ON_FIRST_INVOCATION_BEGIN();
        Sequencer.reset();
      ON_FIRST_INVOCATION_END();
    }
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: judgeAndDatalog
   *
   * Purpose: judge and put result into event datalog stream.
   *
   *----------------------------------------------------------------------*
   * Description:
   *   judge results of 'result' with 'testLimit' from 'param'
   *
   *   INPUT:  param       - test parameters
   *           result      - result container
   *   OUTPUT:
   *   RETURN:
   * Note:
   *----------------------------------------------------------------------*
   */
    static void judgeAndDatalog(const ProductionIddqTestParam& param,
                                const ProductionIddqTestResult& result)
    {
      bool hasBined = false;
      bool isCheckFunctional = (param.checkFunctional == "ON");

      if (param.isLimitTableUsed) // use limit table
      {
        if(!param.isLimitAppliedForAllGroups)
        {
          ProductionIddqTestUtil::judgeAndLogUtil(param.isMeasuredVec,
                                                  param.dpsPinsVec,
                                                  param.expandedDpsPinsVec,
                                                  param.gangedModeVec,
                                                  param.vectorOrCycleNumberToStopSequnecer,
                                                  param.limitVec,
                                                  param.limitNameVec,
                                                  result,
                                                  param.testMode,
                                                  param.testsuiteName,
                                                  true,
                                                  isCheckFunctional,
                                                  hasBined);
        }
        else  // one limit is applied for all groups
        {
          ProductionIddqTestUtil::judgeAndLogUtilForAllGroups(
                                                  param.isMeasuredVec,
                                                  param.dpsPinsVec,
                                                  param.expandedDpsPinsVec,
                                                  param.gangedModeVec,
                                                  param.vectorOrCycleNumberToStopSequnecer,
                                                  param.limitVec,
                                                  param.limitNameVec,
                                                  result,
                                                  param.testMode,
                                                  param.testsuiteName,
                                                  true,
                                                  isCheckFunctional,
                                                  hasBined);
        }
      }
      else // use testflow's limit
      {
        if(!param.isLimitAppliedForAllGroups)
        {
          ProductionIddqTestUtil::judgeAndLogUtil(param.isMeasuredVec,
                                                  param.dpsPinsVec,
                                                  param.expandedDpsPinsVec,
                                                  param.gangedModeVec,
                                                  param.vectorOrCycleNumberToStopSequnecer,
                                                  param.limitVec,
                                                  param.limitNameVec,
                                                  result,
                                                  param.testMode,
                                                  param.testsuiteName,
                                                  false,
                                                  isCheckFunctional,
                                                  hasBined);
        }
        else  // one limit is applied for all groups
        {
          ProductionIddqTestUtil::judgeAndLogUtilForAllGroups(
                                                  param.isMeasuredVec,
                                                  param.dpsPinsVec,
                                                  param.expandedDpsPinsVec,
                                                  param.gangedModeVec,
                                                  param.vectorOrCycleNumberToStopSequnecer,
                                                  param.limitVec,
                                                  param.limitNameVec,
                                                  result,
                                                  param.testMode,
                                                  param.testsuiteName,
                                                  false,
                                                  isCheckFunctional,
                                                  hasBined);
        }
      }

    }


/*
 *----------------------------------------------------------------------*
 * Routine: reportToUI
 *
 * Purpose: output result to UIWindow 
 *
 *----------------------------------------------------------------------*
 * Description:
 *   display: 
 *       a) results from result,
 *       b) pass range from pass limit of testLimit,
 *       c) pass or fail
 * 
 *   INPUT:  param              - test parameters
 *           result             - result container
 *            output             - "None" or "ReportUI" 
 *   OUTPUT: 
 *   RETURN:  
 * Note:
 *----------------------------------------------------------------------*
 */ 
  static void reportToUI(const ProductionIddqTestParam& param, 
                         const ProductionIddqTestResult& result, 
                         const STRING& output)
  {
    if("ReportUI" != output)
    {
      return;
    }
    int  stopNumSize = param.vectorOrCycleNumberToStopSequnecer.size();
    bool isPass = true;
    double dVal = 0.0;
    double dSumVal = 0.0;
    vector<string>::const_iterator it;
    int nSiteNumber = CURRENT_SITE_NUMBER();

    for ( int index = 0; index < stopNumSize; ++index )
    {
      cout << "production Iddq current '" << param.testsuiteName << "'";
      cout << " Site: " << nSiteNumber << endl;

      vector<MeasurementResultContainer> resultVec = result.dpsResultVec[index];
      for(vector<string>::size_type i = 0; i < param.dpsPinsVec.size(); i++)
      {
        if(!param.isMeasuredVec[i])
        {
          continue;
        }
        dSumVal = 0.0;

        if ( "ON" == param.gangedModeVec[i])
        {
          // for gang mode case
          for ( it = param.expandedDpsPinsVec[i].begin();
                it != param.expandedDpsPinsVec[i].end();
                it++ )
          {
            dSumVal += resultVec[i].getPinsValue((*it));
          }

          switch ( param.testMode )
          {
          case TM::PVAL:
            ProductionIddqTestUtil::datalogToWindow(
                                        "sum of " + param.dpsPinsVec[i],
                                        dSumVal,
                                        param.limitVec[i]);
            break;

          case TM::PPF:
            isPass = param.limitVec[i].pass(dSumVal);
            // judge the sum of current if pass or fail in gang mode
            for ( it = param.expandedDpsPinsVec[i].begin();
                  it != param.expandedDpsPinsVec[i].end();
                  it++ )
            {

              ProductionIddqTestUtil::datalogToWindow(*it, isPass);
            }
            break;

          case TM::GPF:
            isPass = param.limitVec[i].pass(dSumVal);
            ProductionIddqTestUtil::datalogToWindow(param.testsuiteName, isPass);
            break;

          default:
            throw Error("ProductionIddqTest::reportToUI" ,
                        "Unknown Measure Mode",
                        "ProductionIddqTest::reportToUI");
          }
        }
        else
        {
          // for ungang mode
          switch ( param.testMode )
          {
          case TM::PVAL:
            for ( it = param.expandedDpsPinsVec[i].begin();
                  it != param.expandedDpsPinsVec[i].end();
                  it++ )
            {
              dVal = resultVec[i].getPinsValue((*it));
              ProductionIddqTestUtil::datalogToWindow(
                                          *it,
                                          dVal,
                                          param.limitVec[i]);
            }
            break;
          case TM::PPF:
            for ( vector<string>::size_type iPin = 0;
                  iPin < param.expandedDpsPinsVec[i].size();
                  iPin++)
            {
              const string& pin = param.expandedDpsPinsVec[i][iPin];
              isPass = resultVec[i].getPinPassFail(pin);
              ProductionIddqTestUtil::datalogToWindow( pin, isPass );
            }
            break;
          case TM::GPF:
            isPass = resultVec[i].getGlobalPassFail();
            ProductionIddqTestUtil::datalogToWindow(param.testsuiteName, isPass);
            break;
          default:
            throw Error("ProductionIddqTest::reportToUI",
                        "Unknown Measure Mode",
                        "ProductionIddqTest::reportToUI");
          }  // end of switch
        } // end of if-else
      }
      if ( param.checkFunctional == "ON" )
      {
        ProductionIddqTestUtil::datalogToWindow("Functional result: ", result.funcResultVec[index]);
      }
    } 
  }
private:
  ProductionIddqTest() {}  //private constructor to prevent instantiation.

};                              

#endif /*PRODUCTIONIDDQTEST_H_*/
