/**
 * (c) Copyright 2011, Verigy Technologies, all rights reserved.
 *
 * Modification History:
 *
 *
 */

//for testmethod framework interfaces
#include "testmethod.hpp"
//for testmethod API interfaces
#include "mapi.hpp"

#include "ProductionIddqTest.hpp"

/**
 *----------------------------------------------------------------------*
 * @testmethod class: ProductionIddq()
 *
 * @Purpose: production Iddq current
 *----------------------------------------------------------------------*
 * @Description: test method program for production Iddq current 
 *              by utilizing DPS_TASK API
 *
 * @Input Parameters:
 *   string  dpsPins         : {@ | DPS pin}  
 *     DPS pin(s).
 *   string  disconnectPins  : {@ | Digital Pins} 
 *     any pins need to be disconnected(AC relays opened) 
 *     from tester before the measurement.
 *   string  settlingTime     : {ms}
 *     the time will be in addition to the settling time 
 *     calculated by the system. base unit is ms.
 *     after the settling time, the current is measured.
 *   string  samples
 *     The samples for DPS measurement, default is 16.
 *     This must be positive integer.
 *   string  gangedMode      : {ON | OFF}
 *     the sum of all Iddq currents of dpsPins will be given back,
 *     OFF is for each pin's Iddq current.
 *   string  testName   
 *     Name of limit(s).
 *
 *   string  stopMode        : {ToStopVec | ToStopCyc}  
 *     the sequencer to stop at a specific vector or cycle.
 *   string  strStopVecCycNum:
 *     the specified number where the sequencer has to stop.
 *     if specify more than one number, use commas to separated them.
 *   string  checkFunctional : {ON | OFF} 
 *     the functional test shall contribute to 
 *     the overall test result, 
 *     OFF is for not.
 *   string  output          : {NONE | ReportUI} 
 *     Print message or not.
 *     ReportUI - for debug mode
 *     None - for production mode
 * 
 * @Note:
 * 
 *----------------------------------------------------------------------*
 */

class ProductionIddq: public testmethod::TestMethod
{
protected:
  // multi-group parameter
  string  dpsPins;
  string  disconnectPins;
  string  settlingTime_ms;
  string  samples;
  string  gangedMode;
  string  testName;

  // common parameter
  string  stopMode;
  string  strStopVecCycNum;
  string  checkFunctional;
  string  output;

  bool isParameterChanged;

  // Assume all sites' parameters are the same
  ProductionIddqTest::ProductionIddqTestParam param;

protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    addParameter("dpsPins",
                 "PinString",
                 &dpsPins)
      .setDefault("Vee")
      .setComment("dps pins or dcScale pins in DPS mode  for measurement");
    addParameter("disconnectPins",
                 "PinString",
                 &disconnectPins)
      .setComment("pins disconnected before measurement.");
    addParameter("settlingTime_ms",
                 "string",
                 &settlingTime_ms)
      .setDefault("0")
      .setComment("extra settling time, e.g. 1[ms]");
    addParameter("samples",
                 "string",
                 &samples)
      .setDefault("16")
      .setComment("The number of measurement to be averaged");
    addParameter("gangedMode",
                 "string",
                 &gangedMode)
      .setDefault("OFF")
      .setComment("sum of all Iddq currents of dps pins\n"
                  "There are two options: ON  OFF");
    addParameter("testName",
                 "string",
                 &testName)
      .setComment("Name of limit(s).");
    addParameter("stopMode",
                 "string",
                 &stopMode)
      .setDefault("ToStopVEC")
      .setOptions("ToStopVEC:ToStopCYC:NO:ALL")
      .setComment("stop sequencer at vector or cycle\n");
    addParameter("strStopVecCycNum",
                 "string",
                 &strStopVecCycNum)
      .setComment("the number of vector or cycle \n"
                  "When parameter stopMode select ToStopCYC, support multi-port. \n"
                  "For single port pattern, the format of input value is like:12,15 \n"
                  "For multi-port pattern, the format is like 12,15@portName.\n"
                  "When select ToStopVEC, don't support multi-port \n"
                  "the format of input value like: 12,15");
    addParameter("checkFunctional",
                 "string",
                 &checkFunctional)
      .setDefault("ON")
      .setOptions("ON:OFF")
      .setComment("determine whether the functional test result \n"
                  "shall contribute to the overall test result");
    addParameter("output",
                 "string",
                 &output)
      .setDefault("None")
      .setOptions("ReportUI:None")
      .setComment("print information on UI report window");

    isParameterChanged = true;
  }
  
  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
    ProductionIddqTestUtil::ProductionIddqTestResult result;
     
    ON_FIRST_INVOCATION_BEGIN(); 
      /*
       * Process all parameters needed in test. Actually this function is
       * called once under multisite because all input parameters should be
       * the same through all sites. The processed parameters are stored into
       * the static variable 'param' for later reference on all sites.
       */   
      if(isParameterChanged)
      {
        ProductionIddqTest::processParameters(dpsPins,
                                              disconnectPins,
                                              settlingTime_ms,
                                              samples,
                                              gangedMode,
                                              testName,
                                              stopMode,
                                              strStopVecCycNum,
                                              checkFunctional,
                                              param);
        isParameterChanged = false;
      }
    ON_FIRST_INVOCATION_END();
    
    /*
     * Execute measurement with the specified 'param' and store results 
     * into the 'result'. The multisite handling, i.e.
     * ON_FIRST_INVOCATION block are executed inside this function.
     */
    ProductionIddqTest::doMeasurement(param,result);
    /*
     * Judge and datalog based on the 'result'. This function uses
     * testsuite name as test name, so if you'd like to use your own
     * test names for judgement and datalogging it's needed to modify
     * this funciton or create new one.
     */
    ProductionIddqTest::judgeAndDatalog(param,result);
    /*
     * Output contents of the 'result' to Report Window if specified by
     * the "output" parameter.
     */
    ProductionIddqTest::reportToUI(param,result,output);
    return ;
  }
  
  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   *
   *Note: TestMethod API should not be used in this method.
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    isParameterChanged = true;


    if("stopMode" == parameterIdentifier)
    {
      bool toVisible = true;
      if("NO" == stopMode)
      {
        toVisible = false;
        getParameter("checkFunctional").setValid("ON" != checkFunctional);
      }
      else if("ALL" == stopMode)
      {
        toVisible = false;
      }
      getParameter("strStopVecCycNum").setVisible(toVisible);
    }
    else
    {
      if("NO" == stopMode)
      {
        getParameter("checkFunctional").setValid("ON" != checkFunctional);
      }
      else
      {
        getParameter("checkFunctional").setValid(true);
      }
    }
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string  getComment() const
  {
     static string comment = "version: tml_7.1.2_2.1.4";
     return comment;
  }
};

REGISTER_TESTMETHOD("DcTest.ProductionIddq", ProductionIddq);
