#ifndef CONTINUITYUTIL_H_
#define CONTINUITYUTIL_H_

#include "testmethod.hpp"

/**
 * try to get all required test names from test table
 * record valid test name and invalid test name
 */
class TesttableLimitHelper
{
  private:
    std::vector<std::string> mTestnameNotInTable;
    std::vector<std::string> mTestnameInTable;
    std::string mTestsuiteName;
    bool mIsLimitCsvFileLoad;
  public:
    explicit TesttableLimitHelper(const string& testsuitename)
      :mTestsuiteName(testsuitename),mIsLimitCsvFileLoad(false)
    {
      TestTable* pLimitTable = TestTable::getDefaultInstance();
      pLimitTable->readCsvFile();
      mIsLimitCsvFileLoad = pLimitTable->isTmLimitsCsvFile();

      mTestnameNotInTable.clear();
      mTestnameInTable.clear();
    }

    ~TesttableLimitHelper()
    {
    }

    const std::vector<std::string>& getInvalidTestnames()
    {
      return mTestnameNotInTable;
    }

    const std::vector<std::string>& getValidTestnames()
    {
      return mTestnameInTable;
    }

    //return if all test names are valid in CSV file
    const bool isAllInTable()
    {
      return (mIsLimitCsvFileLoad &&
              !mTestnameInTable.empty() &&
              mTestnameNotInTable.empty());
    }

    const bool isLimitCsvFileLoad()
    {
      return mIsLimitCsvFileLoad;
    }

    /**
     * for the current testsuite, the method try to get the limit object from test table
     * by the specified test name (i.e. name for limit).
     * @param:
     *    testname: the specific test name defined for the testsuite
     *    toLimit: the target limit object defined in test table
     * @note:
     *   1) if the test name is defined in test table,
     *      the target limit object is got from table;
     *      otherwise, the limit object is untouched as it is.
     *   2) exceptional case:
     *      a) if the csv file is not loaded, exception is thrown.
     *
     *      b) if there are multiple limits needed for this testsuite,
     *      and only if some testname are valid but others are NOT valid,
     *      one exception is thrown out!
     */
    void getLimit(const std::string& testname, LIMIT& toLimit)throw(Error)
    {
      if (!mIsLimitCsvFileLoad)
      {
        throw Error("TesttableLimitHelper",
          "no limit CSV file is loaded!",
          "TesttableLimitHelper");
      }

      try
      {
        V93kLimits::TMLimits::LimitInfo& limitInfo =
          V93kLimits::tmLimits.getLimit(mTestsuiteName,testname);

        toLimit = limitInfo.TEST_API_LIMIT;
        mTestnameInTable.push_back(testname);
      }
      catch (Error& e)
      {
        mTestnameNotInTable.push_back(testname);
      }

      //confiliction: some limits are valid but others are not
      if (!mTestnameInTable.empty() && !mTestnameNotInTable.empty())
      {
        throw Error("TesttableLimitHelper",
          "[testsuite: \""+mTestsuiteName+"\"]: test name \""+testname
          +"\" is not found in test table!");
      }
    }
}; //class TesttableLimitHelper

/***************************************************************************
 *                    continuity test class
 ***************************************************************************
 */
class ContinuityTestUtil
{
public:
  /*
   *---------------------------------------------------------------------*
   *MeasurementResultContainer:
   *  This class is used to hold and output
   *  global or per pin result: pass/fail, values.
   *---------------------------------------------------------------------*
   *  Notes:
   *  If the results of all sites are cached in Testmethod, not in
   *  TestmethodAPI, this class can store results for each specific site.
   *
   *  Typical use case is to directly use firmware commands to test and get
   *  result for all sites in Testmethod, then use this class to store and
   *  retrieve result for all sites.
   *---------------------------------------------------------------------*
   */
  struct MeasurementResultContainer
  {
    MeasurementResultContainer()
    {
      init();
    };
    ~MeasurementResultContainer() {};
    void setGlobalPassFail(bool isPass,int siteNumber = 0 )
    {
      mMultiSiteGlobalPassFail[siteNumber] = isPass;
    };
    void setPinPassFail(const string& pin,bool isPass,int siteNumber = 0)
    {
      mMultiSitePinPassFail[siteNumber][pin]= isPass;
    };
    void setPinsValue(const string& pins,double value,int siteNumber = 0)
    {
      mMultiSitePinsValue[siteNumber][pins]= value;
    };
    bool getGlobalPassFail(int siteNumber = 0) const
    {
      map< int,bool >::const_iterator it =
                          mMultiSiteGlobalPassFail.find(siteNumber);
      if ( it != mMultiSiteGlobalPassFail.end() )
      {
        return it->second;
      }
      else
      {
        throw Error("MeasurementResultContainer::getGlobalPassFail",
                    "No global result for this site!",
                    "MeasurementResultContainer::getGlobalPassFail");
      }
    };
    bool getPinPassFail(const string& pin,int siteNumber = 0) const
    {
      map< int,map<string,bool> >::const_iterator it =
                                      mMultiSitePinPassFail.find(siteNumber);

      // get the result of the specified site
      if ( it != mMultiSitePinPassFail.end() )
      {
        const map< string,bool >& tmpPinResult = it->second;
        map< string,bool >::const_iterator itPinResult = tmpPinResult.find(pin);

        // get the result of the specified pin
        if ( itPinResult != tmpPinResult.end() )
        {
          return itPinResult->second;
        }
        else
        {
          throw Error("MeasurementResultContainer::getPinPassFail",
                      "No result for this pin: "+pin+".",
                      "MeasurementResultContainer::getPinPassFail");
        }
      }
      else
      {
        throw Error("MeasurementResultContainer::getPinPassFail",
                    "No per pin result for this site!",
                    "MeasurementResultContainer::getPinPassFail");
      }
    };
    double getPinsValue(const string& pins,int siteNumber = 0) const
    {
      map< int,map<string,double> >::const_iterator it =
                                      mMultiSitePinsValue.find(siteNumber);

      // get the result of the specified site
      if ( it != mMultiSitePinsValue.end() )
      {
        const map< string,double >& tmpPinResult = it->second;
        map< string,double >::const_iterator itPinResult = tmpPinResult.find(pins);

        //* get the result of the specified pins
        if ( itPinResult != tmpPinResult.end() )
        {
          return itPinResult->second;
        }
        else
        {
          throw Error("MeasurementResultContainer::getPinsValue",
                      "No result for this pin(s): "+pins+".",
                      "MeasurementResultContainer::getPinsValue");
        }
      }
      else
      {
        throw Error("MeasurementResultContainer::getPinsValue",
                    "No result for this site!",
                    "MeasurementResultContainer::getPinsValue");
      }
    };

    void init()
    {
      mMultiSitePinsValue.clear();
      mMultiSitePinPassFail.clear();
      mMultiSiteGlobalPassFail.clear();
    };
  private:

    /*
     *********************************************
     * Record value for pin(s) per site, e.g.
     *   mMultiSitePinsValue[1] = {"I/O1",2.50}
     *   mMultiSitePinsValue[1] = {"I/O0",1.30}
     *   mMultiSitePinsValue[2] = {"I/O1",2.52}
     *   mMultiSitePinsValue[2] = {"I/O0",1.33}
     *********************************************
     */
    map< INT,map< STRING,DOUBLE > > mMultiSitePinsValue;

    /*
     *********************************************
     * Record pass/fail for each pin per site, e.g.
     *   TRUE: pass; FALSE: fail.
     *   mMultiSitePinPassFail[1] = {"Vcc",FALSE}
     *   mMultiSitePinPassFail[1] = {"Vee",FALSE}
     *   mMultiSitePinPassFail[2] = {"Vcc",TRUE}
     *   mMultiSitePinPassFail[2] = {"Vee",FALSE}
     *********************************************
     */
    map< INT,map< STRING,Boolean > > mMultiSitePinPassFail;
    /*
     *********************************************
     * Record global pass/fail per site, e.g.
     *   TRUE: pass; FALSE: fail.
     *   mMultiSiteGlobalPassFail[1] = TRUE
     *   mMultiSiteGlobalPassFail[2] = FALSE
     *********************************************
     */
    map< INT, Boolean > mMultiSiteGlobalPassFail;

  };





public:

/*
 *----------------------------------------------------------------------*
 *         public interfaces of continuityUtil test                         *
 *----------------------------------------------------------------------*
 */

  /*
   *----------------------------------------------------------------------*
   * Routine: getLimitInfo
   *
   * Purpose: get limit from limit table or get limit information from testflow
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note:
   *
   *----------------------------------------------------------------------*
   */
  static void getLimitInfo(
      const string& testName,
      const int groupNumber,
      const string& unit,
      LIMIT& limit,
      TesttableLimitHelper& testtableHelper)
  {
    TM::COMPARE lowCmp = TM::NA,highCmp = TM::NA;
    double lowVal = 0.0, highVal = 0.0;

    if(testtableHelper.isLimitCsvFileLoad())
    {
      testtableHelper.getLimit(testName,limit);
    }

    if(!testtableHelper.isAllInTable())
    {
      // this API has some issue, it converts the value according
      // to the unit, but it doesn't set the correct unit
      // e.g.  0 mV  <<  limit << 700 mV, using this API to get the limit
      // the lowValue of this limit is 0
      // the highValue of this limit is 0.7
      // but the current unit of this limit still is mV.
      limit = GET_LIMIT_OBJECT(testName);
      if(!(limit.unit().empty()))
      {
        if(unit== "uA")
        {
          limit.unit("A");
        }
        else if(unit == "mV")
        {
          limit.unit("V");
        }
      }
    }

    limit.get(lowCmp,lowVal,highCmp,highVal);
    if ( lowCmp == TM::NA || highCmp == TM::NA )
    {
      throw Error("ContinuityTestUtil::getLimitInfo",
                  testName + " is not specified",
                  "ContinuityTestUtil::getLimitInfo");
    }
    string unitInLimit = limit.unit();
    if(unitInLimit.empty())
    {
      if (unit == "uA")
      {
        limit.low(lowCmp, lowVal * 1e-6);
        limit.high(highCmp, highVal * 1e-6);
        limit.unit("A");
      }
      else if (unit == "mV")
      {
        limit.low(lowCmp, lowVal * 1e-3);
        limit.high(highCmp, highVal * 1e-3);
        limit.unit("V");
      }
      else
      {
        stringstream errMsg;
        errMsg << "the unit: " << unit << " is not a valid unit." <<endl
               << "current the valid units are: uA,mV..." <<endl;
        throw Error("ContinuityTestUtil::getLimitInfo",
                    errMsg.str(),
                    "ContinuityTestUtil::getLimitInfo");
      }
    }
    else
    {
      testmethod::SpecValue specValue;
      double factor = 1.0;
      if(unitInLimit.find('V') != string::npos)
      {
        specValue.setBaseUnit("V");
        specValue.inputValueUnit("1[V]");
        factor = specValue.getValueAsTargetUnit(unitInLimit);
        limit.low(lowCmp,lowVal / factor);
        limit.high(highCmp,highVal / factor);
        limit.unit("V");
      }
      else if(unitInLimit.find('A') != string::npos)
      {
        specValue.setBaseUnit("A");
        specValue.inputValueUnit("1[A]");
        factor = specValue.getValueAsTargetUnit(unitInLimit);
        limit.low(lowCmp,lowVal / factor);
        limit.high(highCmp,highVal / factor);
        limit.unit("A");
      }
      else
      {
        stringstream errMsg;
        errMsg << "the unit: " << unitInLimit
               << " is not a valid unit." <<endl
               << "current the valid units are: mA,uA,nA,mV,uV..." <<endl;
        throw Error("ContinuityTestUtil::getLimitInfo",
                    errMsg.str(),
                    "ContinuityTestUtil::getLimitInfo");
      }
    }
    return;
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: trim
   *
   * Purpose: get rid of head and tail space of input
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note:
   *
   * Return Value: new string
   *----------------------------------------------------------------------*
   */
  static string trim(const string& str)
  {
    int iStart = 0;
    int iStop = 0;
    int i = 0;
    int length =static_cast<int>( str.length());

    for(i=0;i< length;i++)
    {
      if(str[i] != ' ')
      {
        iStart = i;
        break;
      }
    }

    for(i=length-1;i>=0;i--)
    {
      if(str[i] != ' ')
      {
        iStop = i+1;
        break;
      }
    }

    return str.substr(iStart,iStop-iStart);
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: parseListOfString
   *
   * Purpose: parse one string to a string vector
   *
   *----------------------------------------------------------------------*
   * Description:
   *    e.g.    the original string is:
   *                "pin1,(pin2,pin3),pin4"
   *            and the delimiter char is: ','
   *    yields the following string vector results:
   *                "pin1", "pin2,pin3", "pin4"
   *
   *
   *----------------------------------------------------------------------*
   */
  static void parseListOfString(const string& originalString,
                                vector<string>& stringVec,
                                const char delimiter = ',',
                                const bool isParenthesesSupported = false)
  {
    if(originalString.empty())
    {
      stringVec.clear();
      return;
    }
    bool isWithinParentheses = false;
    bool isLeftParenthesesExist = false;
    string word;
    const char* str = originalString.c_str();

    for ( int i = 0 ; *(str+i) != 0 ; ++i )
    {
      char ch = str[i];

      if( ch == delimiter )
      {
        if ( isWithinParentheses && isParenthesesSupported )
        {
          word += ch;
        }
        else 
        {
          stringVec.push_back(trim(word));
          word = "";
        }
      }
      else if (isParenthesesSupported && ch == '(')
      {
        isWithinParentheses = true;
        isLeftParenthesesExist = true;
      }
      else if (isParenthesesSupported && ch == ')') 
      {
        isWithinParentheses = false;
        if(!isLeftParenthesesExist)
        { 
          throw Error("ContinuityTestUtil::parseListOfString",
                      "the parentheses mismatch.The correct format is like:()",
                      "ContinuityTestUtil::parseListOfString");
        }
        isLeftParenthesesExist = false;
      }
      else 
      {
        word += ch;
      }
    }

    if(isLeftParenthesesExist)
    {
      throw Error("ContinuityTestUtil::parseListOfString",
                  "the parentheses mismatch.The correct format is like:()",
                  "ContinuityTestUtil::parseListOfString");    
    }  
    stringVec.push_back(trim(word));

    return;
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: parseListOfDouble
   *
   * Purpose: parse one string to a double vector
   *
   *----------------------------------------------------------------------*
   * Description:
   *    e.g.    the original string is:
   *                "1.5,2.8,5.6"
   *            and the delimiter char is: ','
   *    yields the following double vector results:
   *                "1.5", "2.8", "5.6"
   *
   *
   *----------------------------------------------------------------------*
   */
  static void parseListOfDouble(const string& originalString,
                                vector<double>& doubleVec,
                                const char delimiter = ',')
  {
    if(originalString.empty())
    {
      doubleVec.clear();
      return;
    }
    
    string word;
    double tempValue;
    const char* str = originalString.c_str();

    for ( int i = 0 ; *(str+i) != 0 ; ++i )
    {
      char ch = str[i];
      if( ch == delimiter )
      {
        string tempString = trim(word);
        if(tempString.empty())
        {
          doubleVec.push_back(0.0);
        }
        else
        {
          istringstream stream(word);
          stream >> tempValue;
          doubleVec.push_back(tempValue);
        }
        word = "";
      }
      else 
      {
        word += ch;
      }
    }
    
    string tempString = trim(word);
    if(tempString.empty())
    {
      doubleVec.push_back(0.0);
    }
    else
    {
      istringstream stream(word);
      stream >> tempValue;
      doubleVec.push_back(tempValue);
    }
    return;    
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: getMode
   *
   * Purpose: define to use PVAL|PPF|GPF according test suite flag
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note:
   *
   *----------------------------------------------------------------------*
   */
  static TM::DCTEST_MODE getMode()
  {
    string testSuiteName = "";

    int valueOnPass = 0;
    int perPinOnPass = 0;
    int valueOnFail = 0;
    int perPinOnFail = 0;

    GET_TESTSUITE_NAME(testSuiteName);
    GET_TESTSUITE_FLAG(testSuiteName, "value_on_pass",   &valueOnPass);
    GET_TESTSUITE_FLAG(testSuiteName, "value_on_fail",   &valueOnFail);
    GET_TESTSUITE_FLAG(testSuiteName, "per_pin_on_pass", &perPinOnPass);
    GET_TESTSUITE_FLAG(testSuiteName, "per_pin_on_fail", &perPinOnFail);

    if ( 1 == valueOnPass || 1 == valueOnFail )
    {
      return TM::PVAL;
    }
    else if ( 1 == perPinOnPass || 1 == perPinOnFail )
    {
      return TM::PPF;
    }

    return TM::GPF;
  }


  /*
   *----------------------------------------------------------------------*
   * Routine: datalogToWindow
   *
   * Purpose: print datalog To report Window
   *
   *----------------------------------------------------------------------*
   * Description:
   *   this prototype only for TM::PVAL
   * Note:
   *   measuredValue and limit parameter always use default unit,
   *       that's, "A" for current, "V" for voltage.
   *   unit parameter specifies in which unit the output
   *        in the ReportWindow is, supported: [mV] and [uA]
   *----------------------------------------------------------------------*
   */
  static void datalogToWindow(const string& pin,
                              const double  measuredValue,
                              const LIMIT&  limit,
                              const string& unit)
  {
    string PFjudge = limit.pass(measuredValue)?"P":"F";
    string opl_str, oph_str;

    double lowVal  = 0.0,highVal = 0.0;
    TM::COMPARE lowCmp = TM::NA, highCmp = TM::NA;
    limit.get(lowCmp, lowVal, highCmp, highVal);

    double factor = 1.0;
    if(!(limit.unit().empty()))
    {
      testmethod::SpecValue specValue;
      if (unit == "uA")
      {
        specValue.setBaseUnit("A");
        specValue.inputValueUnit("1[A]");
        factor = specValue.getValueAsTargetUnit(limit.unit());
      }
      else if (unit == "mV")
      {
        specValue.setBaseUnit("V");
        specValue.inputValueUnit("1[V]");
        factor = specValue.getValueAsTargetUnit(limit.unit());
      }
    }
    lowVal = lowVal * factor;
    highVal = highVal * factor;

    switch (lowCmp)
    {
      case TM::GT:
        opl_str = "< ";
        break;

      case TM::GE:
        opl_str = "<=";
        break;

      case TM::NA:
        opl_str = "";
        break;

      default:
        throw Error("ContinuityTestUtil::datalogToWindow",
                    "Unknown Compare Mode of opl",
                    "ContinuityTestUtil::datalogToWindow");

    }
    switch (highCmp)
    {
      case TM::LT:
        oph_str = "< ";
        break;

      case TM::LE:
        oph_str = "<=";
        break;

      case TM::NA:
        oph_str = "";
        break;

      default:
        throw Error("ContinuityTestUtil::datalogToWindow",
                    "Unknown Compare Mode of opl",
                    "ContinuityTestUtil::datalogToWindow");
    }


    ostringstream buf;
    buf << left << setw(16) << pin;
    cout << buf.str() << '\t';

    // value of lower limit
    if ( opl_str != "" )
    {
      cout << "min:";
      printValue(lowVal, unit, false);
      cout << '\t' << opl_str << '\t';
    }

    // measured value
    printValue(measuredValue, unit, true);
    cout << '\t';

    // value of higher limit
    if ( oph_str != "" )
    {
      cout << oph_str << '\t' << "max:";
      printValue(highVal, unit, false);
      cout << '\t';
    }

    // Pass or Fail Info
    cout << PFjudge <<endl;
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: datalogToWindow
   *
   * Purpose: print datalog To report Window
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note:
   *   this protoype only for TM::PPF
   *----------------------------------------------------------------------*
   */
  static void datalogToWindow(const string& pin, const bool bPass)
  {
    ostringstream buf;
    buf << left << setw(16) << pin;
    cout << buf.str() << "\t";
    cout << (bPass? "P": "F") <<endl;
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: printValue
   *
   * Purpose: print result value
   *
   *----------------------------------------------------------------------*
   *
   * Note:
   *      the parameter "val" always use default unit, that's, "A" for
   *      current, "V" for voltage.
   *      the parameter unit, specifies in which unit the output will be
   *      supported: [mV], [uA]
   *
   *----------------------------------------------------------------------*
   */
  static void printValue(double val,const string& unit,const bool bFormat)
  {
    double dVal = 0.0;

    if ( unit == "uA" )
    {
      dVal = val * 1e6;
    }
    else if ( unit == "mV" )
    {
      dVal = val * 1e3;
    }
    else
    {
      throw Error("ContinuityTestUtil::printValue",
                  "Unknown unit",
                  "ContinuityTestUtil::printValue");
    }

    if ( bFormat )
    {
      ostringstream buf;
      buf << setprecision(10) << dVal << " " << unit;
      cout << right << setw(14) << buf.str() << '\t' << left;
    }
    else
    {
      cout << right << setw(10) << dVal << " " << unit << left;
    }
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: parameterCheck
   *
   * Purpose: check whether parameter groups match
   *
   *----------------------------------------------------------------------*
   *
   * Note:
   *
   *----------------------------------------------------------------------*
   */
  template <class T>
  static void checkParameter(const unsigned int lSize,
                             const unsigned int rSize,
                             const string& type,
                             const string& parameter,
                             vector<T>& valueVec )
  {
    if(lSize != rSize)
    {
      if(rSize != 1)
      {
        stringstream errMsg;
        errMsg << type <<": the number of pinlist groups is " << lSize <<endl
               <<"      the number of " << parameter << " groups is " << rSize <<endl
               <<"So the " << parameter << " groups don't match pinlist groups." <<endl;
        throw Error("ContinuityTestUtil::checkParameter()",
                    errMsg.str(),
                    "ContinuityTestUtil::checkParameter()");
      }
      else
      {
        for(vector<string>::size_type i = 1; i < lSize; i++)
        {
          valueVec.push_back(valueVec[0]);
        }
      }
    }
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: reverseLimit
   *
   * Purpose: reverse the limit .
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note:
   *
   *----------------------------------------------------------------------*
   */
  static void reverseLimit(const LIMIT& originalLimit, LIMIT& reversedLimit)
  {
    TM::COMPARE lowCmp,highCmp;
    double dLowVal = 0.0, dHighVal = 0.0;
    originalLimit.get(lowCmp,dLowVal,highCmp,dHighVal);

    // reverse the limit
    double tempValue = 0.0 - dLowVal;
    dLowVal = 0.0 - dHighVal;
    dHighVal = tempValue;
    TM::COMPARE lowTempCmp = TM::NA;
    TM::COMPARE highTempCmp = TM::NA;
    if(lowCmp == TM::GT)
    {
      highTempCmp = TM::LT;
    }
    else if(lowCmp == TM::GE)
    {
      highTempCmp = TM::LE;
    }

    if(highCmp == TM::LT)
    {
      lowTempCmp = TM::GT;
    }
    else if(highCmp == TM::LE)
    {
      lowTempCmp = TM::GE;
    }

    reversedLimit.high(highTempCmp,dHighVal);
    reversedLimit.low(lowTempCmp,dLowVal);
    reversedLimit.unit(originalLimit.unit());
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: judgeAndLogUtil
   *
   * Purpose: utility function for judgement and data log.
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note:
   *
   *----------------------------------------------------------------------*
   */
  template <class T>
  static void judgeAndLogUtil(
    const vector<T>& groups,
    const vector<MeasurementResultContainer>& firstResult,
    const vector<MeasurementResultContainer>& secondResult,
    const TM::DCTEST_MODE& mode,
    const string& testsuiteName,
    const bool isLimitTableUsed,
    const int siteNumber,
    const string& unit,
    bool& hasBined)
  {
    vector<string>::size_type j = 0;
    bool isPassLow = true;
    bool isPassHigh = true;
    bool retLow = true;
    bool retHigh = true;
    ARRAY_D lowResultArray;
    ARRAY_D highResultArray;

    V93kLimits::TMLimits::LimitInfo limitInfo;
    double factor = 1.0;

    for(vector<string>::size_type i = 0; i < groups.size(); ++i)
    {
      if(isLimitTableUsed)
      {
        limitInfo = V93kLimits::tmLimits.getLimit(testsuiteName + ":" + groups[i].limitName);
      }
      // restore it for every group
      retLow = true;
      retHigh = true;
      /*
      ****************************
      *  single polarity
      ****************************
      */
      if ('#' != groups[i].pinlist[0] && groups[i].polarity == "SPOL")
      {
        switch ( mode )
        {
        case TM::PVAL:
          lowResultArray.resizeNoKeep(groups[i].expandedPins.size());

          if(isLimitTableUsed)
          {
            testmethod::SpecValue specValue;
            if( (limitInfo.Units).find('V') != string::npos)
            {
              specValue.setBaseUnit("V");
              specValue.inputValueUnit("1[V]");
              factor = specValue.getValueAsTargetUnit(limitInfo.Units);
            }
            else if( (limitInfo.Units).find('A') != string::npos)
            {
              specValue.setBaseUnit("A");
              specValue.inputValueUnit("1[A]");
              factor = specValue.getValueAsTargetUnit(limitInfo.Units);
            }
            else if(limitInfo.Units.empty())
            {
              if (unit == "uA")
              {
                factor = 1e6;
              }
              else if (unit == "mV")
              {
                factor = 1e3;
              }
            }
            else
            {
              stringstream errMsg;
              errMsg << "the unit: " << limitInfo.Units << " is not a valid unit." <<endl
                     << "current the valid units are: uA,mV..." <<endl;
              throw Error("ContinuityTestUtil::judgeAndLogUtil",
                          errMsg.str(),
                          "ContinuityTestUtil::judgeAndLogUtil");
            }
          }

          for ( j = 0; j< groups[i].expandedPins.size(); ++j )
          {
            lowResultArray[j] = firstResult[i].getPinsValue(groups[i].expandedPins[j],siteNumber);
            lowResultArray[j] = lowResultArray[j] * factor;
          }

          if(isLimitTableUsed)
          {
            TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                          groups[i].expandedPins,
                                          groups[i].limitName,
                                          V93kLimits::tmLimits,
                                          lowResultArray);
          }
          else
          {
            TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                            groups[i].expandedPins,
                                            groups[i].limitName,
                                            groups[i].firstLimit,
                                            lowResultArray);
          }
          break;

        case TM::PPF:
          lowResultArray.resizeNoKeep(groups[i].expandedPins.size());
          for (j = 0; j < groups[i].expandedPins.size(); ++j )
          {
            isPassLow = firstResult[i].getPinPassFail(groups[i].expandedPins[j],siteNumber);
            if(isPassLow) // for pass pin, in PPF mode, we will write 0.0 to MPR
            {
              lowResultArray[j] = 0.0;
            }
            else // for fail pin, in PPF mode, we will write 1.0 to MPR
            {
              lowResultArray[j] = 1.0;
            }
            retLow = isPassLow && retLow;
          }

          if(isLimitTableUsed)
          {
            TESTSET().cont(TM::CONTINUE).testnumber(limitInfo.TestNumber)
                                        .judgeAndLog_ParametricTest(
                                            groups[i].expandedPins,
                                            groups[i].limitName,
                                            retLow ? TM::Pass : TM::Fail,
                                            lowResultArray);
            if(!retLow && !hasBined && limitInfo.BinsNumString.size() > 0)
            {
              hasBined = true;
              SET_MULTIBIN(limitInfo.BinsNumString,limitInfo.BinhNum);
            }
          }
          else
          {
            TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                            groups[i].expandedPins,
                                            groups[i].limitName,
                                            retLow ? TM::Pass : TM::Fail,
                                            lowResultArray);
          }
          break;

        case TM::GPF:
          isPassLow = firstResult[i].getGlobalPassFail(siteNumber);
          if(isLimitTableUsed)
          {
            TESTSET().cont(TM::CONTINUE).testnumber(limitInfo.TestNumber)
                                        .judgeAndLog_ParametricTest(
                                            groups[i].pinlist,
                                            groups[i].limitName,
                                            isPassLow?TM::Pass:TM::Fail,
                                            0.0);
            if(!isPassLow && !hasBined && limitInfo.BinsNumString.size() > 0)
            {
              hasBined = true;
              SET_MULTIBIN(limitInfo.BinsNumString,limitInfo.BinhNum);
            }
          }
          else
          {
            TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                            groups[i].pinlist,
                                            groups[i].limitName,
                                            isPassLow?TM::Pass:TM::Fail,
                                            0.0);
          }
          break;
        default:
          throw Error("ContinuityTestUtil::judgeAndLogUtil",
                      "Unknown Test Mode",
                      "ContinuityTestUtil::judgeAndLogUtil");
        } /*end switch*/
      }
      else if ('#' != groups[i].pinlist[0] && groups[i].polarity == "BPOL")
      {
        /*
         *********************************************
         * Both polarity:
         * combine the two measurements with different
         * polarities.
         * If both pass, total results pass.
         *********************************************
         */
        switch ( mode )
        {
        case TM::PVAL:
          lowResultArray.resizeNoKeep(groups[i].expandedPins.size());
          highResultArray.resizeNoKeep(groups[i].expandedPins.size());

          if(isLimitTableUsed)
          {
            testmethod::SpecValue specValue;
            if( (limitInfo.Units).find('V') != string::npos)
            {
              specValue.setBaseUnit("V");
              specValue.inputValueUnit("1[V]");
              factor = specValue.getValueAsTargetUnit(limitInfo.Units);
            }
            else if( (limitInfo.Units).find('A') != string::npos)
            {
              specValue.setBaseUnit("A");
              specValue.inputValueUnit("1[A]");
              factor = specValue.getValueAsTargetUnit(limitInfo.Units);
            }
            else if(limitInfo.Units.empty())
            {
              if (unit == "uA")
              {
                factor =  1e6;
              }
              else if (unit == "mV")
              {
                factor = 1e3;
              }
            }
            else
            {
              stringstream errMsg;
              errMsg << "the unit: " << limitInfo.Units << " is not a valid unit." <<endl
                     << "current the valid units are: uA,mV..." <<endl;
              throw Error("ContinuityTestUtil::judgeAndLogUtil",
                          errMsg.str(),
                          "ContinuityTestUtil::judgeAndLogUtil");
            }
          }

          for (j = 0; j < groups[i].expandedPins.size(); ++j)
          {
            lowResultArray[j] = firstResult[i].getPinsValue(groups[i].expandedPins[j],siteNumber) * factor;
            highResultArray[j] = secondResult[i].getPinsValue(groups[i].expandedPins[j],siteNumber) * factor;
            if(isLimitTableUsed)
            {
              retLow = retLow && firstResult[i].getPinPassFail(groups[i].expandedPins[j],siteNumber);
              retHigh = retHigh && secondResult[i].getPinPassFail(groups[i].expandedPins[j],siteNumber);
            }
          }
          if(isLimitTableUsed)
          {
            TESTSET().cont(TM::CONTINUE).testnumber(limitInfo.TestNumber)
                                        .judgeAndLog_ParametricTest(
                                            groups[i].expandedPins,
                                            groups[i].limitName,
                                            groups[i].firstLimit,
                                            lowResultArray);
            TESTSET().cont(TM::CONTINUE).testnumber(limitInfo.TestNumber)
                                        .judgeAndLog_ParametricTest(
                                            groups[i].expandedPins,
                                            groups[i].limitName,
                                            groups[i].secondLimit,
                                            highResultArray);

            if((!retLow || !retHigh) && !hasBined && limitInfo.BinsNumString.size() > 0)
            {
              hasBined = true;
              SET_MULTIBIN(limitInfo.BinsNumString,limitInfo.BinhNum);
            }
          }
          else
          {
            TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                            groups[i].expandedPins,
                                            groups[i].limitName,
                                            groups[i].firstLimit,
                                            lowResultArray);
            TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                            groups[i].expandedPins,
                                            groups[i].limitName,
                                            groups[i].secondLimit,
                                            highResultArray);
          }
          break;
        case TM::PPF:
          lowResultArray.resizeNoKeep(groups[i].expandedPins.size());
          highResultArray.resizeNoKeep(groups[i].expandedPins.size());
          for (j = 0; j < groups[i].expandedPins.size(); ++j)
          {
            isPassLow = firstResult[i].getPinPassFail(groups[i].expandedPins[j],siteNumber);
            isPassHigh = secondResult[i].getPinPassFail(groups[i].expandedPins[j],siteNumber);
            if(isPassLow) // for pass pin, in PPF mode, we will write 0.0 to MPR
            {
              lowResultArray[j] = 0.0;
            }
            else // for fail pin, in PPF mode, we will write 1.0 to MPR
            {
              lowResultArray[j] = 1.0;
            }
            if(isPassHigh) // for pass pin, in PPF mode, we will write 0.0 to MPR
            {
              highResultArray[j] = 0.0;
            }
            else // for fail pin, in PPF mode, we will write 1.0 to MPR
            {
              highResultArray[j] = 1.0;
            }
            retLow = retLow && isPassLow;
            retHigh = retHigh && isPassHigh;
          }

          if(isLimitTableUsed)
          {
            TESTSET().cont(TM::CONTINUE).testnumber(limitInfo.TestNumber)
                                        .judgeAndLog_ParametricTest(
                                            groups[i].expandedPins,
                                            groups[i].limitName,
                                            retLow ? TM::Pass : TM::Fail,
                                            lowResultArray);

            TESTSET().cont(TM::CONTINUE).testnumber(limitInfo.TestNumber)
                                        .judgeAndLog_ParametricTest(
                                            groups[i].expandedPins,
                                            groups[i].limitName,
                                            retHigh ? TM::Pass : TM::Fail,
                                            highResultArray);
            if((!retLow || !retHigh) && !hasBined && limitInfo.BinsNumString.size() > 0)
            {
              hasBined = true;
              SET_MULTIBIN(limitInfo.BinsNumString,limitInfo.BinhNum);
            }
          }
          else
          {
            TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                            groups[i].expandedPins,
                                            groups[i].limitName,
                                            retLow ? TM::Pass : TM::Fail,
                                            lowResultArray);

            TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                            groups[i].expandedPins,
                                            groups[i].limitName,
                                            retHigh ? TM::Pass : TM::Fail,
                                            highResultArray);
          }
          break;

        case TM::GPF:
          isPassLow = firstResult[i].getGlobalPassFail(siteNumber);
          isPassHigh = secondResult[i].getGlobalPassFail(siteNumber);
          if(isLimitTableUsed)
          {
            TESTSET().cont(TM::CONTINUE).testnumber(limitInfo.TestNumber)
                                        .judgeAndLog_ParametricTest(
                                            groups[i].pinlist,
                                            groups[i].limitName,
                                            isPassLow?TM::Pass:TM::Fail,
                                            0.0);

            TESTSET().cont(TM::CONTINUE).testnumber(limitInfo.TestNumber)
                                        .judgeAndLog_ParametricTest(
                                            groups[i].pinlist,
                                            groups[i].limitName,
                                            isPassHigh?TM::Pass:TM::Fail,
                                            0.0);

            if((!isPassLow || isPassHigh) && !hasBined && limitInfo.BinsNumString.size() > 0)
            {
              hasBined = true;
              SET_MULTIBIN(limitInfo.BinsNumString,limitInfo.BinhNum);
            }
          }
          else
          {
            TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                            groups[i].pinlist,
                                            groups[i].limitName,
                                            isPassLow?TM::Pass:TM::Fail,
                                            0.0);

            TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                            groups[i].pinlist,
                                            groups[i].limitName,
                                            isPassHigh?TM::Pass:TM::Fail,
                                            0.0);
          }

          break;

        default:
          throw Error("ContinuityTestUtil::judgeAndLogUtil",
                      "Unknown Test Mode",
                      "ContinuityTestUtil::judgeAndLogUtil");
        } //end switch

      }//end else if: BOTH
    }// end for every group
  }
  /*
   *----------------------------------------------------------------------*
   * Routine: judgeAndLogUtilForAllGroups
   *
   * Purpose: judgement and data log.for: one limit is applied for all groups
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note:
   *
   *----------------------------------------------------------------------*
   */
  template <class T>
  static void judgeAndLogUtilForAllGroups(
    const vector<T>& groups,
    const vector<MeasurementResultContainer>& firstResult,
    const vector<MeasurementResultContainer>& secondResult,
    const TM::DCTEST_MODE& mode,
    const string& testsuiteName,
    const bool isLimitTableUsed,
    const int siteNumber,
    const string& unit,
    bool& hasBined)
  {
    vector<string>::size_type j = 0;
    bool isPassLow = true;
    bool isPassHigh = true;
    bool retLow = true;
    bool retHigh = true;
    ARRAY_D lowResultArray;
    ARRAY_D highResultArray;

    int sizeOfLowArray = 0;
    int sizeOfHighArray = 0;
    vector<string> lowPinVec;
    vector<string> highPinVec;
    string lowStringPinlist;
    string highStringPinlist;

    for(vector<string>::size_type i = 0; i < groups.size(); ++i)
    {
      if('#' != groups[i].pinlist[0])
      {
        sizeOfLowArray += groups[i].expandedPins.size();

        if(groups[i].polarity == "BPOL")
        {
          sizeOfHighArray += groups[i].expandedPins.size();
        }
      }
    } // end for: every group

    V93kLimits::TMLimits::LimitInfo limitInfo;
    if(isLimitTableUsed)
    {
      limitInfo = V93kLimits::tmLimits.getLimit(testsuiteName + ":" + groups[0].limitName);
    }

    int indexLow = 0;
    int indexHigh = 0;
    switch(mode)
    {
    case TM::PVAL:
      lowResultArray.resizeNoKeep(sizeOfLowArray);
      highResultArray.resizeNoKeep(sizeOfHighArray);
      for(vector<string>::size_type i = 0; i < groups.size(); ++i)
      {
        if('#' != groups[i].pinlist[0])
        {
          for (j = 0; j < groups[i].expandedPins.size(); ++j)
          {
            lowResultArray[indexLow] = firstResult[i].getPinsValue(groups[i].expandedPins[j],siteNumber); 
            lowPinVec.push_back(groups[i].expandedPins[j]);
            indexLow++;

            if(groups[i].polarity == "BPOL")
            {
              highResultArray[indexHigh] = secondResult[i].getPinsValue(groups[i].expandedPins[j],siteNumber);
              highPinVec.push_back(groups[i].expandedPins[j]);
              indexHigh++;
            }
          } // end for: every pin
        }// end if
      }// end for: every group

      if(isLimitTableUsed)
      {
        if(lowPinVec.size() > 0)
        {
          retLow = TESTSET().cont(TM::CONTINUE).testnumber(limitInfo.TestNumber)
                                               .judgeAndLog_ParametricTest(
                                                   lowPinVec,
                                                   groups[0].limitName,
                                                   groups[0].firstLimit,
                                                   lowResultArray);
        }
        if(highPinVec.size() > 0)
        {
          retHigh = TESTSET().cont(TM::CONTINUE).testnumber(limitInfo.TestNumber)
                                                .judgeAndLog_ParametricTest(
                                                    highPinVec,
                                                    groups[0].limitName,
                                                    groups[0].secondLimit,
                                                    highResultArray);
        }

        if(!hasBined && (!retLow || !retHigh) && limitInfo.BinsNumString.size() > 0)
        {
          hasBined = true;
          SET_MULTIBIN(limitInfo.BinsNumString,limitInfo.BinhNum);
        }
      }
      else // use test flow's limits
      {
        if(lowPinVec.size() > 0)
        {
          TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                          lowPinVec,
                                          groups[0].limitName,
                                          groups[0].firstLimit,
                                          lowResultArray);
        }

        if(highPinVec.size() > 0)
        {
          TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                          highPinVec,
                                          groups[0].limitName,
                                          groups[0].secondLimit,
                                          highResultArray);
        }
      }

      break;

    case TM::PPF:
      lowResultArray.resizeNoKeep(sizeOfLowArray);
      highResultArray.resizeNoKeep(sizeOfHighArray);
      for(vector<string>::size_type i = 0; i < groups.size(); ++i)
      {
        if('#' != groups[i].pinlist[0])
        {
          for(j = 0; j < groups[i].expandedPins.size(); ++j)
          {
            isPassLow = firstResult[i].getPinPassFail(groups[i].expandedPins[j],siteNumber);
            if(isPassLow) // for pass pin, in PPF mode, we will write 0.0 to MPR
            {
              lowResultArray[indexLow] = 0.0;
            }
            else // for fail pin, in PPF mode, we will write 1.0 to MPR
            {
              lowResultArray[indexLow] = 1.0;
            }
            retLow = isPassLow && retLow;
            lowPinVec.push_back(groups[i].expandedPins[j]);
            indexLow++;

            if(groups[i].polarity == "BPOL")
            {
              isPassHigh = secondResult[i].getPinPassFail(groups[i].expandedPins[j],siteNumber);
              if(isPassHigh) // for pass pin, in PPF mode, we will write 0.0 to MPR
              {
                highResultArray[indexHigh] = 0.0;
              }
              else // for fail pin, in PPF mode, we will write 1.0 to MPR
              {
                highResultArray[indexHigh] = 1.0;
              }
              retHigh = isPassHigh && retHigh;
              highPinVec.push_back(groups[i].expandedPins[j]);
              indexHigh++;
            } // end if: BPOL

          } // end for: every pin
        } //end if
      } // end for: every group

      if(isLimitTableUsed)
      {
        if(lowPinVec.size() > 0)
        {
          TESTSET().cont(TM::CONTINUE).testnumber(limitInfo.TestNumber)
                                      .judgeAndLog_ParametricTest(
                                          lowPinVec,
                                          groups[0].limitName,
                                          retLow ? TM::Pass : TM::Fail,
                                          lowResultArray);
        }
        if(highPinVec.size() > 0)
        {
          TESTSET().cont(TM::CONTINUE).testnumber(limitInfo.TestNumber)
                                      .judgeAndLog_ParametricTest(
                                          highPinVec,
                                          groups[0].limitName,
                                          retHigh ? TM::Pass : TM::Fail,
                                          highResultArray);
        }
        if(!hasBined && (!retLow || !retHigh) && limitInfo.BinsNumString.size() > 0)
        {
          hasBined = true;
          SET_MULTIBIN(limitInfo.BinsNumString,limitInfo.BinhNum);
        }
      }
      else // use test flow's limits
      {
        if(lowPinVec.size() > 0)
        {
          TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                          lowPinVec,
                                          groups[0].limitName,
                                          retLow ? TM::Pass : TM::Fail,
                                          lowResultArray);
        }
        if(highPinVec.size() > 0)
        {
          TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                          highPinVec,
                                          groups[0].limitName,
                                          retHigh ? TM::Pass : TM::Fail,
                                          highResultArray);
        }
      }
      break;

    case TM::GPF:
      for(vector<string>::size_type i = 0; i < groups.size(); ++i)
      {
        if('#' != groups[i].pinlist[0])
        {
          retLow = retLow && firstResult[i].getGlobalPassFail(siteNumber);
          lowStringPinlist = lowStringPinlist + groups[i].pinlist + ",";

          if(groups[i].polarity == "BPOL")
          {
            retHigh = retHigh && secondResult[i].getGlobalPassFail(siteNumber);
            highStringPinlist = highStringPinlist + groups[i].pinlist + ",";
          }
        }
      }

      if(isLimitTableUsed)
      {
        if(!lowStringPinlist.empty())
        {
          lowStringPinlist = lowStringPinlist.substr(0, lowStringPinlist.length() -1);
          TESTSET().cont(TM::CONTINUE).testnumber(limitInfo.TestNumber)
                                      .judgeAndLog_ParametricTest(
                                          lowStringPinlist,
                                          groups[0].limitName,
                                          retLow ? TM::Pass : TM::Fail,
                                          0.0);
        }
        if(!highStringPinlist.empty())
        {
          highStringPinlist = highStringPinlist.substr(0,highStringPinlist.length() -1);
          TESTSET().cont(TM::CONTINUE).testnumber(limitInfo.TestNumber)
                                      .judgeAndLog_ParametricTest(
                                          highStringPinlist,
                                          groups[0].limitName,
                                          retHigh ? TM::Pass : TM::Fail,
                                          0.0);
        }
        if(!hasBined && (!retLow || !retHigh) && limitInfo.BinsNumString.size() > 0)
        {
          hasBined = true;
          SET_MULTIBIN(limitInfo.BinsNumString,limitInfo.BinhNum);
        }
      }
      else // use test flow's limits
      {
        if(!lowStringPinlist.empty())
        {
          lowStringPinlist = lowStringPinlist.substr(0,lowStringPinlist.length() -1);
          TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                          lowStringPinlist,
                                          groups[0].limitName,
                                          retLow ? TM::Pass : TM::Fail,
                                          0.0);
        }
        if(!highStringPinlist.empty())
        {
          highStringPinlist = highStringPinlist.substr(0,highStringPinlist.length() -1);
          TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                          highStringPinlist,
                                          groups[0].limitName,
                                          retHigh ? TM::Pass : TM::Fail,
                                          0.0);
        }
      }

      break;
    default:
      throw Error("ContinuityTestUtil::judgeAndLogUtilForAllGroups",
                  "Unknown Test Mode",
                  "ContinuityTestUtil::judgeAndLogUtilForAllGroups");

    } // end switch
  }
  /*
   *----------------------------------------------------------------------*
   * Routine: switchDpsStateToLOZ
   *
   * Purpose: conditionally change DPS to LOZ state
   *
   *----------------------------------------------------------------------*
   * Description:
   *   (1) check primary setting of ALL DPS pins.
   *   (2) change the states of ALL 'HIZ' dps pins to 'LOZ' state.
   * Note:
   *
   *----------------------------------------------------------------------*
   */
  static void switchDpsStateToLOZ(string& strFwRestoreToHIZ)
  {
    //query DPS states of primary setting
    string strFwAnswer = "";
    FW_TASK("PSLV? PRM,(@)\n",strFwAnswer);

    string::size_type iCmdHeaderPos       = 0; //the position of "PSLV"
    string::size_type iStatePos           = 0; //the position of "HIZ" or "HIZ_R"
    string::size_type iCommaAfterStatePos = 0; //the position of the comma after state
    string::size_type iPos                = 0; //the other positions
    string strFwCmdToLOZ    = "";//FW string to switch DPS to LOZ state

    iCmdHeaderPos = strFwAnswer.find("PSLV");
    while (iCmdHeaderPos != string::npos)
    {
      //to identify "HIZ" and "HIZ_R"
      iStatePos = strFwAnswer.find("HIZ",iCmdHeaderPos);
      iPos   = strFwAnswer.find("(",iCmdHeaderPos);
      /*
       *******************************************************
       * The valid "HIZ" or "HIZ_R" must be before the "(".
       * and identify the special case:
       * "...,LOZ,,(Vcc,HIZ,Vee)\n".
       *******************************************************
       */
      if ( (iStatePos != string::npos) && (iPos > iStatePos) )
      {
        iCommaAfterStatePos = strFwAnswer.find(",",iStatePos);
        iPos = strFwAnswer.find(")",iPos+1);
        if (string::npos == iPos)
        {
          break;
        }
        ++iPos; //move to "\n"

        //create FW command string of restoring dps state.
        strFwRestoreToHIZ += strFwAnswer.substr(iCmdHeaderPos,
                                                iPos-iCmdHeaderPos+1);

        //create FW command string of switching dps to LOZ.
        strFwCmdToLOZ += strFwAnswer.substr(iCmdHeaderPos,
                                            iStatePos-iCmdHeaderPos);
        strFwCmdToLOZ += "LOZ";
        strFwCmdToLOZ += strFwAnswer.substr(iCommaAfterStatePos,
                                            iPos-iCommaAfterStatePos+1);
      }
      //try to find the next command line
      iCmdHeaderPos = strFwAnswer.find("PSLV",iPos+1);
    }
    // send command if any
    if ( !strFwCmdToLOZ.empty() )
    {
      FW_TASK(strFwCmdToLOZ);
    }
  }

/*Check if the specified pin is high voltage pin*/
static bool isHvPin(STRING& pinName)
{
  string strFwAnswer = "";
  FW_TASK("CONF? (" + pinName + ")\n", strFwAnswer);

  string::size_type operModePos = strFwAnswer.find(',', 0) + 1;

  if(operModePos != string::npos)
  {
    STRING operMode = strFwAnswer.substr(operModePos, strFwAnswer.find(',', operModePos) - operModePos);
    if(operMode.compare("HV") == 0)
    {
      return true;
    }
  }
  return false;
}


 /*
  *----------------------------------------------------------------------*
  * Routine: getMeasureModeForHVPin
  *
  * Purpose: map the normal measurement mode to HV mode
  *----------------------------------------------------------------------*
  * Description:
  * Note:
  *----------------------------------------------------------------------*
  */
  static const string & getMeasureModeForHVPin(const TM::DCTEST_MODE & testMode)
  {
    static string HV_PPMU_PPF = "HV_PPMU_PPF";
    static string HV_PPMU_GPF = "HV_PPMU_GPF";
    static string HV_PPMU_BADC_VAL = "HV_PPMU_BADC_VAL";
    static string NOT_MATCH = "";

    switch(testMode)
    {
      case TM::PVAL:
        return HV_PPMU_BADC_VAL;
      case TM::GPF:
        return HV_PPMU_GPF;
      case TM::PPF:
        return HV_PPMU_PPF;
      default:
        return NOT_MATCH;
    }
  }

private:
  ContinuityTestUtil() {} //private constructor to prevent instantiation.

};
#endif /*CONTINUITYTEST_H_*/
