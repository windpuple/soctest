/**
 * (c) Copyright 2011, Verigy Technologies, all rights reserved.
 *
 * Modification History:
 * 
 * fix CR70736
 * fix CR71639    31st August,2011
 *
 */

//for testmethod framework interfaces
#include "testmethod.hpp"
//for testmethod API interfaces
#include "mapi.hpp"

#include "ContinuityTest.hpp"

 /**
  *----------------------------------------------------------------------*
  * @testmethod class: Continuity
  *
  * @Purpose: It checks for continuity of the test signal paths,
  *          and for short circuits.
  *
  *----------------------------------------------------------------------*
  * @Description:
  *   ppmu instrument parameter
  *   string ppmuUsed:            {YES | NO }
  *     indicate whether use ppmu to do test or not.
  *   string ppmuPinlist:              {@ | pinlist}
  *     Name of pins to be tested.
  *     valid pin types: I,O,IO type digital pins
  *   string ppmuTestCurrent           {uA}
  *     Value of test current. The unit is uA.
  *   string ppmuSettlingTime          {ms}
  *     The settling time will be in addition to the settling time
  *     calculated by the system. The unit is ms.
  *   string ppmuPolarity              {SPOL | BPOL}
  *     Measurement polarities:
  *     SPOL - single polarity.
  *     BPOL - double polarities.
  *   string ppmuMeasureMode              {PAR | SER}
  *     PAR -  parallel
  *     SER -  serial
  *   string ppmuTestName         
  *     Name of limit(s). 
  * 
  *   spmu instrument parameter
  *   string spmuUsed:            {YES | NO }
  *     indicate whether use spmu to do test or not.
  *   string spmuPinlist:              {@ | pinlist}
  *     Name of pins to be tested
  *     Valid pins: all digital pins.
  *   string spmuTestCurrent           {uA}
  *     Value of test current. The unit is uA.
  *   string spmuSettlingTime          {ms}
  *     The settling time will be in addition to the settling time
  *     calculated by the system. The unit is ms.
  *   string spmuPolarity              {SPOL | BPOL}
  *     Measurement polarities:
  *     SPOL - single polarity.
  *     BPOL - double polarities.
  *   string spmuMeasureMode              {PAR | SER}
  *     PAR -  parallel
  *     SER -  serial
  *   string spmuPrechargeToZeroVol    {ON | OFF}
  *     Force 0 V as the precharge voltage before the current forcing.
  *     ON  - enable precharge.
  *     OFF - disable precharge.
  *   string spmuTestName          
  *     Name of limit(s). 
  *
  *   analog pmu(mcx) instrument parameter
  *   string mcxUsed:            {YES | NO }
  *     indicate whether use analog pmu to do test or not.
  *   string mcxPinlist:              {@ | pinlist}
  *     Name of pins to be tested.
  *     valid pin types: all analog pins
  *   string mcxTestCurrent           {uA}
  *     Value of test current. The unit is uA.
  *   string mcxSettlingTime          {ms}
  *     The settling time will be in addition to the settling time
  *     calculated by the system. The unit is ms.
  *   string mcxPolarity              {SPOL | BPOL}
  *     Measurement polarities:
  *     SPOL - single polarity.
  *     BPOL - double polarities.
  *   string mcxMeasureMode              {PAR | SER}
  *     PAR -  parallel
  *     SER -  serial
  *   string mcxTestName     
  *     Name of limit(s). 
  *
  *   dc scale instrument in SIG mode parameter
  *   string dcScaleSIGUsed:            {YES | NO }
  *     indicate whether use dcScale in SIG mode to do test or not.
  *   string dcScaleSIGPinlist:              {@ | pinlist}
  *     Name of pins to be tested
  *     Valid pins: all dc scale pins in SIG mode.
  *   string dcScaleSIGTestCurrent           {uA}
  *     Value of test current. The unit is uA.
  *   string dcScaleSIGSettlingTime          {ms}
  *     The settling time will be in addition to the settling time 
  *     calculated by the system. The unit is ms.
  *   string dcScaleSIGPolarity              {SPOL | BPOL}
  *     Measurement polarities:
  *     SPOL - single polarity.
  *     BPOL - double polarities.
  *   string dcScaleSIGMeasureMode              {PAR | SER}
  *     PAR -  parallel
  *     SER -  serial
  *   string dcScaleSIGPrechargeToZeroVol    {ON | OFF}
  *     Force 0 V as the precharge voltage before the current forcing.
  *     ON  - enable precharge.
  *     OFF - disable precharge. 
  *   string dcScaleSIGTestName          
  *     Name of limit(s).
  *
  *   dc scale instrument in DPS mode parameter
  *   string dcScaleDPSUsed:            {YES | NO }
  *     indicate whether use dcScale in DPS mode to do test or not.
  *   string dcScaleDPSPinlist:              {@ | pinlist}
  *     Name of pins to be tested
  *     Valid pins: all dc scale pins in DPS mode.
  *   string dcScaleDPSSpecName
  *     spec variable name for dc scale pins in DPS mode.
  *   string dcScaleDPSSpecValue        {V}
  *     value of the spec variable.   The unit is V.
  *   string dcScaleDPSSettlingTime          {ms}
  *     The settling time will be in addition to the settling time
  *     calculated by the system. The unit is ms.
  *   string dcScaleDPSPolarity              {SPOL | BPOL}
  *     Measurement polarities:
  *     SPOL - single polarity.
  *     BPOL - double polarities.
  *   string dcScaleDPSMeasureMode              {PAR | SER}
  *     PAR -  parallel
  *     SER -  serial
  *   string dcScaleDPSTestName
  *     Name of limit(s).
  *
  *   dps instrument parameter
  *   string dpsUsed:            {YES | NO }
  *     indicate whether use dps instrument to do test or not.
  *   string dpsPinlist:              {@ | pinlist}
  *     Name of pins to be tested
  *     Valid pins: all dps pins.
  *   string dpsSpecName
  *     spec variable name for dps pins.
  *   string dpsSpecValue        {V}
  *     value of the spec variable.   The unit is V.
  *   string dpsSettlingTime          {ms}
  *     The settling time will be in addition to the settling time
  *     calculated by the system. The unit is ms.
  *   string dpsPolarity              {SPOL | BPOL}
  *     Measurement polarities:
  *     SPOL - single polarity.
  *     BPOL - double polarities.
  *   string dpsMeasureMode              {PAR | SER}
  *     PAR -  parallel
  *     SER -  serial
  *   string dpsTestName          
  *     Name of limit(s). 
  * 
  *   // common parameters
  *   string output:               {ReportUI | None}
  *     Print message or not. 
  *     ReportUI - for debug mode
  *     None     - for production mode
  *
  * @Note:
  *     
  *
  *----------------------------------------------------------------------*
  */

class Continuity: public testmethod::TestMethod
{
protected:
  // ppmu parameter
  string  ppmuUsed;
  string  ppmuPinlist;
  string  ppmuTestCurrent_uA;
  string  ppmuSettlingTime_ms;
  string  ppmuPolarity;
  string  ppmuMeasureMode;
  string  ppmuTestName;

  // spmu parameter
  string  spmuUsed;
  string  spmuPinlist;
  string  spmuTestCurrent_uA;
  string  spmuSettlingTime_ms;
  string  spmuMeasureMode;
  string  spmuPolarity;
  string  spmuPrechargeToZeroVol;
  string  spmuTestName;

  // mcx-pmu parameter
  string  mcxUsed;
  string  mcxPinlist;
  string  mcxTestCurrent_uA;
  string  mcxSettlingTime_ms;
  string  mcxMeasureMode;
  string  mcxPolarity;
  string  mcxTestName;

  // dcscale pin in SIG mode parameter
  string  dcScaleSIGUsed;
  string  dcScaleSIGPinlist;
  string  dcScaleSIGTestCurrent_uA;
  string  dcScaleSIGSettlingTime_ms;
  string  dcScaleSIGMeasureMode;
  string  dcScaleSIGPolarity;
  string  dcScaleSIGPrechargeToZeroVol;
  string  dcScaleSIGTestName;

  // dcscale pin in DPS mode parameter
  string  dcScaleDPSUsed;
  string  dcScaleDPSPinlist;
  string  dcScaleDPSSpecName;
  string  dcScaleDPSSpecValue;
  string  dcScaleDPSSettlingTime_ms;
  string  dcScaleDPSPolarity;
  string  dcScaleDPSMeasureMode;
  string  dcScaleDPSTestName;

  // dps parameter
  string  dpsUsed;
  string  dpsPinlist;
  string  dpsSpecName;
  string  dpsSpecValue;
  string  dpsSettlingTime_ms;
  string  dpsPolarity;
  string  dpsMeasureMode;
  string  dpsTestName;

  string  output;

  bool isParameterChanged;

  // Assume all sites' parameters are the same
  ContinuityTest::ContinuityTestParam param;
protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    // parameters for PPMU
    addParameter("UsePPMU",
                 "string",
                 &ppmuUsed)
      .setDefault("YES")
      .setOptions("YES:NO");
    addParameter("UsePPMU.pinlist",
                 "PinString",
                 &ppmuPinlist)
      .setDefault("")
      .setComment("names of pins to be tested using PPMU");
    addParameter("UsePPMU.testCurrent_uA",
                 "string",
                 &ppmuTestCurrent_uA)
      .setDefault("10")
      .setComment("value of test current");
    addParameter("UsePPMU.settlingTime_ms",
                 "string",
                 &ppmuSettlingTime_ms)
      .setDefault("1")
      .setComment("extra settling time to system.");
    addParameter("UsePPMU.measureMode",
                 "string",
                 &ppmuMeasureMode)
      .setDefault("PAR")
      .setComment("options: PAR  SER");
    addParameter("UsePPMU.polarity",
                 "string",
                 &ppmuPolarity)
      .setDefault("SPOL")
      .setComment("single polarity or both polarities.");
    addParameter("UsePPMU.testName",
                 "string",
                 &ppmuTestName)
      .setComment("limit's Name");

    // parameters for SPMU
    addParameter("UseSPMU",
                 "string",
                 &spmuUsed)
      .setDefault("NO")
      .setOptions("YES:NO");
    addParameter("UseSPMU.pinlist",
                 "PinString",
                 &spmuPinlist)
      .setDefault("")
      .setComment("names of pins to be tested using SPMU ");
    addParameter("UseSPMU.testCurrent_uA",
                 "string",
                 &spmuTestCurrent_uA)
      .setDefault("10")
      .setComment("value of test current");
    addParameter("UseSPMU.settlingTime_ms",
                 "string",
                 &spmuSettlingTime_ms)
      .setDefault("1")
      .setComment("extra settling time to system.");
    addParameter("UseSPMU.polarity",
                 "string",
                 &spmuPolarity)
      .setDefault("SPOL")
      .setComment("single polarity or both polarities.");
    addParameter("UseSPMU.measureMode",
                 "string",
                 &spmuMeasureMode)
      .setDefault("PAR")
      .setComment("options: PAR  SER");
    addParameter("UseSPMU.prechargeToZeroVol",
                 "string",
                 &spmuPrechargeToZeroVol)
      .setDefault("ON")
      .setComment("options: ON  OFF \n precharge to 0 V before forcing current.");
    addParameter("UseSPMU.testName",
                 "string",
                 &spmuTestName)
      .setComment("limit's Name");

    // parameters for MCX-PMU
    addParameter("UseMCX-PMU",
                 "string",
                 &mcxUsed)
      .setDefault("NO")
      .setOptions("YES:NO");
    addParameter("UseMCX-PMU.pinlist",
                 "PinString",
                 &mcxPinlist)
      .setDefault("")
      .setComment("names of pins to be tested using SPMU ");
    addParameter("UseMCX-PMU.testCurrent_uA",
                 "string",
                 &mcxTestCurrent_uA)
      .setDefault("10")
      .setComment("value of test current");
    addParameter("UseMCX-PMU.settlingTime_ms",
                 "string",
                 &mcxSettlingTime_ms)
      .setDefault("1")
      .setComment("extra settling time to system.");
    addParameter("UseMCX-PMU.polarity",
                 "string",
                 &mcxPolarity)
      .setDefault("SPOL")
      .setComment("single polarity or both polarities.");
    addParameter("UseMCX-PMU.measureMode",
                 "string",
                 &mcxMeasureMode)
      .setDefault("PAR")
      .setComment("options: PAR  SER");
    addParameter("UseMCX-PMU.testName",
                 "string",
                 &mcxTestName)
      .setComment("limit's Name");

    // parameters for dcscale pin in SIG mode
    addParameter("UseDCScaleSIG",
                 "string",
                 &dcScaleSIGUsed)
      .setDefault("NO")
      .setOptions("YES:NO");
    addParameter("UseDCScaleSIG.pinlist",
                 "PinString",
                 &dcScaleSIGPinlist)
      .setDefault("")
      .setComment("names of pins to be tested using SPMU ");
    addParameter("UseDCScaleSIG.testCurrent_uA",
                 "string",
                 &dcScaleSIGTestCurrent_uA)
      .setDefault("10")
      .setComment("value of test current");
    addParameter("UseDCScaleSIG.settlingTime_ms",
                 "string",
                 &dcScaleSIGSettlingTime_ms)
      .setDefault("1")
      .setComment("extra settling time to system.");
    addParameter("UseDCScaleSIG.polarity",
                 "string",
                 &dcScaleSIGPolarity)
      .setDefault("SPOL")
      .setComment("single polarity or both polarities.");
    addParameter("UseDCScaleSIG.measureMode",
                 "string",
                 &dcScaleSIGMeasureMode)
      .setDefault("PAR")
      .setComment("options: PAR  SER");
    addParameter("UseDCScaleSIG.prechargeToZeroVol",
                 "string",
                 &dcScaleSIGPrechargeToZeroVol)
      .setDefault("ON")
      .setComment("options: ON  OFF \n precharge to 0 V before forcing current.");
    addParameter("UseDCScaleSIG.testName",
                 "string",
                 &dcScaleSIGTestName)
      .setComment("limit's Name");

    // parameters for DPS
    addParameter("UseDCScaleDPS",
                 "string",
                 &dcScaleDPSUsed)
      .setDefault("NO")
      .setOptions("YES:NO");
    addParameter("UseDCScaleDPS.pinlist",
                 "PinString",
                 &dcScaleDPSPinlist)
      .setDefault("")
      .setComment("names of pins to be tested using DCScaleDPS");
    addParameter("UseDCScaleDPS.specName",
                 "string",
                 &dcScaleDPSSpecName)
      .setComment("spec variable for every group setup");
    addParameter("UseDCScaleDPS.specValue",
                 "string",
                 &dcScaleDPSSpecValue)
      .setDefault("3.0")
      .setComment("spec value for every group setup.");
    addParameter("UseDCScaleDPS.settlingTime_ms",
                 "string",
                 &dcScaleDPSSettlingTime_ms)
      .setDefault("1")
      .setComment("extra settling time to system.");
    addParameter("UseDCScaleDPS.measureMode",
                 "string",
                 &dcScaleDPSMeasureMode)
      .setDefault("PAR")
      .setComment("options: PAR  SER");
    addParameter("UseDCScaleDPS.polarity",
                 "string",
                 &dcScaleDPSPolarity)
      .setDefault("SPOL")
      .setComment("single polarity or both polarities.");
    addParameter("UseDCScaleDPS.testName",
                 "string",
                 &dcScaleDPSTestName)
      .setComment("limit's Name");

    // parameters for DPS
    addParameter("UseDPS",
                 "string",
                 &dpsUsed)
      .setDefault("NO")
      .setOptions("YES:NO");
    addParameter("UseDPS.pinlist",
                 "PinString",
                 &dpsPinlist)
      .setDefault("")
      .setComment("names of pins to be tested using DPS");
    addParameter("UseDPS.specName",
                 "string",
                 &dpsSpecName)
      .setComment("spec variable for every group setup");
    addParameter("UseDPS.specValue",
                 "string",
                 &dpsSpecValue)
      .setDefault("3.0")
      .setComment("spec value for every group setup.");
    addParameter("UseDPS.settlingTime_ms",
                 "string",
                 &dpsSettlingTime_ms)
      .setDefault("1")
      .setComment("extra settling time to system.");
    addParameter("UseDPS.measureMode",
                 "string",
                 &dpsMeasureMode)
      .setDefault("PAR")
      .setComment("options: PAR  SER");
    addParameter("UseDPS.polarity",
                 "string",
                 &dpsPolarity)
      .setDefault("SPOL")
      .setComment("single polarity or both polarities.");
    addParameter("UseDPS.testName",
                 "string",
                 &dpsTestName)
      .setComment("limit's Name");


    addParameter("output",
                 "string",
                 &output)
      .setDefault("None")
      .setOptions("None:ReportUI")
      .setComment("print out information on UI window");

    isParameterChanged = true;
  }
  
  /**
   *This test is invoked per site.
   */
  virtual void run()
  { 
    static ContinuityTest::ContinuityTestResult result;

    ON_FIRST_INVOCATION_BEGIN();
      /*
       * Process all parameters needed in test. Actually this function is
       * called once under multisite because all input parameters should be
       * the same through all sites. The processed parameters are stored into
       * the static variable 'param' for later reference on all sites.
       */
      if(isParameterChanged)
      {
        ContinuityTest::processParameters(ppmuUsed,     // ppmu's parameters block begin
                                          ppmuPinlist,
                                          ppmuTestCurrent_uA,
                                          ppmuSettlingTime_ms,
                                          ppmuMeasureMode,
                                          ppmuPolarity,
                                          ppmuTestName, // ppmu's parameters block end

                                          spmuUsed,     // spmu's parameters block begin
                                          spmuPinlist,
                                          spmuTestCurrent_uA,
                                          spmuSettlingTime_ms,
                                          spmuMeasureMode,
                                          spmuPolarity,
                                          spmuPrechargeToZeroVol,
                                          spmuTestName, // spmu's parameters block end

                                          mcxUsed,      // mcx-pmu's parameters block begin
                                          mcxPinlist,
                                          mcxTestCurrent_uA,
                                          mcxSettlingTime_ms,
                                          mcxMeasureMode,
                                          mcxPolarity,
                                          mcxTestName,  // mcx-pmu's parameters block end

                                          dcScaleSIGUsed, // dcScaleSIG's parameters block begin
                                          dcScaleSIGPinlist,
                                          dcScaleSIGTestCurrent_uA,
                                          dcScaleSIGSettlingTime_ms,
                                          dcScaleSIGMeasureMode,
                                          dcScaleSIGPolarity,
                                          dcScaleSIGPrechargeToZeroVol,
                                          dcScaleSIGTestName, // dcScaleSIG's parameters block end

                                          dcScaleDPSUsed,     // dcScaleDPS's parameters block begin
                                          dcScaleDPSPinlist,
                                          dcScaleDPSSpecName,
                                          dcScaleDPSSpecValue,
                                          dcScaleDPSSettlingTime_ms,
                                          dcScaleDPSPolarity,
                                          dcScaleDPSMeasureMode,
                                          dcScaleDPSTestName, // dcScaleDPS's parameters block end

                                          dpsUsed,     // dps's parameters block begin
                                          dpsPinlist,
                                          dpsSpecName,
                                          dpsSpecValue,
                                          dpsSettlingTime_ms,
                                          dpsPolarity,
                                          dpsMeasureMode,
                                          dpsTestName,  // dps's parameters block end

                                          param);
        isParameterChanged = false;
      }
    ON_FIRST_INVOCATION_END();

    /*
     * Execute measurement with the specified 'param' and store results
     * into the 'result'. The multisite handling, i.e.
     * ON_FIRST_INVOCATION block are executed inside this function.
     */
    ContinuityTest::doMeasurement(param, result);

    /*
     * Judge and datalog based on the 'result'. This function uses
     * testsuite name as test name, so if you'd like to use your own
     * test names for judgement and datalogging it's needed to modify
     * this funciton or create new one.
     */
    ContinuityTest::judgeAndDatalog(param, result);

    /*
     * Output contents of the 'result' to Report Window if specified by
     * the "output" parameter.
     */
    ContinuityTest::reportToUI(param, result, output);
  
    return ;
  }
  
  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   *
   *Note: TestMethod API should not be used in this method.
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    isParameterChanged = true;
    if("UsePPMU" == parameterIdentifier) 
    {
      bool toVisible = ("YES" == ppmuUsed);
      getParameter("UsePPMU.pinlist").setVisible(toVisible);
      getParameter("UsePPMU.testCurrent_uA").setVisible(toVisible);
      getParameter("UsePPMU.settlingTime_ms").setVisible(toVisible);
      getParameter("UsePPMU.polarity").setVisible(toVisible);
      getParameter("UsePPMU.measureMode").setVisible(toVisible);
      getParameter("UsePPMU.testName").setVisible(toVisible);
    }
    else if("UseSPMU" == parameterIdentifier) 
    {
      bool toVisible = ("YES" == spmuUsed);
      getParameter("UseSPMU.pinlist").setVisible(toVisible);
      getParameter("UseSPMU.testCurrent_uA").setVisible(toVisible);
      getParameter("UseSPMU.settlingTime_ms").setVisible(toVisible);
      getParameter("UseSPMU.polarity").setVisible(toVisible);
      getParameter("UseSPMU.measureMode").setVisible(toVisible);
      getParameter("UseSPMU.prechargeToZeroVol").setVisible(toVisible);
      getParameter("UseSPMU.testName").setVisible(toVisible);
    }
    else if("UseMCX-PMU" == parameterIdentifier) 
    {
      bool toVisible = ("YES" == mcxUsed);
      getParameter("UseMCX-PMU.pinlist").setVisible(toVisible);
      getParameter("UseMCX-PMU.testCurrent_uA").setVisible(toVisible);
      getParameter("UseMCX-PMU.settlingTime_ms").setVisible(toVisible);
      getParameter("UseMCX-PMU.polarity").setVisible(toVisible);
      getParameter("UseMCX-PMU.measureMode").setVisible(toVisible);
      getParameter("UseMCX-PMU.testName").setVisible(toVisible);
    }
    else if("UseDCScaleSIG" == parameterIdentifier) 
    {
      bool toVisible = ("YES" == dcScaleSIGUsed);
      getParameter("UseDCScaleSIG.pinlist").setVisible(toVisible);
      getParameter("UseDCScaleSIG.testCurrent_uA").setVisible(toVisible);
      getParameter("UseDCScaleSIG.settlingTime_ms").setVisible(toVisible);
      getParameter("UseDCScaleSIG.polarity").setVisible(toVisible);
      getParameter("UseDCScaleSIG.measureMode").setVisible(toVisible);
      getParameter("UseDCScaleSIG.prechargeToZeroVol").setVisible(toVisible);
      getParameter("UseDCScaleSIG.testName").setVisible(toVisible);
    }
    else if("UseDCScaleDPS" == parameterIdentifier) 
    {
      bool toVisible = ("YES" == dcScaleDPSUsed);
      getParameter("UseDCScaleDPS").setVisible(false);
      getParameter("UseDCScaleDPS.pinlist").setVisible(toVisible);
      getParameter("UseDCScaleDPS.specName").setVisible(toVisible);
      getParameter("UseDCScaleDPS.specValue").setVisible(toVisible);
      getParameter("UseDCScaleDPS.settlingTime_ms").setVisible(toVisible);
      getParameter("UseDCScaleDPS.polarity").setVisible(toVisible);
      getParameter("UseDCScaleDPS.measureMode").setVisible(toVisible);
      getParameter("UseDCScaleDPS.testName").setVisible(toVisible);
    }
    else if("UseDPS" == parameterIdentifier) 
    {
      bool toVisible = ("YES" == dpsUsed);
      getParameter("UseDPS").setVisible(false);
      getParameter("UseDPS.pinlist").setVisible(toVisible);
      getParameter("UseDPS.specName").setVisible(toVisible);
      getParameter("UseDPS.specValue").setVisible(toVisible);
      getParameter("UseDPS.settlingTime_ms").setVisible(toVisible);
      getParameter("UseDPS.polarity").setVisible(toVisible);
      getParameter("UseDPS.measureMode").setVisible(toVisible);
      getParameter("UseDPS.testName").setVisible(toVisible);
    }
    return ;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string  getComment() const
  {
     static string comment = "version: tml_7.1.2_2.1.4";
     return comment;
  }
};

REGISTER_TESTMETHOD("DcTest.Continuity", Continuity);
