#ifndef CONTINUITYIMP_CPP_
#define CONTINUITYIMP_CPP_

#include "ContinuityTestUtil.hpp"

typedef  ContinuityTestUtil::MeasurementResultContainer MeasurementResultContainer;

/***************************************************************************
 *                    continuity test implementation class
 ***************************************************************************
 */
class ContinuityTest
{
private:

  // ppmu group parameter
  struct PPMUGroupParam
  {
    //original input parameters
    string pinlist;
    double testCurrentFirstPol;//[TWO_POL];
    double testCurrentSecondPol;
    double settlingTime;
    string measureMode;
    string polarity;
    LIMIT  firstLimit;
    LIMIT  secondLimit;
    string limitName;

    // new generated parameter for convenience
    vector<string> expandedPins;   // expanded and validated pins stored in Vector
    bool isHVGroup;

    // initialize stuff to some defaults.
    void init()
    {
      pinlist = "";
      testCurrentFirstPol = 0.0;
      testCurrentSecondPol = 0.0;
      settlingTime = 0.0;
      expandedPins.clear();
      measureMode = "";
      polarity = "";
      limitName = "";
      isHVGroup = false;
    }

    //default constructor for intializing parameters
    PPMUGroupParam()
    {
      init();
    }
  };

  // spmu group parameter
  struct SPMUGroupParam
  {
    //original input parameters
    string pinlist;
    double testCurrentFirstPol;
    double testCurrentSecondPol;
    double settlingTime;
    string measureMode;
    string polarity;
    string prechargeToZeroVol;
    LIMIT  firstLimit;
    LIMIT  secondLimit;
    string limitName;

    // new generated parameter for convenience
    vector<string> expandedPins;   // expanded and validated pins stored in Vector

    // initialize stuff to some defaults.
    void init()
    {
      pinlist = "";
      testCurrentFirstPol = 0.0;
      testCurrentSecondPol = 0.0;
      settlingTime = 0.0;
      measureMode = "";
      prechargeToZeroVol = "";
      expandedPins.clear();
      polarity = "";
      limitName = "";
    }

    //default constructor for intializing parameters
    SPMUGroupParam()
    {
      init();
    }
  };

  // mcx pmu group parameter
  struct MCXGroupParam
  {
    //original input parameters
    string pinlist;
    double testCurrentFirstPol;
    double testCurrentSecondPol;
    double settlingTime;
    string measureMode;
    string polarity;
    LIMIT  firstLimit;
    LIMIT  secondLimit;
    string limitName;

    // new generated parameter for convenience
    vector<string> expandedPins;   // expanded and validated pins stored in Vector

    // initialize stuff to some defaults.
    void init()
    {
      pinlist = "";
      testCurrentFirstPol = 0.0;
      testCurrentSecondPol = 0.0;
      settlingTime = 0.0;
      measureMode = "";
      polarity = "";
      expandedPins.clear();
      limitName = "";
    }

    //default constructor for intializing parameters
    MCXGroupParam()
    {
      init();
    }
  };

  // dc scale pin in SIG mode group parameter
  struct DCScaleSIGGroupParam
  {
    //original input parameters
    string pinlist;
    double testCurrentFirstPol;
    double testCurrentSecondPol;
    double settlingTime;
    string measureMode;
    string prechargeToZeroVol;
    string polarity;
    LIMIT  firstLimit;
    LIMIT  secondLimit;
    string limitName;

    // new generated parameter for convenience
    vector<string> expandedPins;   // expanded and validated pins stored in Vector

    // initialize stuff to some defaults.
    void init()
    {
      pinlist = "";
      testCurrentFirstPol = 0.0;
      testCurrentSecondPol = 0.0;
      settlingTime = 0.0;
      measureMode = "";
      prechargeToZeroVol = "";
      polarity = "";
      expandedPins.clear();
      limitName = "";
    }

    //default constructor for intializing parameters
    DCScaleSIGGroupParam()
    {
      init();
    }
  };

  // dc scale pin in DPS mode group parameter
  struct DCScaleDPSGroupParam
  {
    //original input parameters
    string pinlist;
    string specName;
    double specValueFirstPol;
    double specValueSecondPol;
    double settlingTime;
    string measureMode;
    string polarity;
    LIMIT  firstLimit;
    LIMIT  secondLimit;
    string limitName;

    // new generated parameter for convenience
    vector<string> expandedPins;   // expanded and validated pins stored in Vector
    
    // initialize stuff to some defaults.
    void init()
    {
      pinlist = "";
      specName = "";
      specValueFirstPol = 0.0;
      specValueSecondPol = 0.0;
      settlingTime = 0.0;
      measureMode = "";
      polarity = "";
      expandedPins.clear();
      limitName = "";
    }

    //default constructor for intializing parameters
    DCScaleDPSGroupParam()
    {
      init();
    }
  };
  // dps group parameter
  struct DPSGroupParam
  {
    //original input parameters
    string pinlist;
    string specName;
    double specValueFirstPol;
    double specValueSecondPol;
    double settlingTime;
    string measureMode;
    string polarity;
    LIMIT  firstLimit;
    LIMIT  secondLimit;
    string limitName;

    // new generated parameter for convenience
    vector<string> expandedPins;   // expanded and validated pins stored in Vector

    // initialize stuff to some defaults.
    void init()
    {
      pinlist = "";
      specName = "";
      specValueFirstPol = 0.0;
      specValueSecondPol = 0.0;
      settlingTime = 0.0;
      measureMode = "";
      polarity = "";
      expandedPins.clear();
      limitName = "";
    }

    //default constructor for intializing parameters
    DPSGroupParam()
    {
      init();
    }
  };

public:

  /*
   *----------------------------------------------------------------------*
   *         test results container                                       *
   *----------------------------------------------------------------------*
   */
  struct ContinuityTestResult
  {
    vector<MeasurementResultContainer> ppmuFirstMeasureResultVec;
    vector<MeasurementResultContainer> ppmuSecondMeasureResultVec;

    vector<MeasurementResultContainer> spmuFirstMeasureResultVec;
    vector<MeasurementResultContainer> spmuSecondMeasureResultVec;

    vector<MeasurementResultContainer> mcxFirstMeasureResultVec;
    vector<MeasurementResultContainer> mcxSecondMeasureResultVec;

    vector<MeasurementResultContainer> dcScaleSIGFirstMeasureResultVec;
    vector<MeasurementResultContainer> dcScaleSIGSecondMeasureResultVec;

    vector<MeasurementResultContainer> dcScaleDPSFirstMeasureResultVec;
    vector<MeasurementResultContainer> dcScaleDPSSecondMeasureResultVec;

    vector<MeasurementResultContainer> dpsFirstMeasureResultVec;
    vector<MeasurementResultContainer> dpsSecondMeasureResultVec;


    void init()
    {
      ppmuFirstMeasureResultVec.clear();
      ppmuSecondMeasureResultVec.clear();

      spmuFirstMeasureResultVec.clear();
      spmuSecondMeasureResultVec.clear();

      mcxFirstMeasureResultVec.clear();
      mcxSecondMeasureResultVec.clear();

      dcScaleSIGFirstMeasureResultVec.clear();
      dcScaleSIGSecondMeasureResultVec.clear();

      dcScaleDPSFirstMeasureResultVec.clear();
      dcScaleDPSSecondMeasureResultVec.clear();

      dpsFirstMeasureResultVec.clear();
      dpsSecondMeasureResultVec.clear();

    }

    ContinuityTestResult()
    {
      init();
    }
  };
  /*
   *----------------------------------------------------------------------*
   *         test parameters container                                    *
   *----------------------------------------------------------------------*
   */
  struct ContinuityTestParam
  {
    string ppmuUsed;
    vector<PPMUGroupParam> ppmuGroups;
    bool isPPMULimitAppliedForAllGroups;

    string spmuUsed;
    vector<SPMUGroupParam> spmuGroups;
    bool isSPMULimitAppliedForAllGroups;

    string mcxUsed;
    vector<MCXGroupParam> mcxGroups;
    bool isMCXLimitAppliedForAllGroups;

    string dcScaleSIGUsed;
    vector<DCScaleSIGGroupParam> dcScaleSIGGroups;
    bool isDCScaleSIGLimitAppliedForAllGroups;

    string dcScaleDPSUsed;
    vector<DCScaleDPSGroupParam> dcScaleDPSGroups;
    bool isDCScaleDPSLimitAppliedForAllGroups;

    string dpsUsed;
    vector<DPSGroupParam> dpsGroups;
    bool isDPSLimitAppliedForAllGroups;

    // new generated parameter for convenience
    string testsuiteName;   // current testsuite name
    TM::DCTEST_MODE testMode;
    
    bool isLimitTableUsed; // if limit table is used

    void init()
    {
      ppmuUsed = "YES";
      spmuUsed = "NO";
      mcxUsed = "NO";
      dcScaleSIGUsed = "NO";
      dcScaleDPSUsed = "NO";
      dpsUsed = "NO";
      isLimitTableUsed = false;

      ppmuGroups.clear();

      spmuGroups.clear();
      mcxGroups.clear();
      dcScaleSIGGroups.clear();
      dcScaleDPSGroups.clear();
      dpsGroups.clear();
      isPPMULimitAppliedForAllGroups = false;
      isSPMULimitAppliedForAllGroups = false;
      isMCXLimitAppliedForAllGroups = false;
      isDCScaleSIGLimitAppliedForAllGroups = false;
      isDCScaleDPSLimitAppliedForAllGroups = false;
      isDPSLimitAppliedForAllGroups = false;
      testMode = TM::GPF;
    }

    //default constructor for intializing parameters
    ContinuityTestParam()
    {
      init();
    }
  };


/*
 *----------------------------------------------------------------------*
 *         public interfaces of continuity test                         *
 *----------------------------------------------------------------------*
 */

/*
 *----------------------------------------------------------------------*
 * Routine: processParameter
 *
 * Purpose: parse input parameters and setup internal parameters
 *
 *----------------------------------------------------------------------*
 * Description:
 *
 * Note:
 *----------------------------------------------------------------------*
 */
  static void processParameters(const string& ppmuUsed,
                                const string& ppmuPinlist,
                                const string& ppmuTestCurrent_uA,
                                const string& ppmuSettlingTime_ms,
                                const string& ppmuMeasureMode,
                                const string& ppmuPolarity,
                                const string& ppmuTestName,

                                const string& spmuUsed,
                                const string& spmuPinlist,
                                const string& spmuTestCurrent_uA,
                                const string& spmuSettlingTime_ms,
                                const string& spmuMeasureMode,
                                const string& spmuPolarity,
                                const string& spmuPrechargeToZeroVol,
                                const string& spmuTestName,

                                const string& mcxUsed,
                                const string& mcxPinlist,
                                const string& mcxTestCurrent_uA,
                                const string& mcxSettlingTime_ms,
                                const string& mcxMeasureMode,
                                const string& mcxPolarity,
                                const string& mcxTestName,

                                const string& dcScaleSIGUsed,
                                const string& dcScaleSIGPinlist,
                                const string& dcScaleSIGTestCurrent_uA,
                                const string& dcScaleSIGSettlingTime_ms,
                                const string& dcScaleSIGMeasureMode,
                                const string& dcScaleSIGPolarity,
                                const string& dcScaleSIGPrechargeToZeroVol,
                                const string& dcScaleSIGTestName,

                                const string& dcScaleDPSUsed,         
                                const string& dcScaleDPSPinlist,
                                const string& dcScaleDPSSpecName,
                                const string& dcScaleDPSSpecValue,
                                const string& dcScaleDPSSettlingTime_ms,
                                const string& dcScaleDPSPolarity,
                                const string& dcScaleDPSMeasureMode,
                                const string& dcScaleDPSTestName, 

                                const string& dpsUsed,        
                                const string& dpsPinlist,
                                const string& dpsSpecName,
                                const string& dpsSpecValue,
                                const string& dpsSettlingTime_ms,
                                const string& dpsPolarity,
                                const string& dpsMeasureMode,
                                const string& dpsTestName, 

                                ContinuityTest::ContinuityTestParam& param)
  {
    // initial param
    param.init();

    param.testMode = ContinuityTestUtil::getMode();
    GET_TESTSUITE_NAME(param.testsuiteName);

    /**
     *this map is used to store the relationship: pin group instrument
     * map< string, pair<string,string> >
     *        |            |        |
     *        |            |        |
     *     pinName     groupName  InstrumentName
     *
     * we use this map to check that whether there are the same pin exist
     * in different groups or not.
     */
    map<string,pair<string,string> > pinAndGroupMap;
    
    // check whether limit table is used.
    TesttableLimitHelper testtableHelper(param.testsuiteName);

    string tempString = ContinuityTestUtil::ContinuityTestUtil::trim(ppmuUsed);   
    if("YES" == tempString || "NO" == tempString )
    {
      param.ppmuUsed = tempString;
    }
    else
    {
      throw Error("ContinuityTest::processParameters()",
                  "UsePPMU must be YES or NO",
                  "ContinuityTest::processParameters()");
    }

    tempString = ContinuityTestUtil::trim(spmuUsed);
    if("YES" == tempString || "NO" == tempString )
    {
      param.spmuUsed = tempString;
    }
    else
    {
      throw Error("ContinuityTest::processParameters()",
                  "UseSPMU must be YES or NO",
                  "ContinuityTest::processParameters()");
    }

    tempString = ContinuityTestUtil::trim(mcxUsed);
    if("YES" == tempString || "NO" == tempString )
    {
      param.mcxUsed = tempString;
    }
    else
    {
      throw Error("ContinuityTest::processParameters()",
                  "UseMCX-PMU must be YES or NO",
                  "ContinuityTest::processParameters()");
    }


    tempString = ContinuityTestUtil::trim(dcScaleSIGUsed);
    if("YES" == tempString || "NO" == tempString )
    {
      param.dcScaleSIGUsed = tempString;
    }
    else
    {
      throw Error("ContinuityTest::processParameters()",
                  "UseDCScaleSIG must be YES or NO",
                  "ContinuityTest::processParameters()");
    }

    tempString = ContinuityTestUtil::trim(dcScaleDPSUsed);
    if("YES" == tempString || "NO" == tempString )
    {
      param.dcScaleDPSUsed = tempString;
    }
    else
    {
      throw Error("ContinuityTest::processParameters()",
                  "UseDCScaleDPS must be YES or NO",
                  "ContinuityTest::processParameters()");
    }

    tempString = ContinuityTestUtil::trim(dpsUsed);
    if("YES" == tempString || "NO" == tempString )
    {
      param.dpsUsed = tempString;
    }
    else
    {
      throw Error("ContinuityTest::processParameters()",
                  "UseDPS must be YES or NO",
                  "ContinuityTest::processParameters()");
    }

    if("NO" == param.ppmuUsed &&
       "NO" == param.spmuUsed &&
       "NO" == param.mcxUsed &&
       "NO" == param.dcScaleSIGUsed &&
       "NO" == param.dcScaleDPSUsed &&
       "NO" == param.dpsUsed)
    {
      throw Error("ContinuityTest::processParameters()",
                  "No instruments is selected to do measurement.",
                  "ContinuityTest::processParameters()");
    }

    if("YES" == param.ppmuUsed)
    {
      vector<string> ppmuPinlistVec;
      vector<double> ppmuTestCurrentVec;
      vector<string> ppmuMeasureModeVec;
      vector<string> ppmuPolarityVec;
      vector<double> ppmuSettlingTimeVec;
      vector<string> ppmuTestNameVec;

      ContinuityTestUtil::parseListOfString(ppmuPinlist,ppmuPinlistVec);
      ContinuityTestUtil::parseListOfDouble(ppmuTestCurrent_uA,ppmuTestCurrentVec);
      ContinuityTestUtil::parseListOfDouble(ppmuSettlingTime_ms,ppmuSettlingTimeVec);
      ContinuityTestUtil::parseListOfString(ppmuMeasureMode,ppmuMeasureModeVec);
      ContinuityTestUtil::parseListOfString(ppmuPolarity,ppmuPolarityVec);
      ContinuityTestUtil::parseListOfString(ppmuTestName,ppmuTestNameVec);

      vector<string>::size_type groupSize = ppmuPinlistVec.size();
      if(groupSize == 0)
      {
        throw Error("ContinuityTest::processParameters()",
                    "PPMU: the pinlist groups can not be empty.",
                    "ContinuityTest::processParameters()");
      }

      ContinuityTestUtil::checkParameter(groupSize,
                                         ppmuTestCurrentVec.size(),
                                         "PPMU",
                                         "testCurrent_uA",
                                         ppmuTestCurrentVec);
      ContinuityTestUtil::checkParameter(groupSize,
                                         ppmuSettlingTimeVec.size(),
                                         "PPMU",
                                         "settlingTime_ms",
                                         ppmuSettlingTimeVec);
      ContinuityTestUtil::checkParameter(groupSize,
                                         ppmuMeasureModeVec.size(),
                                         "PPMU",
                                         "measureMode",
                                         ppmuMeasureModeVec);
      ContinuityTestUtil::checkParameter(groupSize,
                                         ppmuPolarityVec.size(),
                                         "PPMU",
                                         "polarity",
                                         ppmuPolarityVec);
      if(ppmuPinlistVec.size() != ppmuTestNameVec.size())
      {
        if(ppmuTestNameVec.size() != 1)
        {
          stringstream errMsg;
          errMsg <<"PPMU: the number of pinlist groups is "
                 << ppmuPinlistVec.size() <<endl
                 <<"      the number of testName groups is "
                 << ppmuTestNameVec.size() <<endl
                 <<"So the testName groups don't match pinlist groups." <<endl;
          throw Error("ContinuityTest::processParameters()",
                      errMsg.str(),
                      "ContinuityTest::processParameters()");
        }
        else
        {
          param.isPPMULimitAppliedForAllGroups = true;
          for(vector<string>::size_type i = 1; i < ppmuPinlistVec.size(); i++)
          {
            ppmuTestNameVec.push_back(ppmuTestNameVec[0]);
          }
        }
      }

      PPMUGroupParam ppmuGroupParam;
      // the following three variables is used for checking duplicate pins
      pair<map<string,pair<string,string> >::iterator,bool> ret;
      pair<string,string> groupAndInstrument;
      const string instrumentType = "PPMUInstrument";
      for(unsigned  i = 0; i< ppmuPinlistVec.size(); i++)
      {
        vector<string> ppmuHvPinlistVec;
        vector<string> nonHVppmuPinlistVec;
    	ppmuHvPinlistVec.clear();
    	nonHVppmuPinlistVec.clear();

        ppmuGroupParam.init();
        ppmuGroupParam.pinlist = ppmuPinlistVec[i];
        ppmuGroupParam.measureMode = ppmuMeasureModeVec[i];
        if(ppmuGroupParam.measureMode != "PAR" &&
           ppmuGroupParam.measureMode != "SER")
        {
          stringstream errMsg;
          errMsg <<"PPMU: for the " << i+1 << " group setup parameter, measureMode: "
                 <<ppmuGroupParam.measureMode << " is invalid."<<endl
                 <<"measureMode can only be the following options: PAR  SER" <<endl;
          throw Error("ContinuityTest::processParamters()",
                      errMsg.str(),
                      "ContinuityTest::processParamters()");
        }
        /*
         *********************************************************
         * Validate and expand pin names from input pinlist,
         * and meanwhile it detects DC pins,
         * if any DC pins exist, it throws an error.
         *********************************************************
         */
        if('#' != ppmuGroupParam.pinlist[0])
        {
          ppmuGroupParam.expandedPins = PinUtility.getDigitalPinNamesFromPinList(
              ppmuPinlistVec[i],
              TM::I_PIN|TM::O_PIN|TM::IO_PIN,true,true);
          // check the duplicate pins
          for(vector<string>::size_type index = 0;
              index < ppmuGroupParam.expandedPins.size();
              index++)
          {
            groupAndInstrument = make_pair(ppmuPinlistVec[i],instrumentType);
            ret =  pinAndGroupMap.insert(
                make_pair(ppmuGroupParam.expandedPins[index],groupAndInstrument));
            if(!ret.second)
            {
              stringstream errMsg;
              errMsg << "In the PPMUInstrument group: " << ppmuPinlistVec[i] <<endl
                     << "   and " << ret.first->second.second << " group: "
                     << ret.first->second.first <<endl
                     << "There are the same pin: "
                     << ppmuGroupParam.expandedPins[index] <<endl;
              throw Error("ContinuityTest::processParameters",
                          errMsg.str(),
                          "ContinuityTest::processParameters");
            }

            //Split the HVpins and Non-HVpins
            if( ContinuityTestUtil::isHvPin(ppmuGroupParam.expandedPins[index]))
            {
              ppmuHvPinlistVec.push_back(ppmuGroupParam.expandedPins[index]);
            }
            else
            {
              nonHVppmuPinlistVec.push_back(ppmuGroupParam.expandedPins[index]);
            }
          }
        }

        if(ppmuSettlingTimeVec[i]  < 0.0)
        {
          stringstream errMsg;
          errMsg << "PPMU: The " << i+1 << " group setup parameter's value is"
                 << ppmuSettlingTimeVec[i] << endl
                 << "settlingTime must be positive!";
          throw Error("ContinuityTest::processParameters",
                      errMsg.str(),
                      "ContinuityTest::processParameters");
        }
        ppmuGroupParam.settlingTime = ppmuSettlingTimeVec[i];
        ppmuGroupParam.testCurrentFirstPol = ppmuTestCurrentVec[i];
        ppmuGroupParam.polarity = ppmuPolarityVec[i];
        if(ppmuGroupParam.polarity != "SPOL" &&
           ppmuGroupParam.polarity != "BPOL")
        {
          stringstream errMsg;
          errMsg <<"PPMU: for the " << i+1 << " group setup parameter, polarity: "
                 <<ppmuGroupParam.polarity << " is invalid."<<endl
                 <<"polarity can only be the following options: SPOL  BPOL" <<endl;
          throw Error("ContinuityTest::processParamters()",
                      errMsg.str(),
                      "ContinuityTest::processParamters()");
        }

        ppmuGroupParam.limitName = ppmuTestNameVec[i];
        ContinuityTestUtil::getLimitInfo(ppmuTestNameVec[i],i,
                                         "mV",ppmuGroupParam.firstLimit,
                                         testtableHelper);
        if("BPOL" == ppmuGroupParam.polarity )
        {
          ppmuGroupParam.testCurrentSecondPol = -ppmuTestCurrentVec[i];
          ContinuityTestUtil::reverseLimit(ppmuGroupParam.firstLimit,ppmuGroupParam.secondLimit);
        }

        if(ppmuHvPinlistVec.size() > 0)
        {
          if(ppmuHvPinlistVec.size() == ppmuGroupParam.expandedPins.size()) //All pins are HV pin.
          {
            ppmuGroupParam.isHVGroup = true;
            param.ppmuGroups.push_back(ppmuGroupParam);
          }
          else
          {
            //Parameter of Non-HvPins
            ppmuGroupParam.expandedPins.clear();
            ppmuGroupParam.expandedPins = nonHVppmuPinlistVec;
            ppmuGroupParam.pinlist = PIN_UTILITY::createPinListFromPinNames(nonHVppmuPinlistVec);
            param.ppmuGroups.push_back(ppmuGroupParam);

            //Parameter of HvPins
            PPMUGroupParam ppmuHvGroupParam;
            ppmuHvGroupParam.init();
            clonePPMUGroupParam(ppmuGroupParam,ppmuHvGroupParam);
            ppmuHvGroupParam.isHVGroup = true;
            ppmuHvGroupParam.expandedPins = ppmuHvPinlistVec;
            ppmuHvGroupParam.pinlist = PIN_UTILITY::createPinListFromPinNames(ppmuHvPinlistVec);
            param.ppmuGroups.push_back(ppmuHvGroupParam);
          }
        }
        else  //all pins are non-hv pin.
        {
            param.ppmuGroups.push_back(ppmuGroupParam);
        }
      }
    }

    if("YES" == param.spmuUsed)
    {
      vector<string> spmuPinlistVec;
      vector<double> spmuTestCurrentVec;
      vector<string> spmuMeasureModeVec;
      vector<string> spmuPolarityVec;
      vector<double> spmuSettlingTimeVec;
      vector<string> spmuPrechargeToZeroVolVec;
      vector<string> spmuTestNameVec;

      ContinuityTestUtil::parseListOfString(spmuPinlist,spmuPinlistVec);
      ContinuityTestUtil::parseListOfDouble(spmuTestCurrent_uA,spmuTestCurrentVec);
      ContinuityTestUtil::parseListOfDouble(spmuSettlingTime_ms,spmuSettlingTimeVec);
      ContinuityTestUtil::parseListOfString(spmuMeasureMode,spmuMeasureModeVec);
      ContinuityTestUtil::parseListOfString(spmuPolarity,spmuPolarityVec);
      ContinuityTestUtil::parseListOfString(spmuPrechargeToZeroVol,spmuPrechargeToZeroVolVec);
      ContinuityTestUtil::parseListOfString(spmuTestName,spmuTestNameVec);

      vector<string>::size_type groupSize = spmuPinlistVec.size();
      if(groupSize == 0)
      {
        throw Error("ContinuityTest::processParameters()",
                    "SPMU: the pinlist groups can not be empty.",
                    "ContinuityTest::processParameters()");
      }

      ContinuityTestUtil::checkParameter(groupSize,
                                         spmuTestCurrentVec.size(),
                                         "SPMU",
                                         "testCurrent_uA",
                                         spmuTestCurrentVec);
      ContinuityTestUtil::checkParameter(groupSize,
                                         spmuSettlingTimeVec.size(),
                                         "SPMU",
                                         "settlingTime_ms",
                                         spmuSettlingTimeVec);
      ContinuityTestUtil::checkParameter(groupSize,
                                         spmuMeasureModeVec.size(),
                                         "SPMU",
                                         "measureMode",
                                         spmuMeasureModeVec);
      ContinuityTestUtil::checkParameter(groupSize,
                                         spmuPolarityVec.size(),
                                         "SPMU",
                                         "polarity",
                                         spmuPolarityVec);
      ContinuityTestUtil::checkParameter(groupSize,
                                         spmuPrechargeToZeroVolVec.size(),
                                         "SPMU",
                                         "prechargeToZeroVol",
                                         spmuPrechargeToZeroVolVec);

      if(spmuPinlistVec.size() != spmuTestNameVec.size())
      {
        if(spmuTestNameVec.size() != 1)
        {
          stringstream errMsg;
          errMsg <<"SPMU: the number of pinlist groups is "
                 << spmuPinlistVec.size() <<endl
                 <<"      the number of testName groups is "
                 << spmuTestNameVec.size() <<endl
                 <<"So the testName groups don't match pinlist groups." <<endl;
          throw Error("ContinuityTest::processParameters()",
                      errMsg.str(),
                      "ContinuityTest::processParameters()");
        }
        else
        {
          param.isSPMULimitAppliedForAllGroups = true;
          for(vector<string>::size_type i = 1; i < spmuPinlistVec.size(); i++)
          {
            spmuTestNameVec.push_back(spmuTestNameVec[0]);
          }
        }
      }

      SPMUGroupParam spmuGroupParam;
      //the following three variables is used for checking the duplicate pins
      pair<map<string,pair<string,string> >::iterator,bool> ret;
      pair<string,string> groupAndInstrument;
      const string instrumentType = "SPMUInstrument";
      for(unsigned  i = 0; i< spmuPinlistVec.size(); i++)
      {
        spmuGroupParam.init();
        spmuGroupParam.pinlist = spmuPinlistVec[i];
        spmuGroupParam.measureMode = spmuMeasureModeVec[i];
        if(spmuGroupParam.measureMode != "PAR" &&
           spmuGroupParam.measureMode != "SER")
        {
          stringstream errMsg;
          errMsg <<"SPMU: for the " << i+1 << " group setup parameter, measureMode: "
                 <<spmuGroupParam.measureMode << " is invalid."<<endl
                 <<"measureMode can only be the following options: PAR  SER" <<endl;
          throw Error("ContinuityTest::processParamters()",
                      errMsg.str(),
                      "ContinuityTest::processParamters()");
        }
        spmuGroupParam.prechargeToZeroVol = spmuPrechargeToZeroVolVec[i];
        if(spmuGroupParam.prechargeToZeroVol != "ON" &&
           spmuGroupParam.prechargeToZeroVol != "OFF")
        {
          stringstream errMsg;
          errMsg <<"SPMU: for the " << i+1 << " group setup parameter, prechargeToZeroVol: "
                 <<spmuGroupParam.prechargeToZeroVol << " is invalid."<<endl
                 <<"prechargeToZeroVol can only be the following options: ON  OFF" <<endl;
          throw Error("ContinuityTest::processParamters()",
                      errMsg.str(),
                      "ContinuityTest::processParamters()");
        }
        /*
         *********************************************************
         * Validate and expand pin names from input pinlist,
         * and meanwhile it detects DC pins.
         *********************************************************
         */
        if('#' != spmuGroupParam.pinlist[0])
        {
          spmuGroupParam.expandedPins = PinUtility.getDigitalPinNamesFromPinList(
              spmuPinlistVec[i],
              TM::I_PIN|TM::O_PIN|TM::IO_PIN|TM::DC_PIN,true,true);
          // check the duplicate pins
          for(vector<string>::size_type index = 0;
              index < spmuGroupParam.expandedPins.size();
              index++)
          {
            groupAndInstrument = make_pair(spmuPinlistVec[i],instrumentType);
            ret =  pinAndGroupMap.insert(
                make_pair(spmuGroupParam.expandedPins[index],groupAndInstrument));
            if(!ret.second)
            {
              stringstream errMsg;
              errMsg << "In the SPMUInstrument group: " << spmuPinlistVec[i] <<endl
                     << "   and " << ret.first->second.second << " group: "
                     << ret.first->second.first <<endl
                     << "There are the same pin: "
                     << spmuGroupParam.expandedPins[index] <<endl;
              throw Error("ContinuityTest::processParameters",
                          errMsg.str(),
                          "ContinuityTest::processParameters");
            }

            if(ContinuityTestUtil::isHvPin(spmuGroupParam.expandedPins[index]))
            {
                stringstream errMsg;
                errMsg << "In the SPMUInstrument group:" << spmuPinlistVec[i] <<endl
                       << "There is HV pin: " << spmuGroupParam.expandedPins[index] << endl;
                throw Error("ContinuityTest::processParameters",
                            errMsg.str(),
                            "ContinuityTest::processParameters");
            }
          }
        }

        if(spmuSettlingTimeVec[i]  < 0.0)
        {
          stringstream errMsg;
          errMsg << "SPMU: The " << i+1 << " group setup parameter's value is"
                 << spmuSettlingTimeVec[i] << endl
                 << "settlingTime must be positive!";
          throw Error("ContinuityTest::processParameters",
                      errMsg.str(),
                      "ContinuityTest::processParameters");
        }
        spmuGroupParam.settlingTime = spmuSettlingTimeVec[i];
        spmuGroupParam.testCurrentFirstPol = spmuTestCurrentVec[i];
        spmuGroupParam.polarity = spmuPolarityVec[i];
        if(spmuGroupParam.polarity != "SPOL" &&
           spmuGroupParam.polarity != "BPOL")
        {
          stringstream errMsg;
          errMsg <<"SPMU: for the " << i+1 << " group setup parameter, polarity: "
                 <<spmuGroupParam.polarity << " is invalid."<<endl
                 <<"polarity can only be the following options: SPOL  BPOL" <<endl;
          throw Error("ContinuityTest::processParamters()",
                      errMsg.str(),
                      "ContinuityTest::processParamters()");
        }

        spmuGroupParam.limitName = spmuTestNameVec[i];
        ContinuityTestUtil::getLimitInfo(spmuTestNameVec[i],i,
                                         "mV",spmuGroupParam.firstLimit,
                                         testtableHelper);
        if("BPOL" == spmuGroupParam.polarity )
        {
          spmuGroupParam.testCurrentSecondPol = -spmuTestCurrentVec[i];
          ContinuityTestUtil::reverseLimit(spmuGroupParam.firstLimit,spmuGroupParam.secondLimit);
        }
        param.spmuGroups.push_back(spmuGroupParam);
      }
    }


    if("YES" == param.mcxUsed)
    {
      vector<string> mcxPinlistVec;
      vector<double> mcxTestCurrentVec;
      vector<string> mcxMeasureModeVec;
      vector<string> mcxPolarityVec;
      vector<double> mcxSettlingTimeVec;
      vector<string> mcxTestNameVec;

      ContinuityTestUtil::parseListOfString(mcxPinlist,mcxPinlistVec);
      ContinuityTestUtil::parseListOfDouble(mcxTestCurrent_uA,mcxTestCurrentVec);
      ContinuityTestUtil::parseListOfDouble(mcxSettlingTime_ms,mcxSettlingTimeVec);
      ContinuityTestUtil::parseListOfString(mcxMeasureMode,mcxMeasureModeVec);
      ContinuityTestUtil::parseListOfString(mcxPolarity,mcxPolarityVec);
      ContinuityTestUtil::parseListOfString(mcxTestName,mcxTestNameVec);

      vector<string>::size_type groupSize = mcxPinlistVec.size();
      if(groupSize == 0)
      {
        throw Error("ContinuityTest::processParameters()",
                    "MCX-PMU: the pinlist groups can not be empty.",
                    "ContinuityTest::processParameters()");
      }

      ContinuityTestUtil::checkParameter(groupSize,
                                         mcxTestCurrentVec.size(),
                                         "MCX-PMU",
                                         "testCurrent_uA",
                                         mcxTestCurrentVec);
      ContinuityTestUtil::checkParameter(groupSize,
                                         mcxSettlingTimeVec.size(),
                                         "MCX-PMU",
                                         "settlingTime_ms",
                                         mcxSettlingTimeVec);
      ContinuityTestUtil::checkParameter(groupSize,
                                         mcxMeasureModeVec.size(),
                                         "MCX-PMU",
                                         "measureMode",
                                         mcxMeasureModeVec);
      ContinuityTestUtil::checkParameter(groupSize,
                                         mcxPolarityVec.size(),
                                         "MCX-PMU",
                                         "polarity",
                                         mcxPolarityVec);

      if(mcxPinlistVec.size() != mcxTestNameVec.size())
      {
        if(mcxTestNameVec.size() != 1)
        {
          stringstream errMsg;
          errMsg <<"MCX-PMU: the number of pinlist groups is "
                 << mcxPinlistVec.size() <<endl
                 <<"         the number of testName groups is "
                 << mcxTestNameVec.size() <<endl
                 <<"So the testName groups don't match pinlist groups." <<endl;
          throw Error("ContinuityTest::processParameters()",
                      errMsg.str(),
                      "ContinuityTest::processParameters()");
        }
        else
        {
          param.isMCXLimitAppliedForAllGroups = true;
          for(vector<string>::size_type i = 1; i < mcxPinlistVec.size(); i++)
          {
            mcxTestNameVec.push_back(mcxTestNameVec[0]);
          }
        }
      }

      MCXGroupParam mcxGroupParam;
      //the following three variables is used for checking the duplicate pins
      pair<map<string,pair<string,string> >::iterator,bool> ret;
      pair<string,string> groupAndInstrument;
      const string instrumentType = "MCX-PMUInstrument";
      for(unsigned  i = 0; i< mcxPinlistVec.size(); i++)
      {
        mcxGroupParam.init();
        mcxGroupParam.pinlist = mcxPinlistVec[i];
        mcxGroupParam.measureMode = mcxMeasureModeVec[i];
        if(mcxGroupParam.measureMode != "PAR" &&
           mcxGroupParam.measureMode != "SER")
        {
          stringstream errMsg;
          errMsg <<"MCX-PMU: for the " << i+1 << " group setup parameter, measureMode: "
                 <<mcxGroupParam.measureMode << " is invalid."<<endl
                 <<"measureMode can only be the following options: PAR  SER" <<endl;
          throw Error("ContinuityTest::processParamters()",
                      errMsg.str(),
                      "ContinuityTest::processParamters()");
        }

        if('#' != mcxGroupParam.pinlist[0])
        {
          ContinuityTestUtil::parseListOfString(mcxGroupParam.pinlist,mcxGroupParam.expandedPins,',');
          // check the duplicate pins
          for(vector<string>::size_type index = 0;
              index < mcxGroupParam.expandedPins.size();
              index++)
          {
            groupAndInstrument = make_pair(mcxPinlistVec[i],instrumentType);
            ret =  pinAndGroupMap.insert(
                make_pair(mcxGroupParam.expandedPins[index],groupAndInstrument));
            if(!ret.second)
            {
              stringstream errMsg;
              errMsg << "In the MCX-PMUInstrument group: " << mcxPinlistVec[i] <<endl
                     << "   and " << ret.first->second.second << " group: "
                     << ret.first->second.first <<endl
                     << "There are the same pin: "
                     << mcxGroupParam.expandedPins[index] <<endl;
              throw Error("ContinuityTest::processParameters",
                          errMsg.str(),
                          "ContinuityTest::processParameters");
            }
          }
        }

        if(mcxSettlingTimeVec[i]  < 0.0)
        {
          stringstream errMsg;
          errMsg << "MCX-PMU: The " << i+1 << " group setup parameter's value is"
                 << mcxSettlingTimeVec[i] << endl
                 << "settlingTime must be positive!";
          throw Error("ContinuityTest::processParameters",
                      errMsg.str(),
                      "ContinuityTest::processParameters");
        }
        mcxGroupParam.settlingTime = mcxSettlingTimeVec[i];
        mcxGroupParam.testCurrentFirstPol = mcxTestCurrentVec[i];
        mcxGroupParam.polarity = mcxPolarityVec[i];
        if(mcxGroupParam.polarity != "SPOL" &&
           mcxGroupParam.polarity != "BPOL")
        {
          stringstream errMsg;
          errMsg <<"MCX-PMU: for the " << i+1 << " group setup parameter, measureMode: "
                 <<mcxGroupParam.polarity << " is invalid."<<endl
                 <<"polarity can only be the following options: SPOL  BPOL" <<endl;
          throw Error("ContinuityTest::processParamters()",
                      errMsg.str(),
                      "ContinuityTest::processParamters()");
        }

        mcxGroupParam.limitName = mcxTestNameVec[i];
        ContinuityTestUtil::getLimitInfo(mcxTestNameVec[i],i,
                                         "mV",mcxGroupParam.firstLimit,
                                          testtableHelper);
        if("BPOL" == mcxGroupParam.polarity )
        {
          mcxGroupParam.testCurrentSecondPol = -mcxTestCurrentVec[i];
          ContinuityTestUtil::reverseLimit(mcxGroupParam.firstLimit,mcxGroupParam.secondLimit);
        }
        param.mcxGroups.push_back(mcxGroupParam);
      }
    }


    if("YES" == param.dcScaleSIGUsed)
    {
      vector<string> dcScaleSIGPinlistVec;
      vector<double> dcScaleSIGTestCurrentVec;
      vector<string> dcScaleSIGMeasureModeVec;
      vector<string> dcScaleSIGPolarityVec;
      vector<double> dcScaleSIGSettlingTimeVec;
      vector<string> dcScaleSIGPrechargeToZeroVolVec;
      vector<string> dcScaleSIGTestNameVec;

      ContinuityTestUtil::parseListOfString(dcScaleSIGPinlist,dcScaleSIGPinlistVec);
      ContinuityTestUtil::parseListOfDouble(dcScaleSIGTestCurrent_uA,dcScaleSIGTestCurrentVec);
      ContinuityTestUtil::parseListOfDouble(dcScaleSIGSettlingTime_ms,dcScaleSIGSettlingTimeVec);
      ContinuityTestUtil::parseListOfString(dcScaleSIGMeasureMode,dcScaleSIGMeasureModeVec);
      ContinuityTestUtil::parseListOfString(dcScaleSIGPolarity,dcScaleSIGPolarityVec);
      ContinuityTestUtil::parseListOfString(dcScaleSIGPrechargeToZeroVol,dcScaleSIGPrechargeToZeroVolVec);
      ContinuityTestUtil::parseListOfString(dcScaleSIGTestName,dcScaleSIGTestNameVec);

      vector<string>::size_type groupSize = dcScaleSIGPinlistVec.size();
      if(groupSize == 0)
      {
        throw Error("ContinuityTest::processParameters()",
                    "DcScaleSIG: the pinlist groups can not be empty.",
                    "ContinuityTest::processParameters()");
      }

      ContinuityTestUtil::checkParameter(groupSize,
                                         dcScaleSIGTestCurrentVec.size(),
                                         "DcScaleSIG",
                                         "testCurrent_uA",
                                         dcScaleSIGTestCurrentVec);
      ContinuityTestUtil::checkParameter(groupSize,
                                         dcScaleSIGSettlingTimeVec.size(),
                                         "DcScaleSIG",
                                         "settlingTime_ms",
                                         dcScaleSIGSettlingTimeVec);
      ContinuityTestUtil::checkParameter(groupSize,
                                         dcScaleSIGMeasureModeVec.size(),
                                         "DcScaleSIG",
                                         "measureMode",
                                         dcScaleSIGMeasureModeVec);
      ContinuityTestUtil::checkParameter(groupSize,
                                         dcScaleSIGPolarityVec.size(),
                                         "DcScaleSIG",
                                         "polarity",
                                         dcScaleSIGPolarityVec);
      ContinuityTestUtil::checkParameter(groupSize,
                                         dcScaleSIGPrechargeToZeroVolVec.size(),
                                         "DcScaleSIG",
                                         "prechargeToZeroVol",
                                         dcScaleSIGPrechargeToZeroVolVec);
      if(dcScaleSIGPinlistVec.size() != dcScaleSIGTestNameVec.size())
      {
        if(dcScaleSIGTestNameVec.size() != 1)
        {
          stringstream errMsg;
          errMsg <<"DcScaleSIG: the number of pinlist groups is "
                 << dcScaleSIGPinlistVec.size() <<endl
                 <<"            the number of testName groups is "
                 << dcScaleSIGTestNameVec.size() <<endl
                 <<"So the testName groups don't match pinlist groups." <<endl;
          throw Error("ContinuityTest::processParameters()",
                      errMsg.str(),
                      "ContinuityTest::processParameters()");
        }
        else
        {
          param.isDCScaleSIGLimitAppliedForAllGroups = true;
          for(vector<string>::size_type i = 1; i < dcScaleSIGPinlistVec.size(); i++)
          {
            dcScaleSIGTestNameVec.push_back(dcScaleSIGTestNameVec[0]);
          }
        }
      }

      DCScaleSIGGroupParam dcScaleSIGGroupParam;
      //the following three variables is used for checking the duplicate pins
      pair<map<string,pair<string,string> >::iterator,bool> ret;
      pair<string,string> groupAndInstrument;
      const string instrumentType = "DcScaleSIGInstrument";
      for(unsigned  i = 0; i< dcScaleSIGPinlistVec.size(); i++)
      {
        dcScaleSIGGroupParam.init();
        dcScaleSIGGroupParam.pinlist = dcScaleSIGPinlistVec[i];
        dcScaleSIGGroupParam.measureMode = dcScaleSIGMeasureModeVec[i];
        if(dcScaleSIGGroupParam.measureMode != "PAR" &&
           dcScaleSIGGroupParam.measureMode != "SER")
        {
          stringstream errMsg;
          errMsg <<"DcScaleSIG: for the " << i+1 << " group setup parameter, measureMode: "
                 <<dcScaleSIGGroupParam.measureMode << " is invalid."<<endl
                 <<"measureMode can only be the following options: PAR  SER" <<endl;
          throw Error("ContinuityTest::processParamters()",
                      errMsg.str(),
                      "ContinuityTest::processParamters()");
        }
        dcScaleSIGGroupParam.prechargeToZeroVol = dcScaleSIGPrechargeToZeroVolVec[i];
        if(dcScaleSIGGroupParam.prechargeToZeroVol != "ON" &&
           dcScaleSIGGroupParam.prechargeToZeroVol != "OFF")
        {
          stringstream errMsg;
          errMsg <<"DcScaleSIG: for the " << i+1 << " group setup parameter, prechargeToZeroVol: "
                 <<dcScaleSIGGroupParam.prechargeToZeroVol << " is invalid."<<endl
                 <<"prechargeToZeroVol can only be the following options: ON  OFF" <<endl;
          throw Error("ContinuityTest::processParamters()",
                      errMsg.str(),
                      "ContinuityTest::processParamters()");
        }

        if('#' != dcScaleSIGGroupParam.pinlist[0])
        {
          dcScaleSIGGroupParam.expandedPins =
              PinUtility.getDigitalPinNamesFromPinList(dcScaleSIGGroupParam.pinlist,
                                                       TM::DC_PIN,true,true);
          // check the duplicate pins
          for(vector<string>::size_type index = 0;
              index < dcScaleSIGGroupParam.expandedPins.size();
              index++)
          {
            groupAndInstrument = make_pair(dcScaleSIGPinlistVec[i],instrumentType);
            ret =  pinAndGroupMap.insert(
                make_pair(dcScaleSIGGroupParam.expandedPins[index],groupAndInstrument));
            if(!ret.second)
            {
              stringstream errMsg;
              errMsg << "In the DcScaleSIGInstrument group: " << dcScaleSIGPinlistVec[i] <<endl
                     << "   and " << ret.first->second.second << " group: "
                     << ret.first->second.first <<endl
                     << "There are the same pin: "
                     << dcScaleSIGGroupParam.expandedPins[index] <<endl;
              throw Error("ContinuityTest::processParameters",
                          errMsg.str(),
                          "ContinuityTest::processParameters");
            }
          }
        }

        if(dcScaleSIGSettlingTimeVec[i]  < 0.0)
        {
          stringstream errMsg;
          errMsg << "DcScaleSIG: The " << i+1 << " group setup parameter's value is"
                 << dcScaleSIGSettlingTimeVec[i] << endl
                 << "settlingTime must be positive!";
          throw Error("ContinuityTest::processParameters",
                      errMsg.str(),
                      "ContinuityTest::processParameters");
        }
        dcScaleSIGGroupParam.settlingTime = dcScaleSIGSettlingTimeVec[i];
        dcScaleSIGGroupParam.testCurrentFirstPol = dcScaleSIGTestCurrentVec[i];
        dcScaleSIGGroupParam.polarity = dcScaleSIGPolarityVec[i];
        if(dcScaleSIGGroupParam.polarity != "SPOL" &&
           dcScaleSIGGroupParam.polarity != "BPOL")
        {
          stringstream errMsg;
          errMsg <<"DcScaleSIG: for the " << i+1 << " group setup parameter, polarity: "
                 <<dcScaleSIGGroupParam.polarity << " is invalid."<<endl
                 <<"polarity can only be the following options: SPOL  BPOL" <<endl;
          throw Error("ContinuityTest::processParamters()",
                      errMsg.str(),
                      "ContinuityTest::processParamters()");
        }

        dcScaleSIGGroupParam.limitName = dcScaleSIGTestNameVec[i];
        ContinuityTestUtil::getLimitInfo(dcScaleSIGTestNameVec[i],i,
                                         "mV",dcScaleSIGGroupParam.firstLimit,
                                         testtableHelper);
        if("BPOL" == dcScaleSIGGroupParam.polarity )
        {
          dcScaleSIGGroupParam.testCurrentSecondPol = -dcScaleSIGTestCurrentVec[i];
          ContinuityTestUtil::reverseLimit(dcScaleSIGGroupParam.firstLimit,dcScaleSIGGroupParam.secondLimit);
        }
        param.dcScaleSIGGroups.push_back(dcScaleSIGGroupParam);
      }
    }

    if("YES" == param.dcScaleDPSUsed)
    {
      vector<string> dcScaleDPSPinlistVec;
      vector<string> dcScaleDPSSpecNameVec;
      vector<double> dcScaleDPSSpecValueVec;
      vector<string> dcScaleDPSMeasureModeVec;
      vector<string> dcScaleDPSPolarityVec;
      vector<double> dcScaleDPSSettlingTimeVec;
      vector<string> dcScaleDPSTestNameVec;

      ContinuityTestUtil::parseListOfString(dcScaleDPSPinlist,dcScaleDPSPinlistVec);
      ContinuityTestUtil::parseListOfString(dcScaleDPSSpecName,dcScaleDPSSpecNameVec);
      ContinuityTestUtil::parseListOfDouble(dcScaleDPSSpecValue,dcScaleDPSSpecValueVec);
      ContinuityTestUtil::parseListOfDouble(dcScaleDPSSettlingTime_ms,dcScaleDPSSettlingTimeVec);
      ContinuityTestUtil::parseListOfString(dcScaleDPSMeasureMode,dcScaleDPSMeasureModeVec);
      ContinuityTestUtil::parseListOfString(dcScaleDPSPolarity,dcScaleDPSPolarityVec);
      ContinuityTestUtil::parseListOfString(dcScaleDPSTestName,dcScaleDPSTestNameVec);

      vector<string>::size_type groupSize = dcScaleDPSPinlistVec.size();
      if(groupSize == 0)
      {
        throw Error("ContinuityTest::processParameters()",
                    "DcScaleDPS: the pinlist groups can not be empty.",
                    "ContinuityTest::processParameters()");
      }

      ContinuityTestUtil::checkParameter(groupSize,
                                         dcScaleDPSSpecNameVec.size(),
                                         "DcScaleDPS",
                                         "specName",
                                         dcScaleDPSSpecNameVec);
      ContinuityTestUtil::checkParameter(groupSize,
                                         dcScaleDPSSpecValueVec.size(),
                                         "DcScaleDPS",
                                         "specValue",
                                         dcScaleDPSSpecValueVec);
      ContinuityTestUtil::checkParameter(groupSize,
                                         dcScaleDPSSettlingTimeVec.size(),
                                         "DcScaleDPS",
                                         "settlingTime_ms",
                                         dcScaleDPSSettlingTimeVec);
      ContinuityTestUtil::checkParameter(groupSize,
                                         dcScaleDPSMeasureModeVec.size(),
                                         "DcScaleDPS",
                                         "measureMode",
                                         dcScaleDPSMeasureModeVec);
      ContinuityTestUtil::checkParameter(groupSize,
                                         dcScaleDPSPolarityVec.size(),
                                         "DcScaleDPS",
                                         "polarity",
                                         dcScaleDPSPolarityVec);
      if(dcScaleDPSPinlistVec.size() != dcScaleDPSTestNameVec.size())
      {
        if(dcScaleDPSTestNameVec.size() != 1)
        {
          stringstream errMsg;
          errMsg <<"DCScaleDPS: the number of pinlist groups is "
                 << dcScaleDPSPinlistVec.size() <<endl
                 <<"            the number of testName groups is "
                 << dcScaleDPSTestNameVec.size() <<endl
                 <<"So the testName groups don't match pinlist groups." <<endl;
          throw Error("ContinuityTest::processParameters()",
                      errMsg.str(),
                      "ContinuityTest::processParameters()");
        }
        else
        {
          param.isDCScaleDPSLimitAppliedForAllGroups = true;
          for(vector<string>::size_type i = 1; i < dcScaleDPSPinlistVec.size(); i++)
          {
            dcScaleDPSTestNameVec.push_back(dcScaleDPSTestNameVec[0]);
          }
        }
      }

      DCScaleDPSGroupParam dcScaleDPSGroupParam;
      //the following three variables is used for checking the duplicate pins
      pair<map<string,pair<string,string> >::iterator,bool> ret;
      pair<string,string> groupAndInstrument;
      const string instrumentType = "DCScaleDPSInstrument";
      pinAndGroupMap.clear();
      for(unsigned  i = 0; i< dcScaleDPSPinlistVec.size(); i++)
      {
        dcScaleDPSGroupParam.init();
        dcScaleDPSGroupParam.pinlist = dcScaleDPSPinlistVec[i];
        dcScaleDPSGroupParam.measureMode = dcScaleDPSMeasureModeVec[i];
        if(dcScaleDPSGroupParam.measureMode != "PAR" &&
           dcScaleDPSGroupParam.measureMode != "SER")
        {
          stringstream errMsg;
          errMsg <<"DCScaleDPS: for the " << i+1 << " group setup parameter, measureMode: "
                 <<dcScaleDPSGroupParam.measureMode << " is invalid."<<endl
                 <<"measureMode can only be the following options: PAR  SER" <<endl;
          throw Error("ContinuityTest::processParamters()",
                      errMsg.str(),
                      "ContinuityTest::processParamters()");
        }
        dcScaleDPSGroupParam.specName = dcScaleDPSSpecNameVec[i];

        if('#' != dcScaleDPSGroupParam.pinlist[0])
        {
          dcScaleDPSGroupParam.expandedPins =
                     PinUtility.getDpsPinNamesFromPinList(dcScaleDPSPinlistVec[i],true);
          // check the duplicate pins
          for(vector<string>::size_type index = 0;
              index < dcScaleDPSGroupParam.expandedPins.size();
              index++)
          {
            groupAndInstrument = make_pair(dcScaleDPSPinlistVec[i],instrumentType);
            ret =  pinAndGroupMap.insert(
                make_pair(dcScaleDPSGroupParam.expandedPins[index],groupAndInstrument));
            if(!ret.second)
            {
              stringstream errMsg;
              errMsg << "In the DcScaleDPSInstrument group: " << dcScaleDPSPinlistVec[i] <<endl
                     << "   and " << ret.first->second.second << " group: "
                     << ret.first->second.first <<endl
                     << "There are the same pin: "
                     << dcScaleDPSGroupParam.expandedPins[index] <<endl;
              throw Error("ContinuityTest::processParameters",
                          errMsg.str(),
                          "ContinuityTest::processParameters");
            }
          }
        }

        if(dcScaleDPSSettlingTimeVec[i]  < 0.0)
        {
          stringstream errMsg;
          errMsg << "DCScaleDPS: The " << i+1 << " group setup parameter's value is"
                 << dcScaleDPSSettlingTimeVec[i] << endl
                 << "settlingTime must be positive!";
          throw Error("ContinuityTest::processParameters",
                      errMsg.str(),
                      "ContinuityTest::processParameters");
        }
        dcScaleDPSGroupParam.settlingTime = dcScaleDPSSettlingTimeVec[i];
        dcScaleDPSGroupParam.specValueFirstPol = dcScaleDPSSpecValueVec[i];
        dcScaleDPSGroupParam.polarity = dcScaleDPSPolarityVec[i];
        if(dcScaleDPSGroupParam.polarity != "SPOL" &&
           dcScaleDPSGroupParam.polarity != "BPOL")
        {
          stringstream errMsg;
          errMsg <<"DCScaleDPS: for the " << i+1 << " group setup parameter, polarity: "
                 <<dcScaleDPSGroupParam.polarity << " is invalid."<<endl
                 <<"polarity can only be the following options: SPOL  BPOL" <<endl;
          throw Error("ContinuityTest::processParamters()",
                      errMsg.str(),
                      "ContinuityTest::processParamters()");
        }

        dcScaleDPSGroupParam.limitName = dcScaleDPSTestNameVec[i];
        ContinuityTestUtil::getLimitInfo(dcScaleDPSTestNameVec[i],i,
                                         "mV",dcScaleDPSGroupParam.firstLimit,
                                          testtableHelper);
        if("BPOL" == dcScaleDPSGroupParam.polarity )
        {
          dcScaleDPSGroupParam.specValueSecondPol = -dcScaleDPSSpecValueVec[i];
          ContinuityTestUtil::reverseLimit(dcScaleDPSGroupParam.firstLimit,dcScaleDPSGroupParam.secondLimit);
        }
        param.dcScaleDPSGroups.push_back(dcScaleDPSGroupParam);
      }
    }

    if("YES" == param.dpsUsed)
    {
      vector<string> dpsPinlistVec;
      vector<string> dpsSpecNameVec;
      vector<double> dpsSpecValueVec;
      vector<string> dpsMeasureModeVec;
      vector<string> dpsPolarityVec;
      vector<double> dpsSettlingTimeVec;
      vector<string> dpsTestNameVec;

      ContinuityTestUtil::parseListOfString(dpsPinlist,dpsPinlistVec);
      ContinuityTestUtil::parseListOfString(dpsSpecName,dpsSpecNameVec);
      ContinuityTestUtil::parseListOfDouble(dpsSpecValue,dpsSpecValueVec);
      ContinuityTestUtil::parseListOfDouble(dpsSettlingTime_ms,dpsSettlingTimeVec);
      ContinuityTestUtil::parseListOfString(dpsMeasureMode,dpsMeasureModeVec);
      ContinuityTestUtil::parseListOfString(dpsPolarity,dpsPolarityVec);
      ContinuityTestUtil::parseListOfString(dpsTestName,dpsTestNameVec);

      vector<string>::size_type groupSize = dpsPinlistVec.size();
      if(groupSize == 0)
      {
        throw Error("ContinuityTest::processParameters()",
                    "DPS: the pinlist groups can not be empty.",
                    "ContinuityTest::processParameters()");
      }

      ContinuityTestUtil::checkParameter(groupSize,
                                         dpsSpecNameVec.size(),
                                         "DPS",
                                         "specName",
                                         dpsSpecNameVec);

      ContinuityTestUtil::checkParameter(groupSize,
                                         dpsSpecValueVec.size(),
                                         "DPS",
                                         "specValue",
                                         dpsSpecValueVec);

      ContinuityTestUtil::checkParameter(groupSize,
                                         dpsSettlingTimeVec.size(),
                                         "DPS",
                                         "settlingTime_ms",
                                         dpsSettlingTimeVec);

      ContinuityTestUtil::checkParameter(groupSize,
                                         dpsMeasureModeVec.size(),
                                         "DPS",
                                         "measureMode",
                                         dpsMeasureModeVec);

      ContinuityTestUtil::checkParameter(groupSize,
                                         dpsPolarityVec.size(),
                                         "DPS",
                                         "polarity",
                                         dpsPolarityVec);
      if(dpsPinlistVec.size() != dpsTestNameVec.size())
      {
        if(dpsTestNameVec.size() != 1)
        {
          stringstream errMsg;
          errMsg <<"DPS: the number of pinlist groups is "
                 << dpsPinlistVec.size() <<endl
                 <<"     the number of testName groups is "
                 << dpsTestNameVec.size() <<endl
                 <<"So the testName groups don't match pinlist groups." <<endl;
          throw Error("ContinuityTest::processParameters()",
                      errMsg.str(),
                      "ContinuityTest::processParameters()");
        }
        else
        {
          param.isDPSLimitAppliedForAllGroups = true;
          for(vector<string>::size_type i = 1; i < dpsPinlistVec.size(); i++)
          {
            dpsTestNameVec.push_back(dpsTestNameVec[0]);
          }
        }
      }

      DPSGroupParam dpsGroupParam;
      //the following three variables is used for checking the duplicate pins
      pair<map<string,pair<string,string> >::iterator,bool> ret;
      pair<string,string> groupAndInstrument;
      const string instrumentType = "DPSInstrument";
      if("YES" != param.dcScaleDPSUsed)
      {
        pinAndGroupMap.clear();
      }
      for(unsigned  i = 0; i< dpsPinlistVec.size(); i++)
      {
        dpsGroupParam.init();
        dpsGroupParam.pinlist = dpsPinlistVec[i];
        dpsGroupParam.measureMode = dpsMeasureModeVec[i];
        if(dpsGroupParam.measureMode != "PAR" &&
           dpsGroupParam.measureMode != "SER")
        {
          stringstream errMsg;
          errMsg <<"DPS: for the " << i+1 << " group setup parameter, measureMode: "
                 <<dpsGroupParam.measureMode << " is invalid."<<endl
                 <<"measureMode can only be the following options: PAR  SER" <<endl;
          throw Error("ContinuityTest::processParamters()",
                      errMsg.str(),
                      "ContinuityTest::processParamters()");
        }
        dpsGroupParam.specName = dpsSpecNameVec[i];

        if('#' != dpsGroupParam.pinlist[0])
        {
          dpsGroupParam.expandedPins = PinUtility.getDpsPinNamesFromPinList(dpsPinlistVec[i],true);
          // check the duplicate pins
          for(vector<string>::size_type index = 0;
              index < dpsGroupParam.expandedPins.size();
              index++)
          {
            groupAndInstrument = make_pair(dpsPinlistVec[i],instrumentType);
            ret =  pinAndGroupMap.insert(
                make_pair(dpsGroupParam.expandedPins[index],groupAndInstrument));
            if(!ret.second)
            {
              stringstream errMsg;
              errMsg << "In the DPSInstrument group: " << dpsPinlistVec[i] <<endl
                     << "   and " << ret.first->second.second << " group: "
                     << ret.first->second.first <<endl
                     << "There are the same pin: "
                     << dpsGroupParam.expandedPins[index] <<endl;
              throw Error("ContinuityTest::processParameters",
                          errMsg.str(),
                          "ContinuityTest::processParameters");
            }
          }
        }

        if(dpsSettlingTimeVec[i]  < 0.0)
        {
          stringstream errMsg;
          errMsg << "DPS: The " << i+1 << " group setup parameter's value is"
                 << dpsSettlingTimeVec[i] << endl
                 << "settlingTime must be positive!";
          throw Error("ContinuityTest::processParameters",
                      errMsg.str(),
                      "ContinuityTest::processParameters");
        }
        dpsGroupParam.settlingTime = dpsSettlingTimeVec[i];
        dpsGroupParam.specValueFirstPol = dpsSpecValueVec[i];
        dpsGroupParam.polarity = dpsPolarityVec[i];
        if(dpsGroupParam.polarity != "SPOL" &&
           dpsGroupParam.polarity != "BPOL")
        {
          stringstream errMsg;
          errMsg <<"DPS: for the " << i+1 << " group setup parameter, polarity: "
                 <<dpsGroupParam.polarity << " is invalid."<<endl
                 <<"polarity can only be the following options: SPOL  BPOL" <<endl;
          throw Error("ContinuityTest::processParamters()",
                      errMsg.str(),
                      "ContinuityTest::processParamters()");
        }

        dpsGroupParam.limitName = dpsTestNameVec[i];
        ContinuityTestUtil::getLimitInfo(dpsTestNameVec[i],i,
                                         "uA",dpsGroupParam.firstLimit,
                                         testtableHelper);
        if("BPOL" == dpsGroupParam.polarity )
        {
          dpsGroupParam.specValueSecondPol = -dpsSpecValueVec[i];
          ContinuityTestUtil::reverseLimit(dpsGroupParam.firstLimit,dpsGroupParam.secondLimit);
        }
        param.dpsGroups.push_back(dpsGroupParam);
      }
    }

    param.isLimitTableUsed = testtableHelper.isAllInTable();
  }

/*
 *----------------------------------------------------------------------*
 * Routine: doMeasurement
 *
 * Purpose: execute measurement by PPMU or Program Load and store results
 *
 *----------------------------------------------------------------------*
 * Description:
 *   INPUT:  param       - test parameters
 *           testLimit   - test limit(s) container
 *           result      - result container
 *
 *   OUTPUT:
 *   RETURN:
 *----------------------------------------------------------------------*
 */
  static void doMeasurement(
      const ContinuityTestParam& param,
      ContinuityTestResult& result)
  {
    // swtich DPS state
    string fwCmdToRestoreDpsState = "";
    ON_FIRST_INVOCATION_BEGIN();
      //init result
      result.init();
      DISCONNECT();
      ContinuityTestUtil::switchDpsStateToLOZ(fwCmdToRestoreDpsState);
    ON_FIRST_INVOCATION_END();

    bool hasParallelGroupForFirstPpmuMeasure = false;
    bool hasParallelGroupForSecondPpmuMeasure = false;
    bool hasHvParallelGroupForFirstPpmuMeasure = false;
    bool hasHvParallelGroupForSecondPpmuMeasure = false;

    bool hasParallelGroupForSpmuTask = false;
    SPMU_TASK spFirstForceON;
    SPMU_TASK spSecondForceON;
    SPMU_TASK spFirstMeasure;
    SPMU_TASK spSecondMeasure;
    SPMU_TASK spFirstForceOFF;
    SPMU_TASK spSecondForceOFF;
    PPMU_MEASURE  ppmuMeasureFirst,ppmuMeasureSecond;
    HV_DC_TASK hvDcTaskFirst, hvDcTaskSecond;

    ON_FIRST_INVOCATION_BEGIN();
    PPMU_SETTING  ppmuSettingFirstPol;
    PPMU_SETTING  ppmuSettingSecondPol;
    PPMU_CLAMP    ppmuClampOn, ppmuClampOff;
    PPMU_RELAY    relayPm, relayAc;
    TASK_LIST taskList;

    // for ppmu measurement's setup
    if(param.ppmuUsed == "YES")
    {
      ppmuInstrumentVoltageMeasurement(
          param.ppmuGroups,
          param.testMode,
          ppmuSettingFirstPol,
          ppmuSettingSecondPol,
          ppmuClampOn,
          ppmuClampOff,
          relayPm,
          relayAc,
          ppmuMeasureFirst,
          ppmuMeasureSecond,
          hvDcTaskFirst,
          hvDcTaskSecond,
          hasParallelGroupForFirstPpmuMeasure,
          hasParallelGroupForSecondPpmuMeasure,
          hasHvParallelGroupForFirstPpmuMeasure,
          hasHvParallelGroupForSecondPpmuMeasure);
    }
    // for DCScaleDPS measurement's setup
    if(param.spmuUsed == "YES")
    {
      spmuInstrumentVoltageMeasurementSetup(
          param.spmuGroups,
          param.testMode,
          spFirstForceON,
          spSecondForceON,
          spFirstMeasure,
          spSecondMeasure,
          spFirstForceOFF,
          spSecondForceOFF,
          hasParallelGroupForSpmuTask);
    }
    

    // for dcscale pin in SIG mode measurement's setup
    if(param.dcScaleSIGUsed == "YES")
    {
      DCScaleSIGInstrumentVoltageMeasurementSetup(
          param.dcScaleSIGGroups,
          param.testMode,
          spFirstMeasure,
          spSecondMeasure,
          hasParallelGroupForSpmuTask);
    }

    if(hasParallelGroupForFirstPpmuMeasure   &&
       hasParallelGroupForSecondPpmuMeasure  &&
       hasParallelGroupForSpmuTask )
    {
      taskList.add(ppmuSettingFirstPol)
              .add(ppmuClampOn)
              .add(relayPm)
              .add(ppmuClampOff)
              .add(spFirstForceON);
      if(hasHvParallelGroupForFirstPpmuMeasure)
      {
        taskList.add(hvDcTaskFirst);  
      }
      taskList.add(ppmuMeasureFirst)
              .add(spFirstMeasure)
              .add(spFirstForceOFF)
              .add(ppmuSettingSecondPol)
              .add(spSecondForceON);
      if(hasHvParallelGroupForSecondPpmuMeasure)
      {
        taskList.add(hvDcTaskSecond);  
      }
      taskList.add(ppmuMeasureSecond)
              .add(spSecondMeasure)
              .add(relayAc)
              .add(spSecondForceOFF);
    }
    else if(hasParallelGroupForFirstPpmuMeasure   &&
            hasParallelGroupForSecondPpmuMeasure)
    {
      taskList.add(ppmuSettingFirstPol)
              .add(ppmuClampOn)
              .add(relayPm)
              .add(ppmuClampOff);
      if(hasHvParallelGroupForFirstPpmuMeasure)
      {
        taskList.add(hvDcTaskFirst);  
      }
      taskList.add(ppmuMeasureFirst)
              .add(ppmuSettingSecondPol);
      if(hasHvParallelGroupForSecondPpmuMeasure)
      {
        taskList.add(hvDcTaskSecond);  
      }
      taskList.add(ppmuMeasureSecond)
              .add(relayAc);
    }
    else if(hasParallelGroupForFirstPpmuMeasure   &&
            hasParallelGroupForSpmuTask)
    {
      taskList.add(ppmuSettingFirstPol)
              .add(ppmuClampOn)
              .add(relayPm)
              .add(ppmuClampOff)
              .add(spFirstForceON);
      if(hasHvParallelGroupForFirstPpmuMeasure)
      {
        taskList.add(hvDcTaskFirst);
      }
      taskList.add(ppmuMeasureFirst)
              .add(spFirstMeasure)
              .add(spFirstForceOFF)
              .add(spSecondForceON);
      if(hasHvParallelGroupForSecondPpmuMeasure)
      {
        taskList.add(hvDcTaskSecond);
      }
      taskList.add(spSecondMeasure)
              .add(relayAc)
              .add(spSecondForceOFF);
    }
    else if(hasParallelGroupForFirstPpmuMeasure )
    {
      taskList.add(ppmuSettingFirstPol)
              .add(ppmuClampOn)
              .add(relayPm)
              .add(ppmuClampOff);
      if(hasHvParallelGroupForFirstPpmuMeasure)
      {
        taskList.add(hvDcTaskFirst);
      }
      taskList.add(ppmuMeasureFirst);
      if(hasHvParallelGroupForSecondPpmuMeasure)
      {
        taskList.add(hvDcTaskSecond);
      }
      taskList.add(relayAc);
    }
    else if(hasParallelGroupForSpmuTask)
    {
      taskList.add(spFirstForceON);
      if(hasHvParallelGroupForFirstPpmuMeasure)
      {
        taskList.add(hvDcTaskFirst);
      }
      taskList.add(spFirstMeasure)
              .add(spFirstForceOFF)
              .add(spSecondForceON);
      if(hasHvParallelGroupForSecondPpmuMeasure)
      {
        taskList.add(hvDcTaskSecond);
      }
      taskList.add(spSecondMeasure)
              .add(spSecondForceOFF);
         
    }
    else if(param.ppmuUsed == "YES")
    {
      // for serial mode, some actions can do parallelly.
      taskList.add(ppmuSettingFirstPol)
              .add(ppmuClampOn);
      if(hasHvParallelGroupForFirstPpmuMeasure)
      {
          taskList.add(hvDcTaskFirst);
      }

      if(hasHvParallelGroupForSecondPpmuMeasure)
      {
          taskList.add(hvDcTaskSecond);
      }
    }
    else if (hasHvParallelGroupForFirstPpmuMeasure || hasHvParallelGroupForSecondPpmuMeasure)
    {
      if(hasHvParallelGroupForFirstPpmuMeasure)
      {
        taskList.add(hvDcTaskFirst);  
      }

      if(hasHvParallelGroupForSecondPpmuMeasure)
      {
        taskList.add(hvDcTaskSecond);
      }
    }
    taskList.execute();
    ON_FIRST_INVOCATION_END();

    // HV pins are tested before non-HV pins
    if(param.ppmuUsed == "YES")
    {
      ppmuVoltageHvMeasurementUpdateTestResult(
          param.ppmuGroups,
          param.testMode,
          hvDcTaskFirst,
          hvDcTaskSecond,
          result.ppmuFirstMeasureResultVec,
          result.ppmuSecondMeasureResultVec);
    }

    //non-HV pins
    // for mcx-pmu measure and update result
    if(param.mcxUsed == "YES")
    {
      mcxInstrumentVoltageMeasurement(
          param.mcxGroups,
          param.testMode,
          result.mcxFirstMeasureResultVec,
          result.mcxSecondMeasureResultVec);
    }
    

    // for dcscale pin in DPS mode measure and update result
    if(param.dcScaleDPSUsed == "YES")
    {
      DCScaleDPSInstrumentVoltageMeasurement(
            param.dcScaleDPSGroups,
            param.testMode,
            result.dcScaleDPSFirstMeasureResultVec,
            result.dcScaleDPSSecondMeasureResultVec);
    }
    
    // for normal dps pin measure and update result
    if(param.dpsUsed == "YES")
    {
      dpsInstrumentCurrentMeasurement(
            param.dpsGroups,
            param.testMode,
            result.dpsFirstMeasureResultVec,
            result.dpsSecondMeasureResultVec);
    }
    // update ppmu result
    if(param.ppmuUsed == "YES")
    {
      ppmuVoltageMeasurementUpdateTestResult(
          param.ppmuGroups,
          param.testMode,
          ppmuMeasureFirst,
          ppmuMeasureSecond,
          result.ppmuFirstMeasureResultVec,
          result.ppmuSecondMeasureResultVec);
    }
    // update spmu result
    if(param.spmuUsed == "YES")
    {
      spmuVoltageMeasurementUpdateTestResult(
          param.spmuGroups,
          param.testMode,
          spFirstMeasure,
          spSecondMeasure,
          result.spmuFirstMeasureResultVec,
          result.spmuSecondMeasureResultVec);
    }
    
    // update dcscale pin in SIG mode result
    if(param.dcScaleSIGUsed == "YES")
    {
      DCScaleSIGMeasurementVoltageUpdateTestResult(
          param.dcScaleSIGGroups,
          param.testMode,
          spFirstMeasure,
          spSecondMeasure,
          result.dcScaleSIGFirstMeasureResultVec,
          result.dcScaleSIGSecondMeasureResultVec);
    }

    ON_FIRST_INVOCATION_BEGIN();
    FW_TASK("SQST OFF\n");
    //  restore DPS state
    if(!fwCmdToRestoreDpsState.empty())
    {
      //append a string of update the DPS level setup
      fwCmdToRestoreDpsState += " UPTD DPS,1\nUPTD LEV,1\n";
      FW_TASK(fwCmdToRestoreDpsState);
    }
    ON_FIRST_INVOCATION_END();
  }

/*
 *----------------------------------------------------------------------*
 * Routine: judgeAndDatalog
 *
 * Purpose: judge and put result into event datalog stream.
 *
 *----------------------------------------------------------------------*
 * Description:
 *   judge results of 'result' with 'testLimit' from 'param'
 *
 *   INPUT:  param       - test parameters container
 *           testLimit   - test limit container
 *           result      - result container
 *   OUTPUT:
 *   RETURN:
 * Note:
 *----------------------------------------------------------------------*
 */
  static void judgeAndDatalog(
      const ContinuityTestParam& param,
      const ContinuityTestResult &result)
  {
    bool hasBined = false;
    if(param.ppmuUsed == "YES")
    {
      ContinuityJudgeAndLogUtil(param.ppmuGroups,
                                result.ppmuFirstMeasureResultVec,
                                result.ppmuSecondMeasureResultVec,
                                param.testMode,
                                param.testsuiteName,
                                param.isPPMULimitAppliedForAllGroups,
                                param.isLimitTableUsed,
                                "mV",
                                hasBined);
    }

    if(param.spmuUsed == "YES")
    {
      ContinuityJudgeAndLogUtil(param.spmuGroups,
                                result.spmuFirstMeasureResultVec,
                                result.spmuSecondMeasureResultVec,
                                param.testMode,
                                param.testsuiteName,
                                param.isSPMULimitAppliedForAllGroups,
                                param.isLimitTableUsed,
                                "mV",
                                hasBined);
    }
    if(param.mcxUsed == "YES")
    {
      ContinuityJudgeAndLogUtil(param.mcxGroups,
                                result.mcxFirstMeasureResultVec,
                                result.mcxSecondMeasureResultVec,
                                param.testMode,
                                param.testsuiteName,
                                param.isMCXLimitAppliedForAllGroups,
                                param.isLimitTableUsed,
                                "mV",
                                hasBined,
                                true);
    }

    if(param.dcScaleSIGUsed == "YES")
    {
      ContinuityJudgeAndLogUtil(param.dcScaleSIGGroups,
                                result.dcScaleSIGFirstMeasureResultVec,
                                result.dcScaleSIGSecondMeasureResultVec,
                                param.testMode,
                                param.testsuiteName,
                                param.isDCScaleSIGLimitAppliedForAllGroups,
                                param.isLimitTableUsed,
                                "mV",
                                hasBined);
    }
        
    if(param.dcScaleDPSUsed == "YES")
    {
      ContinuityJudgeAndLogUtil(param.dcScaleDPSGroups,
                                result.dcScaleDPSFirstMeasureResultVec,
                                result.dcScaleDPSSecondMeasureResultVec,
                                param.testMode,
                                param.testsuiteName,
                                param.isDCScaleDPSLimitAppliedForAllGroups,
                                param.isLimitTableUsed,
                                "mV",
                                hasBined);
    }
    
    if(param.dpsUsed == "YES")
    {
      ContinuityJudgeAndLogUtil(param.dpsGroups,
                                result.dpsFirstMeasureResultVec,
                                result.dpsSecondMeasureResultVec,
                                param.testMode,
                                param.testsuiteName,
                                param.isDPSLimitAppliedForAllGroups,
                                param.isLimitTableUsed,
                                "uA",
                                hasBined);
    }

    return;
  }

/*
 *----------------------------------------------------------------------*
 * Routine: reportToUI
 *
 * Purpose: output result to UIWindow
 *
 *----------------------------------------------------------------------*
 * Description:
 *   display:
 *       a) results from result,
 *       b) pass range from pass limits of param,
 *       c) pass or fail
 *
 *   INPUT:  param              - test parameters
 *           testLimit          - test limit(s) container
 *           output             - "None" or "ReportUI"
 *           result             - result container
 *   OUTPUT:
 *   RETURN:
 * Note:
 *----------------------------------------------------------------------*
 */
  static void reportToUI(
      const ContinuityTestParam& param,
      const ContinuityTestResult& result,
      const string& output)
  {
    if("ReportUI" != output)
    {
      return;
    }

    cout << "Continuity '" << param.testsuiteName << "'";
    cout << " Site: " << CURRENT_SITE_NUMBER() << endl;
    if(param.ppmuGroups.size() != 0)
    {
      ContinuityReportToUIUtil(param.ppmuGroups,
                               result.ppmuFirstMeasureResultVec,
                               result.ppmuSecondMeasureResultVec,
                               param.testMode,
                               param.testsuiteName,
                               "mV",
                               output);
    }

    if(param.spmuGroups.size() != 0)
    {
      ContinuityReportToUIUtil(param.spmuGroups,
                               result.spmuFirstMeasureResultVec,
                               result.spmuSecondMeasureResultVec,
                               param.testMode,
                               param.testsuiteName,
                               "mV",
                               output);
    }
    if(param.mcxGroups.size() != 0)
    {
      ContinuityReportToUIUtil(param.mcxGroups,
                               result.mcxFirstMeasureResultVec,
                               result.mcxSecondMeasureResultVec,
                               param.testMode,
                               param.testsuiteName,
                               "mV",
                               output,
                               true);
    }

    if(param.dcScaleSIGGroups.size() != 0)
    {
      ContinuityReportToUIUtil(param.dcScaleSIGGroups,
                               result.dcScaleSIGFirstMeasureResultVec,
                               result.dcScaleSIGSecondMeasureResultVec,
                               param.testMode,
                               param.testsuiteName,
                               "mV",
                               output);
    }
    if(param.dcScaleDPSGroups.size() != 0)
    {
      ContinuityReportToUIUtil(param.dcScaleDPSGroups,
                               result.dcScaleDPSFirstMeasureResultVec,
                               result.dcScaleDPSSecondMeasureResultVec,
                               param.testMode,
                               param.testsuiteName,
                               "mV",
                               output);
    }

    if(param.dpsGroups.size() != 0)
    {
      ContinuityReportToUIUtil(param.dpsGroups,
                               result.dpsFirstMeasureResultVec,
                               result.dpsSecondMeasureResultVec,
                               param.testMode,
                               param.testsuiteName,
                               "uA",
                               output);
    }

    return ;
  }

private:


  ContinuityTest() {} //private constructor to prevent instantiation.

  static void ppmuInstrumentVoltageMeasurement(
      const vector<PPMUGroupParam>& groups,
      const TM::DCTEST_MODE& testMode,
      PPMU_SETTING&  settingPpmuFirstPol,
      PPMU_SETTING&  settingPpmuSecondPol,
      PPMU_CLAMP&    ppmuClampOn,
      PPMU_CLAMP&    ppmuClampOff,
      PPMU_RELAY&    relayPm,
      PPMU_RELAY&    relayAc,
      PPMU_MEASURE&  measureFirst,
      PPMU_MEASURE&  measureSecond,
      HV_DC_TASK&    hvMeasureFirst,
      HV_DC_TASK&    hvMeasureSecond,
      bool&          hasParallelGroupForFirst,
      bool&          hasParallelGroupForSecond,
      bool&          hasHvParallelGroupForFirst,
      bool&          hasHvParallelGroupForSecond);

  static void ppmuVoltageMeasurementUpdateTestResult(
      const vector<PPMUGroupParam>& groups,
      const TM::DCTEST_MODE& testMode,
      const PPMU_MEASURE&    measurePpmuFirst,
      const PPMU_MEASURE&    measurePpmuSecond,
      vector<MeasurementResultContainer> &firstResultVec,
      vector<MeasurementResultContainer> &secondResultVec);

  static void ppmuVoltageHvMeasurementUpdateTestResult(
      const vector<PPMUGroupParam>& groups,
      const TM::DCTEST_MODE& testMode,
      const HV_DC_TASK&      hvMeasurePpmuFirst,
      const HV_DC_TASK&      hvMeasurePpmuSecond,
      vector<MeasurementResultContainer> &firstResultVec,
      vector<MeasurementResultContainer> &secondResultVec);

  template<class T>
  static void xpmuVoltageMeasurementUpdateTestResultForEveryGroup(
      const vector<string>&   pinList,
      const TM::DCTEST_MODE& testMode,
      const T&    measureXpmu,
      MeasurementResultContainer& result);

  static void spmuInstrumentVoltageMeasurementSetup(
      const vector<SPMUGroupParam>& groups,
      const TM::DCTEST_MODE& mode,
      SPMU_TASK&  spmuFirstTaskForceON,
      SPMU_TASK&  spmuSecondTaskForceON,
      SPMU_TASK&  spmuFirstTaskMeasure,
      SPMU_TASK&  spmuSecondTaskMeasure,
      SPMU_TASK&  spmuFirstTaskForceOFF,
      SPMU_TASK&  spmuSecondTaskForceOFF,
      bool& hasParallelGroup);


  static void spmuVoltageMeasurementUpdateTestResult(
      const vector<SPMUGroupParam>& groups,
      const TM::DCTEST_MODE& testMode,
      const SPMU_TASK&    firstSpmuTask,
      const SPMU_TASK&    secondSpmuTask,
      vector<MeasurementResultContainer>& firstResult,
      vector<MeasurementResultContainer>& secondResult);
  
  static void mcxInstrumentVoltageMeasurement(
      const vector<MCXGroupParam>& groups,
      const TM::DCTEST_MODE& mode,
      vector<MeasurementResultContainer>& firstResultVec,
      vector<MeasurementResultContainer>& secondResultVec);

  static void UpdateTestResultForUsingLegacyAPI(
      const vector<string>&   pinList,
      const TM::DCTEST_MODE& testMode,
      const PMU_IFVM&    pmuTask,
      MeasurementResultContainer& result);

  static void dpsInstrumentCurrentMeasurement(
      const vector<DPSGroupParam>& groups,
      const TM::DCTEST_MODE& mode,
      vector<MeasurementResultContainer>& firstResultVec,
      vector<MeasurementResultContainer>& secondResultVec);

  static void dpsMeasurementCurrentGetResultForEveryGroup(
      const vector<string>&   pinList,
      const TM::DCTEST_MODE& testMode,
      const DPS_TASK&    dpsTask,
      MeasurementResultContainer& result);

  static void DCScaleSIGInstrumentVoltageMeasurementSetup(
       const vector<DCScaleSIGGroupParam>& groups,
       const TM::DCTEST_MODE& mode,
       SPMU_TASK& spmuFirstTaskMeasure,
       SPMU_TASK& spmuSecondTaskMeasure,
       bool& hasParallelGroup);

 static void DCScaleSIGMeasurementVoltageUpdateTestResult(
     const vector<DCScaleSIGGroupParam>& groups,
     const TM::DCTEST_MODE& testMode,
     const SPMU_TASK&    firstSpmuTask,
     const SPMU_TASK&    secondSpmuTask,
     vector<MeasurementResultContainer>& firstResult,
     vector<MeasurementResultContainer>& secondResult);

 static void DCScaleDPSInstrumentVoltageMeasurement(
     const vector<DCScaleDPSGroupParam>& groups,
     const TM::DCTEST_MODE& mode,
     vector<MeasurementResultContainer>& firstResultVec,
     vector<MeasurementResultContainer>& secondResultVec);

 static void DCScaleDPSMeasurementUpdateTestResult(
     const vector<string>&   pinList,
     const TM::DCTEST_MODE& testMode,
     const DPS_TASK&    dpsTask,
     MeasurementResultContainer& result);

 static void clonePPMUGroupParam(
	 const PPMUGroupParam & nonHvPara,
	 PPMUGroupParam & hvPara);


  template <class T>
  static void ContinuityJudgeAndLogUtil(
      const vector<T>& groups,
      const vector<MeasurementResultContainer>& firstResult,
      const vector<MeasurementResultContainer>& secondResult,
      const TM::DCTEST_MODE& mode,
      const string& testsuiteName,
      const bool isLimitAppliedForAllGroup,
      const bool isLimitTableUsed,
      const string& unit,
      bool& hasBined,
      const bool isLegacyAPIUsed = false);

  template <class T>
  static void ContinuityReportToUIUtil(
      const vector<T>& groups,
      const vector<MeasurementResultContainer> resultLow,
      const vector<MeasurementResultContainer> resultHigh,
      const TM::DCTEST_MODE& mode,
      const string& testsuiteName,
      const string& unit,
      const string& output,
      const bool isLegacyAPIUsed = false);
};

template <class T> inline void
ContinuityTest::ContinuityJudgeAndLogUtil(
    const vector<T>& groups,
    const vector<MeasurementResultContainer>& firstResult,
    const vector<MeasurementResultContainer>& secondResult,
    const TM::DCTEST_MODE& mode,
    const string& testsuiteName,
    const bool isLimitAppliedForAllGroups,
    const bool isLimitTableUsed,
    const string& unit,
    bool& hasBined,
    const bool isLegacyAPIUsed)
{
  int siteNumber = 0;
  if(isLegacyAPIUsed)
  {
    siteNumber = CURRENT_SITE_NUMBER();
  }

  if(isLimitTableUsed) // use limit table
  {
    V93kLimits::TMLimits::LimitInfo limitInfo;
    if(!isLimitAppliedForAllGroups)
    {
      ContinuityTestUtil::judgeAndLogUtil(groups,
                                          firstResult,
                                          secondResult,
                                          mode,
                                          testsuiteName,
                                          true,
                                          siteNumber,
                                          unit,
                                          hasBined);
    }
    else // one limit applied for all groups
    {
      ContinuityTestUtil::judgeAndLogUtilForAllGroups(groups,
                                                      firstResult,
                                                      secondResult,
                                                      mode,
                                                      testsuiteName,
                                                      true,
                                                      siteNumber,
                                                      unit,
                                                      hasBined);
    }
  }
  else // use testflow's limit
  {
    if(!isLimitAppliedForAllGroups)
    {
      ContinuityTestUtil::judgeAndLogUtil(groups,
                                          firstResult,
                                          secondResult,
                                          mode,
                                          testsuiteName,
                                          false,
                                          siteNumber,
                                          unit,
                                          hasBined);
    } //
    else // for one limit is applied for all groups
    {
      ContinuityTestUtil::judgeAndLogUtilForAllGroups(groups,
                                                      firstResult,
                                                      secondResult,
                                                      mode,
                                                      testsuiteName,
                                                      false,
                                                      siteNumber,
                                                      unit,
                                                      hasBined);
    }
  } // end if: limit from testflow file
}

template <class T> inline void
ContinuityTest::ContinuityReportToUIUtil(
    const vector<T> & groups,
    const vector<MeasurementResultContainer> firstResult,
    const vector<MeasurementResultContainer> secondResult,
    const TM::DCTEST_MODE& mode,
    const string& testsuiteName,
    const string& unit,
    const string& output,
    const bool isLegacyAPIUsed)
{
  if("ReportUI" != output)
  {
    return;
  }
  vector<string>::size_type j = 0;
  bool bPass = true;
  int siteNumber = 0;
  if(isLegacyAPIUsed)
  {
    siteNumber = CURRENT_SITE_NUMBER();
  }

  for(vector<string>::size_type i = 0; i < groups.size(); i++)
  {
    /*
     ****************************
     *  single polarity
     ****************************
     */
    if ('#' != groups[i].pinlist[0] && groups[i].polarity == "SPOL")
    {
      switch ( mode )
      {
      case TM::PVAL:
        for ( j = 0; j< groups[i].expandedPins.size(); ++j )
        {
          double dMeasValue = firstResult[i].getPinsValue(groups[i].expandedPins[j],siteNumber);
          ContinuityTestUtil::datalogToWindow(
                          groups[i].expandedPins[j],
                          dMeasValue,
                          groups[i].firstLimit,
                          unit);
        }
        break;

      case TM::PPF:
        for ( j = 0; j < groups[i].expandedPins.size(); ++j )
        {
          bPass = firstResult[i].getPinPassFail(groups[i].expandedPins[j],siteNumber);
          ContinuityTestUtil::datalogToWindow(groups[i].expandedPins[j],bPass);
        }
        break;

      case TM::GPF:
        bPass = firstResult[i].getGlobalPassFail(siteNumber);
        ContinuityTestUtil::datalogToWindow(testsuiteName, bPass);
        break;

      default:
        throw Error("ContinuityTest::ContinuityReportToUIUtil",
                    "Unknown Test Mode",
                    "ContinuityTest::ContinuityReportToUIUtil");
      }// end switch
    }
    else if ('#' != groups[i].pinlist[0] && groups[i].polarity == "BPOL")
    {
      /*
       *********************************************
       * Both polarity:
       * combine the two measurements with different
       * polarities.
       * If both pass, total results pass.
       *********************************************
       */
      double dMeasValue1 = 0;
      double dMeasValue2 = 0;
      bool bPass1 = true;
      bool bPass2 = true;
      switch ( mode )
      {
      case TM::PVAL:
        for ( j = 0; j< groups[i].expandedPins.size(); ++j )
        {
          dMeasValue1 = firstResult[i].getPinsValue(groups[i].expandedPins[j],siteNumber);
          dMeasValue2 = secondResult[i].getPinsValue(groups[i].expandedPins[j],siteNumber);

          ContinuityTestUtil::datalogToWindow(
                          groups[i].expandedPins[j],
                          dMeasValue1,
                          groups[i].firstLimit,
                          unit);

          ContinuityTestUtil::datalogToWindow(
                          groups[i].expandedPins[j],
                          dMeasValue2,
                          groups[i].secondLimit,
                          unit);
        }
        break;

      case TM::PPF:
        for ( j = 0; j < groups[i].expandedPins.size(); ++j )
        {
          bPass1 = firstResult[i].getPinPassFail(groups[i].expandedPins[j],siteNumber);
          bPass2 = secondResult[i].getPinPassFail(groups[i].expandedPins[j],siteNumber);
          bPass = bPass1 && bPass2;
          ContinuityTestUtil::datalogToWindow(groups[i].expandedPins[j], bPass);
        }
        break;

      case TM::GPF:
        bPass1 = firstResult[i].getGlobalPassFail(siteNumber);
        bPass2 = secondResult[i].getGlobalPassFail(siteNumber);
        bPass = bPass1 && bPass2;
        ContinuityTestUtil::datalogToWindow(testsuiteName, bPass);
        break;

      default:
        throw Error("ContinuityTest::ContinuityReportToUIUtil",
                    "Unknown Test Mode",
                    "ContinuityTest::ContinuityReportToUIUtil");
      }/* end switch*/
    }
  }
}

inline void
ContinuityTest::ppmuInstrumentVoltageMeasurement(
    const vector<PPMUGroupParam>& groups,
    const TM::DCTEST_MODE& testMode,
    PPMU_SETTING&  settingPpmuFirstPol,
    PPMU_SETTING&  settingPpmuSecondPol,
    PPMU_CLAMP&    ppmuClampOn,
    PPMU_CLAMP&    ppmuClampOff,
    PPMU_RELAY&    relayPm,
    PPMU_RELAY&    relayAc,
    PPMU_MEASURE&  measureFirst,
    PPMU_MEASURE&  measureSecond,
    HV_DC_TASK&    hvMeasureFirst,
    HV_DC_TASK&    hvMeasureSecond,
    bool&          hasParallelGroupForFirst,
    bool&          hasParallelGroupForSecond,
    bool&          hasHvParallelGroupForFirst,
    bool&          hasHvParallelGroupForSecond)
{
  double low =  0.0;
  double high =  0.0;
  double settling = 0.0;
  string hvTestMode = ContinuityTestUtil::getMeasureModeForHVPin(testMode);

  for(vector<string>::size_type i = 0; i < groups.size(); i++)
  {
    if('#' != groups[i].pinlist[0])
    {
      double dCurrentRange = fabs(groups[i].testCurrentFirstPol);

      groups[i].firstLimit.getLow(&low);
      groups[i].firstLimit.getHigh(&high);

      if (groups[i].isHVGroup)  //HV pins
      {
        if("PAR" == groups[i].measureMode)
        {
          hasHvParallelGroupForFirst = true;
          hvMeasureFirst.pin(groups[i].pinlist)
                        .iForceRange(dCurrentRange uA)
                        .min(low)
                        .max(high)
                        .iForce(groups[i].testCurrentFirstPol uA)
                        .settling(groups[i].settlingTime ms)
                        .execMode(hvTestMode);
          if (groups[i].polarity == "BPOL")
          {
            /*
             **************************************************
             * do opposite polarity measurement:
             * Before testing, change the polarity of current
             * and update the limit for judgement.
             **************************************************
             */
            hasHvParallelGroupForSecond = true;

            groups[i].secondLimit.getLow(&low);
            groups[i].secondLimit.getHigh(&high);

            hvMeasureSecond.pin(groups[i].pinlist)
                           .iForceRange(dCurrentRange uA)
                           .min(low)
                           .max(high)
                           .iForce(groups[i].testCurrentSecondPol uA)
                           .settling(groups[i].settlingTime ms)
                           .execMode(hvTestMode);
          }
        } //end of if "PAR"
      }
      else   // non-HV pins
      {
        if("PAR" == groups[i].measureMode)
        {
          hasParallelGroupForFirst = true;

          settingPpmuFirstPol.pin(groups[i].pinlist)
                             .iRange(dCurrentRange uA)
                             .min(low)
                             .max(high)
                             .iForce(groups[i].testCurrentFirstPol uA);

          //  1. set the clamp
          // clamp low/high are fixed to -0.1V/0.1V
          ppmuClampOn.pin(groups[i].pinlist).status("CLAMP_ON").low(-0.1 V).high(0.1 V);
          ppmuClampOn.wait(1 ms);

          //  2.relay switch
          relayPm.pin(groups[i].pinlist).status("PPMU_ON");
          relayPm.wait(0.3 ms);

          // 3. switch clamp off (PinScale)
          ppmuClampOff.pin(groups[i].pinlist).status("CLAMP_OFF");
          if(settling < groups[i].settlingTime + 1)
          {
            settling = groups[i].settlingTime + 1;
            ppmuClampOff.wait(settling ms);
          }


          //  4. determine measure
          // PVAL or PPF or GPF is defined by TestSuite Flag
          measureFirst.pin(groups[i].pinlist).execMode(testMode);

          if (groups[i].polarity == "BPOL")
          {
            /*
             **************************************************
             * do opposite polarity measurement:
             * Before testing, change the polarity of current
             * and update the limit for judgement.
             **************************************************
             */
            hasParallelGroupForSecond = true;
            groups[i].secondLimit.getLow(&low);
            groups[i].secondLimit.getHigh(&high);
            settingPpmuSecondPol.pin(groups[i].pinlist)
                                .iRange(dCurrentRange uA)
                                .min(low)
                                .max(high)
                                .iForce(groups[i].testCurrentSecondPol uA);

            measureSecond.pin(groups[i].pinlist).execMode(testMode);
          }

          // 5.relay restore
          relayAc.pin(groups[i].pinlist).status("PPMU_OFF");
          relayAc.wait(0.3 ms);
        }
        else
        {
          settingPpmuFirstPol.pin(groups[i].pinlist)
                             .iRange(dCurrentRange uA)
                             .min(low)
                             .max(high)
                             .iForce(groups[i].testCurrentFirstPol uA);

          // clamp low/high are fixed to -0.1V/0.1V
          ppmuClampOn.pin(groups[i].pinlist).status("CLAMP_ON").low(-0.1 V).high(0.1 V);
          ppmuClampOn.wait(1 ms);
        }
      }
    }
  }
}

inline void
ContinuityTest::ppmuVoltageMeasurementUpdateTestResult(
    const vector<PPMUGroupParam>& groups,
    const TM::DCTEST_MODE& testMode,
    const PPMU_MEASURE&    measurePpmuFirst,
    const PPMU_MEASURE&    measurePpmuSecond,
    vector<MeasurementResultContainer>& firstResultVec,
    vector<MeasurementResultContainer>& secondResultVec)
{
  // get test result
  MeasurementResultContainer everyGroupResult;
  for(vector<string>::size_type i = 0; i < groups.size(); i++)
  {
    everyGroupResult.init();
    if(firstResultVec.size() <= i)
    {
      firstResultVec.push_back(everyGroupResult);
    }
    if(secondResultVec.size() <= i)
    {
      secondResultVec.push_back(everyGroupResult);
    }
    if('#' != groups[i].pinlist[0] && !groups[i].isHVGroup)
    {
      bool hasSecondMeasure = (groups[i].polarity == "BPOL");
      if(groups[i].measureMode == "PAR")
      {
        xpmuVoltageMeasurementUpdateTestResultForEveryGroup(
            groups[i].expandedPins,testMode,measurePpmuFirst,firstResultVec[i]);
        if(hasSecondMeasure)
        {
          xpmuVoltageMeasurementUpdateTestResultForEveryGroup(
              groups[i].expandedPins,testMode,measurePpmuSecond,secondResultVec[i]);
        }
      }
      else
      {
        PPMU_MEASURE measureFirst, measureSecond;
        ON_FIRST_INVOCATION_BEGIN();

        vector<string>::size_type length = groups[i].expandedPins.size();

        for (vector<string>::size_type j = 0; j < length; j++)
        {
          measureFirst.pin(groups[i].expandedPins[j]).execMode(testMode);
          if(hasSecondMeasure)
          {
            measureSecond.pin(groups[i].expandedPins[j]).execMode(testMode);
          }
        }

        for (vector<string>::size_type j = 0; j < length; j++)
        {
          TASK_LIST taskList1;
          FLEX_RELAY flexRelay;
          flexRelay.pin(groups[i].expandedPins[j]).set("PPMU");
          flexRelay.wait(0.3 ms);

          PPMU_CLAMP ppmuClampOff;
          ppmuClampOff.pin(groups[i].expandedPins[j]).status("CLAMP_OFF");
          ppmuClampOff.wait((groups[i].settlingTime + 1) ms);
          taskList1.add(flexRelay).add(ppmuClampOff).execute();
          // do measurement for single pin
          measureFirst.execute(groups[i].expandedPins[j]);

          if(hasSecondMeasure)
          {
            double low = 0.0 ,high = 0.0;
            groups[i].secondLimit.getLow(&low);
            groups[i].secondLimit.getHigh(&high);
            double dCurrentRange = fabs(groups[i].testCurrentSecondPol);
            TASK_LIST settlingTaskOnly;
            PPMU_SETTING settingPpmuSecond;
            settingPpmuSecond.pin(groups[i].expandedPins[j])
                             .iRange(dCurrentRange uA)
                             .min(low)
                             .max(high)
                             .iForce(groups[i].testCurrentSecondPol uA);
            settlingTaskOnly.add(settingPpmuSecond).execute();
            measureSecond.execute(groups[i].expandedPins[j]);
          }
          TASK_LIST relayTaskOnly;
          FLEX_RELAY flexRelayRestore;
          flexRelayRestore.pin(groups[i].expandedPins[j]).set("IDLE");
          flexRelayRestore.wait(0.3 ms);
          relayTaskOnly.add(flexRelayRestore).execute();
        }
        ON_FIRST_INVOCATION_END();
        xpmuVoltageMeasurementUpdateTestResultForEveryGroup(
            groups[i].expandedPins,testMode,measureFirst,firstResultVec[i]);
        if(hasSecondMeasure)
        {
          xpmuVoltageMeasurementUpdateTestResultForEveryGroup(
              groups[i].expandedPins,testMode,measureSecond,secondResultVec[i]);
        }
      }
    }
  }
}

inline void
ContinuityTest::ppmuVoltageHvMeasurementUpdateTestResult(
    const vector<PPMUGroupParam>& groups,
    const TM::DCTEST_MODE& testMode,
    const HV_DC_TASK&      hvMeasurePpmuFirst,
    const HV_DC_TASK&      hvMeasurePpmuSecond,
    vector<MeasurementResultContainer>& firstResultVec,
    vector<MeasurementResultContainer>& secondResultVec)
{
  // get test result
  MeasurementResultContainer everyGroupResult;
  string hvTestMode = ContinuityTestUtil::getMeasureModeForHVPin(testMode);

  //HV pins are tested before non-HV pins
  for(vector<string>::size_type i = 0; i < groups.size(); i++)
  {
    everyGroupResult.init();
    if(firstResultVec.size() <= i)
    {
      firstResultVec.push_back(everyGroupResult);
    }
    if(secondResultVec.size() <= i)
    {
      secondResultVec.push_back(everyGroupResult);
    }
    if('#' != groups[i].pinlist[0] && groups[i].isHVGroup)
    {
      bool hasSecondMeasure = (groups[i].polarity == "BPOL");
      if(groups[i].measureMode == "PAR")
      {
        xpmuVoltageMeasurementUpdateTestResultForEveryGroup(
            groups[i].expandedPins,testMode,hvMeasurePpmuFirst,firstResultVec[i]);
        if(hasSecondMeasure)
        {
          xpmuVoltageMeasurementUpdateTestResultForEveryGroup(
              groups[i].expandedPins,testMode,hvMeasurePpmuSecond,secondResultVec[i]);
        }
      }
      else
      {
        //Serial testing.
        HV_DC_TASK taskFirst, taskSecond;
        ON_FIRST_INVOCATION_BEGIN();

        double low = 0.0 ,high = 0.0;
        double dCurrentRange = fabs(groups[i].testCurrentFirstPol);

        groups[i].firstLimit.getLow(&low);
        groups[i].firstLimit.getHigh(&high);
        taskFirst.pin(groups[i].pinlist)
                   .iForceRange(dCurrentRange uA)
                   .min(low)
                   .max(high)
                   .iForce(groups[i].testCurrentFirstPol uA)
                   .settling(groups[i].settlingTime ms)
                   .execMode(hvTestMode);

           taskFirst.execute();

          if(hasSecondMeasure)
          {
            dCurrentRange = fabs(groups[i].testCurrentSecondPol);
            taskSecond.pin(groups[i].pinlist)
                      .iForceRange(dCurrentRange uA)
                      .min(low)
                      .max(high)
                      .iForce(groups[i].testCurrentSecondPol uA)
                      .settling(groups[i].settlingTime ms)
                      .execMode(hvTestMode);

            taskSecond.execute();
          }
        ON_FIRST_INVOCATION_END();

        // retrieval test result
        xpmuVoltageMeasurementUpdateTestResultForEveryGroup(
            groups[i].expandedPins,testMode,taskFirst,firstResultVec[i]);
        if(hasSecondMeasure)
        {
          xpmuVoltageMeasurementUpdateTestResultForEveryGroup(
              groups[i].expandedPins,testMode,taskSecond,secondResultVec[i]);
        }
      }
    }
  }
}

template<class T> inline void
ContinuityTest::xpmuVoltageMeasurementUpdateTestResultForEveryGroup(
    const vector<string>&   pinList,
    const TM::DCTEST_MODE& testMode,
    const T&    xpmuTask,
    ContinuityTestUtil::MeasurementResultContainer& result)
{
  vector<string>::size_type  j = 0;
  bool isPass = true;
  switch ( testMode )
  {
  case TM::PVAL:
    for ( j = 0; j < pinList.size(); j++ )
    {
      isPass = xpmuTask.getPassFail(pinList[j]);
      double dMeasValue = xpmuTask.getValue(pinList[j]);

      result.setPinPassFail(pinList[j],isPass);
      result.setPinsValue(pinList[j],dMeasValue);
    }
    break;
  case TM::PPF:
    for ( j = 0; j < pinList.size(); j++ )
    {
      isPass = xpmuTask.getPassFail(pinList[j]);
      result.setPinPassFail(pinList[j],isPass);
    }
    break;
  case TM::GPF:
      isPass = xpmuTask.getPassFail();
      result.setGlobalPassFail(isPass);
    break;
  default:
    throw Error("ContinuityTest::xpmuVoltageMeasurementUpdateTestResultForEveryGroup",
                "Unknown Measure Mode",
                "ContinuityTest::xpmuVoltageMeasurementUpdateTestResultForEveryGroup");
  }
}

inline void
ContinuityTest::spmuInstrumentVoltageMeasurementSetup(
    const vector<SPMUGroupParam>& groups,
    const TM::DCTEST_MODE& testMode,
    SPMU_TASK& spFirstForceOn,
    SPMU_TASK& spSecondForceOn,
    SPMU_TASK& spFirstMeasure,
    SPMU_TASK& spSecondMeasure,
    SPMU_TASK& spFirstForceOff,
    SPMU_TASK& spSecondForceOff,
    bool& hasParallelGroup)
{
  for(vector<string>::size_type i = 0; i < groups.size(); i++)
  {
    if('#' != groups[i].pinlist[0] && groups[i].measureMode == "PAR")
    {
      hasParallelGroup = true;
      double low = 0.0, high = 0.0;
      double clampVoltage = 0.0;
      groups[i].firstLimit.getLow(&low);
      groups[i].firstLimit.getHigh(&high);
      if(groups[i].testCurrentFirstPol > 0)
      {
        clampVoltage = high;
      }
      else
      {
        clampVoltage = low;
      }
      if ( groups[i].prechargeToZeroVol == "ON" )
      {
        spFirstForceOn.pin(groups[i].pinlist)
                      .preCharge(0.0)
                      .max(high)
                      .min(low)
                      .mode("IFVM")
                      .iForce(groups[i].testCurrentFirstPol uA)
                      .clamp(clampVoltage V)
                      .execMode("PAR")
                      .relay("TERM")
                      .settling(groups[i].settlingTime ms);
        spFirstForceOn.execMode("FORCE_ON");
        spFirstMeasure.pin(groups[i].pinlist)
                      .max(high)
                      .min(low)
                      .mode("IFVM")
                      .iForce(groups[i].testCurrentFirstPol uA)
                      .clamp(clampVoltage V)
                      .execMode("PAR")
                      .relay("TERM");
        spFirstMeasure.execMode(testMode);
        spFirstForceOff.pin(groups[i].pinlist)
                       .max(high)
                       .min(low)
                       .mode("IFVM")
                       .iForce(groups[i].testCurrentFirstPol uA)
                       .clamp(clampVoltage V)
                       .execMode("PAR")
                       .relay("TERM");
        spFirstForceOff.execMode("FORCE_OFF");
        if(groups[i].polarity == "BPOL")
        {
          groups[i].secondLimit.getLow(&low);
          groups[i].secondLimit.getHigh(&high);
          spSecondForceOn.pin(groups[i].pinlist)
                         .preCharge(0.0)
                         .max(high)
                         .min(low)
                         .mode("IFVM")
                         .iForce(groups[i].testCurrentSecondPol uA)
                         .clamp(-clampVoltage V)
                         .execMode("PAR")
                         .relay("TERM")
                         .settling(groups[i].settlingTime ms);
          spSecondForceOn.execMode("FORCE_ON");
          spSecondMeasure.pin(groups[i].pinlist)
                         .max(high)
                         .min(low)
                         .mode("IFVM")
                         .iForce(groups[i].testCurrentSecondPol uA)
                         .clamp(-clampVoltage V)
                         .execMode("PAR")
                         .relay("TERM");
          spSecondMeasure.execMode(testMode);
          spSecondForceOff.pin(groups[i].pinlist)
                          .max(high)
                          .min(low)
                          .mode("IFVM")
                          .iForce(groups[i].testCurrentSecondPol uA)
                          .clamp(-clampVoltage V)
                          .execMode("PAR")
                          .relay("TERM");
          spSecondForceOff.execMode("FORCE_OFF");
        }
      }
      else
      {
        spFirstForceOn.pin(groups[i].pinlist)
                      .max(high)
                      .min(low)
                      .mode("IFVM")
                      .iForce(groups[i].testCurrentFirstPol uA)
                      .clamp(clampVoltage V)
                      .execMode("PAR")
                      .relay("TERM")
                      .settling(groups[i].settlingTime ms);
        spFirstForceOn.execMode("FORCE_ON");
        spFirstMeasure.pin(groups[i].pinlist)
                      .max(high)
                      .min(low)
                      .mode("IFVM")
                      .iForce(groups[i].testCurrentFirstPol uA)
                      .clamp(clampVoltage V)
                      .execMode("PAR")
                      .relay("TERM");
        spFirstMeasure.execMode(testMode);
        spFirstForceOff.pin(groups[i].pinlist)
                       .max(high)
                       .min(low)
                       .mode("IFVM")
                       .iForce(groups[i].testCurrentFirstPol uA)
                       .clamp(clampVoltage V)
                       .execMode("PAR")
                       .relay("TERM");
        spFirstForceOff.execMode("FORCE_OFF");
        if(groups[i].polarity == "BPOL")
        {
          groups[i].secondLimit.getLow(&low);
          groups[i].secondLimit.getHigh(&high);
          spSecondForceOn.pin(groups[i].pinlist)
                         .max(high)
                         .min(low)
                         .mode("IFVM")
                         .iForce(groups[i].testCurrentSecondPol uA)
                         .clamp(-clampVoltage V)
                         .execMode("PAR")
                         .relay("TERM")
                         .settling(groups[i].settlingTime ms);
          spSecondForceOn.execMode("FORCE_ON");
          spSecondMeasure.pin(groups[i].pinlist)
                         .max(high)
                         .min(low)
                         .mode("IFVM")
                         .iForce(groups[i].testCurrentSecondPol uA)
                         .clamp(-clampVoltage V)
                         .execMode("PAR")
                         .relay("TERM");
          spSecondMeasure.execMode(testMode);
          spSecondForceOff.pin(groups[i].pinlist)
                          .max(high)
                          .min(low)
                          .mode("IFVM")
                          .iForce(groups[i].testCurrentSecondPol uA)
                          .clamp(-clampVoltage V)
                          .execMode("PAR")
                          .relay("TERM");
          spSecondForceOff.execMode("FORCE_OFF");
        }
      }
    }
  }
}



inline void
ContinuityTest::spmuVoltageMeasurementUpdateTestResult(
    const vector<SPMUGroupParam>& groups,
    const TM::DCTEST_MODE& testMode,
    const SPMU_TASK&    firstSpmuTask,
    const SPMU_TASK&    secondSpmuTask,
    vector<MeasurementResultContainer>& firstResult,
    vector<MeasurementResultContainer>& secondResult)
{
  // get test result
  MeasurementResultContainer everyGroupResult;
  for(vector<string>::size_type i = 0; i < groups.size(); i++)
  {
    everyGroupResult.init();
    if(firstResult.size() <= i)
    {
      firstResult.push_back(everyGroupResult);
    }
    if(secondResult.size() <= i)
    {
      secondResult.push_back(everyGroupResult);
    }
    if('#' != groups[i].pinlist[0] && groups[i].measureMode == "PAR")
    {
      xpmuVoltageMeasurementUpdateTestResultForEveryGroup(
          groups[i].expandedPins,testMode,firstSpmuTask,firstResult[i]);
      if(groups[i].polarity == "BPOL")
      {
        xpmuVoltageMeasurementUpdateTestResultForEveryGroup(
            groups[i].expandedPins,testMode,secondSpmuTask,secondResult[i]);
      }
    }
    else if('#' != groups[i].pinlist[0])
    {
      SPMU_TASK spmuTaskOne, spmuTaskTwo;
      ON_FIRST_INVOCATION_BEGIN();
      double low = 0.0, high = 0.0;
      double clampVoltage = 0.0;
      groups[i].firstLimit.getLow(&low);
      groups[i].firstLimit.getHigh(&high);
      if(groups[i].testCurrentFirstPol > 0)
      {
        clampVoltage = high;
      }
      else
      {
        clampVoltage = low;
      }
      if ( groups[i].prechargeToZeroVol == "ON" )
      {
        spmuTaskOne.pin(groups[i].pinlist)
                   .preCharge(0.0)
                   .max(high)
                   .min(low)
                   .mode("IFVM")
                   .iForce(groups[i].testCurrentFirstPol uA)
                   .clamp(clampVoltage V)
                   .execMode("SER")
                   .relay("TERM")
                   .settling(groups[i].settlingTime ms);
        if(groups[i].polarity == "BPOL")
        {
          groups[i].secondLimit.getLow(&low);
          groups[i].secondLimit.getHigh(&high);
          spmuTaskTwo.pin(groups[i].pinlist)
                     .preCharge(0.0)
                     .max(high)
                     .min(low)
                     .mode("IFVM")
                     .iForce(groups[i].testCurrentSecondPol uA)
                     .clamp(-clampVoltage V)
                     .execMode("SER")
                     .relay("TERM")
                     .settling(groups[i].settlingTime ms);
        }
      }
      else
      {
        spmuTaskOne.pin(groups[i].pinlist)
                   .max(high)
                   .min(low)
                   .mode("IFVM")
                   .iForce(groups[i].testCurrentFirstPol uA)
                   .clamp(clampVoltage V)
                   .execMode("SER")
                   .relay("TERM")
                   .settling(groups[i].settlingTime ms);
        if(groups[i].polarity == "BPOL")
        {
          groups[i].secondLimit.getLow(&low);
          groups[i].secondLimit.getHigh(&high);
          spmuTaskTwo.pin(groups[i].pinlist)
                     .max(high)
                     .min(low)
                     .mode("IFVM")
                     .iForce(groups[i].testCurrentSecondPol uA)
                     .clamp(-clampVoltage V)
                     .execMode("SER")
                     .relay("TERM")
                     .settling(groups[i].settlingTime ms);
        }
      }
      // PVAL or PPF or GPF is defined by TestSuite Flag
      spmuTaskOne.execMode(testMode);
      spmuTaskOne.execute();
      if(groups[i].polarity == "BPOL")
      {
        spmuTaskTwo.execMode(testMode);
        spmuTaskTwo.execute();
      }
      ON_FIRST_INVOCATION_END();
      xpmuVoltageMeasurementUpdateTestResultForEveryGroup(
          groups[i].expandedPins,testMode,spmuTaskOne,firstResult[i]);
      if(groups[i].polarity == "BPOL")
      {
        xpmuVoltageMeasurementUpdateTestResultForEveryGroup(
            groups[i].expandedPins,testMode,spmuTaskTwo,secondResult[i]);
      }
    }
  }
}

inline void
ContinuityTest::mcxInstrumentVoltageMeasurement(
    const vector<MCXGroupParam>& groups,
    const TM::DCTEST_MODE& testMode,
    vector<MeasurementResultContainer>& firstResultVec,
    vector<MeasurementResultContainer>& secondResultVec)
{
  MeasurementResultContainer everyGroupResult;
  for(vector<string>::size_type i = 0; i < groups.size(); i++)
  {
    everyGroupResult.init();
    if(firstResultVec.size() <= i)
    {
      firstResultVec.push_back(everyGroupResult);
    }
    if(secondResultVec.size() <= i)
    {
      secondResultVec.push_back(everyGroupResult);
    }
    if('#' != groups[i].pinlist[0])
    {
      PMU_IFVM pmuIfvm(groups[i].pinlist,TM::PPMU);

      ON_FIRST_INVOCATION_BEGIN();
      double low = 0.0, high = 0.0;
      groups[i].firstLimit.getLow(&low);
      groups[i].firstLimit.getHigh(&high);

      pmuIfvm.iForce(groups[i].testCurrentFirstPol uA)
             .min_voltage(low)
             .max_voltage(high)
             .settling(groups[i].settlingTime ms);
      // for MCX-PMU, member function iRange is ignored since the MCX has only one current range
      if(groups[i].measureMode == "PAR")
      {
        pmuIfvm.mode("NP");
      }
      else
      {
        pmuIfvm.mode("NS");
      }
      // PVAL or PPF or GPF is defined by TestSuite Flag
      pmuIfvm.execute(testMode);

      FOR_EACH_SITE_BEGIN();
        UpdateTestResultForUsingLegacyAPI(
            groups[i].expandedPins,testMode,pmuIfvm,firstResultVec[i]);
      FOR_EACH_SITE_END();

      if(groups[i].polarity == "BPOL")
      {
        groups[i].secondLimit.getLow(&low);
        groups[i].secondLimit.getHigh(&high);

        pmuIfvm.iForce(groups[i].testCurrentSecondPol uA)
               .min_voltage(low)
               .max_voltage(high)
               .settling(groups[i].settlingTime ms);
        // for MCX-PMU, member function iRange is ignored since the MCX has only one current range
        if(groups[i].measureMode == "PAR")
        {
          pmuIfvm.mode("NP");
        }
        else
        {
          pmuIfvm.mode("NS");
        }
        // PVAL or PPF or GPF is defined by TestSuite Flag
        pmuIfvm.execute( testMode);

        FOR_EACH_SITE_BEGIN();
          UpdateTestResultForUsingLegacyAPI(
            groups[i].expandedPins,testMode,pmuIfvm,secondResultVec[i]);
        FOR_EACH_SITE_END();

      }
      ON_FIRST_INVOCATION_END();
    }
  }
}

inline void
ContinuityTest::UpdateTestResultForUsingLegacyAPI(
    const vector<string>&   pinList,
    const TM::DCTEST_MODE& testMode,
    const PMU_IFVM&    measurePmu,
    MeasurementResultContainer& result)
{
  int siteNumber = CURRENT_SITE_NUMBER();
  vector<string>::size_type  j = 0;
  bool isPass = true;
  switch ( testMode )
  {
  case TM::PVAL:
    for ( j = 0; j < pinList.size(); j++ )
    {
      isPass = measurePmu.getPassFail(pinList[j]);
      double dMeasValue = measurePmu.getValue(pinList[j]);
      // we use PMU_IFVM API, change the value's unit
      dMeasValue = dMeasValue * 1e-3; // [mV] --> [V]

      result.setPinPassFail(pinList[j],isPass,siteNumber);
      result.setPinsValue(pinList[j],dMeasValue,siteNumber);
    }
    break;
  case TM::PPF:
    for ( j = 0; j < pinList.size(); j++ )
    {
      isPass = measurePmu.getPassFail(pinList[j]);
      result.setPinPassFail(pinList[j],isPass,siteNumber);
    }
    break;
  case TM::GPF:
      isPass = measurePmu.getPassFail();
      result.setGlobalPassFail(isPass,siteNumber);
    break;
  default:
    throw Error("ContinuityTest::UpdateTestResultForUsingLegacyAPI",
                "Unknown Measure Mode",
                "ContinuityTest::UpdateTestResultForUsingLegacyAPI");
  }
}

inline void
ContinuityTest::dpsInstrumentCurrentMeasurement(
    const vector<DPSGroupParam>& groups,
    const TM::DCTEST_MODE& testMode,
    vector<MeasurementResultContainer>& firstResultVec,
    vector<MeasurementResultContainer>& secondResultVec)
{
  // for Parallel execute mode
  DPS_TASK dpsTaskParallelFirstPol;
  DPS_TASK dpsTaskParallelSecondPol;

  bool hasParallelGroupFirstPol = false;
  bool hasParallelGroupSecondPol = false;

  ON_FIRST_INVOCATION_BEGIN();
  CONNECT();
  double waitTime = 0.0;
  for(vector<string>::size_type i = 0; i < groups.size(); i++)
  {
    if('#' != groups[i].pinlist[0])
    {
      Primary.getLevelSpec().change(groups[i].specName,groups[i].specValueFirstPol);
      if(groups[i].measureMode == "PAR")
      {
        hasParallelGroupFirstPol = true;
        dpsTaskParallelFirstPol.pin(groups[i].pinlist).limits(groups[i].firstLimit);
        dpsTaskParallelFirstPol.samples(4);// default samples is 4?
        if(waitTime < groups[i].settlingTime)
        {
          waitTime = groups[i].settlingTime;
        }
      }
    }
  }
  //  PVAL or PPF or GPF is defined by TestSuite Flag
  if(hasParallelGroupFirstPol)
  {
    FLUSH(TM::APRM);
    dpsTaskParallelFirstPol.wait(waitTime ms);
    dpsTaskParallelFirstPol.execMode(testMode);
    dpsTaskParallelFirstPol.execute();
    Primary.getLevelSpec().restore();
    FLUSH(TM::APRM);
  }

  waitTime = 0.0;
  for(vector<string>::size_type i = 0; i< groups.size(); i++)
  {
    if('#' != groups[i].pinlist[0] && groups[i].polarity == "BPOL")
    {
      Primary.getLevelSpec().change(groups[i].specName,groups[i].specValueSecondPol);
      if(groups[i].measureMode == "PAR")
      {
        hasParallelGroupSecondPol = true;
        dpsTaskParallelSecondPol.pin(groups[i].pinlist).limits(groups[i].secondLimit);
        dpsTaskParallelFirstPol.samples(4);// default samples is 4?
        if(waitTime < groups[i].settlingTime)
        {
          waitTime = groups[i].settlingTime;
        }
      }
    }
  }
  // PVAL or PPF or GPF is defined by TestSuite Flag
  if(hasParallelGroupSecondPol)
  {
    FLUSH(TM::APRM);
    dpsTaskParallelSecondPol.wait(waitTime ms);
    dpsTaskParallelSecondPol.execMode(testMode);
    dpsTaskParallelSecondPol.execute();
    Primary.getLevelSpec().restore();
    FLUSH(TM::APRM);
  }
  DISCONNECT();
  ON_FIRST_INVOCATION_END();

  MeasurementResultContainer groupResult;
  // get test result
  for(vector<string>::size_type i = 0; i < groups.size(); i++)
  {
    groupResult.init();
    if(firstResultVec.size() <= i)
    {
      firstResultVec.push_back(groupResult);
    }
    if(secondResultVec.size() <= i)
    {
      secondResultVec.push_back(groupResult);
    }
    if('#' != groups[i].pinlist[0] && groups[i].measureMode == "PAR")
    {
      dpsMeasurementCurrentGetResultForEveryGroup(
          groups[i].expandedPins,testMode,dpsTaskParallelFirstPol,firstResultVec[i]);
      if(groups[i].polarity == "BPOL")
      {
        dpsMeasurementCurrentGetResultForEveryGroup(
            groups[i].expandedPins,testMode,dpsTaskParallelSecondPol,secondResultVec[i]);
      }
    }
    else if('#' != groups[i].pinlist[0])
    {
      DPS_TASK dpsTaskFirstPol,dpsTaskSecondPol;
      ON_FIRST_INVOCATION_BEGIN();
      CONNECT();
      Primary.getLevelSpec().change(groups[i].specName,groups[i].specValueFirstPol);
      dpsTaskFirstPol.pin(groups[i].pinlist)
                     .limits(groups[i].firstLimit);
      dpsTaskFirstPol.wait(groups[i].settlingTime ms);

      /* PVAL or PPF or GPF is defined by TestSuite Flag */
      FLUSH(TM::APRM);
      dpsTaskFirstPol.execMode(testMode);
      dpsTaskFirstPol.execute();
      Primary.getLevelSpec().restore();
      FLUSH(TM::APRM);

      if(groups[i].polarity == "BPOL")
      {
        Primary.getLevelSpec().change(groups[i].specName,groups[i].specValueSecondPol);
        dpsTaskSecondPol.pin(groups[i].pinlist)
                        .limits(groups[i].secondLimit);
        dpsTaskSecondPol.wait(groups[i].settlingTime ms);

        /* PVAL or PPF or GPF is defined by TestSuite Flag */
        FLUSH(TM::APRM);
        dpsTaskSecondPol.execMode(testMode);
        dpsTaskSecondPol.execute();
        Primary.getLevelSpec().restore();
        FLUSH(TM::APRM);
      }
      DISCONNECT();
      ON_FIRST_INVOCATION_END();
      dpsMeasurementCurrentGetResultForEveryGroup(
          groups[i].expandedPins,testMode,dpsTaskFirstPol,firstResultVec[i]);
      if(groups[i].polarity == "BPOL")
      {
        dpsMeasurementCurrentGetResultForEveryGroup(
            groups[i].expandedPins,testMode,dpsTaskSecondPol,secondResultVec[i]);
      }
    }
  }
}


inline void
ContinuityTest::dpsMeasurementCurrentGetResultForEveryGroup(
    const vector<string>&   pinlist,
    const TM::DCTEST_MODE& testMode,
    const DPS_TASK&    dpsTask,
    MeasurementResultContainer& result)
{
  vector<string>::size_type  j = 0;
  bool isPass = true;

  switch ( testMode )
  {
  case TM::PVAL:
    for ( j = 0; j < pinlist.size(); j++ )
    {
      isPass = dpsTask.getPassFail(pinlist[j]);
      double dMeasValue = dpsTask.getValue(pinlist[j]); /* [A] */

      result.setPinPassFail(pinlist[j],isPass);
      result.setPinsValue(pinlist[j],dMeasValue);
    }
    break;

  case TM::PPF:
    for ( j = 0; j < pinlist.size(); j++ )
    {
      isPass = dpsTask.getPassFail(pinlist[j]);
      result.setPinPassFail(pinlist[j],isPass);
    }
    break;

  case TM::GPF:
    isPass = isPass && dpsTask.getPassFail();
    result.setGlobalPassFail(isPass);
    break;

  default:
    throw Error("ContinuityTest::dpsMeasurementCurrentGetResultForEveryGroup",
                "Unknown Measure Mode",
                "ContinuityTest::dpsMeasurementCurrentGetResultForEveryGroup");
  }
}

inline void
ContinuityTest::DCScaleSIGInstrumentVoltageMeasurementSetup(
    const vector<DCScaleSIGGroupParam>& groups,
    const TM::DCTEST_MODE& testMode,
    SPMU_TASK& spmuFirstTaskMeasure,
    SPMU_TASK& spmuSecondTaskMeasure,
    bool& hasParallelGroup)
{
  // for Parallel execute mode
  for(unsigned i = 0; i < groups.size(); i++)
  {
    if('#' != groups[i].pinlist[0] && groups[i].measureMode == "PAR")
    {
      hasParallelGroup = true;
      double low = 0.0, high = 0.0;
      double clampVoltage = 0.0;
      groups[i].firstLimit.getLow(&low);
      groups[i].firstLimit.getHigh(&high);
      if(groups[i].testCurrentFirstPol > 0)
      {
        clampVoltage = high;
      }
      else
      {
        clampVoltage = low;
      }
      if ( groups[i].prechargeToZeroVol == "ON" )
      {
        spmuFirstTaskMeasure.pin(groups[i].pinlist)
                            .preCharge(0.0)
                            .max(high)
                            .min(low)
                            .mode("IFVM")
                            .iForce(groups[i].testCurrentFirstPol uA)
                            .clamp(clampVoltage V)
                            .execMode("PAR")
                            .relay("NT")
                            .settling(groups[i].settlingTime ms);
        spmuFirstTaskMeasure.execMode(testMode);
        if(groups[i].polarity == "BPOL")
        {
          groups[i].secondLimit.getLow(&low);
          groups[i].secondLimit.getHigh(&high);
          spmuSecondTaskMeasure.pin(groups[i].pinlist)
                               .preCharge(0.0)
                               .max(high)
                               .min(low)
                               .mode("IFVM")
                               .iForce(groups[i].testCurrentSecondPol uA)
                               .clamp(-clampVoltage V)
                               .execMode("PAR")
                               .relay("NT")
                               .settling(groups[i].settlingTime ms);
          spmuSecondTaskMeasure.execMode(testMode);
        }
      }
      else
      {
        spmuFirstTaskMeasure.pin(groups[i].pinlist)
                            .max(high)
                            .min(low)
                            .mode("IFVM")
                            .iForce(groups[i].testCurrentFirstPol uA)
                            .clamp(clampVoltage V)
                            .execMode("PAR")
                            .relay("NT")
                            .settling(groups[i].settlingTime ms);
        spmuFirstTaskMeasure.execMode(testMode);
        if(groups[i].polarity == "BPOL")
        {
          groups[i].secondLimit.getLow(&low);
          groups[i].secondLimit.getHigh(&high);
          spmuSecondTaskMeasure.pin(groups[i].pinlist)
                               .max(high)
                               .min(low)
                               .mode("IFVM")
                               .iForce(groups[i].testCurrentSecondPol uA)
                               .clamp(-clampVoltage V)
                               .execMode("PAR")
                               .relay("NT")
                               .settling(groups[i].settlingTime ms);
          spmuSecondTaskMeasure.execMode(testMode);
        }
      }
    }
  }
}


inline void
ContinuityTest::DCScaleSIGMeasurementVoltageUpdateTestResult(
    const vector<DCScaleSIGGroupParam>& groups,
    const TM::DCTEST_MODE& testMode,
    const SPMU_TASK&    firstSpmuTask,
    const SPMU_TASK&    secondSpmuTask,
    vector<MeasurementResultContainer>& firstResult,
    vector<MeasurementResultContainer>& secondResult)
{
  // get test result
  MeasurementResultContainer everyGroupResult;
  for(vector<string>::size_type i = 0; i < groups.size(); i++)
  {
    everyGroupResult.init();
    if(firstResult.size() <= i)
    {
      firstResult.push_back(everyGroupResult);
    }
    if(secondResult.size() <= i)
    {
      secondResult.push_back(everyGroupResult);
    }

    if('#' != groups[i].pinlist[0] && groups[i].measureMode == "PAR")
    {
      xpmuVoltageMeasurementUpdateTestResultForEveryGroup(
          groups[i].expandedPins,testMode,firstSpmuTask,firstResult[i]);
      if(groups[i].polarity == "BPOL")
      {
        xpmuVoltageMeasurementUpdateTestResultForEveryGroup(
            groups[i].expandedPins,testMode,secondSpmuTask,secondResult[i]);
      }
    }
    else if('#' != groups[i].pinlist[0])
    {
      SPMU_TASK spmuTaskOne, spmuTaskTwo;
      SPMU_TASK spmuFirstForceOn,spmuSecondForceOn;
      SPMU_TASK spmuFirstForceOff, spmuSecondForceOff;
      ON_FIRST_INVOCATION_BEGIN();
      TASK_LIST tastList;
      double low = 0.0, high = 0.0;
      double clampVoltage = 0.0;
      groups[i].firstLimit.getLow(&low);
      groups[i].firstLimit.getHigh(&high);
      if(groups[i].testCurrentFirstPol > 0)
      {
        clampVoltage = high;
      }
      else
      {
        clampVoltage = low;
      }
      if ( groups[i].prechargeToZeroVol == "ON" )
      {
        spmuFirstForceOn.pin(groups[i].pinlist)
                        .preCharge(0.0)
                        .max(high)
                        .min(low)
                        .mode("IFVM")
                        .iForce(groups[i].testCurrentFirstPol uA)
                        .clamp(clampVoltage V)
                        .execMode("SER")
                        .relay("NT")
                        .settling(groups[i].settlingTime ms);
        spmuFirstForceOn.execMode("FORCE_ON");
        spmuTaskOne.pin(groups[i].pinlist)
                   .max(high)
                   .min(low)
                   .mode("IFVM")
                   .iForce(groups[i].testCurrentFirstPol uA)
                   .clamp(clampVoltage V)
                   .execMode("SER")
                   .relay("NT");
        spmuFirstForceOff.pin(groups[i].pinlist)
                         .max(high)
                         .min(low)
                         .mode("IFVM")
                         .iForce(groups[i].testCurrentFirstPol uA)
                         .clamp(clampVoltage V)
                         .execMode("SER")
                         .relay("NT");
        spmuFirstForceOff.execMode("FORCE_OFF");
        if(groups[i].polarity == "BPOL")
        {
          groups[i].secondLimit.getLow(&low);
          groups[i].secondLimit.getHigh(&high);
          spmuSecondForceOn.pin(groups[i].pinlist)
                           .preCharge(0.0)
                           .max(high)
                           .min(low)
                           .mode("IFVM")
                           .iForce(groups[i].testCurrentSecondPol uA)
                           .clamp(-clampVoltage V)
                           .execMode("SER")
                           .relay("NT")
                           .settling(groups[i].settlingTime ms);
          spmuTaskTwo.pin(groups[i].pinlist)
                     .max(high)
                     .min(low)
                     .mode("IFVM")
                     .iForce(groups[i].testCurrentSecondPol uA)
                     .clamp(-clampVoltage V)
                     .execMode("SER")
                     .relay("NT");
          spmuSecondForceOff.pin(groups[i].pinlist)
                            .max(high)
                            .min(low)
                            .mode("IFVM")
                            .iForce(groups[i].testCurrentSecondPol uA)
                            .clamp(-clampVoltage V)
                            .execMode("SER")
                            .relay("NT");
        }
      }
      else
      {
        spmuFirstForceOn.pin(groups[i].pinlist)
                        .max(high)
                        .min(low)
                        .mode("IFVM")
                        .iForce(groups[i].testCurrentFirstPol uA)
                        .clamp(clampVoltage V)
                        .execMode("SER")
                        .relay("NT")
                        .settling(groups[i].settlingTime ms);
        spmuTaskOne.pin(groups[i].pinlist)
                   .max(high)
                   .min(low)
                   .mode("IFVM")
                   .iForce(groups[i].testCurrentFirstPol uA)
                   .clamp(clampVoltage V)
                   .execMode("SER")
                   .relay("NT");
        spmuFirstForceOff.pin(groups[i].pinlist)
                         .max(high)
                         .min(low)
                         .mode("IFVM")
                         .iForce(groups[i].testCurrentFirstPol uA)
                         .clamp(clampVoltage V)
                         .execMode("SER")
                         .relay("NT");
        if(groups[i].polarity == "BPOL")
        {
          groups[i].secondLimit.getLow(&low);
          groups[i].secondLimit.getHigh(&high);
          spmuSecondForceOn.pin(groups[i].pinlist)
                           .max(high)
                           .min(low)
                           .mode("IFVM")
                           .iForce(groups[i].testCurrentSecondPol uA)
                           .clamp(-clampVoltage V)
                           .execMode("SER")
                           .relay("NT")
                           .settling(groups[i].settlingTime ms);
          spmuTaskTwo.pin(groups[i].pinlist)
                     .max(high)
                     .min(low)
                     .mode("IFVM")
                     .iForce(groups[i].testCurrentSecondPol uA)
                     .clamp(-clampVoltage V)
                     .execMode("SER")
                     .relay("NT");
          spmuSecondForceOff.pin(groups[i].pinlist)
                            .max(high)
                            .min(low)
                            .mode("IFVM")
                            .iForce(groups[i].testCurrentSecondPol uA)
                            .clamp(-clampVoltage V)
                            .execMode("SER")
                            .relay("NT");
        }
      }
      // PVAL or PPF or GPF is defined by TestSuite Flag
      spmuTaskOne.execMode(testMode);
      spmuTaskOne.execute();
      if(groups[i].polarity == "BPOL")
      {
        spmuTaskTwo.execMode(testMode);
        spmuTaskTwo.execute();
      }
      ON_FIRST_INVOCATION_END();
      xpmuVoltageMeasurementUpdateTestResultForEveryGroup(
          groups[i].expandedPins,testMode,spmuTaskOne,firstResult[i]);
      if(groups[i].polarity == "BPOL")
      {
        xpmuVoltageMeasurementUpdateTestResultForEveryGroup(
            groups[i].expandedPins,testMode,spmuTaskTwo,secondResult[i]);
      }
    }
  }
}


inline void
ContinuityTest::DCScaleDPSInstrumentVoltageMeasurement(
    const vector<DCScaleDPSGroupParam>& groups,
    const TM::DCTEST_MODE& testMode,
    vector<MeasurementResultContainer>& firstResultVec,
    vector<MeasurementResultContainer>& secondResultVec)
{
  // for Parallel execute mode
  DPS_TASK dpsTaskParallelFirstPol;
  DPS_TASK dpsTaskParallelSecondPol;

  bool hasParallelGroupFirstPol = false;
  bool hasParallelGroupSecondPol = false;

  ON_FIRST_INVOCATION_BEGIN();
  CONNECT();
  double waitTime = 0.0;
  for(vector<string>::size_type i = 0; i < groups.size(); i++)
  {
    if('#' != groups[i].pinlist[0])
    {
      Primary.getLevelSpec().change(groups[i].specName,groups[i].specValueFirstPol);
      if(groups[i].measureMode == "PAR")
      {
        hasParallelGroupFirstPol = true;
        dpsTaskParallelFirstPol.pin(groups[i].pinlist)
                               .measurementMode(TM::MEASURE_VOLTAGE)
                               .limits(groups[i].firstLimit);
        if(waitTime < groups[i].settlingTime)
        {
          waitTime = groups[i].settlingTime;
        }
      }
    }
  }

  /* PVAL or PPF or GPF is defined by TestSuite Flag */
  if(hasParallelGroupFirstPol)
  {
    FLUSH(TM::APRM);
    dpsTaskParallelFirstPol.wait(waitTime ms);
    dpsTaskParallelFirstPol.execMode(testMode);
    dpsTaskParallelFirstPol.execute();
    Primary.getLevelSpec().restore();
    FLUSH(TM::APRM);
  }

  waitTime = 0.0;
  for(vector<string>::size_type i = 0; i< groups.size(); i++)
  {
    if('#' != groups[i].pinlist[0] && groups[i].polarity == "BPOL")
    {
      Primary.getLevelSpec().change(groups[i].specName,groups[i].specValueSecondPol);
      if(groups[i].measureMode == "PAR")
      {
        hasParallelGroupSecondPol = true;
        dpsTaskParallelSecondPol.pin(groups[i].pinlist)
                                .measurementMode(TM::MEASURE_VOLTAGE)
                                .limits(groups[i].secondLimit);
        if(waitTime < groups[i].settlingTime)
        {
          waitTime = groups[i].settlingTime;
        }
      }
    }
  }
  /* PVAL or PPF or GPF is defined by TestSuite Flag */
  if(hasParallelGroupSecondPol)
  {
    FLUSH(TM::APRM);
    dpsTaskParallelSecondPol.wait(waitTime ms);
    dpsTaskParallelSecondPol.execMode(testMode);
    dpsTaskParallelSecondPol.execute();
    Primary.getLevelSpec().restore();
    FLUSH(TM::APRM);
  }
  DISCONNECT();
  ON_FIRST_INVOCATION_END();

  MeasurementResultContainer groupResult;
  // get test result
  for(vector<string>::size_type i = 0; i < groups.size(); i++)
  {
    groupResult.init();
    if(firstResultVec.size() <= i)
    {
      firstResultVec.push_back(groupResult);
    }
    if(secondResultVec.size() <= i)
    {
      secondResultVec.push_back(groupResult);
    }
    if('#' != groups[i].pinlist[0] && groups[i].measureMode == "PAR")
    {
      DCScaleDPSMeasurementUpdateTestResult(
          groups[i].expandedPins,testMode,dpsTaskParallelFirstPol,firstResultVec[i]);
      if(groups[i].polarity == "BPOL")
      {
        DCScaleDPSMeasurementUpdateTestResult(
            groups[i].expandedPins,testMode,dpsTaskParallelSecondPol,secondResultVec[i]);
      }
    }
    else if('#' != groups[i].pinlist[0])
    {
      DPS_TASK dpsTaskFirstPol,dpsTaskSecondPol;
      ON_FIRST_INVOCATION_BEGIN();
      CONNECT();
      Primary.getLevelSpec().change(groups[i].specName,groups[i].specValueFirstPol);
      dpsTaskFirstPol.pin(groups[i].pinlist)
                     .measurementMode(TM::MEASURE_VOLTAGE)
                     .limits(groups[i].firstLimit);
      dpsTaskFirstPol.wait(groups[i].settlingTime ms);

      /* PVAL or PPF or GPF is defined by TestSuite Flag */
      FLUSH(TM::APRM);
      dpsTaskFirstPol.execMode(testMode);
      dpsTaskFirstPol.execute();
      Primary.getLevelSpec().restore();
      FLUSH(TM::APRM);

      if(groups[i].polarity == "BPOL")
      {
        Primary.getLevelSpec().change(groups[i].specName,groups[i].specValueSecondPol);
        dpsTaskSecondPol.pin(groups[i].pinlist)
                        .measurementMode(TM::MEASURE_VOLTAGE)
                        .limits(groups[i].secondLimit);
        dpsTaskSecondPol.wait(groups[i].settlingTime ms);

        /* PVAL or PPF or GPF is defined by TestSuite Flag */
        FLUSH(TM::APRM);
        dpsTaskSecondPol.execMode(testMode);
        dpsTaskSecondPol.execute();
        Primary.getLevelSpec().restore();
        FLUSH(TM::APRM);
      }
      DISCONNECT();
      ON_FIRST_INVOCATION_END();
      DCScaleDPSMeasurementUpdateTestResult(
          groups[i].expandedPins,testMode,dpsTaskFirstPol,firstResultVec[i]);
      if(groups[i].polarity == "BPOL")
      {
        DCScaleDPSMeasurementUpdateTestResult(
            groups[i].expandedPins,testMode,dpsTaskSecondPol,secondResultVec[i]);
      }
    }
  }
}


inline void
ContinuityTest::DCScaleDPSMeasurementUpdateTestResult(
    const vector<string>&   pinList,
    const TM::DCTEST_MODE& testMode,
    const DPS_TASK&    dpsTask,
    MeasurementResultContainer& result)
{
  vector<string>::size_type  j = 0;
  bool isPass = true;
  switch ( testMode )
  {
  case TM::PVAL:
    for ( j = 0; j < pinList.size(); j++ )
    {
      isPass = dpsTask.getPassFail(pinList[j]);
      double dMeasValue = dpsTask.getValue(pinList[j]); /* [A] */

      result.setPinPassFail(pinList[j],isPass);
      result.setPinsValue(pinList[j],dMeasValue);
    }
    break;

  case TM::PPF:
    for ( j = 0; j < pinList.size(); j++ )
    {
      isPass = dpsTask.getPassFail(pinList[j]);
      result.setPinPassFail(pinList[j],isPass);
    }
    break;

  case TM::GPF:
    isPass = dpsTask.getPassFail();
    result.setGlobalPassFail(isPass);
    break;

  default:
    throw Error("ContinuityTest::DCScaleDPSMeasurementUpdateTestResult",
                "Unknown Measure Mode",
                "ContinuityTest::DCScaleDPSMeasurementUpdateTestResult");
  }
}

inline void ContinuityTest::clonePPMUGroupParam(
		     const PPMUGroupParam & nonHvPara,
		     PPMUGroupParam & hvPara)
{
  //hvPara.pinlist, will be assigned value later
  hvPara.testCurrentFirstPol = nonHvPara.testCurrentFirstPol;
  hvPara.testCurrentSecondPol = nonHvPara.testCurrentSecondPol;
  hvPara.settlingTime = nonHvPara.settlingTime;
  hvPara.measureMode = nonHvPara.measureMode;
  hvPara.polarity = nonHvPara.polarity;
  hvPara.firstLimit = nonHvPara.firstLimit;
  hvPara.secondLimit = nonHvPara.secondLimit;
  hvPara.limitName = nonHvPara.limitName;
  //hvPara.expandedPins will be assigned value later.
}

#endif /* CONTINUITYIMP_CPP_ */
