#ifndef LEAKAGETESTUTIL_HPP_
#define LEAKAGETESTUTIL_HPP_

#include "testmethod.hpp"

/**
 * try to get all required test names from test table
 * record valid test name and invalid test name
 */
class TesttableLimitHelper
{
  private:
    std::vector<std::string> mTestnameNotInTable;
    std::vector<std::string> mTestnameInTable;
    std::string mTestsuiteName;
    bool mIsLimitCsvFileLoad;
  public:
    explicit TesttableLimitHelper(const string& testsuitename)
      :mTestsuiteName(testsuitename),mIsLimitCsvFileLoad(false)
    {
      TestTable* pLimitTable = TestTable::getDefaultInstance();
      pLimitTable->readCsvFile();
      mIsLimitCsvFileLoad = pLimitTable->isTmLimitsCsvFile();

      mTestnameNotInTable.clear();
      mTestnameInTable.clear();
    }

    ~TesttableLimitHelper()
    {
    }

    const std::vector<std::string>& getInvalidTestnames()
    {
      return mTestnameNotInTable;
    }

    const std::vector<std::string>& getValidTestnames()
    {
      return mTestnameInTable;
    }

    //return if all test names are valid in CSV file
    const bool isAllInTable()
    {
      return (mIsLimitCsvFileLoad &&
              !mTestnameInTable.empty() &&
              mTestnameNotInTable.empty());
    }

    const bool isLimitCsvFileLoad()
    {
      return mIsLimitCsvFileLoad;
    }

    /**
     * for the current testsuite, the method try to get the limit object from test table
     * by the specified test name (i.e. name for limit).
     * @param:
     *    testname: the specific test name defined for the testsuite
     *    toLimit: the target limit object defined in test table
     * @note:
     *   1) if the test name is defined in test table,
     *      the target limit object is got from table;
     *      otherwise, the limit object is untouched as it is.
     *   2) exceptional case:
     *      a) if the csv file is not loaded, exception is thrown.
     *
     *      b) if there are multiple limits needed for this testsuite,
     *      and only if some testname are valid but others are NOT valid,
     *      one exception is thrown out!
     */
    void getLimit(const std::string& testname, LIMIT& toLimit)throw(Error)
    {
      if (!mIsLimitCsvFileLoad)
      {
        throw Error("TesttableLimitHelper",
          "no limit CSV file is loaded!",
          "TesttableLimitHelper");
      }

      try
      {
        V93kLimits::TMLimits::LimitInfo& limitInfo =
          V93kLimits::tmLimits.getLimit(mTestsuiteName,testname);

        toLimit = limitInfo.TEST_API_LIMIT;
        mTestnameInTable.push_back(testname);
      }
      catch (Error& e)
      {
        mTestnameNotInTable.push_back(testname);
      }

      //confiliction: some limits are valid but others are not
      if (!mTestnameInTable.empty() && !mTestnameNotInTable.empty())
      {
        throw Error("TesttableLimitHelper",
          "[testsuite: \""+mTestsuiteName+"\"]: test name \""+testname
          +"\" is not found in test table!");
      }
    }
}; //class TesttableLimitHelper


class LeakageTestUtil
{
public:
  /*
   *---------------------------------------------------------------------*
   *MeasurementResultContainer:
   *  This class is used to hold and output
   *  global or per pin result: pass/fail, values.
   *---------------------------------------------------------------------*
   *  Notes:
   *  If the results of all sites are cached in Testmethod, not in
   *  TestmethodAPI, this class can store results for each specific site.
   *
   *  Typical use case is to directly use firmware commands to test and get
   *  result for all sites in Testmethod, then use this class to store and
   *  retrieve result for all sites.
   *---------------------------------------------------------------------*
   */
  struct MeasurementResultContainer
  {
    MeasurementResultContainer()
    {
      init();
    };
    ~MeasurementResultContainer() {};
    void setGlobalPassFail(bool isPass,int siteNumber = 0 )
    {
      mMultiSiteGlobalPassFail[siteNumber] = isPass;
    };
    void setPinPassFail(const string& pin,bool isPass,int siteNumber = 0)
    {
      mMultiSitePinPassFail[siteNumber][pin]= isPass;
    };
    void setPinsValue(const string& pins,double value,int siteNumber = 0)
    {
      mMultiSitePinsValue[siteNumber][pins]= value;
    };
    bool getGlobalPassFail(int siteNumber = 0) const
    {
      map< int,bool >::const_iterator it =
                          mMultiSiteGlobalPassFail.find(siteNumber);
      if ( it != mMultiSiteGlobalPassFail.end() )
      {
        return it->second;
      }
      else
      {
        throw Error("MeasurementResultContainer::getGlobalPassFail",
                    "No global result for this site!",
                    "MeasurementResultContainer::getGlobalPassFail");
      }
    };
    bool getPinPassFail(const string& pin,int siteNumber = 0) const
    {
      map< int,map<string,bool> >::const_iterator it =
                                      mMultiSitePinPassFail.find(siteNumber);

      // get the result of the specified site
      if ( it != mMultiSitePinPassFail.end() )
      {
        const map< string,bool >& tmpPinResult = it->second;
        map< string,bool >::const_iterator itPinResult = tmpPinResult.find(pin);

        // get the result of the specified pin
        if ( itPinResult != tmpPinResult.end() )
        {
          return itPinResult->second;
        }
        else
        {
          throw Error("MeasurementResultContainer::getPinPassFail",
                      "No result for this pin: "+pin+".",
                      "MeasurementResultContainer::getPinPassFail");
        }
      }
      else
      {
        throw Error("MeasurementResultContainer::getPinPassFail",
                    "No per pin result for this site!",
                    "MeasurementResultContainer::getPinPassFail");
      }
    };
    double getPinsValue(const string& pins,int siteNumber = 0) const
    {
      map< int,map<string,double> >::const_iterator it =
                                      mMultiSitePinsValue.find(siteNumber);

      // get the result of the specified site
      if ( it != mMultiSitePinsValue.end() )
      {
        const map< string,double >& tmpPinResult = it->second;
        map< string,double >::const_iterator itPinResult = tmpPinResult.find(pins);

        //* get the result of the specified pins
        if ( itPinResult != tmpPinResult.end() )
        {
          return itPinResult->second;
        }
        else
        {
          throw Error("MeasurementResultContainer::getPinsValue",
                      "No result for this pin(s): "+pins+".",
                      "MeasurementResultContainer::getPinsValue");
        }
      }
      else
      {
        throw Error("MeasurementResultContainer::getPinsValue",
                    "No result for this site!",
                    "MeasurementResultContainer::getPinsValue");
      }
    };

    void init()
    {
      mMultiSitePinsValue.clear();
      mMultiSitePinPassFail.clear();
      mMultiSiteGlobalPassFail.clear();
    };
  private:

    /*
     *********************************************
     * Record value for pin(s) per site, e.g.
     *   mMultiSitePinsValue[1] = {"I/O1",2.50}
     *   mMultiSitePinsValue[1] = {"I/O0",1.30}
     *   mMultiSitePinsValue[2] = {"I/O1",2.52}
     *   mMultiSitePinsValue[2] = {"I/O0",1.33}
     *********************************************
     */
    map< INT,map< STRING,DOUBLE > > mMultiSitePinsValue;

    /*
     *********************************************
     * Record pass/fail for each pin per site, e.g.
     *   TRUE: pass; FALSE: fail.
     *   mMultiSitePinPassFail[1] = {"Vcc",FALSE}
     *   mMultiSitePinPassFail[1] = {"Vee",FALSE}
     *   mMultiSitePinPassFail[2] = {"Vcc",TRUE}
     *   mMultiSitePinPassFail[2] = {"Vee",FALSE}
     *********************************************
     */
    map< INT,map< STRING,Boolean > > mMultiSitePinPassFail;
    /*
     *********************************************
     * Record global pass/fail per site, e.g.
     *   TRUE: pass; FALSE: fail.
     *   mMultiSiteGlobalPassFail[1] = TRUE
     *   mMultiSiteGlobalPassFail[2] = FALSE
     *********************************************
     */
    map< INT, Boolean > mMultiSiteGlobalPassFail;

  };

  /*
   *----------------------------------------------------------------------*
   * Routine: getMode
   *
   * Purpose: define to use PVAL|PPF|GPF according test suite flag
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note:
   *
   *----------------------------------------------------------------------*
   */
  static TM::DCTEST_MODE getMode()
  {
    string testSuiteName = "";

    int valueOnPass = 0;
    int perPinOnPass = 0;
    int valueOnFail = 0;
    int perPinOnFail = 0;

    GET_TESTSUITE_NAME(testSuiteName);
    GET_TESTSUITE_FLAG(testSuiteName, "value_on_pass",   &valueOnPass);
    GET_TESTSUITE_FLAG(testSuiteName, "value_on_fail",   &valueOnFail);
    GET_TESTSUITE_FLAG(testSuiteName, "per_pin_on_pass", &perPinOnPass);
    GET_TESTSUITE_FLAG(testSuiteName, "per_pin_on_fail", &perPinOnFail);

    if ( 1 == valueOnPass || 1 == valueOnFail )
    {
      return TM::PVAL;
    }
    else if ( 1 == perPinOnPass || 1 == perPinOnFail )
    {
      return TM::PPF;
    }

    return TM::GPF;
  }


  /*
   *----------------------------------------------------------------------*
   * Routine: trim
   *
   * Purpose: get rid of head and tail space of input
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note:
   *
   * Return Value: new string
   *----------------------------------------------------------------------*
   */
  static string trim(const string& str)
  {
    int iStart = 0;
    int iStop = 0;
    int i = 0;
    int length = static_cast<int>(str.length());

    for(i=0;i< length;i++)
    {
      if(str[i] != ' ')
      {
        iStart = i;
        break;
      }
    }

    for(i=length-1;i>=0;i--)
    {
      if(str[i] != ' ')
      {
        iStop = i+1;
        break;
      }
    }

    return str.substr(iStart,iStop-iStart);
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: datalogToWindow
   *
   * Purpose: print datalog To report Window
   *
   *----------------------------------------------------------------------*
   * Description:
   *   this prototype only for TM::PVAL
   * Note:
   *   measuredValue and limit parameter always use default unit,
   *       that's, "A" for current, "V" for voltage.
   *   unit parameter specifies in which unit the output
   *        in the ReportWindow is, supported: [mV] and [uA]
   *----------------------------------------------------------------------*
   */
  static void datalogToWindow(const string& pin,
                              const double  measuredValue,
                              const LIMIT&  limit,
                              const string& unit)
  {
    string PFjudge = limit.pass(measuredValue)?"P":"F";
    string opl_str, oph_str;

    double lowVal  = 0.0,highVal = 0.0;
    TM::COMPARE lowCmp = TM::NA, highCmp = TM::NA;
    limit.get(lowCmp, lowVal, highCmp, highVal);

    double factor = 1.0;
    if(!(limit.unit().empty()))
    {
      testmethod::SpecValue specValue;
      specValue.setBaseUnit("A");
      specValue.inputValueUnit("1[A]");
      factor = specValue.getValueAsTargetUnit(limit.unit());
    }
    lowVal = lowVal * factor;
    highVal = highVal * factor;

    switch (lowCmp)
    {
      case TM::GT:
        opl_str = "< ";
        break;

      case TM::GE:
        opl_str = "<=";
        break;

      case TM::NA:
        opl_str = "";
        break;

      default:
        throw Error("LeakageTestUtil::datalogToWindow",
                    "Unknown Compare Mode of opl",
                    "LeakageTestUtil::datalogToWindow");

    }
    switch (highCmp)
    {
      case TM::LT:
        oph_str = "< ";
        break;

      case TM::LE:
        oph_str = "<=";
        break;

      case TM::NA:
        oph_str = "";
        break;

      default:
        throw Error("LeakageTestUtil::datalogToWindow",
                    "Unknown Compare Mode of opl",
                    "LeakageTestUtil::datalogToWindow");

    }

    ostringstream buf;
    buf << left << setw(16) << pin;
    cout << buf.str() << '\t';

    // value of lower limit
    if ( opl_str != "" )
    {
      cout << "min:";
      printValue(lowVal, unit, FALSE);
      cout << '\t' << opl_str << '\t';
    }

    // measured value
    printValue(measuredValue, unit, TRUE);
    cout << '\t';

    // value of higher limit
    if ( oph_str != "" )
    {
      cout << oph_str << '\t' << "max:";
      printValue(highVal, unit, FALSE);
      cout << '\t';
    }

    // Pass or Fail Info
    cout << PFjudge <<endl;
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: datalogToWindow
   *
   * Purpose: print datalog To report Window
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note:
   *   this protoype only for TM::PPF
   *----------------------------------------------------------------------*
   */
  static void datalogToWindow(const string& pin, const bool bPass)
  {
    ostringstream buf;
    buf << left << setw(16) << pin;
    cout << buf.str() << "\t";
    cout << (bPass? "P": "F") <<endl;
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: printValue
   *
   * Purpose: print result value
   *
   *----------------------------------------------------------------------*
   *
   * Note:
   *      the parameter "val" always use default unit, that's, "A" for
   *      current, "V" for voltage.
   *      the parameter unit, specifies in which unit the output will be
   *      supported: [mV], [uA]
   *
   *----------------------------------------------------------------------*
   */
  static void printValue(double val,const string& unit,const bool bFormat)
  {
    double dVal = 0.0;

    if ( unit == "uA" )
    {
      dVal = val * 1e6;
    }
    else if ( unit == "mV" )
    {
      dVal = val * 1e3;
    }
    else
    {
      throw Error("LeakageTestUtil::printValue",
                  "Unknown unit",
                  "LeakageTestUtil::printValue");
    }

    if ( bFormat )
    {
      ostringstream buf;
      buf << setprecision(10) << dVal << " " << unit;
      cout << right << setw(14) << buf.str() << '\t' << left;
    }
    else
    {
      cout << right << setw(10) << dVal << " " << unit << left;
    }
  }


  /*
   *----------------------------------------------------------------------*
   * Routine: parseListOfString
   *
   * Purpose: parse one string to a string vector
   *
   *----------------------------------------------------------------------*
   * Description:
   *    e.g.    the original string is:
   *                "pin1,(pin2,pin3),pin4"
   *            and the delimiter char is: ','
   *    yields the following string vector results:
   *                "pin1", "pin2,pin3", "pin4"
   *
   *
   *----------------------------------------------------------------------*
   */
  static void parseListOfString(const string& originalString,
                                vector<string>& stringVec,
                                const char delimiter = ',',
                                const bool isParenthesesSupported = false)
  {
    if(originalString.empty())
    {
      stringVec.clear();
      return;
    }
    bool isWithinParentheses = false;
    bool isLeftParenthesesExist = false;
    string word;
    const char* str = originalString.c_str();

    for ( int i = 0 ; *(str+i) != 0 ; ++i )
    {
      char ch = str[i];

      if( ch == delimiter )
      {
        if ( isWithinParentheses && isParenthesesSupported )
        {
          word += ch;
        }
        else 
        {
          stringVec.push_back(trim(word));
          word = "";
        }
      }
      else if (isParenthesesSupported && ch == '(')
      {
        isWithinParentheses = true;
        isLeftParenthesesExist = true;
      }
      else if (isParenthesesSupported && ch == ')') 
      {
        isWithinParentheses = false;
        if(!isLeftParenthesesExist)
        { 
          throw Error("LeakageTestUtil::parseListOfString",
                      "the parentheses mismatch.The correct format is like:()",
                      "LeakageTestUtil::parseListOfString");
        }
        isLeftParenthesesExist = false;
      }
      else 
      {
        word += ch;
      }
    }

    if(isLeftParenthesesExist)
    {
      throw Error("LeakageTestUtil::parseListOfString",
                  "the parentheses mismatch.The correct format is like:()",
                  "LeakageTestUtil::parseListOfString");    
    }  
    stringVec.push_back(trim(word));

    return;
  }


  /*
   *----------------------------------------------------------------------*
   * Routine: parseListOfDouble
   *
   * Purpose: parse one string to a double vector
   *
   *----------------------------------------------------------------------*
   * Description:
   *    e.g.    the original string is:
   *                "1.5,2.8,5.6"
   *            and the delimiter char is: ','
   *    yields the following double vector results:
   *                "1.5", "2.8", "5.6"
   *
   *
   *----------------------------------------------------------------------*
   */
  static void parseListOfDouble(const string& originalString,
                                vector<double>& doubleVec,
                                const char delimiter = ',')
  {
    if(originalString.empty())
    {
      doubleVec.clear();
      return;
    }
    
    string word;
    double tempValue;
    const char* str = originalString.c_str();

    for ( int i = 0 ; *(str+i) != 0 ; ++i )
    {
      char ch = str[i];
      if( ch == delimiter )
      {
        string tempString = trim(word);
        if(tempString.empty())
        {
          doubleVec.push_back(0.0);
        }
        else
        {
          istringstream stream(word);
          stream >> tempValue;
          doubleVec.push_back(tempValue);
        }
        word = "";
      }
      else 
      {
        word += ch;
      }
    }
    
    string tempString = trim(word);
    if(tempString.empty())
    {
      doubleVec.push_back(0.0);
    }
    else
    {
      istringstream stream(word);
      stream >> tempValue;
      doubleVec.push_back(tempValue);
    }
    return;    
  }

  
  /*
   *----------------------------------------------------------------------*
   * Routine: getLimitInfo
   *
   * Purpose: get limit from limit table or get limit information from testflow
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note:
   *
   *----------------------------------------------------------------------*
   */
  static void getLimitInfo(
      const string& testName,
      const int groupNumber,
      LIMIT& limit,
      TesttableLimitHelper& testtableHelper)
  {
    TM::COMPARE lowCmp = TM::NA,highCmp = TM::NA;
    double lowVal = 0.0, highVal = 0.0;

    if(testtableHelper.isLimitCsvFileLoad())
    {
      testtableHelper.getLimit(testName,limit);
    }

    if(!testtableHelper.isAllInTable())
    {
      // this API has some issue, it converts the value according
      // to the unit, but it doesn't set the correct unit
      // e.g.  0 uA  <<  limit << 20uA, using this API to get the limit
      // the lowValue of this limit is 0
      // the highValue of this limit is 0.00002
      // but the current unit of this limit still is uA.
      limit = GET_LIMIT_OBJECT(testName);
      if(!(limit.unit().empty()))
      {
        limit.unit("A");
      }
    }

    limit.get(lowCmp,lowVal,highCmp,highVal);

    if ( lowCmp == TM::NA || highCmp == TM::NA )
    {
      throw Error("LeakageTestUtil::getLimitInfo",
                  testName + " is not specified",
                  "LeakageTestUtil::getLimitInfo");
    }
    string unitInLimit = limit.unit();

    if(unitInLimit.empty())
    {
      limit.low(lowCmp, lowVal * 1e-6);
      limit.high(highCmp, highVal * 1e-6);
      limit.unit("A");
    }
    else
    {
      testmethod::SpecValue specValue;
      specValue.setBaseUnit("A");
      specValue.inputValueUnit("1[A]");
      double factor = specValue.getValueAsTargetUnit(unitInLimit);
      limit.low(lowCmp,lowVal / factor);
      limit.high(highCmp,highVal / factor);
      limit.unit("A");
    }
    return;
  }


  /*
   *----------------------------------------------------------------------*
   * Routine: splitPortDataAndPortName
   *
   * Purpose: split port data and port name from input string.
   *
   *----------------------------------------------------------------------*
   * Description:
   *   Typical Usage(e.g.):
   *        input   : "123@port_1"
   *        portData: "123"
   *        portName: "port_1"
   *   Invalid input(e.g):
   *       (1)"@port_x","nnn@","nnn@illegal_portname"
   *       (2)"nnn" (if throwErrorForNoPortName is true)
   * Parameters:
   *   1. input: the original input string need to be split
   *   2. portData: to be filled with the data info at that port.
   *   3. portName: to be filled with the specific port name
   *   4. throwErrorForNoPortName:
   *             issue error if input doesn't contain port.
   *             this flag is true by default.
   * Output:
   *   status
   *   0:   succeed
   *   -1:  failed.
   * Note:
   *
   *----------------------------------------------------------------------*
   */
  static int splitPortDataAndPortName(
      const string& input,
      string& portData,
      string& portName,
      bool throwErrorForNoPortName)
  {
    int status = -1;
    portData = "";
    portName = "";

    if ( !input.empty() )
    {
      //position of port symbol
      string::size_type pos = input.find_first_of('@',0);
      if ( pos != string::npos )
      {
        if ( pos > 0) // 0 means a testflow variable
        {
          // get all chars before '@'
          portData = input.substr(0,pos);
          // get all chars after '@'
          portName = trim(input.substr(pos+1));
          if ( portName.length() > 0 )
          {
              status = 0;
          }
        }
      }
      else // no '@'* found
      {
        if ( !throwErrorForNoPortName )
        {
          status = 0;// sucess case
          portData = input;
          portName = "";
        }
      }
    }

    // check the status and error handling
    if ( status != 0 )
    {
      const string funcName = "LeakageTestUtil::splitPortDataAndPortName";
      string errorMsg;
      if ( input.empty() )
      {
        errorMsg = "Input string is empty!";
      }
      else
      {
        errorMsg = "Invalid port of input string: " + input;
      }

      throw Error(funcName,errorMsg,funcName);
    }

    return status;
  }


  /*
   *----------------------------------------------------------------------*
   * Routine: string2Double
   *
   * Purpose: convert a string to double, if the string content is not a
   *          double,throw an error
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Parameters:  1. string input :
   *                 string need to convert to double
   *              2. string name :
   *                 parameters name, need for output error message
   *
   * Return Value: output double value
   *----------------------------------------------------------------------*
   */
  static double string2Double(const string& input, const string& name)
  {
    double result = 0.0;
    char* pEnd;
    result = strtod(input.c_str(), &pEnd);

    if((result == 0 && atof(input.c_str())!= 0)
       || pEnd[0] != '\0')
    {
      string api = "Convert parameter["+name+"] :"+ input + " to DOUBLE fail";
      string msg = "it is not a double!";
      throw Error(api.c_str(),msg.c_str(),api.c_str());
    }

    return result;
  }
  /*
   *----------------------------------------------------------------------*
   * Routine: string2Long
   *
   * Purpose: convert a string to long int, if the string content is not a
   *          long int,throw an error
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Parameters:  1. string input :
   *                 string need to convert to long int
   *              2. string name :
   *                 parameters name, need for output error message
   *
   * Return Value: output long int value
   *----------------------------------------------------------------------*
   */
  static long string2Long(const string& input,const string& name)
  {
    long result = 0;
    char* pEnd;
    result = strtol(input.c_str(),&pEnd,10);

    if((result == 0 && atol(input.c_str()) != 0) ||
       (pEnd[0] != '\0' && pEnd[0] != '\n'))
    {
      string api = "Convert parameter["+name+"] :"+input + " to long fail";
      string msg = "it is not a long int!";
      throw Error(api.c_str(),msg.c_str(),api.c_str());
    }

    return result;
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: isHighVoltagePin
   *
   * Purpose: check if the specified pin is high voltage pin
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note:
   *
   *----------------------------------------------------------------------*
   */
  static bool isHighVoltagePin(const string & pinName)
  {
    string strFwAnswer = "";
    FW_TASK("CONF? (" + pinName + ")\n",strFwAnswer);
    string::size_type iPos = strFwAnswer.find(",");
    if (iPos != string::npos)
    {
      string mode = strFwAnswer.substr(iPos + 1, 2);
      if (mode.compare("HV") == 0)
      {
        return true;
      }
    }
    return false;
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: getMeasureModeForHVPin
   *
   * Purpose: map the normal measurement mode to HV mode
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note:
   *
   *----------------------------------------------------------------------*
   */
  static const string & getMeasureModeForHVPin(const TM::DCTEST_MODE & testMode)
  {
    static string HV_PPMU_PPF = "HV_PPMU_PPF";
    static string HV_PPMU_GPF = "HV_PPMU_GPF";
    static string HV_PPMU_BADC_VAL = "HV_PPMU_BADC_VAL";
    static string NOT_MATCH = "";

    switch(testMode)
    {
      case TM::PVAL:
        return HV_PPMU_BADC_VAL;
      case TM::GPF:
        return HV_PPMU_GPF;
      case TM::PPF:
        return HV_PPMU_PPF;
      default:
        return NOT_MATCH;
    }
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: parameterCheck
   *
   * Purpose: check whether parameter groups match
   *
   *----------------------------------------------------------------------*
   *
   * Note:
   *
   *----------------------------------------------------------------------*
   */
  template <class T>
  static void checkParameter(const unsigned int lSize,
                             const unsigned int rSize,
                             const string& type,
                             const string& parameter,
                             vector<T>& valueVec )
  {
    if(lSize != rSize)
    {
      if(rSize != 1)
      {
        stringstream errMsg;
        errMsg << type <<": the number of pinlist groups is " << lSize <<endl
               <<"      the number of " << parameter << " groups is " << rSize <<endl
               <<"So the " << parameter << " groups don't match pinlist groups." <<endl;
        throw Error("LeakageTestUtil::checkParameter()",
                    errMsg.str(),
                    "LeakageTestUtil::checkParameter()");
      }
      else
      {
        for(vector<string>::size_type i = 1; i < lSize; i++)
        {
          valueVec.push_back(valueVec[0]);
        }
      }
    }
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: judgeAndLogUtil
   *
   * Purpose: utility function for judgement and data log.
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note:
   *
   *----------------------------------------------------------------------*
   */
  static void judgeAndLogUtil(
    const vector<bool> &isMeasuredLow,
    const vector<bool> &isMeasuredHigh,
    const vector<string> &pinlistVec,
    const vector<vector<string> > &expandedPinsVec,
    const vector<LIMIT> &limitLowVec,
    const vector<LIMIT> &limitHighVec,
    const vector<string> &limitNameLowVec,
    const vector<string> &limitNameHighVec,
    const vector<MeasurementResultContainer> &resultLow,
    const vector<MeasurementResultContainer> &resultHigh,
    const TM::DCTEST_MODE& mode,
    const string& testsuiteName,
    const bool isLimitTableUsed,
    bool& measureLow,
    bool& measureHigh,
    const int siteNumber,
    bool& hasBined)
  {
    vector<string>::size_type j = 0;
    bool isPassLow = true;
    bool isPassHigh = true;
    bool retLow = true;
    bool retHigh = true;
    ARRAY_D lowResultArray;
    ARRAY_D highResultArray;

    V93kLimits::TMLimits::LimitInfo limitInfoLow;
    V93kLimits::TMLimits::LimitInfo limitInfoHigh;
    double factor = 1.0;
    for(vector<string>::size_type i = 0; i < expandedPinsVec.size(); ++i)
    {
      // restore it for every group
      retLow = true;
      retHigh = true;
      if (isMeasuredLow[i]) // judge and datalog low level measurement
      {
        if(isLimitTableUsed)
        {
          limitInfoLow = V93kLimits::tmLimits.getLimit(testsuiteName + ":" + limitNameLowVec[i]);
        }

        measureLow = true;
        switch ( mode )
        {
        case TM::PVAL:
          lowResultArray.resizeNoKeep(expandedPinsVec[i].size());
          if(isLimitTableUsed)
          {
            testmethod::SpecValue specValue;
            if( (limitInfoLow.Units).find('A') != string::npos)
            {
              specValue.setBaseUnit("A");
              specValue.inputValueUnit("1[A]");
              factor = specValue.getValueAsTargetUnit(limitInfoLow.Units);
            }
            else if(limitInfoLow.Units.empty())
            {
              factor = 1e6;
            }
            else
            {
              stringstream errMsg;
              errMsg << "the low limit's unit: " << limitInfoLow.Units << " is not a valid unit." <<endl
                     << "current the valid units are: mA,uA..." <<endl;
              throw Error("LeakageTestUtil::judgeAndLogUtil",
                          errMsg.str(),
                          "LeakageTestUtil::judgeAndLogUtil");
            }
          }
          for ( j = 0; j< expandedPinsVec[i].size(); ++j )
          {
            lowResultArray[j] = resultLow[i].getPinsValue(expandedPinsVec[i][j],siteNumber);
            lowResultArray[j] = lowResultArray[j] * factor;
          }

          if(isLimitTableUsed)
          {
            TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                          expandedPinsVec[i],
                                          limitNameLowVec[i],
                                          V93kLimits::tmLimits,
                                          lowResultArray);
          }
          else
          {
            TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                            expandedPinsVec[i],
                                            limitNameLowVec[i],
                                            limitLowVec[i],
                                            lowResultArray);
          }
          break;

        case TM::PPF:
          lowResultArray.resizeNoKeep(expandedPinsVec[i].size());
          for (j = 0; j < expandedPinsVec[i].size(); ++j )
          {
            isPassLow = resultLow[i].getPinPassFail(expandedPinsVec[i][j],siteNumber);
            if(isPassLow) // for pass pin, in PPF mode, we will write 0.0 to MPR
            {
              lowResultArray[j] = 0.0;
            }
            else // for fail pin, in PPF mode, we will write 1.0 to MPR
            {
              lowResultArray[j] = 1.0;
            }
            retLow = isPassLow && retLow;
          }

          if(isLimitTableUsed)
          {
            TESTSET().cont(TM::CONTINUE).testnumber(limitInfoLow.TestNumber)
                                        .judgeAndLog_ParametricTest(
                                            expandedPinsVec[i],
                                            limitNameLowVec[i],
                                            retLow ? TM::Pass : TM::Fail,
                                            lowResultArray);
            if(!retLow && !hasBined && limitInfoLow.BinsNumString.size() > 0)
            {
              hasBined = true;
              SET_MULTIBIN(limitInfoLow.BinsNumString,limitInfoLow.BinhNum);
            }
          }
          else
          {
            TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                            expandedPinsVec[i],
                                            limitNameLowVec[i],
                                            retLow ? TM::Pass : TM::Fail,
                                            lowResultArray);
          }
          break;

        case TM::GPF:
          isPassLow = resultLow[i].getGlobalPassFail(siteNumber);
          if(isLimitTableUsed)
          {
            TESTSET().cont(TM::CONTINUE).testnumber(limitInfoLow.TestNumber)
                                        .judgeAndLog_ParametricTest(
                                            pinlistVec[i],
                                            limitNameLowVec[i],
                                            isPassLow ? TM::Pass : TM::Fail,
                                            0.0);

            if(!isPassLow && !hasBined && limitInfoLow.BinsNumString.size() > 0)
            {
              hasBined = true;
              SET_MULTIBIN(limitInfoLow.BinsNumString,limitInfoLow.BinhNum);
            }
          }
          else
          {
            TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                            pinlistVec[i],
                                            limitNameLowVec[i],
                                            isPassLow ? TM::Pass : TM::Fail,
                                            0.0);
          }
          break;
        default:
          throw Error("LeakageTestUtil::judgeAndLogUtil",
                      "Unknown Test Mode",
                      "LeakageTestUtil::judgeAndLogUtil");
        } // end switch
      } // end if: low

      if (isMeasuredHigh[i]) //judge and datalog high level measurement
      {
        if(isLimitTableUsed)
        {
          limitInfoHigh = V93kLimits::tmLimits.getLimit(testsuiteName + ":" + limitNameHighVec[i]);
        }

        measureHigh = true;
        switch ( mode )
        {
        case TM::PVAL:
          highResultArray.resizeNoKeep(expandedPinsVec[i].size());
          if(isLimitTableUsed)
          {
            testmethod::SpecValue specValue;
            if( (limitInfoHigh.Units).find('A') != string::npos)
            {
              specValue.setBaseUnit("A");
              specValue.inputValueUnit("1[A]");
              factor = specValue.getValueAsTargetUnit(limitInfoHigh.Units);
            }
            else if(limitInfoHigh.Units.empty())
            {
              factor = 1e6;
            }
            else
            {
              stringstream errMsg;
              errMsg << "the high limit's unit: " << limitInfoHigh.Units << " is not a valid unit." <<endl
                     << "current the valid units are: mA,uA..." <<endl;
              throw Error("LeakageTestUtil::judgeAndLogUtil",
                          errMsg.str(),
                          "LeakageTestUtil::judgeAndLogUtil");
            }
          }
          for ( j = 0; j< expandedPinsVec[i].size(); ++j )
          {
            highResultArray[j] = resultHigh[i].getPinsValue(expandedPinsVec[i][j],siteNumber);
            highResultArray[j] = highResultArray[j] * factor;
          }

          if(isLimitTableUsed)
          {
            TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                          expandedPinsVec[i],
                                          limitNameHighVec[i],
                                          V93kLimits::tmLimits,
                                          highResultArray);
          }
          else
          {
            TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                            expandedPinsVec[i],
                                            limitNameHighVec[i],
                                            limitHighVec[i],
                                            highResultArray);
          }
          break;

        case TM::PPF:
          highResultArray.resizeNoKeep(expandedPinsVec[i].size());
          for (j = 0; j < expandedPinsVec[i].size(); ++j )
          {
            isPassHigh = resultHigh[i].getPinPassFail(expandedPinsVec[i][j],siteNumber);
            if(isPassHigh) // for pass pin, in PPF mode, we will write 0.0 to MPR
            {
              highResultArray[j] = 0.0;
            }
            else // for fail pin, in PPF mode, we will write 1.0 to MPR
            {
              highResultArray[j] = 1.0;
            }
            retHigh = isPassHigh && retHigh;
          }

          if(isLimitTableUsed)
          {
            TESTSET().cont(TM::CONTINUE).testnumber(limitInfoHigh.TestNumber)
                                        .judgeAndLog_ParametricTest(
                                            expandedPinsVec[i],
                                            limitNameHighVec[i],
                                            retHigh ? TM::Pass : TM::Fail,
                                            highResultArray);
            if(!retHigh && !hasBined && limitInfoHigh.BinsNumString.size() > 0)
            {
              hasBined = true;
              SET_MULTIBIN(limitInfoHigh.BinsNumString,limitInfoHigh.BinhNum);
            }
          }
          else
          {
            TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                            expandedPinsVec[i],
                                            limitNameHighVec[i],
                                            retHigh ? TM::Pass : TM::Fail,
                                            highResultArray);
          }
          break;

        case TM::GPF:
          isPassHigh = resultHigh[i].getGlobalPassFail(siteNumber);
          if(isLimitTableUsed)
          {
            TESTSET().cont(TM::CONTINUE).testnumber(limitInfoHigh.TestNumber)
                                        .judgeAndLog_ParametricTest(
                                            pinlistVec[i],
                                            limitNameHighVec[i],
                                            isPassHigh ? TM::Pass : TM::Fail,
                                            0.0);

            if(!isPassHigh && !hasBined && limitInfoHigh.BinsNumString.size() > 0)
            {
              hasBined = true;
              SET_MULTIBIN(limitInfoHigh.BinsNumString,limitInfoHigh.BinhNum);
            }
          }
          else
          {
            TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                            pinlistVec[i],
                                            limitNameHighVec[i],
                                            isPassHigh ? TM::Pass : TM::Fail,
                                            0.0);
          }
          break;
        default:
          throw Error("LeakageTestUtil::judgeAndLogUtil",
                      "Unknown Test Mode",
                      "LeakageTestUtil::judgeAndLogUtil");
        } //end switch

      }//end if: high
    }// end for every group
  }
  /*
   *----------------------------------------------------------------------*
   * Routine: judgeAndLogUtilForAllGroups
   *
   * Purpose: judgement and data log.for: one limit is applied for all groups
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note:
   *
   *----------------------------------------------------------------------*
   */
  static void judgeAndLogUtilForAllGroups(
    const vector<bool> &isMeasuredLow,
    const vector<bool> &isMeasuredHigh,
    const vector<string> &pinlistVec,
    const vector<vector<string> > &expandedPinsVec,
    const vector<LIMIT> &limitLowVec,
    const vector<LIMIT> &limitHighVec,
    const vector<string> &limitNameLowVec,
    const vector<string> &limitNameHighVec,
    const vector<MeasurementResultContainer> &resultLow,
    const vector<MeasurementResultContainer> &resultHigh,
    const TM::DCTEST_MODE& mode,
    const string& testsuiteName,
    const bool isLimitTableUsed,
    bool& measureLow,
    bool& measureHigh,
    const int siteNumber,
    bool& hasBined)
  {
    vector<string>::size_type j = 0;
    bool isPassLow = true;
    bool isPassHigh = true;
    bool retLow = true;
    bool retHigh = true;
    ARRAY_D lowResultArray;
    ARRAY_D highResultArray;

    int sizeOfLowArray = 0;
    int sizeOfHighArray = 0;
    int indexLow = 0;
    int indexHigh = 0;
    vector<string> lowPinVec;
    vector<string> highPinVec;
    string lowStringPinlist;
    string highStringPinlist;

    for(vector<string>::size_type i = 0; i < expandedPinsVec.size(); ++i)
    {
      if(isMeasuredLow[i])
      {
        sizeOfLowArray += expandedPinsVec[i].size();
        indexLow = i;
      }
      if(isMeasuredHigh[i])
      {
        sizeOfHighArray += expandedPinsVec[i].size();
        indexHigh = i;
      }
    } // end for: every group

    V93kLimits::TMLimits::LimitInfo limitInfoLow;
    V93kLimits::TMLimits::LimitInfo limitInfoHigh;
    if(isLimitTableUsed)
    {
      if(sizeOfLowArray > 0)
      {
        limitInfoLow = V93kLimits::tmLimits.getLimit(testsuiteName + ":" + limitNameLowVec[indexLow]);
      }
      if(sizeOfHighArray > 0)
      {
        limitInfoHigh = V93kLimits::tmLimits.getLimit(testsuiteName + ":" + limitNameHighVec[indexHigh]);
      }
    }
    double factorLow = 1.0;
    double factorHigh = 1.0;

    switch(mode)
    {
    case TM::PVAL:
      lowResultArray.resizeNoKeep(sizeOfLowArray);
      highResultArray.resizeNoKeep(sizeOfHighArray);
      if(isLimitTableUsed)
      {
        testmethod::SpecValue specValue;

        if(sizeOfLowArray > 0)
        {
           if( (limitInfoLow.Units).find('A') != string::npos)
           {
             specValue.setBaseUnit("A");
             specValue.inputValueUnit("1[A]");
             factorLow = specValue.getValueAsTargetUnit(limitInfoLow.Units);
           }
           else if(limitInfoLow.Units.empty())
           {
             factorLow = 1e6;
           }
           else
           {
             stringstream errMsg;
             errMsg << "the low limit's unit: " << limitInfoLow.Units << " is not a valid unit." <<endl
                    << "current the valid units are: mA,uA..." <<endl;
             throw Error("LeakageTestUtil::judgeAndLogUtil",
                         errMsg.str(),
                         "LeakageTestUtil::judgeAndLogUtil");
          }
        }

        if(sizeOfHighArray > 0)
        {
          if( (limitInfoHigh.Units).find('A') != string::npos)
          {
            specValue.setBaseUnit("A");
            specValue.inputValueUnit("1[A]");
            factorHigh = specValue.getValueAsTargetUnit(limitInfoHigh.Units);
          }
          else if(limitInfoHigh.Units.empty())
          {
            factorHigh = 1e6;
          }
          else
          {
            stringstream errMsg;
            errMsg << "the hight limit's unit: " << limitInfoHigh.Units << " is not a valid unit." <<endl
                   << "current the valid units are: mA,uA..." <<endl;
            throw Error("LeakageTestUtil::judgeAndLogUtil",
                        errMsg.str(),
                        "LeakageTestUtil::judgeAndLogUtil");
          }
        }
      }

      for(vector<string>::size_type i = 0; i < expandedPinsVec.size(); ++i)
      {
        int counterLow = 0;
        int counterHigh = 0;
        if(isMeasuredLow[i])
        {
          for (j = 0; j < expandedPinsVec[i].size(); ++j)
          {
            lowResultArray[counterLow] = resultLow[i].getPinsValue(expandedPinsVec[i][j],siteNumber);
            lowResultArray[counterLow] = lowResultArray[counterLow] * factorLow;
            lowPinVec.push_back(expandedPinsVec[i][j]);
            counterLow++;
          } // end for: every pin
        }// end if: low
        if(isMeasuredHigh[i])
        {
          for (j = 0; j < expandedPinsVec[i].size(); ++j)
          {
            highResultArray[counterHigh] = resultHigh[i].getPinsValue(expandedPinsVec[i][j],siteNumber);
            highResultArray[counterHigh] = highResultArray[counterHigh] * factorHigh;
            highPinVec.push_back(expandedPinsVec[i][j]);
            counterHigh++;
          } // end for: every pin
        }// end if: high
      }// end for: every group

      if(isLimitTableUsed)
      {
        if(lowPinVec.size() > 0)
        {
          TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                        lowPinVec,
                                        limitNameLowVec[indexLow],
                                        V93kLimits::tmLimits,
                                        lowResultArray);
        }
        if(highPinVec.size() > 0)
        {
          TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                        highPinVec,
                                        limitNameHighVec[indexHigh],
                                        V93kLimits::tmLimits,
                                        highResultArray);
        }
      }
      else // use test flow's limits
      {
        if(lowPinVec.size() > 0)
        {
          TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                          lowPinVec,
                                          limitNameLowVec[indexLow],
                                          limitLowVec[indexLow],
                                          lowResultArray);
        }
        if(highPinVec.size() > 0)
        {
          TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                          highPinVec,
                                          limitNameHighVec[indexHigh],
                                          limitHighVec[indexHigh],
                                          highResultArray);
        }
      }
      break;

    case TM::PPF:
      lowResultArray.resizeNoKeep(sizeOfLowArray);
      highResultArray.resizeNoKeep(sizeOfHighArray);
      for(vector<string>::size_type i = 0; i < expandedPinsVec.size(); ++i)
      {
        int counterLow = 0;
        int counterHigh = 0;
        if(isMeasuredLow[i])
        {
          for(j = 0; j < expandedPinsVec[i].size(); ++j)
          {
            isPassLow = resultLow[i].getPinPassFail(expandedPinsVec[i][j],siteNumber);
            if(isPassLow) // for pass pin, in PPF mode, we will write 0.0 to MPR
            {
              lowResultArray[counterLow] = 0.0;
            }
            else // for fail pin, in PPF mode, we will write 1.0 to MPR
            {
              lowResultArray[counterLow] = 1.0;
            }
            retLow = isPassLow && retLow;
            lowPinVec.push_back(expandedPinsVec[i][j]);
            counterLow++;
          } // end for: every pin
        } //end if

        if(isMeasuredHigh[i])
        {
          for(j = 0; j < expandedPinsVec[i].size(); ++j)
          {
            isPassHigh = resultHigh[i].getPinPassFail(expandedPinsVec[i][j],siteNumber);
            if(isPassHigh) // for pass pin, in PPF mode, we will write 0.0 to MPR
            {
              highResultArray[counterHigh] = 0.0;
            }
            else // for fail pin, in PPF mode, we will write 1.0 to MPR
            {
              highResultArray[counterHigh] = 1.0;
            }
            retHigh = isPassHigh && retHigh;
            highPinVec.push_back(expandedPinsVec[i][j]);
            counterHigh++;
          } // end for: every pin
        } //end if
      } // end for: every group

      if(isLimitTableUsed)
      {
        if(lowPinVec.size() > 0)
        {
          TESTSET().cont(TM::CONTINUE).testnumber(limitInfoLow.TestNumber)
                                      .judgeAndLog_ParametricTest(
                                          lowPinVec,
                                          limitNameLowVec[indexLow],
                                          retLow ? TM::Pass : TM::Fail,
                                          lowResultArray);
        }
        if(!hasBined && !retLow && limitInfoLow.BinsNumString.size() > 0)
        {
          hasBined = true;
          SET_MULTIBIN(limitInfoLow.BinsNumString,limitInfoLow.BinhNum);
        }
        if(highPinVec.size() > 0)
        {
          TESTSET().cont(TM::CONTINUE).testnumber(limitInfoHigh.TestNumber)
                                      .judgeAndLog_ParametricTest(
                                          highPinVec,
                                          limitNameHighVec[indexHigh],
                                          retHigh ? TM::Pass : TM::Fail,
                                          highResultArray);
        }
        if(!hasBined && !retHigh && limitInfoHigh.BinsNumString.size() > 0)
        {
          hasBined = true;
          SET_MULTIBIN(limitInfoHigh.BinsNumString,limitInfoHigh.BinhNum);
        }
      }
      else // use test flow's limits
      {
        if(lowPinVec.size() > 0)
        {
          TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                          lowPinVec,
                                          limitNameLowVec[indexLow],
                                          retLow ? TM::Pass : TM::Fail,
                                          lowResultArray);
        }
        if(highPinVec.size() > 0)
        {
          TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                          highPinVec,
                                          limitNameHighVec[indexHigh],
                                          retHigh ? TM::Pass : TM::Fail,
                                          highResultArray);
        }
      }
      break;

    case TM::GPF:
      for(vector<string>::size_type i = 0; i < expandedPinsVec.size(); ++i)
      {
        if(isMeasuredLow[i])
        {
          retLow = retLow && resultLow[i].getGlobalPassFail(siteNumber);
          lowStringPinlist = lowStringPinlist + pinlistVec[i] + ",";
        }
        if(isMeasuredHigh[i])
        {
          retHigh = retHigh && resultHigh[i].getGlobalPassFail(siteNumber);
          highStringPinlist = highStringPinlist + pinlistVec[i] + ",";
        }
      }

      if(isLimitTableUsed)
      {
        if(!lowStringPinlist.empty())
        {
          lowStringPinlist = lowStringPinlist.substr(0,lowStringPinlist.length()-1);
          TESTSET().cont(TM::CONTINUE).testnumber(limitInfoLow.TestNumber)
                                      .judgeAndLog_ParametricTest(
                                          lowStringPinlist,
                                          limitNameLowVec[indexLow],
                                          retLow ? TM::Pass : TM::Fail,
                                          0.0);
        }
        if(!hasBined && !retLow  && limitInfoLow.BinsNumString.size() > 0)
        {
          hasBined = true;
          SET_MULTIBIN(limitInfoLow.BinsNumString,limitInfoLow.BinhNum);
        }
        if(!highStringPinlist.empty())
        {
          highStringPinlist = highStringPinlist.substr(0,highStringPinlist.length()-1);
          TESTSET().cont(TM::CONTINUE).testnumber(limitInfoHigh.TestNumber)
                                      .judgeAndLog_ParametricTest(
                                          highStringPinlist,
                                          limitNameHighVec[indexHigh],
                                          retHigh ? TM::Pass : TM::Fail,
                                          0.0);
        }
        if(!hasBined && !retHigh && limitInfoHigh.BinsNumString.size() > 0)
        {
          hasBined = true;
          SET_MULTIBIN(limitInfoHigh.BinsNumString,limitInfoHigh.BinhNum);
        }
      }
      else // use test flow's limits
      {
        if(!lowStringPinlist.empty())
        {
          lowStringPinlist = lowStringPinlist.substr(0,lowStringPinlist.length() -1);
          TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                          lowStringPinlist,
                                          limitNameLowVec[indexLow],
                                          retLow ? TM::Pass : TM::Fail,
                                          0.0);
        }
        if(!highStringPinlist.empty())
        {
          highStringPinlist = highStringPinlist.substr(0,highStringPinlist.length() -1);
          TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                          highStringPinlist,
                                          limitNameHighVec[indexHigh],
                                          retHigh ? TM::Pass : TM::Fail,
                                          0.0);
        }
      }

      break;
    default:
      throw Error("LeakageTestUtil::judgeAndLogUtilForAllGroups",
                  "Unknown Test Mode",
                  "LeakageTestUtil::judgeAndLogUtilForAllGroups");

    } // end switch
  }


  static void ppmuInstrumentCurrentMeasurementSetup(
      const vector<string> &pinlistVec,
      const vector<bool>   &isMeasuredVec,
      const vector<double> &forceVoltageVec,
      const vector<string> &prechargeVec,
      const vector<double> &prechargeVoltageVec,
      const vector<double> &settlingTimeVec,
      const vector<string> &measureModeVec,
      const vector<string> &relaySwitchModeVec,
      const vector<LIMIT>  &limitVec,
      const vector<bool>   &isHVPinVec,
      const TM::DCTEST_MODE& mode,
      PPMU_SETTING &ppmuSettingStep1,
      PPMU_SETTING &ppmuSettingStep2,
      PPMU_RELAY   &ppmuRelayStep1,
      PPMU_RELAY   &ppmuRelayStep2,
      PPMU_RELAY   &ppmuRelayRestoreStep1,
      PPMU_RELAY   &ppmuRelayRestoreStep2,
      PPMU_MEASURE &measurePpmu,
      HV_DC_TASK   &hvDcTask,
      bool &hasPpmuParallelGroup,
      bool &hasHVPpmuParallelGroup);

  static void ppmuCurrentMeasurementUpdateTestResult(
      const vector<string> &pinlistVec,
      const vector<bool>   &isMeasuredVec,
      const vector<double> &forceVoltageVec,
      const vector<string> &prechargeVec,
      const vector<double> &prechargeVoltageVec,
      const vector<double> &settlingTimeVec,
      const vector<string> &measureModeVec,
      const vector<string> &relaySwitchModeVec,
      const vector<LIMIT>  &limitVec,
      const vector<vector<string> > &expandedPinsVec,
      const vector<bool>   &isHVPinVec,
      const TM::DCTEST_MODE& testMode,
      const PPMU_MEASURE&    measurePpmu,
      vector<MeasurementResultContainer> &result);

  static void ppmuCurrentHVMeasurementUpdateTestResult(
      const vector<string> &pinlistVec,
      const vector<bool>   &isMeasuredVec,
      const vector<double> &forceVoltageVec,
      const vector<string> &prechargeVec,
      const vector<double> &prechargeVoltageVec,
      const vector<double> &settlingTimeVec,
      const vector<string> &measureModeVec,
      const vector<string> &relaySwitchModeVec,
      const vector<LIMIT>  &limitVec,
      const vector<vector<string> > &expandedPinsVec,
      const vector<bool>   &isHVPinVec,
      const TM::DCTEST_MODE& testMode,
      const HV_DC_TASK&  hvDcTask,
      vector<MeasurementResultContainer> &result);

  static void spmuInstrumentCurrentMeasurementSetup(
      const vector<string>&  pinlistVec,
      const vector<bool>&    isMeasuredVec,
      const vector<double>&  forceVoltageVec,
      const vector<string>&  measureModeVec,
      const vector<double>&  clampVoltageVec,
      const vector<string>&  prechargeVec,
      const vector<double>&  prechargeVoltageVec,
      const vector<double>&  settlingTimeVec,
      const vector<string>&  relaySwitchModeVec,
      const vector<LIMIT>&   limitVec,
      const TM::DCTEST_MODE& mode,
      SPMU_TASK& spmuTaskForceON,
      SPMU_TASK& spmuTaskMeasure,
      SPMU_TASK& spmuTaskForceOFF,
      bool&  hasParallelGroup);

   static void spmuCurrentMeasurementUpdateTestResult(
       const vector<string>&  pinlistVec,
       const vector<bool>&    isMeasuredVec,
       const vector<double>&  forceVoltageVec,
       const vector<string>&  measureModeVec,
       const vector<double>&  clampValueVec,
       const vector<string>&  prechargeVec,
       const vector<double>&  prechargeVoltageVec,
       const vector<double>&  settlingTimeVec,
       const vector<string>&  relaySwitchModeVec,
       const vector<LIMIT>&   limitVec,
       const vector<vector<string> >& expandedPinsVec,
       const TM::DCTEST_MODE& testMode,
       SPMU_TASK& spmuMeasure,
       vector<MeasurementResultContainer>& result);

   static void DCScaleSIGInstrumentCurrentMeasurementSetup(
       const vector<string>&  pinlistVec,
       const vector<bool>&    isMeasuredVec,
       const vector<double>&  forceVoltageVec,
       const vector<string>&  measureModeVec,
       const vector<double>&  clampValueVec,
       const vector<string>&  prechargeVec,
       const vector<double>&  prechargeVoltageVec,
       const vector<double>&  settlingTimeVec,
       const vector<string>&  relaySwitchModeVec,
       const vector<LIMIT>&   limitVec,
       const TM::DCTEST_MODE& testMode,
       SPMU_TASK& spmuTaskForceON,
       SPMU_TASK& spmuTaskMeasure,
       SPMU_TASK& spmuTaskForceOFF,
       bool&  hasParallelGroup);


   static void DCScaleSIGMeasurementCurrentUpdateTestResult(
       const vector<string>&  pinlistVec,
       const vector<bool>&    isMeasuredVec,
       const vector<double>&  forceVoltageVec,
       const vector<string>&  measureModeVec,
       const vector<double>&  clampValueVec,
       const vector<string>&  prechargeVec,
       const vector<double>&  prechargeVoltageVec,
       const vector<double>&  settlingTimeVec,
       const vector<string>&  relaySwitchModeVec,
       const vector<LIMIT>&   limitVec,
       const vector<vector<string> >& expandedPinsVec,
       const TM::DCTEST_MODE& testMode,
       const SPMU_TASK&   spmuTask,
       vector<MeasurementResultContainer>& resultVec);

   static void mcxInstrumentCurrentMeasurement(
       const vector<string>& pinlistVec,
       const vector<bool>&   isMeasuredVec,
       const vector<double>& forceVoltageVec,
       const vector<string>&  measureModeVec,
       const vector<string>&  prechargeVec,
       const vector<double>&  prechargeVoltageVec,
       const vector<double>&  settlingTimeVec,
       const vector<LIMIT>&   limitVec,
       const vector<vector<string> >& expandedPinsVec,
       const TM::DCTEST_MODE& testMode,
       vector<MeasurementResultContainer>& resultVec);

private:

  static void ppmuMeasurementRelaySwitchChange_SinglePin(
      const string&   singlePinName,
      const string&   relaySwitchMode,
      const double    settingTime = 0.0,
      const string&   termination = "OFF");

  static void ppmuMeasurementRelaySwitchRestore_SinglePin(
      const string&   singlePinName,
      const string&   relaySwitchMode,
      const string&   termination = "OFF");

  template<class T>
  static void getTestResultForEveryGroup(
      const vector<string>&   pinlist,
      const TM::DCTEST_MODE& testMode,
      const T&    measureXpmu,
      MeasurementResultContainer& result);

  static void mcxCurrentMeasurementUpdateTestResult(
      const vector<string>& pinlist,
      const TM::DCTEST_MODE& testMode,
      const PMU_VFIM& pmuTask,
      MeasurementResultContainer& result);
};


/*
 *----------------------------------------------------------------------*
 * Routine: LeakageTestUtil::ppmuInstrumentCurrentMeasurement
 *
 * Purpose: execute ppmu Current Measurement
 *
 *----------------------------------------------------------------------*
 * Description:
 *  for parallel execute:
 * workflow:
 *   1) IF  precharge THEN
 *        1.1 PPMU_SETTING for precharge purpose
 *        1.2 PPMU_RELAY switch change without extra settling time
 *        1.3 PPMU_SETTING for measurement with extra settling time
 *      ELSE
 *        1.1 PPMU_SETTING for measurement without extra settling time
 *        1.2 PPMU_RELAY switch change with extra settling time
 *   2) PPMU_MEASURE measurement
 *   3) PPMU_RELAY switch restore
 *
 *  for serial execute:
 * workflow:
 *  IF  precharge THEN
 *     1.1 PPMU_SETTING for precharge purpose
 *       FOR each single pin DO
 *         1.2 PPMU_RELAY switch change without extra settling time
 *         1.3 PPMU_SETTING for measurement with extra settling time
 *         1.4 PPMU_MEASURE do measurement
 *         1.5 PPMU_RELAY restore relay status
 *       END-FOR
 *   ELSE
 *     1.1 PPMU_SETTING for measurement without extra settling time
 *        FOR each single pin DO
 *          1.2 PPMU_RELAY switch change with extra settling time
 *          1.3 PPMU_MEASURE do measurement
 *          1.4 PPMU_RELAY restore relay status
 *        END-FOR
 *
 * Note:
 *   use Flex-DC
 *----------------------------------------------------------------------*
 */

inline void
LeakageTestUtil::ppmuInstrumentCurrentMeasurementSetup(
    const vector<string> &pinlistVec,
    const vector<bool>   &isMeasuredVec,
    const vector<double> &forceVoltageVec,
    const vector<string> &prechargeVec,
    const vector<double> &prechargeVoltageVec,
    const vector<double> &settlingTimeVec,
    const vector<string> &measureModeVec,
    const vector<string> &relaySwitchModeVec,
    const vector<LIMIT>  &limitVec,
    const vector<bool>   &isHVPinVec,
    const TM::DCTEST_MODE& testMode,
    PPMU_SETTING &ppmuSettingStep1,
    PPMU_SETTING &ppmuSettingStep2,
    PPMU_RELAY   &ppmuRelayStep1,
    PPMU_RELAY   &ppmuRelayStep2,
    PPMU_RELAY   &ppmuRelayRestoreStep1,
    PPMU_RELAY   &ppmuRelayRestoreStep2,
    PPMU_MEASURE &measurePpmu,
    HV_DC_TASK   &hvDcTask,
    bool &hasPpmuParallelGroup,
    bool &hasHVPpmuParallelGroup)
{
  bool hasBBMMode = false;
  bool hasMBBMode = false;
  bool hasParallelGroup = false;
  bool hasPpmuSettingStep1 = false;

  double timeForSettingStep1 = 0.0;
  double timeForSettingStep2 = 0.0;
  double timeForRelayStep2 = 0.0;

  const double prechargeSettlingTime = 1.0;

  string hvTestMode = getMeasureModeForHVPin(testMode);

  for(vector<string>::size_type i = 0; i < pinlistVec.size(); i++)
  {
    if(isMeasuredVec[i])
    {
      double low = 0.0 , high = 0.0;
      limitVec[i].getLow(&low);
      limitVec[i].getHigh(&high);
      double currentRange = MAX(fabs(low),fabs(high));

      if (isHVPinVec[i])  // HV Pins
      {
        if(measureModeVec[i] == "PAR")
        {
          hasHVPpmuParallelGroup = true;
          if (prechargeVec[i] == "ON" )
          {
            hvDcTask.pin(pinlistVec[i])
                    .preCharge(prechargeVoltageVec[i] mV)
                    .iForceRange(currentRange uA)
                    .min(low)
                    .max(high)
                    .vForce(forceVoltageVec[i] mV)
                    .settling(settlingTimeVec[i] ms)
                    .execMode(hvTestMode);
          }
          else  //OFF
          {
            hvDcTask.pin(pinlistVec[i])
                    .iForceRange(currentRange uA)
                    .min(low)
                    .max(high)
                    .vForce(forceVoltageVec[i] mV)
                    .settling(settlingTimeVec[i] ms)
                    .execMode(hvTestMode);
          }
        }
      }
      else  //non HV pins
      {
        hasPpmuSettingStep1 = true; // for parallel and serial groups

        if(measureModeVec[i] == "PAR")
        {
          hasPpmuParallelGroup = true;
          hasParallelGroup = true;
          if (prechargeVec[i] == "ON" )
          {
            // 1. determine precharge
            // min and max have no influence on precharge
            ppmuSettingStep1.pin(pinlistVec[i])
                            .iRange(1 uA)
                            .min(-1 uA)
                            .max(1 uA)
                            .vForce(prechargeVoltageVec[i] mV);
            if(timeForSettingStep1 < prechargeSettlingTime )
            {
              timeForSettingStep1 = prechargeSettlingTime;
            }
            ppmuSettingStep2.pin(pinlistVec[i])
                            .iRange(currentRange)
                            .min(low)
                            .max(high)
                            .vForce(forceVoltageVec[i] mV);
            if(timeForSettingStep2 < settlingTimeVec[i] + 1 )
            {
              timeForSettingStep2 = settlingTimeVec[i] + 1;
              ppmuSettingStep2.wait(timeForSettingStep2 ms);
            }

            // 2.relay switch
            if (relaySwitchModeVec[i] == "DEFAULT(BBM)")
            {
              ppmuRelayStep1.pin(pinlistVec[i]).status("AC_OFF");
              ppmuRelayStep2.pin(pinlistVec[i]).status("PPMU_ON");
              if(timeForRelayStep2 < 0.3)
              {
                timeForRelayStep2 = 0.3;
              }
            }
            else if (relaySwitchModeVec[i] == "MBB" )
            {
              ppmuRelayStep2.pin(pinlistVec[i]).status("OAC_OFF");
              ppmuRelayStep1.pin(pinlistVec[i]).status("OPM_ON");
              if(timeForRelayStep2 < 0.3)
              {
                timeForRelayStep2 = 0.3;
              }
            }
            else
            {
              ppmuRelayStep2.pin(pinlistVec[i]).status("PPMU_ON");
              if(timeForRelayStep2 < 0.3)
              {
                timeForRelayStep2 = 0.3;
              }
            }
          }
          else
          {
            ppmuSettingStep1.pin(pinlistVec[i])
                            .iRange(currentRange)
                            .min(low)
                            .max(high)
                            .vForce(forceVoltageVec[i] mV);

            // 2.relay switch
            if (relaySwitchModeVec[i] == "DEFAULT(BBM)")
            {
              ppmuRelayStep1.pin(pinlistVec[i]).status("AC_OFF");
              ppmuRelayStep2.pin(pinlistVec[i]).status("PPMU_ON");
              if(timeForRelayStep2 < settlingTimeVec[i] + 1.3)
              {
                timeForRelayStep2 = settlingTimeVec[i] + 1.3;
              }
            }
            else if (relaySwitchModeVec[i] == "MBB" )
            {
              ppmuRelayStep2.pin(pinlistVec[i]).status("OAC_OFF");
              ppmuRelayStep1.pin(pinlistVec[i]).status("OPM_ON");
              if(timeForRelayStep2 < settlingTimeVec[i] + 1.3)
              {
                timeForRelayStep2 = settlingTimeVec[i] + 1.3;
              }
            }
            else
            {
              ppmuRelayStep2.pin(pinlistVec[i]).status("PPMU_ON");
              if(timeForRelayStep2 < settlingTimeVec[i] + 1.3)
              {
                timeForRelayStep2 = settlingTimeVec[i] + 1.3;
              }
            }
          }
          //  3. determine measure

          // PVAL or PPF or GPF is defined by TestSuite Flag
          measurePpmu.pin(pinlistVec[i]).execMode(testMode);

          // 4.relay restore
          if(relaySwitchModeVec[i] == "DEFAULT(BBM)")
          {
            hasBBMMode = true;
            ppmuRelayRestoreStep1.pin(pinlistVec[i]).status("PPMU_OFF");
            ppmuRelayRestoreStep2.pin(pinlistVec[i]).status("AC_ON");
          }
          else if(relaySwitchModeVec[i] == "MBB")
          {
            hasMBBMode = true;
            ppmuRelayRestoreStep2.pin(pinlistVec[i]).status("OPM_OFF");
            ppmuRelayRestoreStep1.pin(pinlistVec[i]).status("OAC_ON");
          }
          else
          {
            ppmuRelayRestoreStep2.pin(pinlistVec[i]).status("AC_ON");
          }
        }
        else
        {
          if(prechargeVec[i] == "ON")
          {
            ppmuSettingStep1.pin(pinlistVec[i])
                            .iRange(1 uA)
                            .min(-1 uA)
                            .max(1 uA)
                            .vForce(prechargeVoltageVec[i] mV);
            if(timeForSettingStep1 < prechargeSettlingTime )
            {
              timeForSettingStep1 = prechargeSettlingTime;
            }
          }
          else
          {
            ppmuSettingStep1.pin(pinlistVec[i])
                            .iRange(currentRange)
                            .min(low)
                            .max(high)
                            .vForce(forceVoltageVec[i] mV);
          }
        }
      }
    }
  }

  if(hasPpmuSettingStep1)
  {
    ppmuSettingStep1.wait(timeForSettingStep1 ms);
  }

  if(hasParallelGroup)
  {
    ppmuRelayStep2.wait(timeForRelayStep2 ms);
    ppmuRelayRestoreStep2.wait(0.3 ms);
    if(hasMBBMode || hasBBMMode)
    {
      ppmuRelayStep1.wait(0.3 ms);
      ppmuRelayRestoreStep1.wait(0.3 ms);
    }
  }
}

inline void
LeakageTestUtil::ppmuCurrentMeasurementUpdateTestResult(
    const vector<string> &pinlistVec,
    const vector<bool>   &isMeasuredVec,
    const vector<double> &forceVoltageVec,
    const vector<string> &prechargeVec,
    const vector<double> &prechargeVoltageVec,
    const vector<double> &settlingTimeVec,
    const vector<string> &measureModeVec,
    const vector<string> &relaySwitchModeVec,
    const vector<LIMIT>  &limitVec,
    const vector<vector<string> > &expandedPinsVec,
    const vector<bool>   &isHVPinVec,
    const TM::DCTEST_MODE& testMode,
    const PPMU_MEASURE&    measurePpmu,
    vector<MeasurementResultContainer>& result)
{
  // get test result
  MeasurementResultContainer everyGroupResult;

  for(vector<string>::size_type i = 0; i < pinlistVec.size(); i++)
  {
    if(result.size() <= i)
    {
      everyGroupResult.init();
      result.push_back(everyGroupResult);
    }
    if(isMeasuredVec[i] && !isHVPinVec[i])
    {
      if(measureModeVec[i] == "PAR")
      {
        getTestResultForEveryGroup(
            expandedPinsVec[i],testMode,measurePpmu,result[i]);
      }
      else
      {
        PPMU_MEASURE measurePpmuEveryGroup;
        ON_FIRST_INVOCATION_BEGIN();

        vector<string>::size_type length = expandedPinsVec[i].size();

        double settling = settlingTimeVec[i] + 1;
        if(prechargeVec[i] == "ON")
        {
          double low = 0.0 ,high = 0.0;
          limitVec[i].getLow(&low);
          limitVec[i].getHigh(&high);
          double currentRange = MAX(fabs(low),fabs(high));

          for (vector<string>::size_type j = 0; j < length; j++)
          {
            measurePpmuEveryGroup.pin(expandedPinsVec[i][j]).execMode(testMode);
          }

          for (vector<string>::size_type j = 0; j < length; j++)
          {
            TASK_LIST tasks;
            PPMU_SETTING settingPpmu;
            ppmuMeasurementRelaySwitchChange_SinglePin(expandedPinsVec[i][j],
                                                       relaySwitchModeVec[i],
                                                       0.0);

            settingPpmu.pin(expandedPinsVec[i][j])
                       .iRange(currentRange)
                       .min(low)
                       .max(high)
                       .vForce(forceVoltageVec[i] mV);

            settingPpmu.wait(settling ms);
            tasks.add(settingPpmu);
            tasks.execute();

            // do measurement for single pin
            measurePpmuEveryGroup.execute(expandedPinsVec[i][j]);

            ppmuMeasurementRelaySwitchRestore_SinglePin(expandedPinsVec[i][j],
                                                        relaySwitchModeVec[i]);
          }
        }
        else
        {
          for (vector<string>::size_type j = 0; j < length; j++)
          {
            measurePpmuEveryGroup.pin(expandedPinsVec[i][j]).execMode(testMode);
          }

          for (vector<string>::size_type j = 0; j < length; j++)
          {
            ppmuMeasurementRelaySwitchChange_SinglePin(expandedPinsVec[i][j],
                                                       relaySwitchModeVec[i],
                                                       settling);
            // do measurement for single pin
            measurePpmuEveryGroup.execute(expandedPinsVec[i][j]);

            ppmuMeasurementRelaySwitchRestore_SinglePin(expandedPinsVec[i][j],
                                                        relaySwitchModeVec[i]);
          }
        }
        ON_FIRST_INVOCATION_END();
        getTestResultForEveryGroup(
          expandedPinsVec[i],testMode,measurePpmuEveryGroup,everyGroupResult);
        result[i] = everyGroupResult;
      }
    }
  }
}

inline void
LeakageTestUtil::ppmuCurrentHVMeasurementUpdateTestResult(
    const vector<string> &pinlistVec,
    const vector<bool>   &isMeasuredVec,
    const vector<double> &forceVoltageVec,
    const vector<string> &prechargeVec,
    const vector<double> &prechargeVoltageVec,
    const vector<double> &settlingTimeVec,
    const vector<string> &measureModeVec,
    const vector<string> &relaySwitchModeVec,
    const vector<LIMIT>  &limitVec,
    const vector<vector<string> > &expandedPinsVec,
    const vector<bool>   &isHVPinVec,
    const TM::DCTEST_MODE& testMode,
    const HV_DC_TASK&    hvDcTask,
    vector<MeasurementResultContainer>& result)
{
  // get test result
  MeasurementResultContainer everyGroupResult;
  string hvTestMode = getMeasureModeForHVPin(testMode);

  //HV pins are tested before non-HV pins
  for(vector<string>::size_type i = 0; i < pinlistVec.size(); i++)
  {
    if(result.size() <= i)
    {
      everyGroupResult.init();
      result.push_back(everyGroupResult);
    }
    if(isMeasuredVec[i] && isHVPinVec[i])
    {
      if(measureModeVec[i] == "PAR")
      {
        getTestResultForEveryGroup(
            expandedPinsVec[i],testMode,hvDcTask,result[i]);
      }
      else
      {
        HV_DC_TASK hvDcTaskEveryGroup;
        ON_FIRST_INVOCATION_BEGIN();

        double low = 0.0 ,high = 0.0;
        limitVec[i].getLow(&low);
        limitVec[i].getHigh(&high);
        double currentRange = MAX(fabs(low),fabs(high));

        if(prechargeVec[i] == "ON")
        {
          hvDcTaskEveryGroup.pin(pinlistVec[i])
                                .preCharge(prechargeVoltageVec[i] mV)
                                .iForceRange(currentRange uA)
                                .min(low)
                                .max(high)
                                .vForce(forceVoltageVec[i] mV)
                                .settling(settlingTimeVec[i] ms)
                                .execMode(hvTestMode);
          hvDcTaskEveryGroup.execute();
        }
        else
        {
          hvDcTaskEveryGroup.pin(pinlistVec[i])
                            .iForceRange(currentRange uA)
                            .min(low)
                            .max(high)
                            .vForce(forceVoltageVec[i] mV)
                            .settling(settlingTimeVec[i] ms)
                            .execMode(hvTestMode);
          hvDcTaskEveryGroup.execute();
        }
        ON_FIRST_INVOCATION_END();
        getTestResultForEveryGroup(
            expandedPinsVec[i],testMode,hvDcTaskEveryGroup,everyGroupResult);
        result[i] = everyGroupResult;
      }
    }
  }
}

template<class T> inline void
LeakageTestUtil::getTestResultForEveryGroup(
    const vector<string>&   pinlist,
    const TM::DCTEST_MODE& testMode,
    const T&    measureXpmu,
    MeasurementResultContainer& result)
{
  vector<string>::size_type  j = 0;
  bool isPass = true;
  switch ( testMode )
  {
  case TM::PVAL:
    for ( j = 0; j < pinlist.size(); j++ )
    {
      isPass = measureXpmu.getPassFail(pinlist[j]);
      double dMeasValue = measureXpmu.getValue(pinlist[j]);
      
      result.setPinPassFail(pinlist[j],isPass);
      result.setPinsValue(pinlist[j],dMeasValue);
    }
    break;
  case TM::PPF:
    for ( j = 0; j < pinlist.size(); j++ )
    {
      isPass = measureXpmu.getPassFail(pinlist[j]);
      result.setPinPassFail(pinlist[j],isPass);
    }
    break;
  case TM::GPF:
      isPass = measureXpmu.getPassFail();
      result.setGlobalPassFail(isPass);
    break;
  default:
    throw Error("LeakageTestUtil::getTestResultForEveryGroup",
                "Unknown Measure Mode",
                "LeakageTestUtil::getTestResultForEveryGroup");
  }
}

inline void
LeakageTestUtil::ppmuMeasurementRelaySwitchChange_SinglePin(
    const string& singlePinName,
    const string& relaySwitchMode,
    const double  settlingTime,
    const string& termination)
{
  TASK_LIST relayList;
  FLEX_RELAY step1;
  FLEX_RELAY step2;
  if(termination == "OFF")
  {
    if ( relaySwitchMode == "DEFAULT(BBM)" )
    {
      //open AC -> close PMU
      step1.pin(singlePinName).set("IDLE");
      step1.wait(0.3 ms);
      step2.pin(singlePinName).set("PPMU");
      step2.wait((settlingTime + 0.3) ms);

      relayList.add(step1).add(step2);
    }
    else if ( relaySwitchMode == "MBB" )
    {
      //close PMU/AC -> open AC
      step1.pin(singlePinName).set("ACPM");
      step1.wait(0.3 ms);
      step2.pin(singlePinName).set("PPMU");
      step2.wait((settlingTime + 0.3) ms);

      relayList.add(step1).add(step2);
    }
    else if ( relaySwitchMode == "PARALLEL" )
    {
      //close PMU/open AC
      step1.pin(singlePinName).set("PPMU");
      step1.wait((settlingTime + 0.3) ms);
      relayList.add(step1);
    }
    else
    {
      throw Error("LeakageTestUtil::ppmuMeasurementRelaySwitchChange_SinglePin",
                  "InValid relaySwitchMode",
                  "LeakageTestUtil::ppmuMeasurementRelaySwitchChange_SinglePin");
    }
  }
  else if(termination == "ON")
  {
    step1.pin(singlePinName).set("ACPM");
    step1.wait((settlingTime + 0.3) ms);
    relayList.add(step1);
  }
  else
  {
    throw Error("LeakageTestUtil::ppmuMeasurementRelaySwitchChange_SinglePin",
                "Unknown termination Status",
                "LeakageTestUtil::ppmuMeasurementRelaySwitchChange_SinglePin");
  }

  relayList.execute();
}

/*
*----------------------------------------------------------------------*
* Routine: LeakageTestUtil::ppmuMeasurementRelaySwitchRestore_SinglePin
*
* Purpose: using FLEX_RELAY to restore PMU and AC relay.
*
*----------------------------------------------------------------------*
* Description:
*   support relay switch mode: DEFAULT(BBM)|MBB|PARALLEL
* Note:
*
*----------------------------------------------------------------------*
*/
inline void
LeakageTestUtil::ppmuMeasurementRelaySwitchRestore_SinglePin(
    const string& singlePinName,
    const string& relaySwitchMode,
    const string& termination)
{
  TASK_LIST relayList;
  FLEX_RELAY step1;
  FLEX_RELAY step2;

  if(termination == "OFF")
  {
    if ( relaySwitchMode == "DEFAULT(BBM)" )
    {
      // open PPMU -> close AC
      step1.pin(singlePinName).set("IDLE");
      step1.wait(0.3 ms);
      step2.pin(singlePinName).set("AC");
      step2.wait(0.3 ms);

      relayList.add(step1).add(step2);
    }
    else if ( relaySwitchMode == "MBB" )
    {
      //close AC -> open PPMU
      step1.pin(singlePinName).set("ACPM");
      step1.wait(0.3 ms);
      step2.pin(singlePinName).set("AC");
      step2.wait(0.3 ms);

      relayList.add(step1).add(step2);
    }
    else if ( relaySwitchMode == "PARALLEL" )
    {
      // close AC/open PMU parallel
      step1.pin(singlePinName).set("AC");
      step1.wait(0.3 ms);
      relayList.add(step1);
    }
    else
    {
      throw Error("LeakageTestUtil::ppmuMeasurementRelaySwitchRestore_SinglePin",
                  "InValid relaySwitchMode",
                  "LeakageTestUtil::ppmuMeasurementRelaySwitchRestore_SinglePin");
    }
  }
  else
  {
    step1.pin(singlePinName).set("AC");
    step1.wait(0.3 ms);
    relayList.add(step1);
  }

  relayList.execute();
}

inline void
LeakageTestUtil::spmuInstrumentCurrentMeasurementSetup(
    const vector<string>&  pinlistVec,
    const vector<bool>&    isMeasuredVec,
    const vector<double>&  forceVoltageVec,
    const vector<string>&  measureModeVec,
    const vector<double>&  clampValueVec,
    const vector<string>&  prechargeVec,
    const vector<double>&  prechargeVoltageVec,
    const vector<double>&  settlingTimeVec,
    const vector<string>&  relaySwitchModeVec,
    const vector<LIMIT>&   limitVec,
    const TM::DCTEST_MODE& testMode,
    SPMU_TASK& spForceOn,
    SPMU_TASK& spMeasure,
    SPMU_TASK& spForceOff,
    bool&  hasParallelGroup)
{
  for(unsigned i = 0; i < pinlistVec.size(); i++)
  {
    if(isMeasuredVec[i])
    {
      if("PAR" == measureModeVec[i])
      {
        hasParallelGroup = true;
        double low, high;
        limitVec[i].getLow(&low);
        limitVec[i].getHigh(&high);
        if ("ON" == prechargeVec[i]) // have precharge
        {
          spForceOn.pin(pinlistVec[i])
                   .preCharge(prechargeVoltageVec[i] mV)
                   .max(high)
                   .min(low)
                   .mode("VFIM")
                   .vForce(forceVoltageVec[i] mV)
                   .clamp(clampValueVec[i] uA)
                   .execMode("PAR")
                   .relay(relaySwitchModeVec[i])
                   .settling(settlingTimeVec[i] ms);
          spForceOn.execMode("FORCE_ON");
          spMeasure.pin(pinlistVec[i])
                   .max(high)
                   .min(low)
                   .mode("VFIM")
                   .vForce(forceVoltageVec[i] mV)
                   .clamp(clampValueVec[i] uA)
                   .execMode("PAR")
                   .relay(relaySwitchModeVec[i]);
          spMeasure.execMode(testMode);
          spForceOff.pin(pinlistVec[i])
                    .max(high)
                    .min(low)
                    .mode("VFIM")
                    .vForce(forceVoltageVec[i] mV)
                    .clamp(clampValueVec[i] uA)
                    .execMode("PAR")
                    .relay(relaySwitchModeVec[i]);
          spForceOff.execMode("FORCE_OFF");
        }
        else // no precharge
        {
            spForceOn.pin(pinlistVec[i])
                     .max(high)
                     .min(low)
                     .mode("VFIM")
                     .vForce(forceVoltageVec[i] mV)
                     .clamp(clampValueVec[i] uA)
                     .execMode("PAR")
                     .relay(relaySwitchModeVec[i])
                     .settling(settlingTimeVec[i] ms);
            spForceOn.execMode("FORCE_ON");
            spMeasure.pin(pinlistVec[i])
                     .max(high)
                     .min(low)
                     .mode("VFIM")
                     .vForce(forceVoltageVec[i] mV)
                     .clamp(clampValueVec[i] uA)
                     .execMode("PAR")
                     .relay(relaySwitchModeVec[i]);
            spMeasure.execMode(testMode);
            spForceOff.pin(pinlistVec[i])
                      .max(high)
                      .min(low)
                      .mode("VFIM")
                      .vForce(forceVoltageVec[i] mV)
                      .clamp(clampValueVec[i] uA)
                      .execMode("PAR")
                      .relay(relaySwitchModeVec[i]);
            spForceOff.execMode("FORCE_OFF");
        }
      }
    }
  }
}


inline void
LeakageTestUtil::spmuCurrentMeasurementUpdateTestResult(
    const vector<string>&  pinlistVec,
    const vector<bool>&    isMeasuredVec,
    const vector<double>&  forceVoltageVec,
    const vector<string>&  measureModeVec,
    const vector<double>&  clampValueVec,
    const vector<string>&  prechargeVec,
    const vector<double>&  prechargeVoltageVec,
    const vector<double>&  settlingTimeVec,
    const vector<string>&  relaySwitchModeVec,
    const vector<LIMIT>&   limitVec,
    const vector<vector<string> >& expandedPinsVec,
    const TM::DCTEST_MODE& testMode,
    SPMU_TASK& spmuMeasure,
    vector<MeasurementResultContainer>& result)
{
  // get test result
  MeasurementResultContainer everyGroupResult;
  for(vector<string>::size_type i = 0; i < pinlistVec.size(); i++)
  {
    if(result.size() <= i)
    {
      everyGroupResult.init();
      result.push_back(everyGroupResult);
    }

    if(isMeasuredVec[i])
    {
      if("PAR" == measureModeVec[i])
      {
        getTestResultForEveryGroup(
            expandedPinsVec[i],testMode,spmuMeasure,result[i]);
      }
      else
      {
        SPMU_TASK spmuTask;
        ON_FIRST_INVOCATION_BEGIN();
        double low = 0.0, high = 0.0;
        limitVec[i].getLow(&low);
        limitVec[i].getHigh(&high);

        if ("ON" == prechargeVec[i]) // has precharge
        {
          spmuTask.pin(pinlistVec[i])
                  .preCharge(prechargeVoltageVec[i] mV)
                  .max(high)
                  .min(low)
                  .mode("VFIM")
                  .vForce(forceVoltageVec[i] mV)
                  .clamp(clampValueVec[i] uA)
                  .execMode("SER")
                  .relay(relaySwitchModeVec[i])
                  .settling(settlingTimeVec[i] ms);
        }
        else
        {
          spmuTask.pin(pinlistVec[i])
                  .max(high)
                  .min(low)
                  .mode("VFIM")
                  .vForce(forceVoltageVec[i] mV)
                  .clamp(clampValueVec[i] uA)
                  .execMode("SER")
                  .relay(relaySwitchModeVec[i])
                  .settling(settlingTimeVec[i] ms);
        }
        // PVAL or PPF or GPF is defined by TestSuite Flag
        spmuTask.execMode(testMode);
        spmuTask.execute();
        ON_FIRST_INVOCATION_END();
        getTestResultForEveryGroup(
            expandedPinsVec[i],testMode,spmuTask,result[i]);
      }
    }
  }
}


inline void
LeakageTestUtil::DCScaleSIGInstrumentCurrentMeasurementSetup(
    const vector<string>& pinlistVec,
    const vector<bool>&   isMeasuredVec,
    const vector<double>&  forceVoltageVec,
    const vector<string>&  measureModeVec,
    const vector<double>&  clampValueVec,
    const vector<string>&  prechargeVec,
    const vector<double>&  prechargeVoltageVec,
    const vector<double>&  settlingTimeVec,
    const vector<string>&  relaySwitchModeVec,
    const vector<LIMIT>&   limitVec,
    const TM::DCTEST_MODE& testMode,
    SPMU_TASK& spmuTaskForceON,
    SPMU_TASK& spmuTaskMeasure,
    SPMU_TASK& spmuTaskForceOFF,
    bool&  hasParallelGroup)
{
  // for Parallel execute mode
  for(unsigned i = 0; i < pinlistVec.size(); i++)
  {
    if(isMeasuredVec[i])
    {
      if("PAR" == measureModeVec[i])
      {
        hasParallelGroup = true;
        if ("ON" == prechargeVec[i])
        {
          spmuTaskForceON.pin(pinlistVec[i])
                         .preCharge(prechargeVoltageVec[i] mV)
                         .limits(limitVec[i])
                         .mode("VFIM")
                         .vForce(forceVoltageVec[i] mV)
                         .clamp(clampValueVec[i] uA)
                         .execMode("PAR")
                         .relay(relaySwitchModeVec[i])
                         .settling(settlingTimeVec[i] ms);
          spmuTaskForceON.execMode("FORCE_ON");
          spmuTaskMeasure.pin(pinlistVec[i])
                         .limits(limitVec[i])
                         .mode("VFIM")
                         .vForce(forceVoltageVec[i] mV)
                         .clamp(clampValueVec[i] uA)
                         .execMode("PAR")
                         .relay(relaySwitchModeVec[i]);
          spmuTaskMeasure.execMode(testMode);
          spmuTaskForceOFF.pin(pinlistVec[i])
                          .limits(limitVec[i])
                          .mode("VFIM")
                          .vForce(forceVoltageVec[i] mV)
                          .clamp(clampValueVec[i] uA)
                          .execMode("PAR")
                          .relay(relaySwitchModeVec[i]);
          spmuTaskForceOFF.execMode("FORCE_OFF");
        }
        else  // no precharge
        {
          spmuTaskForceON.pin(pinlistVec[i])
                         .limits(limitVec[i])
                         .mode("VFIM")
                         .vForce(forceVoltageVec[i] mV)
                         .clamp(clampValueVec[i] uA)
                         .execMode("PAR")
                         .relay(relaySwitchModeVec[i])
                         .settling(settlingTimeVec[i] ms);
          spmuTaskForceON.execMode("FORCE_ON");
          spmuTaskMeasure.pin(pinlistVec[i])
                         .limits(limitVec[i])
                         .mode("VFIM")
                         .vForce(forceVoltageVec[i] mV)
                         .clamp(clampValueVec[i] uA)
                         .execMode("PAR")
                         .relay(relaySwitchModeVec[i]);
          spmuTaskMeasure.execMode(testMode);
          spmuTaskForceOFF.pin(pinlistVec[i])
                          .limits(limitVec[i])
                          .mode("VFIM")
                          .vForce(forceVoltageVec[i] mV)
                          .clamp(clampValueVec[i] uA)
                          .execMode("PAR")
                          .relay(relaySwitchModeVec[i]);
          spmuTaskForceOFF.execMode("FORCE_OFF");
        }
      }
    }
  }
}


inline void
LeakageTestUtil::DCScaleSIGMeasurementCurrentUpdateTestResult(
    const vector<string>& pinlistVec,
    const vector<bool>&   isMeasuredVec,
    const vector<double>&  forceVoltageVec,
    const vector<string>&  measureModeVec,
    const vector<double>&  clampValueVec,
    const vector<string>&  prechargeVec,
    const vector<double>&  prechargeVoltageVec,
    const vector<double>&  settlingTimeVec,
    const vector<string>&  relaySwitchModeVec,
    const vector<LIMIT>&   limitVec,
    const vector<vector<string> >& expandedPinsVec,
    const TM::DCTEST_MODE& testMode,
    const SPMU_TASK&   spmuTask,
    vector<MeasurementResultContainer>& resultVec)
{
  // get test result
  MeasurementResultContainer everyGroupResult;
  for(vector<string>::size_type i = 0; i < pinlistVec.size(); i++)
  {
    if(resultVec.size() <= i)
    {
      everyGroupResult.init();
      resultVec.push_back(everyGroupResult);
    }

    if(isMeasuredVec[i])
    {

      if("PAR" == measureModeVec[i])
      {
        getTestResultForEveryGroup(
            expandedPinsVec[i],testMode,spmuTask,resultVec[i]);
      }
      else
      {
        SPMU_TASK spmuForceON,spmuMeasure,spmuForceOFF;
        ON_FIRST_INVOCATION_BEGIN();
        TASK_LIST taskList;

        if ("ON" == prechargeVec[i]) // has precharge
        {
          spmuForceON.pin(pinlistVec[i])
                     .preCharge(prechargeVoltageVec[i] mV)
                     .limits(limitVec[i])
                     .mode("VFIM")
                     .vForce(forceVoltageVec[i] mV)
                     .clamp(clampValueVec[i] uA)
                     .execMode("SER")
                     .relay(relaySwitchModeVec[i])
                     .settling(settlingTimeVec[i] ms);
          spmuForceON.execMode("FORCE_ON");
          spmuMeasure.pin(pinlistVec[i])
                     .limits(limitVec[i])
                     .mode("VFIM")
                     .vForce(forceVoltageVec[i] mV)
                     .clamp(clampValueVec[i] uA)
                     .execMode("SER")
                     .relay(relaySwitchModeVec[i]);
          spmuMeasure.execMode(testMode);
          spmuForceOFF.pin(pinlistVec[i])
                      .limits(limitVec[i])
                      .mode("VFIM")
                      .vForce(forceVoltageVec[i] mV)
                      .clamp(clampValueVec[i] uA)
                      .execMode("SER")
                      .relay(relaySwitchModeVec[i]);
          spmuForceOFF.execMode("FORCE_OFF");
        }
        else // no precharge
        {
          spmuForceON.pin(pinlistVec[i])
                     .limits(limitVec[i])
                     .mode("VFIM")
                     .vForce(forceVoltageVec[i] mV)
                     .clamp(clampValueVec[i] uA)
                     .execMode("SER")
                     .relay(relaySwitchModeVec[i])
                     .settling(settlingTimeVec[i] ms);
          spmuForceON.execMode("FORCE_ON");
          spmuMeasure.pin(pinlistVec[i])
                     .limits(limitVec[i])
                     .mode("VFIM")
                     .vForce(forceVoltageVec[i] mV)
                     .clamp(clampValueVec[i] uA)
                     .execMode("SER")
                     .relay(relaySwitchModeVec[i]);
          spmuMeasure.execMode(testMode);
          spmuForceOFF.pin(pinlistVec[i])
                      .limits(limitVec[i])
                      .mode("VFIM")
                      .vForce(forceVoltageVec[i] mV)
                      .clamp(clampValueVec[i] uA)
                      .execMode("SER")
                      .relay(relaySwitchModeVec[i]);
          spmuForceOFF.execMode("FORCE_OFF");
        }
        // PVAL or PPF or GPF is defined by TestSuite Flag
        taskList.add(spmuForceON).add(spmuMeasure).add(spmuForceOFF).execute();
        ON_FIRST_INVOCATION_END();
        getTestResultForEveryGroup(
            expandedPinsVec[i],testMode,spmuMeasure,resultVec[i]);
      }
    }
  }
}


inline void
LeakageTestUtil::mcxInstrumentCurrentMeasurement(
    const vector<string>& pinlistVec,
    const vector<bool>&   isMeasuredVec,
    const vector<double>& forceVoltageVec,
    const vector<string>&  measureModeVec,
    const vector<string>&  prechargeVec,
    const vector<double>&  prechargeVoltageVec,
    const vector<double>&  settlingTimeVec,
    const vector<LIMIT>&   limitVec,
    const vector<vector<string> >& expandedPinsVec,
    const TM::DCTEST_MODE& testMode,
    vector<MeasurementResultContainer>& resultVec)
{
  MeasurementResultContainer everyGroupResult;
  for(vector<string>::size_type i = 0; i < pinlistVec.size(); i++)
  {
    if(resultVec.size() <= i)
    {
      everyGroupResult.init();
      resultVec.push_back(everyGroupResult);
    }

    if(isMeasuredVec[i])
    {
      //type TM::PPMU is for the MCA/MCB/MCC pins
      PMU_VFIM pmuVfim(pinlistVec[i],TM::PPMU);
      ON_FIRST_INVOCATION_BEGIN();

      if ("ON" == prechargeVec[i])
      {
        pmuVfim.preCharge(prechargeVoltageVec[i] mV);
      }
      // for MCX-PMU, member function iRange is ignored since the MCX has only one current range
      pmuVfim.vForce(forceVoltageVec[i] mV)
             .limits(limitVec[i])
             .settling(settlingTimeVec[i] ms);

      if("PAR" == measureModeVec[i])
      {
        pmuVfim.mode("NP");
      }
      else if("SER" == measureModeVec[i])
      {
        pmuVfim.mode("NS");
      }
      else
      {
        throw Error("LeakageTestUtil::mcxInstrumentCurrentMeasurement",
                    "InValid measure mode;the valid options: PAR SER",
                    "LeakageTestUtil::mcxInstrumentCurrentMeasurement");
      }
      // PVAL or PPF or GPF is defined by TestSuite Flag
      pmuVfim.execute( testMode);

      FOR_EACH_SITE_BEGIN();
        mcxCurrentMeasurementUpdateTestResult(
            expandedPinsVec[i],testMode,pmuVfim,resultVec[i]);
      FOR_EACH_SITE_END();

      ON_FIRST_INVOCATION_END();
    }
  }
}

inline void
LeakageTestUtil::mcxCurrentMeasurementUpdateTestResult(
    const vector<string>&   pinlist,
    const TM::DCTEST_MODE& testMode,
    const PMU_VFIM&    measurePmu,
    MeasurementResultContainer& result)
{
  int siteNumber = CURRENT_SITE_NUMBER();
  vector<string>::size_type  j = 0;
  bool isPass = true;
  switch ( testMode )
  {
  case TM::PVAL:
    for ( j = 0; j < pinlist.size(); j++ )
    {
      isPass = measurePmu.getPassFail(pinlist[j]);
      double dMeasValue = measurePmu.getValue(pinlist[j]);
      dMeasValue = dMeasValue * 1e-6; // [uA] --->[A]

      result.setPinPassFail(pinlist[j],isPass,siteNumber);
      result.setPinsValue(pinlist[j],dMeasValue,siteNumber);
    }
    break;
  case TM::PPF:
    for ( j = 0; j < pinlist.size(); j++ )
    {
      isPass = measurePmu.getPassFail(pinlist[j]);
      result.setPinPassFail(pinlist[j],isPass,siteNumber);
    }
    break;
  case TM::GPF:
      isPass = measurePmu.getPassFail();
      result.setGlobalPassFail(isPass,siteNumber);
    break;
  default:
    throw Error("LeakageTestUtil::mcxCurrentMeasurementUpdateTestResult",
                "Unknown Measure Mode",
                "LeakageTestUtil::mcxCurrentMeasurementUpdateTestResult");
  }
}

#endif /* LEAKAGETESTUTIL_HPP_ */
