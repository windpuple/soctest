#ifndef LEAKAGEUTIL_H_
#define LEAKAGEUTIL_H_

#include "LeakageTestUtil.hpp"

typedef LeakageTestUtil::MeasurementResultContainer MeasurementResultContainer;

/***************************************************************************
 *                    leakage test class
 ***************************************************************************
 */
class LeakageTest
{
public:

/*
 *----------------------------------------------------------------------*
 *         test parameters container                                    *
 *----------------------------------------------------------------------*
 */

struct LeakageTestParam
{
  string ppmuUsed;
  // original input parameters
  vector<string> ppmuPinlistVec;
  vector<double> ppmuForceVoltageLowVec; // two kinds of leakage level:low high
  vector<double> ppmuForceVoltageHighVec;
  vector<string> ppmuPrechargeVec;
  vector<double> ppmuPrechargeVoltageLowVec;// two kinds of leakage level: low high
  vector<double> ppmuPrechargeVoltageHighVec;
  vector<double> ppmuSettlingTimeLowVec; // two kinds of leakage level: low high
  vector<double> ppmuSettlingTimeHighVec;
  vector<string> ppmuMeasureModeVec;            // Parallel,Serial
  vector<string> ppmuRelaySwitchModeVec;
  vector<LIMIT>  ppmuLimitLowVec;
  vector<LIMIT>  ppmuLimitHighVec;
  vector<string> ppmuLimitNameLowVec;
  vector<string> ppmuLimitNameHighVec;

  // new generated parameter for convenience
  vector<bool> ppmuIsMeasureLowVec;
  vector<bool> ppmuIsMeasureHighVec;
  vector< vector<string> >  ppmuExpandedPinsVec;    // expanded and validated pins stored in Vector
  vector<bool> ppmuIsHVPinsVec;  //true if pins in the list are all HV pins
  
  bool ppmuMeasureLow;
  bool ppmuMeasureHigh;
  bool isPPMULimitAppliedForAllGroups;

  string spmuUsed;
  // original input parameters
  vector<string> spmuPinlistVec;
  vector<double> spmuForceVoltageLowVec; // two kinds of leakage level:low high
  vector<double> spmuForceVoltageHighVec;
  vector<string> spmuPrechargeVec;
  vector<double> spmuPrechargeVoltageLowVec;// two kinds of leakage level: low high
  vector<double> spmuPrechargeVoltageHighVec;
  vector<double> spmuClampCurrentLowVec;
  vector<double> spmuClampCurrentHighVec;
  vector<double> spmuSettlingTimeLowVec; // two kinds of leakage level: low high
  vector<double> spmuSettlingTimeHighVec;
  vector<string> spmuMeasureModeVec;            // Parallel,Serial
  vector<string> spmuRelaySwitchModeVec;
  vector<LIMIT>  spmuLimitLowVec;
  vector<LIMIT>  spmuLimitHighVec;
  vector<string> spmuLimitNameLowVec;
  vector<string> spmuLimitNameHighVec;

  // new generated parameter for convenience
  vector<bool> spmuIsMeasureLowVec;
  vector<bool> spmuIsMeasureHighVec;
  vector< vector<string> >  spmuExpandedPinsVec;    // expanded and validated pins stored in Vector
  
  bool spmuMeasureLow;
  bool spmuMeasureHigh;
  bool isSPMULimitAppliedForAllGroups;

  string mcxUsed;
  // original input parameters
  vector<string> mcxPinlistVec;
  vector<double> mcxForceVoltageLowVec; // two kinds of leakage level:low high
  vector<double> mcxForceVoltageHighVec;
  vector<string> mcxPrechargeVec;
  vector<double> mcxPrechargeVoltageLowVec;// two kinds of leakage level: low high
  vector<double> mcxPrechargeVoltageHighVec;
  vector<double> mcxSettlingTimeLowVec; // two kinds of leakage level: low high
  vector<double> mcxSettlingTimeHighVec;
  vector<string> mcxMeasureModeVec;            // Parallel,Serial
  vector<LIMIT>  mcxLimitLowVec;
  vector<LIMIT>  mcxLimitHighVec;
  vector<string> mcxLimitNameLowVec;
  vector<string> mcxLimitNameHighVec;

  // new generated parameter for convenience
  vector<bool> mcxIsMeasureLowVec;
  vector<bool> mcxIsMeasureHighVec;
  vector< vector<string> >  mcxExpandedPinsVec;    // expanded and validated pins stored in Vector
  
  bool mcxMeasureLow;
  bool mcxMeasureHigh;
  bool isMCXLimitAppliedForAllGroups;

  string dcScaleSIGUsed;
  // original input parameters
  vector<string> dcScaleSIGPinlistVec;
  vector<double> dcScaleSIGForceVoltageLowVec; // two kinds of leakage level:low high
  vector<double> dcScaleSIGForceVoltageHighVec;
  vector<string> dcScaleSIGPrechargeVec;
  vector<double> dcScaleSIGPrechargeVoltageLowVec;// two kinds of leakage level: low high
  vector<double> dcScaleSIGPrechargeVoltageHighVec;
  vector<double> dcScaleSIGClampCurrentLowVec;
  vector<double> dcScaleSIGClampCurrentHighVec;
  vector<double> dcScaleSIGSettlingTimeLowVec; // two kinds of leakage level: low high
  vector<double> dcScaleSIGSettlingTimeHighVec;
  vector<string> dcScaleSIGMeasureModeVec;            // Parallel,Serial
  vector<string> dcScaleSIGRelaySwitchModeVec;
  vector<LIMIT>  dcScaleSIGLimitLowVec;
  vector<LIMIT>  dcScaleSIGLimitHighVec;
  vector<string> dcScaleSIGLimitNameLowVec;
  vector<string> dcScaleSIGLimitNameHighVec;

  // new generated parameter for convenience
  vector<bool> dcScaleSIGIsMeasureLowVec;
  vector<bool> dcScaleSIGIsMeasureHighVec;
  vector< vector<string> >  dcScaleSIGExpandedPinsVec; // expanded and validated pins stored in Vector
  
  bool dcScaleSIGMeasureLow;
  bool dcScaleSIGMeasureHigh;
  bool isDCScaleSIGLimitAppliedForAllGroups;

  string preFunction;
  int stopVec[2];
  int stopCyc[2];
  string lowPortName;
  string highPortName;
  string checkFunctionalResult;

  // new generated parameter for convenience
  string testsuiteName;   // current testsuite name
  TM::DCTEST_MODE testMode;
  
  bool isLimitTableUsed;// if limit table is used
  
  bool measureLow;
  bool measureHigh;

  void init()
  {
    ppmuUsed = "";
    ppmuPinlistVec.clear();
    ppmuForceVoltageLowVec.clear();
    ppmuForceVoltageHighVec.clear();
    ppmuPrechargeVec.clear();
    ppmuPrechargeVoltageLowVec.clear();
    ppmuPrechargeVoltageHighVec.clear();
    ppmuSettlingTimeLowVec.clear();
    ppmuSettlingTimeHighVec.clear();
    ppmuMeasureModeVec.clear();
    ppmuRelaySwitchModeVec.clear();
    ppmuLimitLowVec.clear();
    ppmuLimitHighVec.clear();
    ppmuLimitNameLowVec.clear();
    ppmuLimitNameHighVec.clear();
    ppmuIsMeasureLowVec.clear();
    ppmuIsMeasureHighVec.clear();
    ppmuExpandedPinsVec.clear();
    ppmuIsHVPinsVec.clear();

    spmuUsed = "";
    spmuPinlistVec.clear();
    spmuForceVoltageLowVec.clear();
    spmuForceVoltageHighVec.clear();
    spmuPrechargeVec.clear();
    spmuPrechargeVoltageLowVec.clear();
    spmuPrechargeVoltageHighVec.clear();
    spmuClampCurrentLowVec.clear();
    spmuClampCurrentHighVec.clear();
    spmuSettlingTimeLowVec.clear();
    spmuSettlingTimeHighVec.clear();
    spmuMeasureModeVec.clear();
    spmuRelaySwitchModeVec.clear();
    spmuLimitLowVec.clear();
    spmuLimitHighVec.clear();
    spmuLimitNameLowVec.clear();
    spmuLimitNameHighVec.clear();
    spmuIsMeasureLowVec.clear();
    spmuIsMeasureHighVec.clear();
    spmuExpandedPinsVec.clear();

    mcxUsed = "";
    mcxPinlistVec.clear();
    mcxForceVoltageLowVec.clear();
    mcxForceVoltageHighVec.clear();
    mcxPrechargeVec.clear();
    mcxPrechargeVoltageLowVec.clear();
    mcxPrechargeVoltageHighVec.clear();
    mcxSettlingTimeLowVec.clear();
    mcxSettlingTimeHighVec.clear();
    mcxMeasureModeVec.clear();
    mcxLimitLowVec.clear();
    mcxLimitHighVec.clear();
    mcxLimitNameLowVec.clear();
    mcxLimitNameHighVec.clear();
    mcxIsMeasureLowVec.clear();
    mcxIsMeasureHighVec.clear();
    mcxExpandedPinsVec.clear();

    dcScaleSIGUsed = "";
    dcScaleSIGPinlistVec.clear();
    dcScaleSIGForceVoltageLowVec.clear();
    dcScaleSIGForceVoltageHighVec.clear();
    dcScaleSIGPrechargeVec.clear();
    dcScaleSIGPrechargeVoltageLowVec.clear();
    dcScaleSIGPrechargeVoltageHighVec.clear();
    dcScaleSIGClampCurrentLowVec.clear();
    dcScaleSIGClampCurrentHighVec.clear();
    dcScaleSIGSettlingTimeLowVec.clear();
    dcScaleSIGSettlingTimeHighVec.clear();
    dcScaleSIGMeasureModeVec.clear();
    dcScaleSIGRelaySwitchModeVec.clear();
    dcScaleSIGLimitLowVec.clear();
    dcScaleSIGLimitHighVec.clear();
    dcScaleSIGLimitNameLowVec.clear();
    dcScaleSIGLimitNameHighVec.clear();
    dcScaleSIGIsMeasureLowVec.clear();
    dcScaleSIGIsMeasureHighVec.clear();
    dcScaleSIGExpandedPinsVec.clear();

    ppmuMeasureLow = false;
    ppmuMeasureHigh = false;
    isPPMULimitAppliedForAllGroups = false;

    spmuMeasureLow = false;
    spmuMeasureHigh = false;
    isSPMULimitAppliedForAllGroups = false;

    mcxMeasureLow = false;
    mcxMeasureHigh = false;
    isMCXLimitAppliedForAllGroups = false;

    dcScaleSIGMeasureLow = false;
    dcScaleSIGMeasureHigh = false;
    isDCScaleSIGLimitAppliedForAllGroups = false;

    measureLow = false;
    measureHigh = false;

    testsuiteName = "";
    preFunction = "";
    stopVec[0] = 0;
    stopVec[1] = 1;
    stopCyc[0] = 0;
    stopCyc[1] = 0;
    lowPortName = "";
    highPortName = "";
    checkFunctionalResult = "";
    testMode = TM::GPF;
    isLimitTableUsed = false;
  }

  LeakageTestParam()
  {
    init();
  }
};


/*
 *----------------------------------------------------------------------*
 *         test results container                                       *
 *----------------------------------------------------------------------*
 */
struct LeakageTestResult
{
  vector<MeasurementResultContainer> ppmuMeasureResultLowVec;
  vector<MeasurementResultContainer> ppmuMeasureResultHighVec;

  vector<MeasurementResultContainer> spmuMeasureResultLowVec;
  vector<MeasurementResultContainer> spmuMeasureResultHighVec;

  vector<MeasurementResultContainer> mcxMeasureResultLowVec;
  vector<MeasurementResultContainer> mcxMeasureResultHighVec;

  vector<MeasurementResultContainer> dcScaleSIGMeasureResultLowVec;
  vector<MeasurementResultContainer> dcScaleSIGMeasureResultHighVec;

  bool funcResult[2];   //true: PASS, false: FAIL

  void init()
  {
    ppmuMeasureResultLowVec.clear();
    ppmuMeasureResultHighVec.clear();

    spmuMeasureResultLowVec.clear();
    spmuMeasureResultHighVec.clear();

    mcxMeasureResultLowVec.clear();
    mcxMeasureResultHighVec.clear();

    dcScaleSIGMeasureResultLowVec.clear();
    dcScaleSIGMeasureResultHighVec.clear();

    funcResult[0] = true;
    funcResult[1] = true;
  }

  LeakageTestResult()
  {
    init();
  }
};

/*
 *----------------------------------------------------------------------*
 *         public interfaces of leakage test                            *
 *----------------------------------------------------------------------*
 */

/*
 *----------------------------------------------------------------------*
 * Routine: processParameter
 *
 * Purpose: parse input parameters and setup internal parameters
 *
 *----------------------------------------------------------------------*
 * Description:
 *
 * Note:
 *----------------------------------------------------------------------*
 */
static void processParameters(
    const string& ppmuUsed,
    const string& ppmuPinlist, // ppmu parameters block begin
    const string& ppmuMeasure,
    const string& ppmuForceVoltage_mV,
    const string& ppmuPrecharge,
    const string& ppmuPrechargeVoltage_mV,
    const string& ppmuSettlingTime_ms,
    const string& ppmuMeasureMode,
    const string& ppmuRelaySwitchMode,
    const string& ppmuTestName, // ppmu parameters block end

    const string& spmuUsed,
    const string& spmuPinlist, // spmu parameters block begin
    const string& spmuMeasure,
    const string& spmuForceVoltage_mV,
    const string& spmuPrecharge,
    const string& spmuPrechargeVoltage_mV,
    const string& spmuClampCurrent_uA,
    const string& spmuSettlingTime_ms,
    const string& spmuMeasureMode,
    const string& spmuRelaySwitchMode,
    const string& spmuTestName, // spmu parameters block end

    const string& mcxUsed,
    const string& mcxPinlist, // mcx parameters block begin
    const string& mcxMeasure,
    const string& mcxForceVoltage_mV,
    const string& mcxPrecharge,
    const string& mcxPrechargeVoltage_mV,
    const string& mcxSettlingTime_ms,
    const string& mcxMeasureMode,
    const string& mcxTestName, // mcx parameters block end

    const string& dcScaleSIGUsed,
    const string& dcScaleSIGPinlist, // dc scale pin in SIG mode parameters block begin
    const string& dcScaleSIGMeasure,
    const string& dcScaleSIGForceVoltage_mV,
    const string& dcScaleSIGPrecharge,
    const string& dcScaleSIGPrechargeVoltage_mV,
    const string& dcScaleSIGClampCurrent_uA,
    const string& dcScaleSIGSettlingTime_ms,
    const string& dcScaleSIGMeasureMode,
    const string& dcScaleSIGRelaySwitchMode,
    const string& dcScaleSIGTestName, // dc scale pin in SIG parameters block end

    const string& preFunction,
    const int stopVecLow,
    const int stopVecHigh,
    const string& stopCycLow,
    const string& stopCycHigh,
    const string& checkFunctionalResult,

    LeakageTestParam& param)
{
  // initial parameters
  param.init();

  // get test mode and test suite name
  GET_TESTSUITE_NAME ( param.testsuiteName );
  param.testMode = LeakageTestUtil::getMode();

  /**
   *this map is used to store the relationship: pin group instrument
   * map< string, pair<string,string> >
   *        |            |        |
   *        |            |        |
   *     pinName     groupName  InstrumentName
   *
   * we use this map to check that whether there are the same pin exist
   * in different groups or not.
   */
  map<string, pair<string, string> > pinAndGroupMap;

  // check whether limit table is used.
  TesttableLimitHelper testtableHelper(param.testsuiteName);

  string tempString = LeakageTestUtil::trim(ppmuUsed);
  if("YES" == tempString || "NO" == tempString )
  {
    param.ppmuUsed = tempString;
  }
  else
  {
    throw Error("LeakageTest::processParameters()",
                "UsePPMU must be YES or NO",
                "LeakageTest::processParameters()");
  }

  tempString = LeakageTestUtil::trim(spmuUsed);
  if("YES" == tempString || "NO" == tempString )
  {
    param.spmuUsed = tempString;
  }
  else
  {
    throw Error("LeakageTest::processParameters()",
                "UseSPMU must be YES or NO",
                "LeakageTest::processParameters()");
  }

  tempString = LeakageTestUtil::trim(mcxUsed);
  if("YES" == tempString || "NO" == tempString )
  {
    param.mcxUsed = tempString;
  }
  else
  {
    throw Error("LeakageTest::processParameters()",
                "UseMCX-PMU must be YES or NO",
                "LeakageTest::processParameters()");
  }

  tempString = LeakageTestUtil::trim(dcScaleSIGUsed);
  if("YES" == tempString || "NO" == tempString )
  {
    param.dcScaleSIGUsed = tempString;
  }
  else
  {
    throw Error("LeakageTest::processParameters()",
                "UseDCScaleSIG must be YES or NO",
                "LeakageTest::processParameters()");
  }


  if("YES" == param.ppmuUsed)
  {
    vector<string> ppmuMeasureVec;
    vector<string> ppmuForceVoltageVec;
    vector<string> ppmuPrechargeVoltageVec;
    vector<string> ppmuSettlingTimeVec;
    vector<string> ppmuTestNameVec;

    LeakageTestUtil::parseListOfString(ppmuPinlist,param.ppmuPinlistVec);
    LeakageTestUtil::parseListOfString(ppmuMeasure,ppmuMeasureVec);
    LeakageTestUtil::parseListOfString(ppmuForceVoltage_mV,
                                       ppmuForceVoltageVec,
                                       ',',
                                       true);
    LeakageTestUtil::parseListOfString(ppmuPrecharge,param.ppmuPrechargeVec);
    LeakageTestUtil::parseListOfString(ppmuPrechargeVoltage_mV,
                                       ppmuPrechargeVoltageVec,
                                       ',',
                                       true);
    LeakageTestUtil::parseListOfString(ppmuSettlingTime_ms,
                                       ppmuSettlingTimeVec,
                                       ',',
                                       true);
    LeakageTestUtil::parseListOfString(ppmuTestName,
                                       ppmuTestNameVec,
                                       ',',
                                       true);
    LeakageTestUtil::parseListOfString(ppmuMeasureMode,param.ppmuMeasureModeVec);
    LeakageTestUtil::parseListOfString(ppmuRelaySwitchMode,param.ppmuRelaySwitchModeVec);

    vector<string>::size_type groupSize = param.ppmuPinlistVec.size();
    if(groupSize == 0)
    {
      throw Error("LeakageTest::processParameters()",
                  "PPMU: the pinlist groups can not be empty.",
                  "LeakageTest::processParameters()");
    }

    LeakageTestUtil::checkParameter(groupSize,
                                    ppmuMeasureVec.size(),
                                    "PPMU",
                                    "measure",
                                    ppmuMeasureVec);
    LeakageTestUtil::checkParameter(groupSize,
                                    ppmuForceVoltageVec.size(),
                                    "PPMU",
                                    "forceVoltage_mV",
                                    ppmuForceVoltageVec);
    LeakageTestUtil::checkParameter(groupSize,
                                    param.ppmuPrechargeVec.size(),
                                    "PPMU",
                                    "precharge",
                                    param.ppmuPrechargeVec);
    LeakageTestUtil::checkParameter(groupSize,
                                    ppmuPrechargeVoltageVec.size(),
                                    "PPMU",
                                    "prechargeVoltage_mV",
                                    ppmuPrechargeVoltageVec);
    LeakageTestUtil::checkParameter(groupSize,
                                    ppmuSettlingTimeVec.size(),
                                    "PPMU",
                                    "settlingTime_ms",
                                    ppmuSettlingTimeVec);
    LeakageTestUtil::checkParameter(groupSize,
                                    param.ppmuMeasureModeVec.size(),
                                    "PPMU",
                                    "measureMode",
                                    param.ppmuMeasureModeVec);
    LeakageTestUtil::checkParameter(groupSize,
                                    param.ppmuRelaySwitchModeVec.size(),
                                    "PPMU",
                                    "relaySwitchMode",
                                    param.ppmuRelaySwitchModeVec);

    if(param.ppmuPinlistVec.size() != ppmuTestNameVec.size())
    {
      if(ppmuTestNameVec.size() != 1)
      {
        stringstream errMsg;
        errMsg <<"PPMU: the number of pinlist groups is "
               << param.ppmuPinlistVec.size() <<endl
               <<"      the number of testName groups is "
               << ppmuTestNameVec.size() <<endl
               <<"So the testName groups don't match pinlist groups." <<endl;
        throw Error("LeakageTest::processParameters()",
                    errMsg.str(),
                    "LeakageTest::processParameters()");
      }
      else
      {
        param.isPPMULimitAppliedForAllGroups = true;
        for(vector<string>::size_type i = 1; i < param.ppmuPinlistVec.size(); i++)
        {
          ppmuTestNameVec.push_back(ppmuTestNameVec[0]);
        }
      }
    }

    // the following three variables is used for checking duplicate pins
    pair<map<string, pair<string, string> >::iterator, bool> ret;
    pair<string, string> groupAndInstrument;
    const string instrumentType = "PPMUInstrument";

    // the following variables are used to store HV pins
    vector<long unsigned int>  ppmuHvPinIndexlist;
    vector<vector<string> > ppmuHvExpandedPinsVec;

    ppmuHvPinIndexlist.clear();
    ppmuHvExpandedPinsVec.clear();
    param.ppmuIsHVPinsVec.resize(param.ppmuPinlistVec.size());

    for(vector<string>::size_type  i = 0; i< param.ppmuPinlistVec.size(); i++)
    {
      param.ppmuIsHVPinsVec[i] = false;
      bool isThisGroupNotCommented = ('#' != param.ppmuPinlistVec[i][0]);
      vector<string> expandedPins;
      if(isThisGroupNotCommented)
      {
        expandedPins = PinUtility.getDigitalPinNamesFromPinList(
                                         (param.ppmuPinlistVec)[i],
                                         TM::I_PIN|TM::O_PIN|TM::IO_PIN,
                                         true,true);
        // For checking HV pins
        vector<string> hvPins, nonHvPins;
        hvPins.clear();
        nonHvPins.clear();

        // check the duplicate pins
        for (vector<string>::size_type index = 0; index < expandedPins.size(); index++)
        {
          groupAndInstrument = make_pair(param.ppmuPinlistVec[i], instrumentType);
          ret = pinAndGroupMap.insert(make_pair(expandedPins[index], groupAndInstrument));
          if (!ret.second)
          {
            stringstream errMsg;
            errMsg << "In the PPMUInstrument group: " << param.ppmuPinlistVec[i]<< endl
                   << "   and " << ret.first->second.second << " group: "
                   << ret.first->second.first << endl
                   << "There are the same pin: "
                   << expandedPins[index] << endl;
            throw Error("LeakageTest::processParameters",
                        errMsg.str(),
                        "LeakageTest::processParameters");
          }

          if (LeakageTestUtil::isHighVoltagePin(expandedPins[index]))
          {
            hvPins.push_back(expandedPins[index]);
          }
          else
          {
            nonHvPins.push_back(expandedPins[index]);
          }
        }

        if (hvPins.size() == expandedPins.size())
        {
          param.ppmuIsHVPinsVec[i] = true;
        }
        else if (hvPins.size() == 0)
        {
          param.ppmuIsHVPinsVec[i] = false;
        }
        else if (hvPins.size() > 0 && hvPins.size() < expandedPins.size())
        {
          //adapt current pins
          param.ppmuIsHVPinsVec[i] = false;
          expandedPins = nonHvPins;
          param.ppmuPinlistVec[i] = PinUtility.createPinListFromPinNames(nonHvPins);

          //remember the new one
          ppmuHvPinIndexlist.push_back(i);
          ppmuHvExpandedPinsVec.push_back(hvPins);
        }
      }
      (param.ppmuExpandedPinsVec).push_back(expandedPins );
    }

    // create the new pinlist and its test properties
    if (ppmuHvPinIndexlist.size() > 0)
    {
      vector<string> tmpPinlistVec, tmpMeasureVec, tmpForceVoltageVec,
                     tmpPreChargeVec, tmpPreChargeVoltageVec, tmpSettlingTimeVec,
                     tmpMeasureMode, tmpRelaySwitchMode,tmpTestNameVec;
      vector<vector<string> >tmpExpandedPinsVec;
      vector<bool> tmpIsHVPinsVec;
      for(vector<string>::size_type  i = 0; i< param.ppmuPinlistVec.size(); i++)
      {
        tmpPinlistVec.push_back(param.ppmuPinlistVec[i]);
        tmpMeasureVec.push_back(ppmuMeasureVec[i]);
        tmpForceVoltageVec.push_back(ppmuForceVoltageVec[i]);
        tmpPreChargeVec.push_back(param.ppmuPrechargeVec[i]);
        tmpPreChargeVoltageVec.push_back(ppmuPrechargeVoltageVec[i]);
        tmpSettlingTimeVec.push_back(ppmuSettlingTimeVec[i]);
        tmpMeasureMode.push_back(param.ppmuMeasureModeVec[i]);
        tmpRelaySwitchMode.push_back(param.ppmuRelaySwitchModeVec[i]);
        tmpTestNameVec.push_back(ppmuTestNameVec[i]);
        tmpExpandedPinsVec.push_back(param.ppmuExpandedPinsVec[i]);
        tmpIsHVPinsVec.push_back(param.ppmuIsHVPinsVec[i]);

        vector<long unsigned int>::iterator it = find(ppmuHvPinIndexlist.begin(), ppmuHvPinIndexlist.end(), i);
        if (it != ppmuHvPinIndexlist.end())
        {
          long unsigned int index = it - ppmuHvPinIndexlist.begin();
          tmpPinlistVec.push_back(PinUtility.createPinListFromPinNames(ppmuHvExpandedPinsVec[index]));
          tmpMeasureVec.push_back(ppmuMeasureVec[i]);
          tmpForceVoltageVec.push_back(ppmuForceVoltageVec[i]);
          tmpPreChargeVec.push_back(param.ppmuPrechargeVec[i]);
          tmpPreChargeVoltageVec.push_back(ppmuPrechargeVoltageVec[i]);
          tmpSettlingTimeVec.push_back(ppmuSettlingTimeVec[i]);
          tmpMeasureMode.push_back(param.ppmuMeasureModeVec[i]);
          tmpRelaySwitchMode.push_back(param.ppmuRelaySwitchModeVec[i]);
          tmpTestNameVec.push_back(ppmuTestNameVec[i]);
          tmpExpandedPinsVec.push_back(ppmuHvExpandedPinsVec[index]);
          tmpIsHVPinsVec.push_back(true);
        }
      }

      param.ppmuPinlistVec.swap(tmpPinlistVec);
      ppmuMeasureVec.swap(tmpMeasureVec);
      ppmuForceVoltageVec.swap(tmpForceVoltageVec);
      param.ppmuPrechargeVec.swap(tmpPreChargeVec);
      ppmuPrechargeVoltageVec.swap(tmpPreChargeVoltageVec);
      ppmuSettlingTimeVec.swap(tmpSettlingTimeVec);
      param.ppmuMeasureModeVec.swap(tmpMeasureMode);
      param.ppmuRelaySwitchModeVec.swap(tmpRelaySwitchMode);
      ppmuTestNameVec.swap(tmpTestNameVec);
      param.ppmuExpandedPinsVec.swap(tmpExpandedPinsVec);
      param.ppmuIsHVPinsVec.swap(tmpIsHVPinsVec);
    }

    for(vector<string>::size_type  i = 0; i< param.ppmuPinlistVec.size(); i++)
    {
      bool isThisGroupNotCommented = ('#' != param.ppmuPinlistVec[i][0]);

      if(param.ppmuMeasureModeVec[i] != "PAR" &&
         param.ppmuMeasureModeVec[i] != "SER")
      {
        stringstream errMsg;
        errMsg <<"PPMU: for the " << i+1 << " group setup parameter, measureMode: "
               <<param.ppmuMeasureModeVec[i] << " is invalid."<<endl
               <<"measureMode can only be the following options: PAR  SER" <<endl;
        throw Error("LeakageTest::processParamters()",
                    errMsg.str(),
                    "LeakageTest::processParamters()");
      }
      if(param.ppmuPrechargeVec[i] != "ON" &&
         param.ppmuPrechargeVec[i] != "OFF")
      {
        stringstream errMsg;
        errMsg <<"PPMU: for the " << i+1 << " group setup parameter, precharge: "
               <<param.ppmuPrechargeVec[i] << " is invalid."<<endl
               <<"precharge can only be the following options: ON  OFF" <<endl;
        throw Error("LeakageTest::processParamters()",
                    errMsg.str(),
                    "LeakageTest::processParamters()");
      }
      if(param.ppmuRelaySwitchModeVec[i] != "DEFAULT(BBM)" &&
         param.ppmuRelaySwitchModeVec[i] != "MBB"          &&
         param.ppmuRelaySwitchModeVec[i] != "PARALLEL")
      {
        stringstream errMsg;
        errMsg <<"PPMU: for the " << i+1 << " group setup parameter, relaySwitchMode: "
               <<param.ppmuRelaySwitchModeVec[i] << " is invalid."<<endl
               <<"relaySwitchMode can only be the following options: DEFAULT(BBM) MBB PARALLEL" <<endl;
        throw Error("LeakageTest::processParamters()",
                    errMsg.str(),
                    "LeakageTest::processParamters()");
      }

      bool isPrecharge = (param.ppmuPrechargeVec)[i] == "ON";

      LIMIT limitLow,limitHigh;
      (param.ppmuIsMeasureLowVec).push_back(false);
      (param.ppmuForceVoltageLowVec).push_back(0.0);
      (param.ppmuSettlingTimeLowVec).push_back(0.0);
      (param.ppmuPrechargeVoltageLowVec).push_back(0.0);
      (param.ppmuIsMeasureHighVec).push_back(false);
      (param.ppmuForceVoltageHighVec).push_back(0.0);
      (param.ppmuSettlingTimeHighVec).push_back(0.0);
      (param.ppmuPrechargeVoltageHighVec).push_back(0.0);
      (param.ppmuLimitLowVec).push_back(limitLow);
      (param.ppmuLimitHighVec).push_back(limitHigh);
      (param.ppmuLimitNameLowVec).push_back("");
      (param.ppmuLimitNameHighVec).push_back("");

      string measureString = ppmuMeasureVec[i];
      if(isThisGroupNotCommented &&
         ("LOW" == measureString ||
          "Low" == measureString ||
          "low" == measureString) )
      {
        param.ppmuMeasureLow = true;
        param.measureLow = true;
        (param.ppmuIsMeasureLowVec)[i] = true;
        (param.ppmuForceVoltageLowVec)[i]
                 = LeakageTestUtil::string2Double(ppmuForceVoltageVec[i],"ppmuForceVoltage_mV");

        (param.ppmuSettlingTimeLowVec)[i]
              = LeakageTestUtil::string2Double(ppmuSettlingTimeVec[i],"ppmuSettlingTime_ms");

        if(isPrecharge)
        {
          (param.ppmuPrechargeVoltageLowVec)[i]
                = LeakageTestUtil::string2Double(ppmuPrechargeVoltageVec[i],"ppmuPrechargeVoltage_mV");
        }

        param.ppmuLimitNameLowVec[i] = ppmuTestNameVec[i];
        LeakageTestUtil::getLimitInfo(ppmuTestNameVec[i],i,
                                      param.ppmuLimitLowVec[i],
                                      testtableHelper);
      }
      else if(isThisGroupNotCommented &&
              ("HIGH" == measureString ||
               "High" == measureString ||
               "high" == measureString) )
      {
        param.ppmuMeasureHigh = true;
        param.measureHigh = true;
        (param.ppmuIsMeasureHighVec)[i] = true;
        (param.ppmuForceVoltageHighVec)[i]
                 = LeakageTestUtil::string2Double(ppmuForceVoltageVec[i],"ppmuForceVoltage_mV");

        (param.ppmuSettlingTimeHighVec)[i]
              = LeakageTestUtil::string2Double(ppmuSettlingTimeVec[i],"ppmuSettlingTime_ms");

        if(isPrecharge)
        {
          (param.ppmuPrechargeVoltageHighVec)[i]
                = LeakageTestUtil::string2Double(ppmuPrechargeVoltageVec[i],"ppmuPrechargeVoltage_mV");
        }

        param.ppmuLimitNameHighVec[i] = ppmuTestNameVec[i];
        LeakageTestUtil::getLimitInfo(ppmuTestNameVec[i],i,
                                      param.ppmuLimitHighVec[i],
                                      testtableHelper);
      }
      else if (isThisGroupNotCommented &&
               ("BOTH" == measureString ||
                "Both" == measureString ||
                "both" == measureString) )
      {
        vector<double> forceVoltageVec;
        vector<double> prechargeVoltageVec;
        vector<double> settlingTimeVec;
        vector<string> limitVec;

        // parse forceVoltage_mV and check the format
        LeakageTestUtil::parseListOfDouble(ppmuForceVoltageVec[i],forceVoltageVec);
        if(2 != forceVoltageVec.size())
        {
          stringstream errMsg;
          errMsg <<"PPMU: the input of forceVoltage_mV for the " << i+1
                 <<" group's format is not correct!"<<endl
                 <<"      Now the measure is for both,"
                 <<"so the input format is like: (400,3800)"<<endl;
          throw Error("LeakageTest::processParameters()",
                      errMsg.str(),
                      "LeakageTest::processParameters()");
        }

        // parse prechargeVoltage_mv and check the format
        if(isPrecharge)
        {
          LeakageTestUtil::parseListOfDouble(ppmuPrechargeVoltageVec[i], prechargeVoltageVec);
          if(2 != prechargeVoltageVec.size())
          {
            stringstream errMsg;
            errMsg <<"PPMU: the input of prechargeVoltage_mV for the " << i+1
                   <<" group's format is not correct!"<<endl
                   <<"      Now the measure is for both,"
                   <<"so the input format is like: (400,3800)"<<endl;
            throw Error("LeakageTest::processParameters()",
                        errMsg.str(),
                        "LeakageTest::processParameters()");
          }
        }

        // parse settlingTime_ms and check the format
        LeakageTestUtil::parseListOfDouble(ppmuSettlingTimeVec[i],settlingTimeVec);
        if(2 != settlingTimeVec.size())
        {
          stringstream errMsg;
          errMsg <<"PPMU: the input of settlingTime_ms for the " << i+1
                 <<" group's format is not correct!"<<endl
                 <<"      Now the measure is for both,"
                 <<"so the input format is like: (1.5,1.2)"<<endl;
          throw Error("LeakageTest::processParameters()",
                      errMsg.str(),
                      "LeakageTest::processParameters()");
        }

        // parse testName and check the format
        LeakageTestUtil::parseListOfString(ppmuTestNameVec[i],limitVec);

        if(2 != limitVec.size())
        {
          stringstream errMsg;
          errMsg <<"PPMU: the input of testName for the " << i+1
                 <<" group's format is not correct!"<<endl
                 <<"      Now the measure is for both,"
                 <<"so the input format is like: (limitNameLow,limitNameHigh)"<<endl;
          throw Error("LeakageTest::processParameters()",
                      errMsg.str(),
                      "LeakageTest::processParameters()");
        }

        (param.ppmuIsMeasureLowVec)[i] = true;      // the low level measurement will be done
        param.ppmuMeasureLow = true;
        param.measureLow = true;
        (param.ppmuForceVoltageLowVec)[i] = forceVoltageVec[0];
        (param.ppmuSettlingTimeLowVec)[i] = settlingTimeVec[0];
        if(isPrecharge)
        {
          (param.ppmuPrechargeVoltageLowVec)[i] =  prechargeVoltageVec[0];
          (param.ppmuPrechargeVoltageHighVec)[i] = prechargeVoltageVec[1];
        }

        param.ppmuLimitNameLowVec[i] = limitVec[0];
        param.ppmuLimitNameHighVec[i] = limitVec[1];

        LeakageTestUtil::getLimitInfo(limitVec[0],i,
                                      param.ppmuLimitLowVec[i],
                                      testtableHelper);
        LeakageTestUtil::getLimitInfo(limitVec[1],i,
                                      param.ppmuLimitHighVec[i],
                                      testtableHelper);

        (param.ppmuIsMeasureHighVec)[i] = true;    // the high level measurement will be done
        param.ppmuMeasureHigh = true;
        param.measureHigh = true;
        (param.ppmuForceVoltageHighVec)[i] = forceVoltageVec[1];
        (param.ppmuSettlingTimeHighVec)[i] = settlingTimeVec[1];
      }
      else if(isThisGroupNotCommented)
      {
        stringstream errMsg;
        errMsg <<"PPMU: for the " << i+1 << " group setup parameter, measure: "
               <<measureString << " is invalid."<<endl
               <<"measure can only be the following options:" <<endl
               <<"LOW HIGH BOTH" <<endl;
        throw Error("LeakageTest::processParamters()",
                    errMsg.str(),
                    "LeakageTest::processParamters()");
      }
    }
  }

  if("YES" == param.spmuUsed)
  {
    vector<string> spmuMeasureVec;
    vector<string> spmuForceVoltageVec;
    vector<string> spmuPrechargeVoltageVec;
    vector<string> spmuClampCurrentVec;
    vector<string> spmuSettlingTimeVec;
    vector<string> spmuTestNameVec;

    LeakageTestUtil::parseListOfString(spmuPinlist,param.spmuPinlistVec);
    LeakageTestUtil::parseListOfString(spmuMeasure,spmuMeasureVec);
    LeakageTestUtil::parseListOfString(spmuForceVoltage_mV,
                                       spmuForceVoltageVec,
                                       ',',
                                       true);
    LeakageTestUtil::parseListOfString(spmuPrecharge,param.spmuPrechargeVec);
    LeakageTestUtil::parseListOfString(spmuPrechargeVoltage_mV,
                                       spmuPrechargeVoltageVec,
                                       ',',
                                       true);
    LeakageTestUtil::parseListOfString(spmuClampCurrent_uA,
                                       spmuClampCurrentVec,
                                       ',',
                                       true);
    LeakageTestUtil::parseListOfString(spmuSettlingTime_ms,
                                       spmuSettlingTimeVec,
                                       ',',
                                       true);
    LeakageTestUtil::parseListOfString(spmuTestName,
                                       spmuTestNameVec,
                                       ',',
                                       true);
    LeakageTestUtil::parseListOfString(spmuMeasureMode,param.spmuMeasureModeVec);
    LeakageTestUtil::parseListOfString(spmuRelaySwitchMode,param.spmuRelaySwitchModeVec);

    vector<string>::size_type groupSize = param.spmuPinlistVec.size();
    if(groupSize == 0)
    {
      throw Error("LeakageTest::processParameters()",
                  "SPMU: the pinlist groups can not be empty.",
                  "LeakageTest::processParameters()");
    }

    LeakageTestUtil::checkParameter(groupSize,
                                    spmuMeasureVec.size(),
                                    "SPMU",
                                    "measure",
                                    spmuMeasureVec);
    LeakageTestUtil::checkParameter(groupSize,
                                    spmuForceVoltageVec.size(),
                                    "SPMU",
                                    "forceVoltage_mV",
                                    spmuForceVoltageVec);
    LeakageTestUtil::checkParameter(groupSize,
                                    param.spmuPrechargeVec.size(),
                                    "SPMU",
                                    "precharge",
                                    param.spmuPrechargeVec);
    LeakageTestUtil::checkParameter(groupSize,
                                    spmuPrechargeVoltageVec.size(),
                                    "SPMU",
                                    "prechargeVoltage_mV",
                                    spmuPrechargeVoltageVec);
    LeakageTestUtil::checkParameter(groupSize,
                                    spmuClampCurrentVec.size(),
                                    "SPMU",
                                    "clampCurrent_uA",
                                    spmuClampCurrentVec);
    LeakageTestUtil::checkParameter(groupSize,
                                    spmuSettlingTimeVec.size(),
                                    "SPMU",
                                    "settlingTime_ms",
                                    spmuSettlingTimeVec);
    LeakageTestUtil::checkParameter(groupSize,
                                    param.spmuMeasureModeVec.size(),
                                    "SPMU",
                                    "measureMode",
                                    param.spmuMeasureModeVec);
    LeakageTestUtil::checkParameter(groupSize,
                                    param.spmuRelaySwitchModeVec.size(),
                                    "SPMU",
                                    "relaySwitchMode",
                                    param.spmuRelaySwitchModeVec);

    if(param.spmuPinlistVec.size() != spmuTestNameVec.size())
    {
      if(spmuTestNameVec.size() != 1)
      {
        stringstream errMsg;
        errMsg <<"SPMU: the number of pinlist groups is "
               << param.spmuPinlistVec.size() <<endl
               <<"      the number of testName groups is "
               << spmuTestNameVec.size() <<endl
               <<"So the testName groups don't match pinlist groups." <<endl;
        throw Error("LeakageTest::processParamters()",
                    errMsg.str(),
                    "LeakageTest::processParamters()");
      }
      else
      {
        param.isSPMULimitAppliedForAllGroups = true;
        for(vector<string>::size_type i = 1; i < param.spmuPinlistVec.size(); i++)
        {
          spmuTestNameVec.push_back(spmuTestNameVec[0]);
        }
      }
    }

    // the following three variables is used for checking duplicate pins
    pair<map<string, pair<string, string> >::iterator, bool> ret;
    pair<string, string> groupAndInstrument;
    const string instrumentType = "SPMUInstrument";
    for(vector<string>::size_type i = 0; i< param.spmuPinlistVec.size(); i++)
    {
      bool isThisGroupNotCommented = ('#' != param.spmuPinlistVec[i][0]);
      vector<string>  expandedPins;
      if(isThisGroupNotCommented)
      {
        expandedPins = PinUtility.getDigitalPinNamesFromPinList(
            param.spmuPinlistVec[i],
            TM::ALL_DIGITAL,true,true);
        // check the duplicate pins
        for (vector<string>::size_type index = 0; index < expandedPins.size(); index++)
        {
          //HV pin cann't perform spmu test
          if (LeakageTestUtil::isHighVoltagePin(expandedPins[index]))
          {
            stringstream errMsg;
            errMsg << "In the SPMUInstrument group: "
                   << param.spmuPinlistVec[i] << endl
                   << "There is high voltage pin: "
                   << expandedPins[index] << endl;
            throw Error("LeakageTest::processParameters",
                        errMsg.str(),
                        "LeakageTest::processParameters");
          }

          groupAndInstrument = make_pair(param.spmuPinlistVec[i], instrumentType);
          ret = pinAndGroupMap.insert(make_pair(expandedPins[index], groupAndInstrument));
          if (!ret.second)
          {
            stringstream errMsg;
            errMsg << "In the SPMUInstrument group: " << param.spmuPinlistVec[i] << endl
                   << "   and " << ret.first->second.second << " group: "
                   << ret.first->second.first << endl
                   << "There are the same pin: "
                   << expandedPins[index] << endl;
            throw Error("LeakageTest::processParameters",
                        errMsg.str(),
                        "LeakageTest::processParameters");
          }
        }
      }
      param.spmuExpandedPinsVec.push_back(expandedPins);

      if("ON" != param.spmuPrechargeVec[i] &&
         "OFF" != param.spmuPrechargeVec[i])
      {
        stringstream errMsg;
        errMsg <<"SPMU: for the " << i+1 << " group setup parameter, precharge: "
               <<param.spmuPrechargeVec[i] << " is invalid."<<endl
               <<"precharge can only be the following options: ON  OFF" <<endl;
        throw Error("LeakageTest::processParamters()",
                    errMsg.str(),
                    "LeakageTest::processParamters()");
      }

      if("PAR" != param.spmuMeasureModeVec[i] &&
         "SER" != param.spmuMeasureModeVec[i])
      {
        stringstream errMsg;
        errMsg <<"SPMU: for the " << i+1 << " group setup parameter, measureMode: "
               <<param.spmuMeasureModeVec[i] << " is invalid."<<endl
               <<"measureMode can only be the following options: PAR  SER" <<endl;
        throw Error("LeakageTest::processParamters()",
                    errMsg.str(),
                    "LeakageTest::processParamters()");
      }

      if("NTBBM" != param.spmuRelaySwitchModeVec[i] &&
         "NTMBB" != param.spmuRelaySwitchModeVec[i])
      {
        stringstream errMsg;
        errMsg <<"SPMU: for the " << i+1 << " group setup parameter, relaySwitchMode: "
               <<param.spmuRelaySwitchModeVec[i] << " is invalid."<<endl
               <<"relaySwitchMode can only be the following options: NTBBM  NTMBB" <<endl;
        throw Error("LeakageTest::processParamters()",
                    errMsg.str(),
                    "LeakageTest::processParamters()");
      }

      bool isPrecharge = ("ON" == param.spmuPrechargeVec[i]);

      LIMIT limitLow,limitHigh;
      (param.spmuIsMeasureLowVec).push_back(false);
      (param.spmuForceVoltageLowVec).push_back(0.0);
      (param.spmuClampCurrentLowVec).push_back(0.0);
      (param.spmuSettlingTimeLowVec).push_back(0.0);
      (param.spmuPrechargeVoltageLowVec).push_back(0.0);
      (param.spmuIsMeasureHighVec).push_back(false);
      (param.spmuForceVoltageHighVec).push_back(0.0);
      (param.spmuClampCurrentHighVec).push_back(0.0);
      (param.spmuSettlingTimeHighVec).push_back(0.0);
      (param.spmuPrechargeVoltageHighVec).push_back(0.0);
      (param.spmuLimitLowVec).push_back(limitLow);
      (param.spmuLimitHighVec).push_back(limitHigh);
      (param.spmuLimitNameLowVec).push_back("");
      (param.spmuLimitNameHighVec).push_back("");
      
      string measureString = spmuMeasureVec[i];
      if(isThisGroupNotCommented && 
         ("LOW" == measureString ||
          "Low" == measureString ||
          "low" == measureString) )
      {
        param.spmuIsMeasureLowVec[i] = true;
        param.spmuMeasureLow = true;
        param.measureLow = true;
        param.spmuForceVoltageLowVec[i]
                      = LeakageTestUtil::string2Double(spmuForceVoltageVec[i],"spmuForceVoltage_mV");
        param.spmuClampCurrentLowVec[i]
                      = LeakageTestUtil::string2Double(spmuClampCurrentVec[i],"spmuClampCurrent_uA");
        param.spmuSettlingTimeLowVec[i]
                      = LeakageTestUtil::string2Double(spmuSettlingTimeVec[i],"spmuSettlingTime_ms");
        if(isPrecharge)
        {
          param.spmuPrechargeVoltageLowVec[i]
                      = LeakageTestUtil::string2Double(spmuPrechargeVoltageVec[i],"spmuPrechargeVoltage_mV");
        }

        param.spmuLimitNameLowVec[i] = spmuTestNameVec[i];
        LeakageTestUtil::getLimitInfo(spmuTestNameVec[i],i,
                                      param.spmuLimitLowVec[i],
                                      testtableHelper);
      }
      else if(isThisGroupNotCommented &&
              ("HIGH" == measureString ||
               "High" == measureString ||
               "high" == measureString) )
      {
        param.spmuIsMeasureHighVec[i] = true;
        param.spmuMeasureHigh = true;
        param.measureHigh = true;
        param.spmuForceVoltageHighVec[i]
                      = LeakageTestUtil::string2Double(spmuForceVoltageVec[i],"spmuForceVoltage_mV");
        param.spmuClampCurrentHighVec[i]
                      = LeakageTestUtil::string2Double(spmuClampCurrentVec[i],"spmuClampCurrent_uA");
        param.spmuSettlingTimeHighVec[i]
                      = LeakageTestUtil::string2Double(spmuSettlingTimeVec[i],"spmuSettlingTime_ms");
        if(isPrecharge)
        {
          param.spmuPrechargeVoltageHighVec[i]
                      = LeakageTestUtil::string2Double(spmuPrechargeVoltageVec[i],"spmuPrechargeVoltage_mV");
        }

        param.spmuLimitNameHighVec[i] = spmuTestNameVec[i];
        LeakageTestUtil::getLimitInfo(spmuTestNameVec[i],i,
                                      param.spmuLimitHighVec[i],
                                      testtableHelper);
      }
      else if (isThisGroupNotCommented && 
               ("BOTH" == measureString ||
                "Both" == measureString ||
                "both" == measureString) )
      {
        vector<double> forceVoltageVec;
        vector<double> prechargeVoltageVec;
        vector<double> clampCurrentVec;
        vector<double> settlingTimeVec;
        vector<string> limitVec;

        forceVoltageVec.clear();
        prechargeVoltageVec.clear();
        settlingTimeVec.clear();
        limitVec.clear();

        // parse forceVoltage_mV and check the format
        LeakageTestUtil::parseListOfDouble(spmuForceVoltageVec[i],forceVoltageVec);
        if(2 != forceVoltageVec.size())
        {
          stringstream errMsg;
          errMsg <<"SPMU: the input of forceVoltage_mV for the " << i+1
                 <<" group's format is not correct!"<<endl
                 <<"      Now the measure is for both,"
                 <<"so the input format is like: (400,3800)"<<endl;
          throw Error("LeakageTest::processParameters()",
                      errMsg.str(),
                      "LeakageTest::processParameters()");
        }

        // parse prechargeVoltage_mV and check the format
        if(isPrecharge)
        {
          LeakageTestUtil::parseListOfDouble(spmuPrechargeVoltageVec[i],prechargeVoltageVec);
          if(2 != prechargeVoltageVec.size())
          {
            stringstream errMsg;
            errMsg <<"SPMU: the input of prechargeVoltage_mV for the " << i+1
                   <<" group's format is not correct!"<<endl
                   <<"      Now the measure is for both,"
                   <<"so the input format is like: (400,3800)"<<endl;
            throw Error("LeakageTest::processParameters()",
                        errMsg.str(),
                        "LeakageTest::processParameters()");
          }
        }

        //parse clampCurrent_uA and check the format
        LeakageTestUtil::parseListOfDouble(spmuClampCurrentVec[i], clampCurrentVec);
        if(2 != clampCurrentVec.size())
        {
          stringstream errMsg;
          errMsg <<"SPMU: the input of clampCurrent_uA for the " << i+1
                 <<" group's format is not correct!"<<endl
                 <<"      Now the measure is for both,"
                 <<"so the input format is like: (200,700)"<<endl;
          throw Error("LeakageTest::processParameters()",
                      errMsg.str(),
                      "LeakageTest::processParameters()");
        }

        // parse settlingTime_ms and check the format
        LeakageTestUtil::parseListOfDouble(spmuSettlingTimeVec[i], settlingTimeVec);
        if(2 != settlingTimeVec.size())
        {
          stringstream errMsg;
          errMsg <<"SPMU: the input of settlingTime_ms for the " << i+1
                 <<" group's format is not correct!"<<endl
                 <<"      Now the measure is for both,"
                 <<"so the input format is like: (1.5,1.2)"<<endl;
          throw Error("LeakageTest::processParameters()",
                      errMsg.str(),
                      "LeakageTest::processParameters()");
        }

        // parse testName and check the format
        LeakageTestUtil::parseListOfString(spmuTestNameVec[i], limitVec,',');
 
        if(2 != limitVec.size())
        {
          stringstream errMsg;
          errMsg <<"SPMU: the input of testName for the " << i+1
                 <<" group's format is not correct!"<<endl
                 <<"      Now the measure is for both,"
                 <<"so the input format is like: (limitNameLow,limitNameHigh)"<<endl;
          throw Error("LeakageTest::processParameters()",
                      errMsg.str(),
                      "LeakageTest::processParameters()");
        }
        
        param.spmuIsMeasureLowVec[i] = true;
        param.spmuMeasureLow = true;  // the low level measurement will be done
        param.measureLow = true;
        param.spmuForceVoltageLowVec[i] = forceVoltageVec[0];
        param.spmuClampCurrentLowVec[i] = clampCurrentVec[0];
        param.spmuSettlingTimeLowVec[i] = settlingTimeVec[0];
        if(isPrecharge)
        {
          param.spmuPrechargeVoltageLowVec[i] = prechargeVoltageVec[0];
          param.spmuPrechargeVoltageHighVec[i] = prechargeVoltageVec[1];
        }

        param.spmuLimitNameLowVec[i] = limitVec[0];
        param.spmuLimitNameHighVec[i] = limitVec[1];
        LeakageTestUtil::getLimitInfo(limitVec[0],i,
                                      param.spmuLimitLowVec[i],
                                      testtableHelper);
        LeakageTestUtil::getLimitInfo(limitVec[1],i,
                                      param.spmuLimitHighVec[i],
                                      testtableHelper);

        param.spmuIsMeasureHighVec[i] = true;
        param.spmuMeasureHigh = true; // the high level measurement will be done
        param.measureHigh = true;
        param.spmuForceVoltageHighVec[i] = forceVoltageVec[1];
        param.spmuClampCurrentHighVec[i] = clampCurrentVec[1];
        param.spmuSettlingTimeHighVec[i] = settlingTimeVec[1];
      }
      else if(isThisGroupNotCommented)
      {
        stringstream errMsg;
        errMsg <<"SPMU: for the " << i+1 << " group setup parameter, measure: "
               <<measureString << " is invalid."<<endl
               <<"measure can only be the following options:" <<endl
               <<"LOW HIGH BOTH" <<endl;
        throw Error("LeakageTest::processParamters()",
                    errMsg.str(),
                    "LeakageTest::processParamters()");
      }

    }
  }

  if("YES" == param.mcxUsed)
  {
    vector<string> mcxMeasureVec;
    vector<string> mcxForceVoltageVec;
    vector<string> mcxPrechargeVoltageVec;
    vector<string> mcxSettlingTimeVec;
    vector<string> mcxTestNameVec;

    LeakageTestUtil::parseListOfString(mcxPinlist,param.mcxPinlistVec);
    LeakageTestUtil::parseListOfString(mcxMeasure,mcxMeasureVec);
    LeakageTestUtil::parseListOfString(mcxForceVoltage_mV,
                                       mcxForceVoltageVec,
                                       ',',
                                       true);
    LeakageTestUtil::parseListOfString(mcxPrecharge,param.mcxPrechargeVec);
    LeakageTestUtil::parseListOfString(mcxPrechargeVoltage_mV,
                                       mcxPrechargeVoltageVec,
                                       ',',
                                       true);
    LeakageTestUtil::parseListOfString(mcxSettlingTime_ms,
                                       mcxSettlingTimeVec,
                                       ',',
                                       true);
    LeakageTestUtil::parseListOfString(mcxMeasureMode,param.mcxMeasureModeVec);
    LeakageTestUtil::parseListOfString(mcxTestName,
                                       mcxTestNameVec,
                                       ',',
                                       true);

    vector<string>::size_type groupSize = param.mcxPinlistVec.size();
    if(groupSize == 0)
    {
      throw Error("LeakageTest::processParameters()",
                  "MCX-PMU: the pinlist groups can not be empty.",
                  "LeakageTest::processParameters()");
    }

    LeakageTestUtil::checkParameter(groupSize,
                                    mcxMeasureVec.size(),
                                    "MCX-PMU",
                                    "measure",
                                    mcxMeasureVec);
    LeakageTestUtil::checkParameter(groupSize,
                                    mcxForceVoltageVec.size(),
                                    "MCX-PMU",
                                    "forceVoltage_mV",
                                    mcxForceVoltageVec);
    LeakageTestUtil::checkParameter(groupSize,
                                    param.mcxPrechargeVec.size(),
                                    "MCX-PMU",
                                    "precharge",
                                    param.mcxPrechargeVec);
    LeakageTestUtil::checkParameter(groupSize,
                                    mcxPrechargeVoltageVec.size(),
                                    "MCX-PMU",
                                    "prechargeVoltage_mV",
                                    mcxPrechargeVoltageVec);
    LeakageTestUtil::checkParameter(groupSize,
                                    mcxSettlingTimeVec.size(),
                                    "MCX-PMU",
                                    "settlingTime_ms",
                                    mcxSettlingTimeVec);
    LeakageTestUtil::checkParameter(groupSize,
                                    param.mcxMeasureModeVec.size(),
                                    "MCX-PMU",
                                    "measureMode",
                                    param.mcxMeasureModeVec);

    if(param.mcxPinlistVec.size() != mcxTestNameVec.size())
    {
      if(mcxTestNameVec.size() != 1)
      {
        stringstream errMsg;
        errMsg <<"MCX-PMU: the number of pinlist groups is "
               << param.mcxPinlistVec.size() <<endl
               <<"         the number of testName groups is "
               << mcxTestNameVec.size() <<endl
               <<"So the testName groups don't match pinlist groups." <<endl;
        throw Error("LeakageTest::processParameters()",
                    errMsg.str(),
                    "LeakageTest::processParameters()");
      }
      else
      {
        param.isMCXLimitAppliedForAllGroups = true;
        for(vector<string>::size_type i = 1; i < param.mcxPinlistVec.size(); i++)
        {
          mcxTestNameVec.push_back(mcxTestNameVec[0]);
        }
      }
    }

    // the following three variables is used for checking duplicate pins
    pair<map<string, pair<string, string> >::iterator, bool> ret;
    pair<string, string> groupAndInstrument;
    const string instrumentType = "MCX-PMUInstrument";
    for(vector<string>::size_type  i = 0; i< param.mcxPinlistVec.size(); i++)
    {
      bool isThisGroupNotCommented = ('#' != param.mcxPinlistVec[i][0]);
      vector<string>  expandedPins;
      if(isThisGroupNotCommented)
      {
        LeakageTestUtil::parseListOfString(param.mcxPinlistVec[i],expandedPins,',');
        // check the duplicate pins
        for (vector<string>::size_type index = 0; index < expandedPins.size(); index++)
        {
          groupAndInstrument = make_pair(param.mcxPinlistVec[i], instrumentType);
          ret = pinAndGroupMap.insert(make_pair(expandedPins[index], groupAndInstrument));
          if (!ret.second)
          {
            stringstream errMsg;
            errMsg << "In the MCX-PMUInstrument group: " << param.mcxPinlistVec[i]<< endl
                   << "   and " << ret.first->second.second << " group: "
                   << ret.first->second.first << endl
                   << "There are the same pin: "
                   << expandedPins[index] << endl;
            throw Error("LeakageTest::processParameters",
                        errMsg.str(),
                        "LeakageTest::processParameters");
          }
        }
      }
      param.mcxExpandedPinsVec.push_back(expandedPins);

      if("ON" != param.mcxPrechargeVec[i] &&
         "OFF" != param.mcxPrechargeVec[i])
      {
        stringstream errMsg;
        errMsg <<"MCX-PMU: for the " << i+1 << " group setup parameter, precharge: "
               <<param.mcxPrechargeVec[i] << " is invalid."<<endl
               <<"precharge can only be the following options: ON  OFF" <<endl;
        throw Error("LeakageTest::processParamters()",
                    errMsg.str(),
                    "LeakageTest::processParamters()");
      }

      if("PAR" != param.mcxMeasureModeVec[i] &&
         "SER" != param.mcxMeasureModeVec[i])
      {
        stringstream errMsg;
        errMsg <<"MCX-PMU: for the " << i+1 << " group setup parameter, measureMode: "
               <<param.mcxMeasureModeVec[i] << " is invalid."<<endl
               <<"measureMode can only be the following options: PAR  SER" <<endl;
        throw Error("LeakageTest::processParamters()",
                    errMsg.str(),
                    "LeakageTest::processParamters()");
      }

      bool isPrecharge = ("ON" == param.mcxPrechargeVec[i]);

      LIMIT limitLow,limitHigh;
      (param.mcxIsMeasureLowVec).push_back(false);
      (param.mcxForceVoltageLowVec).push_back(0.0);
      (param.mcxSettlingTimeLowVec).push_back(0.0);
      (param.mcxPrechargeVoltageLowVec).push_back(0.0);
      (param.mcxIsMeasureHighVec).push_back(false);
      (param.mcxForceVoltageHighVec).push_back(0.0);
      (param.mcxSettlingTimeHighVec).push_back(0.0);
      (param.mcxPrechargeVoltageHighVec).push_back(0.0);
      (param.mcxLimitLowVec).push_back(limitLow);
      (param.mcxLimitHighVec).push_back(limitHigh);
      (param.mcxLimitNameLowVec).push_back("");
      (param.mcxLimitNameHighVec).push_back("");
      
      string measureString = mcxMeasureVec[i];
      if(isThisGroupNotCommented && 
         ("LOW" == measureString ||
          "Low" == measureString ||
          "low" == measureString) )
      {
        param.mcxIsMeasureLowVec[i] = true;
        param.mcxMeasureLow = true;
        param.measureLow = true;
        param.mcxForceVoltageLowVec[i]
                     = LeakageTestUtil::string2Double(mcxForceVoltageVec[i],"mcxForceVoltage_mV");
        param.mcxSettlingTimeLowVec[i]
                     = LeakageTestUtil::string2Double(mcxSettlingTimeVec[i],"mcx_settingTime_ms");
        if(isPrecharge)
        {
          param.mcxPrechargeVoltageLowVec[i]
                     = LeakageTestUtil::string2Double(mcxPrechargeVoltageVec[i],"mcxPrechargeVoltage_mV");
        }

        param.mcxLimitNameLowVec[i] = mcxTestNameVec[i];
        LeakageTestUtil::getLimitInfo(mcxTestNameVec[i],i,
                                      param.mcxLimitLowVec[i],
                                      testtableHelper);
      }
      else if(isThisGroupNotCommented && 
              ("HIGH" == measureString ||
               "High" == measureString ||
               "high" == measureString) )
      {
        param.mcxIsMeasureHighVec[i] = true;
        param.mcxMeasureHigh = true;
        param.measureHigh = true;
        param.mcxForceVoltageHighVec[i]
                     = LeakageTestUtil::string2Double(mcxForceVoltageVec[i],"mcxForceVoltage_mV");
        param.mcxSettlingTimeHighVec[i]
                     = LeakageTestUtil::string2Double(mcxSettlingTimeVec[i],"mcx_settingTime_ms");
        if(isPrecharge)
        {
          param.mcxPrechargeVoltageHighVec[i]
                     = LeakageTestUtil::string2Double(mcxPrechargeVoltageVec[i],"mcxPrechargeVoltage_mV");
        }

        param.mcxLimitNameHighVec[i] = mcxTestNameVec[i];
        LeakageTestUtil::getLimitInfo(mcxTestNameVec[i],i,
                                      param.mcxLimitHighVec[i],
                                      testtableHelper);
      }
      else if (isThisGroupNotCommented &&
               ("BOTH" == measureString ||
                "Both" == measureString ||
                "both" == measureString) )
      {
        vector<double> forceVoltageVec;
        vector<double> prechargeVoltageVec;
        vector<double> settlingTimeVec;
        vector<string> limitVec;

        forceVoltageVec.clear();
        prechargeVoltageVec.clear();
        settlingTimeVec.clear();
        limitVec.clear();

        // parse forceVoltage_mV and check the format
        LeakageTestUtil::parseListOfDouble(mcxForceVoltageVec[i],forceVoltageVec);
        if(2 != forceVoltageVec.size())
        {
          stringstream errMsg;
          errMsg <<"MCX-PMU: the input of forceVoltage_mV for the " << i+1
                 <<" group's format is not correct!"<<endl
                 <<"     Now the measure is for both,"
                 <<"so the input format is like: (400,3800)"<<endl;
          throw Error("LeakageTest::processParameters()",
                      errMsg.str(),
                      "LeakageTest::processParameters()");
        }

        // parse prechargeVoltage_mV and check the format
        if(isPrecharge)
        {
          LeakageTestUtil::parseListOfDouble(mcxPrechargeVoltageVec[i],prechargeVoltageVec);
          if(2 != prechargeVoltageVec.size())
          {
            stringstream errMsg;
            errMsg <<"MCX-PMU: the input of prechargeVoltage_mV for the " << i+1
                   <<" group's format is not correct!"<<endl
                   <<"     Now the measure is for both,"
                   <<"so the input format is like: (400,3800)"<<endl;
            throw Error("LeakageTest::processParameters()",
                        errMsg.str(),
                        "LeakageTest::processParameters()");
          }
        }

        // parse settling_ms and check the format
        LeakageTestUtil::parseListOfDouble(mcxSettlingTimeVec[i],settlingTimeVec);
        if(2 != settlingTimeVec.size())
        {
         stringstream errMsg;
          errMsg <<"MCX-PMU: the input of settling_ms for the " << i+1
                 <<" group's format is not correct!"<<endl
                 <<"     Now the measure is for both,"
                 <<"so the input format is like: (1.5,1.2)"<<endl;
          throw Error("LeakageTest::processParameters()",
                    errMsg.str(),
                    "LeakageTest::processParameters()");
        }

        // parse testName and check the format
        LeakageTestUtil::parseListOfString(mcxTestNameVec[i], limitVec);

        if(2 != limitVec.size())
        {
          stringstream errMsg;
          errMsg <<"MCX-PMU: the input of testName for the " << i+1
                 <<" group's format is not correct!"<<endl
                 <<"     Now the measure is for both,"
                 <<"so the input format is like: (limitNameLow,limitNameHigh)"<<endl;
          throw Error("LeakageTest::processParameters()",
                      errMsg.str(),
                      "LeakageTest::processParameters()");
        }
        
        param.mcxIsMeasureLowVec[i] = true;
        param.mcxMeasureLow = true;
        param.measureLow = true;
        param.mcxForceVoltageLowVec[i] = forceVoltageVec[0];
        param.mcxSettlingTimeLowVec[i] = settlingTimeVec[0];
        if(isPrecharge)
        {
          param.mcxPrechargeVoltageLowVec[i] = prechargeVoltageVec[0];
          param.mcxPrechargeVoltageHighVec[i] = prechargeVoltageVec[1];
        }

        param.mcxLimitNameLowVec[i] = limitVec[0];
        param.mcxLimitNameHighVec[i] = limitVec[1];
        LeakageTestUtil::getLimitInfo(limitVec[0],i,
                                      param.mcxLimitLowVec[i],
                                      testtableHelper);

        LeakageTestUtil::getLimitInfo(limitVec[1],i,
                                      param.mcxLimitHighVec[i],
                                      testtableHelper);

        param.mcxIsMeasureHighVec[i] = true;
        param.mcxMeasureHigh = true;
        param.measureHigh = true;
        param.mcxForceVoltageLowVec[i] = forceVoltageVec[1];
        param.mcxSettlingTimeLowVec[i]= settlingTimeVec[1];
      }
      else if(isThisGroupNotCommented)
      {
        stringstream errMsg;
        errMsg <<"MCX-PMU: for the " << i+1 << " group setup parameter, measure: "
               <<measureString << " is invalid."<<endl
               <<"measure can only be the following options:" <<endl
               <<"LOW HIGH BOTH" <<endl;
        throw Error("LeakageTest::processParamters()",
                    errMsg.str(),
                    "LeakageTest::processParamters()");
      }
    }
  }

  if("YES" == param.dcScaleSIGUsed)
  {
    vector<string> dcScaleSIGMeasureVec;
    vector<string> dcScaleSIGForceVoltageVec;
    vector<string> dcScaleSIGPrechargeVoltageVec;
    vector<string> dcScaleSIGClampCurrentVec;
    vector<string> dcScaleSIGSettlingTimeVec;
    vector<string> dcScaleSIGTestNameVec;

    LeakageTestUtil::parseListOfString(dcScaleSIGPinlist,param.dcScaleSIGPinlistVec);
    LeakageTestUtil::parseListOfString(dcScaleSIGMeasure,dcScaleSIGMeasureVec);
    LeakageTestUtil::parseListOfString(dcScaleSIGForceVoltage_mV,
                                       dcScaleSIGForceVoltageVec,
                                       ',',
                                       true);
    LeakageTestUtil::parseListOfString(dcScaleSIGPrecharge,param.dcScaleSIGPrechargeVec);
    LeakageTestUtil::parseListOfString(dcScaleSIGPrechargeVoltage_mV,
                                       dcScaleSIGPrechargeVoltageVec,
                                       ',',
                                       true);
    LeakageTestUtil::parseListOfString(dcScaleSIGClampCurrent_uA,
                                       dcScaleSIGClampCurrentVec,
                                       ',',
                                       true);
    LeakageTestUtil::parseListOfString(dcScaleSIGSettlingTime_ms,
                                       dcScaleSIGSettlingTimeVec,
                                       ',',
                                       true);
    LeakageTestUtil::parseListOfString(dcScaleSIGTestName,
                                       dcScaleSIGTestNameVec,
                                       ',',
                                       true);
    LeakageTestUtil::parseListOfString(dcScaleSIGMeasureMode,param.dcScaleSIGMeasureModeVec);
    LeakageTestUtil::parseListOfString(dcScaleSIGRelaySwitchMode,param.dcScaleSIGRelaySwitchModeVec);

    vector<string>::size_type groupSize = param.dcScaleSIGPinlistVec.size();
    if(groupSize == 0)
    {
      throw Error("LeakageTest::processParameters()",
                  "DcScaleSIG: the pinlist groups can not be empty.",
                  "LeakageTest::processParameters()");
    }

    LeakageTestUtil::checkParameter(groupSize,
                                    dcScaleSIGMeasureVec.size(),
                                    "DcScaleSIG",
                                    "measure",
                                    dcScaleSIGMeasureVec);
    LeakageTestUtil::checkParameter(groupSize,
                                    dcScaleSIGForceVoltageVec.size(),
                                    "DcScaleSIG",
                                    "forceVoltage_mV",
                                    dcScaleSIGForceVoltageVec);
    LeakageTestUtil::checkParameter(groupSize,
                                    param.dcScaleSIGPrechargeVec.size(),
                                    "DcScaleSIG",
                                    "precharge",
                                    param.dcScaleSIGPrechargeVec);
    LeakageTestUtil::checkParameter(groupSize,
                                    dcScaleSIGPrechargeVoltageVec.size(),
                                    "DcScaleSIG",
                                    "prechargeVoltage_mV",
                                    dcScaleSIGPrechargeVoltageVec);
    LeakageTestUtil::checkParameter(groupSize,
                                    dcScaleSIGClampCurrentVec.size(),
                                    "DcScaleSIG",
                                    "clampCurrent_uA",
                                    dcScaleSIGClampCurrentVec);
    LeakageTestUtil::checkParameter(groupSize,
                                    dcScaleSIGSettlingTimeVec.size(),
                                    "DcScaleSIG",
                                    "settlingTime_ms",
                                    dcScaleSIGSettlingTimeVec);
    LeakageTestUtil::checkParameter(groupSize,
                                    param.dcScaleSIGMeasureModeVec.size(),
                                    "DcScaleSIG",
                                    "measureMode",
                                    param.dcScaleSIGMeasureModeVec);
    LeakageTestUtil::checkParameter(groupSize,
                                    param.dcScaleSIGRelaySwitchModeVec.size(),
                                    "DcScaleSIG",
                                    "relaySwitchMode",
                                    param.dcScaleSIGRelaySwitchModeVec);

    if(param.dcScaleSIGPinlistVec.size() != dcScaleSIGTestNameVec.size())
    {
      if(dcScaleSIGTestNameVec.size() != 1)
      {
        stringstream errMsg;
        errMsg <<"DcScaleSIG: the number of pinlist groups is "
               << param.dcScaleSIGPinlistVec.size() <<endl
               <<"            the number of testName groups is "
               << dcScaleSIGTestNameVec.size() <<endl
               <<"So the testName groups don't match pinlist groups." <<endl;
        throw Error("LeakageTest::processParameters()",
                    errMsg.str(),
                    "LeakageTest::processParameters()");
      }
      else
      {
        param.isDCScaleSIGLimitAppliedForAllGroups = true;
        for(vector<string>::size_type i = 1; i < param.dcScaleSIGPinlistVec.size(); i++)
        {
          dcScaleSIGTestNameVec.push_back(dcScaleSIGTestNameVec[0]);
        }
      }
    }

    // the following three variables is used for checking duplicate pins
    pair<map<string, pair<string, string> >::iterator, bool> ret;
    pair<string, string> groupAndInstrument;
    const string instrumentType = "DCScaleSIGInstrument";
    for(vector<string>::size_type  i = 0; i< param.dcScaleSIGPinlistVec.size(); i++)
    {
      bool isThisGroupNotCommented = ('#' != param.dcScaleSIGPinlistVec[i][0]);
      vector<string>  expandedPins;
      if(isThisGroupNotCommented)
      {
        expandedPins = PinUtility.getDigitalPinNamesFromPinList(
            param.dcScaleSIGPinlistVec[i],
            TM::DC_PIN,true,true);
        // check the duplicate pins
        for (vector<string>::size_type index = 0; index < expandedPins.size(); index++)
        {
          groupAndInstrument = make_pair(param.dcScaleSIGPinlistVec[i], instrumentType);
          ret = pinAndGroupMap.insert(make_pair(expandedPins[index], groupAndInstrument));
          if (!ret.second)
          {
            stringstream errMsg;
            errMsg << "In the DCScaleSIGInstrument group: "
                   << param.dcScaleSIGPinlistVec[i] << endl
                   << "   and "<< ret.first->second.second << " group: "
                   << ret.first->second.first << endl
                   << "There are the same pin: " << expandedPins[index] << endl;
            throw Error("LeakageTest::processParameters",
                        errMsg.str(),
                        "LeakageTest::processParameters");
          }
        }
      }
      param.dcScaleSIGExpandedPinsVec.push_back(expandedPins);

      if("ON" != param.dcScaleSIGPrechargeVec[i] &&
         "OFF" != param.dcScaleSIGPrechargeVec[i])
      {
        stringstream errMsg;
        errMsg <<"DcScaleSIG: for the " << i+1 << " group setup parameter, precharge: "
               <<param.dcScaleSIGPrechargeVec[i] << " is invalid."<<endl
               <<"precharge can only be the following options: ON  OFF" <<endl;
        throw Error("LeakageTest::processParamters()",
                    errMsg.str(),
                    "LeakageTest::processParamters()");
      }

      if("PAR" != param.dcScaleSIGMeasureModeVec[i] &&
         "SER" != param.dcScaleSIGMeasureModeVec[i])
      {
        stringstream errMsg;
        errMsg <<"DcScaleSIG: for the " << i+1 << " group setup parameter, measureMode: "
               <<param.dcScaleSIGMeasureModeVec[i] << " is invalid."<<endl
               <<"measureMode can only be the following options: PAR  SER" <<endl;
        throw Error("LeakageTest::processParamters()",
                    errMsg.str(),
                    "LeakageTest::processParamters()");
      }

      if("NT" != param.dcScaleSIGRelaySwitchModeVec[i] &&
         "NO" != param.dcScaleSIGRelaySwitchModeVec[i])
      {
        stringstream errMsg;
        errMsg <<"DcScaleSIG: for the " << i+1 << " group setup parameter, relaySwitchMode: "
               <<param.dcScaleSIGRelaySwitchModeVec[i] << " is invalid."<<endl
               <<"relaySwitchMode can only be the following options: NT NO" <<endl;
        throw Error("LeakageTest::processParamters()",
                    errMsg.str(),
                    "LeakageTest::processParamters()");
      }

      bool isPrecharge = ("ON" == param.dcScaleSIGPrechargeVec[i]);

      LIMIT limitLow,limitHigh;
      (param.dcScaleSIGIsMeasureLowVec).push_back(false);
      (param.dcScaleSIGForceVoltageLowVec).push_back(0.0);
      (param.dcScaleSIGClampCurrentLowVec).push_back(0.0);
      (param.dcScaleSIGSettlingTimeLowVec).push_back(0.0);
      (param.dcScaleSIGPrechargeVoltageLowVec).push_back(0.0);
      (param.dcScaleSIGIsMeasureHighVec).push_back(false);
      (param.dcScaleSIGForceVoltageHighVec).push_back(0.0);
      (param.dcScaleSIGClampCurrentHighVec).push_back(0.0);
      (param.dcScaleSIGSettlingTimeHighVec).push_back(0.0);
      (param.dcScaleSIGPrechargeVoltageHighVec).push_back(0.0);
      (param.dcScaleSIGLimitLowVec).push_back(limitLow);
      (param.dcScaleSIGLimitHighVec).push_back(limitHigh);
      (param.dcScaleSIGLimitNameLowVec).push_back("");
      (param.dcScaleSIGLimitNameHighVec).push_back("");

      string measureString = dcScaleSIGMeasureVec[i];
      if(isThisGroupNotCommented &&
         ("LOW" == measureString ||
          "Low" == measureString ||
          "low" == measureString) )
      {
        param.dcScaleSIGMeasureLow = true;
        param.measureLow = true;
        param.dcScaleSIGIsMeasureLowVec[i] = true;
        param.dcScaleSIGForceVoltageLowVec[i]
                            = LeakageTestUtil::string2Double(dcScaleSIGForceVoltageVec[i],"dcScaleSIGForceVoltage_mV");
        param.dcScaleSIGClampCurrentLowVec[i]
                            = LeakageTestUtil::string2Double(dcScaleSIGClampCurrentVec[i],"dcScaleSIGClampCurrent_uA");
        param.dcScaleSIGSettlingTimeLowVec[i]
                            = LeakageTestUtil::string2Double(dcScaleSIGSettlingTimeVec[i],"dcScaleSIGSettlingTime_ms");
        if(isPrecharge)
        {
          param.dcScaleSIGPrechargeVoltageLowVec[i]
                            = LeakageTestUtil::string2Double(dcScaleSIGPrechargeVoltageVec[i],"dcScaleSIGPrechargeVoltage_mV");
        }

        param.dcScaleSIGLimitNameLowVec[i] = dcScaleSIGTestNameVec[i];
        LeakageTestUtil::getLimitInfo(dcScaleSIGTestNameVec[i],i,
                                      param.dcScaleSIGLimitLowVec[i],
                                      testtableHelper);
      }
      else if(isThisGroupNotCommented &&
              ("HIGH" == measureString ||
               "High" == measureString ||
               "high" == measureString) )
      {
        param.dcScaleSIGMeasureHigh = true;
        param.measureHigh = true;
        param.dcScaleSIGIsMeasureHighVec[i] = true;
        param.dcScaleSIGForceVoltageHighVec[i]
                            = LeakageTestUtil::string2Double(dcScaleSIGForceVoltageVec[i],"dcScaleSIGForceVoltage_mV");
        param.dcScaleSIGClampCurrentHighVec[i]
                            = LeakageTestUtil::string2Double(dcScaleSIGClampCurrentVec[i],"dcScaleSIGClampCurrent_uA");
        param.dcScaleSIGSettlingTimeHighVec[i]
                            = LeakageTestUtil::string2Double(dcScaleSIGSettlingTimeVec[i],"dcScaleSIGSettlingTime_ms");
        if(isPrecharge)
        {
          param.dcScaleSIGPrechargeVoltageHighVec[i]
                            = LeakageTestUtil::string2Double(dcScaleSIGPrechargeVoltageVec[i],"dcScaleSIGPrechargeVoltage_mV");
        }

        param.dcScaleSIGLimitNameHighVec[i] = dcScaleSIGTestNameVec[i];
        LeakageTestUtil::getLimitInfo(dcScaleSIGTestNameVec[i],i,
                                      param.dcScaleSIGLimitHighVec[i],
                                      testtableHelper);
      }
      else if (isThisGroupNotCommented &&
               ("BOTH" == measureString ||
                "Both" == measureString ||
                "both" == measureString) )
      {
        vector<double> forceVoltageVec;
        vector<double> prechargeVoltageVec;
        vector<double> clampCurrentVec;
        vector<double> settlingTimeVec;
        vector<string> limitVec;

        forceVoltageVec.clear();
        prechargeVoltageVec.clear();
        settlingTimeVec.clear();
        limitVec.clear();

        // parse forceVoltage_mV and check the format
        LeakageTestUtil::parseListOfDouble(dcScaleSIGForceVoltageVec[i],forceVoltageVec);
        if(2 != forceVoltageVec.size())
        {
          stringstream errMsg;
          errMsg <<"DCScaleSIG: the input of forceVoltage_mV for the " << i+1
                 <<" group's format is not correct!"<<endl
                 <<"            Now the measure is for both,"
                 <<"so the input format is like: (400,3800)"<<endl;
          throw Error("LeakageTest::processParameters()",
                      errMsg.str(),
                      "LeakageTest::processParameters()");
        }

        // parse prechargeVoltage_mV and check the format
        if(isPrecharge)
        {
          LeakageTestUtil::parseListOfDouble(dcScaleSIGPrechargeVoltageVec[i],prechargeVoltageVec);
          if(2 != prechargeVoltageVec.size())
          {
            stringstream errMsg;
            errMsg <<"DCScaleSIG: the input of prechargeVoltage_mV for the " << i+1
                   <<" group's format is not correct!"<<endl
                   <<"            Now the measure is for both,"
                   <<"so the input format is like: (400,3800)"<<endl;
            throw Error("LeakageTest::processParameters()",
                        errMsg.str(),
                        "LeakageTest::processParameters()");
          }
        }

        // parse clampcurrent_uA and check the format
        LeakageTestUtil::parseListOfDouble(dcScaleSIGClampCurrentVec[i],clampCurrentVec);
        if(2 != clampCurrentVec.size())
        {
          stringstream errMsg;
          errMsg <<"DCScaleSIG: the input of clampCurrent_uA for the " << i+1
                 <<" group's format is not correct!"<<endl
                 <<"            Now the measure is for both,"
                 <<"so the input format is like: (200,700)"<<endl;
          throw Error("LeakageTest::processParameters()",
                      errMsg.str(),
                      "LeakageTest::processParameters()");
        }

        // parse settlingTime_ms and check the format
        LeakageTestUtil::parseListOfDouble(dcScaleSIGSettlingTimeVec[i],settlingTimeVec);
        if(2 != settlingTimeVec.size())
        {
          stringstream errMsg;
          errMsg <<"DCScaleSIG: the input of settlingTime_ms for the " << i+1
                 <<" group's format is not correct!"<<endl
                 <<"            Now the measure is for both,"
                 <<"so the input format is like: (1.5,1.2)"<<endl;
          throw Error("LeakageTest::processParameters()",
                      errMsg.str(),
                      "LeakageTest::processParameters()");
        }

        // parse testName and check the format
        LeakageTestUtil::parseListOfString(dcScaleSIGTestNameVec[i], limitVec);

        if(2 != limitVec.size())
        {
          stringstream errMsg;
          errMsg <<"DCScaleSIG: the input of testName for the " << i+1
                 <<" group's format is not correct!"<<endl
                 <<"            Now the measure is for both,"
                 <<"so the input format is like: (limitNameLow,limitNameHigh)"<<endl;
          throw Error("LeakageTest::processParameters()",
                      errMsg.str(),
                      "LeakageTest::processParameters()");
        }

        param.dcScaleSIGIsMeasureLowVec[i] = true;      // the low level measurement will be done
        param.dcScaleSIGMeasureLow = true;
        param.measureLow = true;
        param.dcScaleSIGForceVoltageLowVec[i] = forceVoltageVec[0];
        param.dcScaleSIGClampCurrentLowVec[i] = clampCurrentVec[0];
        param.dcScaleSIGSettlingTimeLowVec[i] = settlingTimeVec[0];
        if(isPrecharge)
        {
          param.dcScaleSIGPrechargeVoltageLowVec[i] = prechargeVoltageVec[0];
          param.dcScaleSIGPrechargeVoltageHighVec[i] = prechargeVoltageVec[1];
        }

        param.dcScaleSIGLimitNameLowVec[i] = limitVec[0];
        param.dcScaleSIGLimitNameHighVec[i] = limitVec[1];

        LeakageTestUtil::getLimitInfo(limitVec[0],i,
                                      param.dcScaleSIGLimitLowVec[i],
                                      testtableHelper);
        LeakageTestUtil::getLimitInfo(limitVec[1],i,
                                      param.dcScaleSIGLimitHighVec[i],
                                      testtableHelper);

        param.dcScaleSIGIsMeasureHighVec[i] = true;    // the high level measurement will be done
        param.dcScaleSIGMeasureHigh = true;
        param.measureHigh = true;
        param.dcScaleSIGForceVoltageHighVec[i] = forceVoltageVec[1];
        param.dcScaleSIGClampCurrentHighVec[i] = clampCurrentVec[1];
        param.dcScaleSIGSettlingTimeHighVec[i] = settlingTimeVec[1];
      }
      else if(isThisGroupNotCommented)
      {
        stringstream errMsg;
        errMsg <<"DCScaleSIG: for the " << i+1 << " group setup parameter, measure: "
               <<measureString << " is invalid."<<endl
               <<"measure can only be the following options:" <<endl
               <<"LOW HIGH BOTH" <<endl;
        throw Error("LeakageTest::processParamters()",
                    errMsg.str(),
                    "LeakageTest::processParamters()");
      }
    }
  }


  // common parameters
  param.preFunction = LeakageTestUtil::trim(preFunction);
  if(param.preFunction != "ALL" && param.preFunction != "NO" &&
     param.preFunction != "ToStopVEC" && param.preFunction != "ToStopCYC")
  {
    throw Error("LeakageTest::processParamters()",
                "Wrong preFunction type. The type options can only be: ALL NO ToStopVEC ToStopCYC",
                "LeakageTest::processParamters()");
  }
  else if(param.preFunction != "NO")
  {
    param.checkFunctionalResult = LeakageTestUtil::trim(checkFunctionalResult);
  }

  param.stopVec[0] = stopVecLow;
  param.stopVec[1] = stopVecHigh;

  if("ToStopCYC" == param.preFunction)
  {
    string portData;
    LeakageTestUtil::splitPortDataAndPortName(stopCycLow,portData,param.lowPortName,false);
    param.stopCyc[0] = LeakageTestUtil::string2Long(portData,"stopCycLow");
    LeakageTestUtil::splitPortDataAndPortName(stopCycHigh,portData,param.highPortName,false);
    param.stopCyc[1] = LeakageTestUtil::string2Long(portData,"stopCycHigh");
  }

  param.isLimitTableUsed = testtableHelper.isAllInTable();
}

/*
 *----------------------------------------------------------------------*
 * Routine: doMeasurement
 *
 * Purpose: execute measurement by instrument(s) and store results
 *
 *----------------------------------------------------------------------*
 * Description:
 *   INPUT:  param       - test parameters
 *           result      - result container
 *
 *   OUTPUT:
 *   RETURN:
 *----------------------------------------------------------------------*
 */
static void doMeasurement(const LeakageTestParam& param,
                          LeakageTestResult& result)
{
  ON_FIRST_INVOCATION_BEGIN();
  CONNECT();
  ON_FIRST_INVOCATION_END();

  // for low level test
  if(param.measureLow)
  {
    ON_FIRST_INVOCATION_BEGIN();
    if ("ALL" == param.preFunction )
    {
      Sequencer.reset();
      FUNCTIONAL_TEST();
    }
    else if ("ToStopVEC" == param.preFunction )
    {
      Sequencer.stopVector(param.stopVec[0]);
      FUNCTIONAL_TEST();
    }
    else if ("ToStopCYC" == param.preFunction )
    {
      if(param.lowPortName.empty())
      {
        Sequencer.stopCycle(param.stopCyc[0]);
      }
      else
      {
        Sequencer.stopCycle(param.stopCyc[0],param.lowPortName);
      }
      FUNCTIONAL_TEST();
    }
    else // param.preFunction == "NO"
    {
      //  Do nothing here.
    }
    ON_FIRST_INVOCATION_END();
    if ( param.preFunction != "NO" )
    {
      // get the low level functional test result
      result.funcResult[0] = GET_FUNCTIONAL_RESULT();
    }
  }

  SPMU_TASK spForceONLow;
  SPMU_TASK spMeasureLow;
  SPMU_TASK spForceOFFLow;
  PPMU_MEASURE ppmuMeasureLow;
  HV_DC_TASK   ppmuHVMeasureLow;
  bool hasParallelGroupForPpmuMeasure = false;
  bool hasParallelGroupForPpmuHVMeasure = false;
  bool hasParallelGroupForSpmuTask = false;

  ON_FIRST_INVOCATION_BEGIN();
  PPMU_SETTING ppmuSettingLowStep1, ppmuSettingLowStep2;
  PPMU_RELAY   ppmuRelayLowStep1,ppmuRelayLowStep2;
  PPMU_RELAY   ppmuRelayRestoreLowStep1,ppmuRelayRestoreLowStep2;
  TASK_LIST taskListLow;
  // for ppmu measurement's setup
  if(param.ppmuMeasureLow)
  {
    LeakageTestUtil::ppmuInstrumentCurrentMeasurementSetup(
        param.ppmuPinlistVec,
        param.ppmuIsMeasureLowVec,
        param.ppmuForceVoltageLowVec,
        param.ppmuPrechargeVec,
        param.ppmuPrechargeVoltageLowVec,
        param.ppmuSettlingTimeLowVec,
        param.ppmuMeasureModeVec,
        param.ppmuRelaySwitchModeVec,
        param.ppmuLimitLowVec,
        param.ppmuIsHVPinsVec,
        param.testMode,
        ppmuSettingLowStep1,
        ppmuSettingLowStep2,
        ppmuRelayLowStep1,
        ppmuRelayLowStep2,
        ppmuRelayRestoreLowStep1,
        ppmuRelayRestoreLowStep2,
        ppmuMeasureLow,
        ppmuHVMeasureLow,
        hasParallelGroupForPpmuMeasure,
        hasParallelGroupForPpmuHVMeasure);
  }
  // for spmu measurement's setup
  if(param.spmuMeasureLow)
  {
    LeakageTestUtil::spmuInstrumentCurrentMeasurementSetup(
        param.spmuPinlistVec,
        param.spmuIsMeasureLowVec,
        param.spmuForceVoltageLowVec,
        param.spmuMeasureModeVec,
        param.spmuClampCurrentLowVec,
        param.spmuPrechargeVec,
        param.spmuPrechargeVoltageLowVec,
        param.spmuSettlingTimeLowVec,
        param.spmuRelaySwitchModeVec,
        param.spmuLimitLowVec,
        param.testMode,
        spForceONLow,
        spMeasureLow,
        spForceOFFLow,
        hasParallelGroupForSpmuTask);
  }
  // for dcScale in SIG mode measurement's setup
  if(param.dcScaleSIGMeasureLow)
  {
    LeakageTestUtil::DCScaleSIGInstrumentCurrentMeasurementSetup(
        param.dcScaleSIGPinlistVec,
        param.dcScaleSIGIsMeasureLowVec,
        param.dcScaleSIGForceVoltageLowVec,
        param.dcScaleSIGMeasureModeVec,
        param.dcScaleSIGClampCurrentLowVec,
        param.dcScaleSIGPrechargeVec,
        param.dcScaleSIGPrechargeVoltageLowVec,
        param.dcScaleSIGSettlingTimeLowVec,
        param.dcScaleSIGRelaySwitchModeVec,
        param.dcScaleSIGLimitLowVec,
        param.testMode,
        spForceONLow,
        spMeasureLow,
        spForceOFFLow,
        hasParallelGroupForSpmuTask);
  }

  // for ppmu, spmu, and dcScale in SIG mode measurement's execution
  if(hasParallelGroupForPpmuMeasure && hasParallelGroupForSpmuTask)
  {
    taskListLow.add(ppmuSettingLowStep1)
               .add(ppmuRelayLowStep1)
               .add(ppmuRelayLowStep2)
               .add(ppmuSettingLowStep2)
               .add(spForceONLow);

    //HV test should be put before PPMU_MEASURE
    if (hasParallelGroupForPpmuHVMeasure)
    {
      taskListLow.add(ppmuHVMeasureLow);
    }

    taskListLow.add(ppmuMeasureLow)
               .add(ppmuRelayRestoreLowStep1)
               .add(ppmuRelayRestoreLowStep2)
               .add(spMeasureLow)
               .add(spForceOFFLow);
  }
  else if(param.ppmuMeasureLow && hasParallelGroupForSpmuTask)
  {
    taskListLow.add(ppmuSettingLowStep1)
               .add(spForceONLow);

    //HV test should be put before SPMU_TASK
    if (hasParallelGroupForPpmuHVMeasure)
    {
      taskListLow.add(ppmuHVMeasureLow);
    }

    taskListLow.add(spMeasureLow)
               .add(spForceOFFLow);
  }
  else if(hasParallelGroupForPpmuMeasure)
  {
    taskListLow.add(ppmuSettingLowStep1)
               .add(ppmuRelayLowStep1)
               .add(ppmuRelayLowStep2)
               .add(ppmuSettingLowStep2);

    //HV test should be put before PPMU_MEASURE
    if (hasParallelGroupForPpmuHVMeasure)
    {
      taskListLow.add(ppmuHVMeasureLow);
    }

    taskListLow.add(ppmuMeasureLow)
               .add(ppmuRelayRestoreLowStep1)
               .add(ppmuRelayRestoreLowStep2);
  }
  else if(param.ppmuMeasureLow)
  {
    taskListLow.add(ppmuSettingLowStep1);
    if (hasParallelGroupForPpmuHVMeasure)
    {
      taskListLow.add(ppmuHVMeasureLow);
    }
  }
  else if(hasParallelGroupForSpmuTask)
  {
    taskListLow.add(spForceONLow);

    //HV test should be put before SPMU_TASK
    if (hasParallelGroupForPpmuHVMeasure)
    {
      taskListLow.add(ppmuHVMeasureLow);
    }

    taskListLow.add(spMeasureLow)
               .add(spForceOFFLow);
  }
  else if (hasParallelGroupForPpmuHVMeasure)
  {
    taskListLow.add(ppmuHVMeasureLow);
  }

  taskListLow.execute();

  ON_FIRST_INVOCATION_END();

  //HV pins are tested before non-HV pins
  if(param.ppmuMeasureLow)
  {
    LeakageTestUtil::ppmuCurrentHVMeasurementUpdateTestResult(
                param.ppmuPinlistVec,
                param.ppmuIsMeasureLowVec,
                param.ppmuForceVoltageLowVec,
                param.ppmuPrechargeVec,
                param.ppmuPrechargeVoltageLowVec,
                param.ppmuSettlingTimeLowVec,
                param.ppmuMeasureModeVec,
                param.ppmuRelaySwitchModeVec,
                param.ppmuLimitLowVec,
                param.ppmuExpandedPinsVec,
                param.ppmuIsHVPinsVec,
                param.testMode,
                ppmuHVMeasureLow,
                result.ppmuMeasureResultLowVec);
  }

  //non-HV pins
  if(param.mcxMeasureLow)
  {
    LeakageTestUtil::mcxInstrumentCurrentMeasurement(
                param.mcxPinlistVec,
                param.mcxIsMeasureLowVec,
                param.mcxForceVoltageLowVec,
                param.mcxMeasureModeVec,
                param.mcxPrechargeVec,
                param.mcxPrechargeVoltageLowVec,
                param.mcxSettlingTimeLowVec,
                param.mcxLimitLowVec,
                param.mcxExpandedPinsVec,
                param.testMode,
                result.mcxMeasureResultLowVec);
  }
  if(param.ppmuMeasureLow)
  {
    LeakageTestUtil::ppmuCurrentMeasurementUpdateTestResult(
                param.ppmuPinlistVec,
                param.ppmuIsMeasureLowVec,
                param.ppmuForceVoltageLowVec,
                param.ppmuPrechargeVec,
                param.ppmuPrechargeVoltageLowVec,
                param.ppmuSettlingTimeLowVec,
                param.ppmuMeasureModeVec,
                param.ppmuRelaySwitchModeVec,
                param.ppmuLimitLowVec,
                param.ppmuExpandedPinsVec,
                param.ppmuIsHVPinsVec,
                param.testMode,
                ppmuMeasureLow,
                result.ppmuMeasureResultLowVec);
  }
  if(param.spmuMeasureLow)
  {
    LeakageTestUtil::spmuCurrentMeasurementUpdateTestResult(
        param.spmuPinlistVec,
        param.spmuIsMeasureLowVec,
        param.spmuForceVoltageLowVec,
        param.spmuMeasureModeVec,
        param.spmuClampCurrentLowVec,
        param.spmuPrechargeVec,
        param.spmuPrechargeVoltageLowVec,
        param.spmuSettlingTimeLowVec,
        param.spmuRelaySwitchModeVec,
        param.spmuLimitLowVec,
        param.spmuExpandedPinsVec,
        param.testMode,
        spMeasureLow,
        result.spmuMeasureResultLowVec);
  }
  if(param.dcScaleSIGMeasureLow)
  {
    LeakageTestUtil::DCScaleSIGMeasurementCurrentUpdateTestResult(
        param.dcScaleSIGPinlistVec,
        param.dcScaleSIGIsMeasureLowVec,
        param.dcScaleSIGForceVoltageLowVec,
        param.dcScaleSIGMeasureModeVec,
        param.dcScaleSIGClampCurrentLowVec,
        param.dcScaleSIGPrechargeVec,
        param.dcScaleSIGPrechargeVoltageLowVec,
        param.dcScaleSIGSettlingTimeLowVec,
        param.dcScaleSIGRelaySwitchModeVec,
        param.dcScaleSIGLimitLowVec,
        param.dcScaleSIGExpandedPinsVec,
        param.testMode,
        spMeasureLow,
        result.dcScaleSIGMeasureResultLowVec);
  }


  // for high level test
  if(param.measureHigh)
  {
    if ("ALL" == param.preFunction)
    {
      if(!param.measureLow)
      {
        ON_FIRST_INVOCATION_BEGIN();
        Sequencer.reset();
        FUNCTIONAL_TEST();
        ON_FIRST_INVOCATION_END();
      }
      result.funcResult[1] = GET_FUNCTIONAL_RESULT();
    }
    else if ("ToStopVEC" == param.preFunction)
    {
      if(!param.measureLow || (param.stopVec[0] != param.stopVec[1]))
      {
        ON_FIRST_INVOCATION_BEGIN();
        Sequencer.stopVector(param.stopVec[1]);
        FUNCTIONAL_TEST();
        ON_FIRST_INVOCATION_END();
      }
      result.funcResult[1] = GET_FUNCTIONAL_RESULT();
    }
    else if ("ToStopCYC" == param.preFunction )
    {
      if(!param.measureLow ||
         (param.stopCyc[0] != param.stopCyc[1]) ||
         (param.lowPortName != param.highPortName))
      {
        ON_FIRST_INVOCATION_BEGIN();
        if(param.highPortName.empty())
        {
          Sequencer.stopCycle(param.stopCyc[1]);
        }
        else
        {
          Sequencer.stopCycle(param.stopCyc[1],param.highPortName);
        }
        FUNCTIONAL_TEST();
        ON_FIRST_INVOCATION_END();
      }
      result.funcResult[1] = GET_FUNCTIONAL_RESULT();
    }
    else // param.preFunction == "NO"
    {
      //  Do nothing here.
    }
  }

  hasParallelGroupForPpmuMeasure = false;
  hasParallelGroupForPpmuHVMeasure = false;
  hasParallelGroupForSpmuTask = false;

  SPMU_TASK spForceONHigh;
  SPMU_TASK spMeasureHigh;
  SPMU_TASK spForceOFFHigh;
  PPMU_MEASURE ppmuMeasureHigh;
  HV_DC_TASK   ppmuHVMeasureHigh;

  ON_FIRST_INVOCATION_BEGIN();
  PPMU_SETTING ppmuSettingHighStep1, ppmuSettingHighStep2;
  PPMU_RELAY   ppmuRelayHighStep1,ppmuRelayHighStep2;
  PPMU_RELAY   ppmuRelayRestoreHighStep1,ppmuRelayRestoreHighStep2;

  TASK_LIST taskListHigh;
  // for ppmu measurement's setup
  if(param.ppmuMeasureHigh)
  {
    LeakageTestUtil::ppmuInstrumentCurrentMeasurementSetup(
        param.ppmuPinlistVec,
        param.ppmuIsMeasureHighVec,
        param.ppmuForceVoltageHighVec,
        param.ppmuPrechargeVec,
        param.ppmuPrechargeVoltageHighVec,
        param.ppmuSettlingTimeHighVec,
        param.ppmuMeasureModeVec,
        param.ppmuRelaySwitchModeVec,
        param.ppmuLimitHighVec,
        param.ppmuIsHVPinsVec,
        param.testMode,
        ppmuSettingHighStep1,
        ppmuSettingHighStep2,
        ppmuRelayHighStep1,
        ppmuRelayHighStep2,
        ppmuRelayRestoreHighStep1,
        ppmuRelayRestoreHighStep2,
        ppmuMeasureHigh,
        ppmuHVMeasureHigh,
        hasParallelGroupForPpmuMeasure,
        hasParallelGroupForPpmuHVMeasure);
  }
  // for spmu measurement's setup
  if(param.spmuMeasureHigh)
  {
    LeakageTestUtil::spmuInstrumentCurrentMeasurementSetup(
        param.spmuPinlistVec,
        param.spmuIsMeasureHighVec,
        param.spmuForceVoltageHighVec,
        param.spmuMeasureModeVec,
        param.spmuClampCurrentHighVec,
        param.spmuPrechargeVec,
        param.spmuPrechargeVoltageHighVec,
        param.spmuSettlingTimeHighVec,
        param.spmuRelaySwitchModeVec,
        param.spmuLimitHighVec,
        param.testMode,
        spForceONHigh,
        spMeasureHigh,
        spForceOFFHigh,
        hasParallelGroupForSpmuTask);
  }
  // for dcScale in SIG mode measurement's setup
  if(param.dcScaleSIGMeasureHigh)
  {
    LeakageTestUtil::DCScaleSIGInstrumentCurrentMeasurementSetup(
        param.dcScaleSIGPinlistVec,
        param.dcScaleSIGIsMeasureHighVec,
        param.dcScaleSIGForceVoltageHighVec,
        param.dcScaleSIGMeasureModeVec,
        param.dcScaleSIGClampCurrentHighVec,
        param.dcScaleSIGPrechargeVec,
        param.dcScaleSIGPrechargeVoltageHighVec,
        param.dcScaleSIGSettlingTimeHighVec,
        param.dcScaleSIGRelaySwitchModeVec,
        param.dcScaleSIGLimitHighVec,
        param.testMode,
        spForceONHigh,
        spMeasureHigh,
        spForceOFFHigh,
        hasParallelGroupForSpmuTask);
  }

  // for ppmu, spmu, and dcScale in SIG mode measurement's execution
  if(hasParallelGroupForPpmuMeasure && hasParallelGroupForSpmuTask)
  {
    taskListHigh.add(ppmuSettingHighStep1)
                .add(ppmuRelayHighStep1)
                .add(ppmuRelayHighStep2)
                .add(ppmuSettingHighStep2)
                .add(spForceONHigh);

    if (hasParallelGroupForPpmuHVMeasure)
    {
      taskListHigh.add(ppmuHVMeasureHigh);
    }

    taskListHigh.add(ppmuMeasureHigh)
                .add(ppmuRelayRestoreHighStep1)
                .add(ppmuRelayRestoreHighStep2)
                .add(spMeasureHigh)
                .add(spForceOFFHigh);
  }
  else if(param.ppmuMeasureHigh && hasParallelGroupForSpmuTask)
  {
    taskListHigh.add(ppmuSettingHighStep1)
                .add(spForceONHigh);

    if (hasParallelGroupForPpmuHVMeasure)
    {
      taskListHigh.add(ppmuHVMeasureHigh);
    }

    taskListHigh.add(spMeasureHigh)
                .add(spForceOFFHigh);
  }
  else if(hasParallelGroupForPpmuMeasure)
  {
    taskListHigh.add(ppmuSettingHighStep1)
                .add(ppmuRelayHighStep1)
                .add(ppmuRelayHighStep2)
                .add(ppmuSettingHighStep2);

    if (hasParallelGroupForPpmuHVMeasure)
    {
      taskListHigh.add(ppmuHVMeasureHigh);
    }

    taskListHigh.add(ppmuMeasureHigh)
                .add(ppmuRelayRestoreHighStep1)
                .add(ppmuRelayRestoreHighStep2);
  }
  else if(param.ppmuMeasureHigh)
  {
    taskListHigh.add(ppmuSettingHighStep1);
    if (hasParallelGroupForPpmuHVMeasure)
    {
      taskListHigh.add(ppmuHVMeasureHigh);
    }
  }
  else if(hasParallelGroupForSpmuTask)
  {
    taskListHigh.add(spForceONHigh);

    if (hasParallelGroupForPpmuHVMeasure)
    {
      taskListHigh.add(ppmuHVMeasureHigh);
    }

    taskListHigh.add(spMeasureHigh)
                .add(spForceOFFHigh);
  }
  else if (hasParallelGroupForPpmuHVMeasure)
  {
    taskListHigh.add(ppmuHVMeasureHigh);
  }

  taskListHigh.execute();
  ON_FIRST_INVOCATION_END();

  //HV pins are tested before non-HV pins
  if(param.ppmuMeasureHigh)
  {
    LeakageTestUtil::ppmuCurrentHVMeasurementUpdateTestResult(
                param.ppmuPinlistVec,
                param.ppmuIsMeasureHighVec,
                param.ppmuForceVoltageHighVec,
                param.ppmuPrechargeVec,
                param.ppmuPrechargeVoltageHighVec,
                param.ppmuSettlingTimeHighVec,
                param.ppmuMeasureModeVec,
                param.ppmuRelaySwitchModeVec,
                param.ppmuLimitHighVec,
                param.ppmuExpandedPinsVec,
                param.ppmuIsHVPinsVec,
                param.testMode,
                ppmuHVMeasureHigh,
                result.ppmuMeasureResultHighVec);
  }

  //non-HV pins
  // for mcx-pmu measure and update result
  if(param.mcxMeasureHigh)
  {
    LeakageTestUtil::mcxInstrumentCurrentMeasurement(
                param.mcxPinlistVec,
                param.mcxIsMeasureHighVec,
                param.mcxForceVoltageHighVec,
                param.mcxMeasureModeVec,
                param.mcxPrechargeVec,
                param.mcxPrechargeVoltageHighVec,
                param.mcxSettlingTimeHighVec,
                param.mcxLimitHighVec,
                param.mcxExpandedPinsVec,
                param.testMode,
                result.mcxMeasureResultHighVec);
  }

  // update ppmu result
  if(param.ppmuMeasureHigh)
  {
    LeakageTestUtil::ppmuCurrentMeasurementUpdateTestResult(
                param.ppmuPinlistVec,
                param.ppmuIsMeasureHighVec,
                param.ppmuForceVoltageHighVec,
                param.ppmuPrechargeVec,
                param.ppmuPrechargeVoltageHighVec,
                param.ppmuSettlingTimeHighVec,
                param.ppmuMeasureModeVec,
                param.ppmuRelaySwitchModeVec,
                param.ppmuLimitHighVec,
                param.ppmuExpandedPinsVec,
                param.ppmuIsHVPinsVec,
                param.testMode,
                ppmuMeasureHigh,
                result.ppmuMeasureResultHighVec);
  }
  // update spmu result
  if(param.spmuMeasureHigh)
  {
    LeakageTestUtil::spmuCurrentMeasurementUpdateTestResult(
        param.spmuPinlistVec,
        param.spmuIsMeasureHighVec,
        param.spmuForceVoltageHighVec,
        param.spmuMeasureModeVec,
        param.spmuClampCurrentHighVec,
        param.spmuPrechargeVec,
        param.spmuPrechargeVoltageHighVec,
        param.spmuSettlingTimeHighVec,
        param.spmuRelaySwitchModeVec,
        param.spmuLimitHighVec,
        param.spmuExpandedPinsVec,
        param.testMode,
        spMeasureHigh,
        result.spmuMeasureResultHighVec);
  }
  // update dcScale in SIG mode result
  if(param.dcScaleSIGMeasureHigh)
  {
    LeakageTestUtil::DCScaleSIGMeasurementCurrentUpdateTestResult(
        param.dcScaleSIGPinlistVec,
        param.dcScaleSIGIsMeasureHighVec,
        param.dcScaleSIGForceVoltageHighVec,
        param.dcScaleSIGMeasureModeVec,
        param.dcScaleSIGClampCurrentHighVec,
        param.dcScaleSIGPrechargeVec,
        param.dcScaleSIGPrechargeVoltageHighVec,
        param.dcScaleSIGSettlingTimeHighVec,
        param.dcScaleSIGRelaySwitchModeVec,
        param.dcScaleSIGLimitHighVec,
        param.dcScaleSIGExpandedPinsVec,
        param.testMode,
        spMeasureHigh,
        result.dcScaleSIGMeasureResultHighVec);
  }

  // reset sequencer if needed
  if("ToStopVEC" == param.preFunction || "ToStopCYC" == param.preFunction)
  {
    ON_FIRST_INVOCATION_BEGIN();
      Sequencer.reset();
    ON_FIRST_INVOCATION_END();
  }
}

/*
 *----------------------------------------------------------------------*
 * Routine: judgeAndDatalog
 *
 * Purpose: judge and put result into event datalog stream.
 *
 *----------------------------------------------------------------------*
 * Description:
 *   judge results of 'result' with pass limits from 'param'
 *
 *   INPUT:  param       - test parameters
 *           testLimit   - test Limit container
 *           result      - result container
 *   OUTPUT:
 *   RETURN:
 * Note:
 *----------------------------------------------------------------------*
 */
static void judgeAndDatalog(const LeakageTestParam & param,
                            const LeakageTestResult& result)
{
  bool measureLow = false;
  bool measureHigh = false;
  bool hasBined = false;

  if("YES" == param.ppmuUsed)
  {
    LeakageJudgeAndLogUtil(
        param.ppmuIsMeasureLowVec,
        param.ppmuIsMeasureHighVec,
        param.ppmuPinlistVec,
        param.ppmuExpandedPinsVec,
        param.ppmuLimitLowVec,
        param.ppmuLimitHighVec,
        param.ppmuLimitNameLowVec,
        param.ppmuLimitNameHighVec,
        result.ppmuMeasureResultLowVec,
        result.ppmuMeasureResultHighVec,
        param.testMode,
        param.testsuiteName,
        param.isPPMULimitAppliedForAllGroups,
        param.isLimitTableUsed,
        measureLow,
        measureHigh,
        hasBined);
  }
  if("YES" == param.spmuUsed)
  {
    LeakageJudgeAndLogUtil(
        param.spmuIsMeasureLowVec,
        param.spmuIsMeasureHighVec,
        param.spmuPinlistVec,
        param.spmuExpandedPinsVec,
        param.spmuLimitLowVec,
        param.spmuLimitHighVec,
        param.spmuLimitNameLowVec,
        param.spmuLimitNameHighVec,
        result.spmuMeasureResultLowVec,
        result.spmuMeasureResultHighVec,
        param.testMode,
        param.testsuiteName,
        param.isSPMULimitAppliedForAllGroups,
        param.isLimitTableUsed,
        measureLow,
        measureHigh,
        hasBined);
  }
  if("YES" == param.mcxUsed)
  {
    LeakageJudgeAndLogUtil(
        param.mcxIsMeasureLowVec,
        param.mcxIsMeasureHighVec,
        param.mcxPinlistVec,
        param.mcxExpandedPinsVec,
        param.mcxLimitLowVec,
        param.mcxLimitHighVec,
        param.mcxLimitNameLowVec,
        param.mcxLimitNameHighVec,
        result.mcxMeasureResultLowVec,
        result.mcxMeasureResultHighVec,
        param.testMode,
        param.testsuiteName,
        param.isMCXLimitAppliedForAllGroups,
        param.isLimitTableUsed,
        measureLow,
        measureHigh,
        hasBined,
        true);
  }
  if("YES" == param.dcScaleSIGUsed)
  {
    LeakageJudgeAndLogUtil(
        param.dcScaleSIGIsMeasureLowVec,
        param.dcScaleSIGIsMeasureHighVec,
        param.dcScaleSIGPinlistVec,
        param.dcScaleSIGExpandedPinsVec,
        param.dcScaleSIGLimitLowVec,
        param.dcScaleSIGLimitHighVec,
        param.dcScaleSIGLimitNameLowVec,
        param.dcScaleSIGLimitNameHighVec,
        result.dcScaleSIGMeasureResultLowVec,
        result.dcScaleSIGMeasureResultHighVec,
        param.testMode,
        param.testsuiteName,
        param.isDCScaleSIGLimitAppliedForAllGroups,
        param.isLimitTableUsed,
        measureLow,
        measureHigh,
        hasBined);
  }

  if(measureLow && "ON" == param.checkFunctionalResult)
  {
    if ("ALL" == param.preFunction )
    {
      TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
          param.testsuiteName,
          "FUNCTION TEST Low, run through the whole pattern",
          result.funcResult[0]?TM::Pass:TM::Fail,
          0.0);
    }
    else if ("ToStopVEC" == param.preFunction )
    {
      TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
          param.testsuiteName,
          "FUNCTION TEST Low, stop on vector",
          result.funcResult[0]?TM::Pass:TM::Fail,
          param.stopVec[0]);
    }
    else if ("ToStopCYC" == param.preFunction )
    {
      TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
          param.testsuiteName,
          "FUNCTION TEST Low, stop on cycle for port " + param.lowPortName,
          result.funcResult[0]?TM::Pass:TM::Fail,
          param.stopCyc[0]);
    }
    else // param.preFunction == "NO"
    {
      //  no function test.
    }
  }
  if(measureHigh && "ON" == param.checkFunctionalResult)
  {
    if ("ALL" == param.preFunction)
    {
      if(!param.measureLow)
      {
        TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
            param.testsuiteName,
            "FUNCTION TEST High, run through the whole pattern",
            result.funcResult[1]?TM::Pass:TM::Fail,
            0.0);
      }
    }
    else if ("ToStopVEC" == param.preFunction)
    {
      if(!param.measureLow || (param.stopVec[0] != param.stopVec[1]))
      {
        TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
            param.testsuiteName,
            "FUNCTION TEST High, stop on vector",
            result.funcResult[0]?TM::Pass:TM::Fail,
            param.stopVec[1]);
      }
    }
    else if ("ToStopCYC" == param.preFunction )
    {
      if(!param.measureLow ||
          (param.stopCyc[0] != param.stopCyc[1]) ||
          (param.lowPortName != param.highPortName))
      {
        TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
            param.testsuiteName,
            "FUNCTION TEST High, stop on cycle for port " + param.highPortName,
            result.funcResult[1]?TM::Pass:TM::Fail,
            param.stopCyc[1]);
      }
    }
    else // param.preFunction == "NO"
    {
      //  Do nothing here.
    }
  }
}

/*
 *----------------------------------------------------------------------*
 * Routine: reportToUI
 *
 * Purpose: output result to UIWindow
 *
 *----------------------------------------------------------------------*
 * Description:
 *   display:
 *       a) results from result,
 *       b) pass range from pass limits of param,
 *       c) pass or fail
 *
 *   INPUT:  param              - test parameters
 *           result             - result container
 *           output             - "None" or "ReportUI"
 *   OUTPUT:
 *   RETURN:
 * Note:
 *----------------------------------------------------------------------*
 */
static void reportToUI(const LeakageTestParam& param,
                       const LeakageTestResult& result,
                       const string& output)
{
  if("ReportUI" != output)
  {
    return;
  }

  bool measureLow = false;
  bool measureHigh = false;

  int nSiteNumber = CURRENT_SITE_NUMBER();
  cout << "Leakage Low Test '" << param.testsuiteName << "'";
  cout << " Site: " << nSiteNumber << endl;

  if("YES" == param.ppmuUsed)
  {
    LeakageReportToUIUtil(param.ppmuIsMeasureLowVec,
                          param.ppmuPinlistVec,
                          param.ppmuExpandedPinsVec,
                          param.ppmuLimitLowVec,
                          result.ppmuMeasureResultLowVec,
                          param.testMode,
                          param.testsuiteName,
                          output,
                          measureLow);
  }
  if("YES" == param.spmuUsed)
  {
    LeakageReportToUIUtil(param.spmuIsMeasureLowVec,
                          param.spmuPinlistVec,
                          param.spmuExpandedPinsVec,
                          param.spmuLimitLowVec,
                          result.spmuMeasureResultLowVec,
                          param.testMode,
                          param.testsuiteName,
                          output,
                          measureLow);
  }
  if("YES" == param.mcxUsed)
  {
    LeakageReportToUIUtil(param.mcxIsMeasureLowVec,
                          param.mcxPinlistVec,
                          param.mcxExpandedPinsVec,
                          param.mcxLimitLowVec,
                          result.mcxMeasureResultLowVec,
                          param.testMode,
                          param.testsuiteName,
                          output,
                          measureLow,
                          true);
  }
  if("YES" == param.dcScaleSIGUsed)
  {
    LeakageReportToUIUtil(param.dcScaleSIGIsMeasureLowVec,
                          param.dcScaleSIGPinlistVec,
                          param.dcScaleSIGExpandedPinsVec,
                          param.dcScaleSIGLimitLowVec,
                          result.dcScaleSIGMeasureResultLowVec,
                          param.testMode,
                          param.testsuiteName,
                          output,
                          measureLow);
  }

  if(measureLow)
  {
    if ( param.preFunction != "NO" )
    {
      LeakageTestUtil::datalogToWindow(
          "Functional result for low level: ",
          result.funcResult[0]);
    }
  }


  cout << "Leakage High Test '" << param.testsuiteName << "'";
  cout << " Site: " << nSiteNumber << endl;

  if("YES" == param.ppmuUsed)
  {
    LeakageReportToUIUtil(param.ppmuIsMeasureHighVec,
                          param.ppmuPinlistVec,
                          param.ppmuExpandedPinsVec,
                          param.ppmuLimitHighVec,
                          result.ppmuMeasureResultHighVec,
                          param.testMode,
                          param.testsuiteName,
                          output,
                          measureHigh);
  }
  if("YES" == param.spmuUsed)
  {
    LeakageReportToUIUtil(param.spmuIsMeasureHighVec,
                          param.spmuPinlistVec,
                          param.spmuExpandedPinsVec,
                          param.spmuLimitHighVec,
                          result.spmuMeasureResultHighVec,
                          param.testMode,
                          param.testsuiteName,
                          output,
                          measureLow);
  }
  if("YES" == param.mcxUsed)
  {
    LeakageReportToUIUtil(param.mcxIsMeasureHighVec,
                          param.mcxPinlistVec,
                          param.mcxExpandedPinsVec,
                          param.mcxLimitHighVec,
                          result.mcxMeasureResultHighVec,
                          param.testMode,
                          param.testsuiteName,
                          output,
                          measureHigh,
                          true);
  }
  if("YES" == param.dcScaleSIGUsed)
  {
    LeakageReportToUIUtil(param.dcScaleSIGIsMeasureHighVec,
                          param.dcScaleSIGPinlistVec,
                          param.dcScaleSIGExpandedPinsVec,
                          param.dcScaleSIGLimitHighVec,
                          result.dcScaleSIGMeasureResultHighVec,
                          param.testMode,
                          param.testsuiteName,
                          output,
                          measureHigh);
  }


  if(measureHigh)
  {
    if ("ALL" == param.preFunction)
    {
      if(!param.measureLow)
      {
        LeakageTestUtil::datalogToWindow(
            "Functional result for high level: ",
            result.funcResult[1]);
      }
    }
    else if ("ToStopVEC" == param.preFunction)
    {
      if(!param.measureLow || (param.stopVec[0] != param.stopVec[1]))
      {
        LeakageTestUtil::datalogToWindow(
            "Functional result for high level: ",
            result.funcResult[1]);
      }
    }
    else if ("ToStopCYC" == param.preFunction )
    {
      if(!param.measureLow ||
         (param.stopCyc[0] != param.stopCyc[1]) ||
         (param.lowPortName != param.highPortName))
      {
        LeakageTestUtil::datalogToWindow(
            "Functional result for high level: ",
            result.funcResult[1]);
      }
    }
    else // param.preFunction == "NO"
    {
      //  Do nothing here.
    }
  }
}
private:

static void LeakageJudgeAndLogUtil(
    const vector<bool> &isMeasuredLow,
    const vector<bool> &isMeasuredHigh,
    const vector<string> &pinlistVec,
    const vector<vector<string> > &expandedPinsVec,
    const vector<LIMIT> &limitLowVec,
    const vector<LIMIT> &limitHighVec,
    const vector<string> &limitNameLowVec,
    const vector<string> &limitNameHighVec,
    const vector<MeasurementResultContainer> &resultLow,
    const vector<MeasurementResultContainer> &resultHigh,
    const TM::DCTEST_MODE& mode,
    const string& testsuiteName,
    const bool isLimitAppliedForAllGroups,
    const bool isLimitTableUsed,
    bool& measureLow,
    bool& measureHigh,
    bool& hasBined,
    const bool isLegacyAPIUsed = false)
{
  int siteNumber = 0;
  if(isLegacyAPIUsed)
  {
    siteNumber = CURRENT_SITE_NUMBER();
  }

  if (isLimitTableUsed) // use limit table
  {
    if(!isLimitAppliedForAllGroups)
    {
      LeakageTestUtil::judgeAndLogUtil(isMeasuredLow,
                                       isMeasuredHigh,
                                       pinlistVec,
                                       expandedPinsVec,
                                       limitLowVec,
                                       limitHighVec,
                                       limitNameLowVec,
                                       limitNameHighVec,
                                       resultLow,
                                       resultHigh,
                                       mode,
                                       testsuiteName,
                                       true,
                                       measureLow,
                                       measureHigh,
                                       siteNumber,
                                       hasBined);
    }
    else // one limit applied for all groups
    {
      LeakageTestUtil::judgeAndLogUtilForAllGroups(isMeasuredLow,
                                                   isMeasuredHigh,
                                                   pinlistVec,
                                                   expandedPinsVec,
                                                   limitLowVec,
                                                   limitHighVec,
                                                   limitNameLowVec,
                                                   limitNameHighVec,
                                                   resultLow,
                                                   resultHigh,
                                                   mode,
                                                   testsuiteName,
                                                   true,
                                                   measureLow,
                                                   measureHigh,
                                                   siteNumber,
                                                   hasBined);
    }
  }
  else // use testflow's limit
  {
    if(!isLimitAppliedForAllGroups)
    {
      LeakageTestUtil::judgeAndLogUtil(isMeasuredLow,
                                       isMeasuredHigh,
                                       pinlistVec,
                                       expandedPinsVec,
                                       limitLowVec,
                                       limitHighVec,
                                       limitNameLowVec,
                                       limitNameHighVec,
                                       resultLow,
                                       resultHigh,
                                       mode,
                                       testsuiteName,
                                       false,
                                       measureLow,
                                       measureHigh,
                                       siteNumber,
                                       hasBined);
    }
    else // one limit is applied for all groups
    {
      LeakageTestUtil::judgeAndLogUtilForAllGroups(isMeasuredLow,
                                                   isMeasuredHigh,
                                                   pinlistVec,
                                                   expandedPinsVec,
                                                   limitLowVec,
                                                   limitHighVec,
                                                   limitNameLowVec,
                                                   limitNameHighVec,
                                                   resultLow,
                                                   resultHigh,
                                                   mode,
                                                   testsuiteName,
                                                   false,
                                                   measureLow,
                                                   measureHigh,
                                                   siteNumber,
                                                   hasBined);
    } // end if: for one group 
  }
}

static void LeakageReportToUIUtil(
    const vector<bool> &isMeasuredVec,
    const vector<string> &pinlistVec,
    const vector<vector<string> > &expandedPinsVec,
    const vector<LIMIT> &limitVec,
    const vector<MeasurementResultContainer> &resultVec,
    const TM::DCTEST_MODE& mode,
    const string& testsuiteName,
    const string& output,
    bool& isMeasured,
    const bool isLegacyAPIUsed = false)
{
  vector<string>::size_type j = 0;
  bool bPass = true;

  int siteNumber = 0;
  if(isLegacyAPIUsed)
  {
    siteNumber = CURRENT_SITE_NUMBER();
  }

  for(string::size_type i = 0; i < expandedPinsVec.size(); i++)
  {
    if (isMeasuredVec[i])
    { //report measurement result to UI window
      isMeasured = true;

      switch ( mode )
      {
      case TM::PVAL:
        for ( j = 0; j < expandedPinsVec[i].size(); ++j )
        {
          double dMeasValue = resultVec[i].getPinsValue(expandedPinsVec[i][j],siteNumber);
          LeakageTestUtil::datalogToWindow(
              expandedPinsVec[i][j],
              dMeasValue,
              limitVec[i],
              "uA");
        }
        break;

      case TM::PPF:
        for ( j = 0; j < expandedPinsVec[i].size(); ++j )
        {
          bPass = resultVec[i].getPinPassFail(expandedPinsVec[i][j],siteNumber);
          LeakageTestUtil::datalogToWindow(expandedPinsVec[i][j], bPass);
        }
        break;

      case TM::GPF:
        bPass = resultVec[i].getGlobalPassFail(siteNumber);
        LeakageTestUtil::datalogToWindow(testsuiteName,bPass);
        break;

      default:
        throw Error("LeakageTest::LeakageReportToUIUtil",
                    "Unknown Test Mode",
                    "LeakageTest::LeakageReportToUIUtil");
      }// end switch
    }
  }
}



LeakageTest() {} //private constructor to prevent instantiation.
};    
#endif /*LEAKAGETEST_H_*/
