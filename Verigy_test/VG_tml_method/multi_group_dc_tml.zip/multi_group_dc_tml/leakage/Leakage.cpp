/**
 * (c) Copyright 2011, Verigy Technologies, all rights reserved.
 *
 * Modification History:
 *
 *
 */

//for testmethod framework interfaces
#include "testmethod.hpp"
//for testmethod API interfaces
#include "mapi.hpp"

#include "LeakageTest.hpp"

/**
 *----------------------------------------------------------------------*
 * @testmethod class: Leakage
 *
 * @Purpose: leakage testing
 *
 *----------------------------------------------------------------------*
 * @Description:
 *   ppmu instrument parameter
 *   string ppmuUsed:            {YES | NO }
 *     indicate whether use ppmu to do test or not.
 *   string ppmuPinlist:              {@ | pinlist}
 *     Name of pins to be tested
 *     valid pin types: I,O,IO type digital pins
 *   string ppmuMeasure:              {LOW | HIGH | BOTH}
 *     Measure side
 *   string ppmuForceVoltage:       {mV}
 *     Value of force voltage (for low/high level test).The format of
 *     input value like: 500 that means force voltage for low or high level
 *     test; (500,3800) that means force 500mV for low level test, force
 *     3800mV for high level test.
 *     The base unit is mV.
 *   string ppmuPrecharge:        {ON | OFF}
 *     Enable precharging or not
 *   string ppmuPrechargeVoltage:   {mV}
 *     Value of precharge voltage (for low/high level test).The format of
 *     input value is like: 500 that means precharge voltage for low or high level
 *     test; (500,3800) that means precharge 500mV for low level test, precharge
 *     3800mV for high level test.
 *     The base unit is mV.
 *   string ppmuSettlingTime:       {ms}
 *     Value of settling time (low/high level test). The format of input value
 *     is like: 1.2 that means settling time for low or high level test; (1.2,1.5)
 *     that means 1.2ms settling time for low level test, 1.5ms settling time
 *     for high level test.
 *     The base unit is ms.
 *   string ppmuMeasureMode:          {PAR | SER}
 *     PAR -  parallel
 *     SER -  serial
 *   string ppmuRelaySwitchMode:      {DEFAULT(BBM) | MBB | PARALLEL}
 *     BBM - Break before Make: Open AC,PMU and DC relay, then open
 *           AC relay, Close PMU and open DC relay relay.
 *     MBB - Make before break(close PMU relay, then open AC relay)
 *     PARALLEL - open AC relay and close PMU relay in parallel
 *     notes: for PS400 pin, only PARALLEL mode works.
 *   string ppmuLTestName
 *     Name of limit(s).
 *
 *   spmu instrument parameter
 *   string spmuUsed:            {YES | NO }
 *     indicate whether use spmu to do test or not.
 *   string spmuPinlist:              {@ | pinlist}
 *     Name of pins to be tested
 *     Valid pins: all digital pins.
 *   string spmuMeasure:              {LOW | HIGH | BOTH}
 *     Measure side
 *   string spmuForceVoltage:       {mV}
 *     Value of force voltage (for low/high level test).The format of
 *     input value is like: 500 that means force voltage for low or high level
 *     test; (500,3800) that means force 500mV for low level test, force
 *     3800mV for high level test.
 *     The base unit is mV.
 *   string spmuClampCurrent:   {uA}
 *     Value of clamp current (low level test, SPMU only). The format of
 *     input value is like: 100 that means clamp current for low or high level
 *     test; (100,300) that means clamp current 100uA for low level test,
 *     clamp current 300uA for high level test.
 *     The base unit is uA.
 *   string spmuPrecharge:        {ON | OFF}
 *     Enable precharging or not
 *   string spmuPrechargeVoltage:   {mV}
 *     Value of precharge voltage (for low/high level test).The format of
 *     input value is like: 500 that means precharge voltage for low or high level
 *     test; (500,3800) that means precharge 500mV for low level test, precharge
 *     3800mV for high level test.
 *     The base unit is mV.
 *   string spmuSettlingTime:       {ms}
 *     Value of settling time (low/high level test). The format of input value
 *     is like: 1.2 that means settling time for low or high level test; (1.2,1.5)
 *     that means 1.2ms settling time for low level test, 1.5ms settling time
 *     for high level test.
 *     The base unit is ms.
 *   string spmuMeasureMode:          {PAR | SER}
 *     PAR -  parallel
 *     SER -  serial
 *   string spmuRelaySwitchMode:      {NTBBM | NTMBB}
 *    NTBBM - Non-terminated,Break before Make(open AC relay, then close PMU relay)
 *    NTMBB - Non-terminated,Make before break(close PMU relay, then open AC relay)
 *   string spmuTestName
 *     Name of limit(s).
 *
 *   anolog pmu(mcx) instrument parameter
 *   string mcxUsed:            {YES | NO }
 *     indicate whether use analog pmu to do test or not.
 *   string mcxPinlist:              {@ | pinlist}
 *     Name of pins to be tested
 *     Valid pins: all analog pins.
 *   string mcxMeasure:              {LOW | HIGH | BOTH}
 *     Measure side
 *   string mcxForceVoltage:       {mV}
 *     Value of force voltage (for low/high level test).The format of
 *     input value is like: 500 that means force voltage for low or high level
 *     test; (500,3800) that means force 500mV for low level test, force
 *     3800mV for high level test.
 *     The base unit is mV.
 *   string mcxPrecharge:        {ON | OFF}
 *     Enable precharging or not
 *   string mcxPrechargeVoltage:   {mV}
 *     Value of precharge voltage (for low/high level test).The format of
 *     input value is like: 500 that means precharge voltage for low or high level
 *     test; (500,3800) that means precharge 500mV for low level test, precharge
 *     3800mV for high level test.
 *     The base unit is mV.
 *   string mcxSettlingTime:       {ms}
  *     Value of settling time (low/high level test). The format of input value is
 *     like: 1.2 that means settling time for low or high level test; (1.2,1.5)
 *     that means 1.2ms settling time for low level test, 1.5ms settling time
 *     for high level test.
 *     The base unit is ms.
 *   string mcxMeasureMode:          {PAR | SER}
 *     PAR -  parallel
 *     SER -  serial
 *   string mcxTestName
 *     Name of limit(s).
 *
 *   dc scale instrument in SIG mode parameter
 *   string dcScaleSIGUsed:            {YES | NO }
 *     indicate whether use dcScale to do test or not.
 *   string dcScaleSIGPinlist:              {@ | pinlist}
 *     Name of pins to be tested
 *     Valid pins: all dc scale pins in SIG mode.
 *   string dcScaleSIGMeasure:              {LOW | HIGH | BOTH}
 *     Measure side
 *   string dcScaleSIGForceVoltage:       {mV}
 *     Value of force voltage (for low/high level test).The format of
 *     input value is like: 500 that means force voltage for low or high level
 *     test; (500,3800) that means force 500mV for low level test, force
 *     3800mV for high level test.
 *     The base unit is mV.
 *   string dcScaleSIGClampCurrent:   {uA}
 *     Value of clamp current (low level test). The format of
 *     input value is like: 100 that means clamp current for low or high level
 *     test; (100,300) that means clamp current 100uA for low level test,
 *     clamp current 300uA for high level test.
 *     The base unit is uA.
 *   string dcScaleSIGPrecharge:        {ON | OFF}
 *     Enable precharging or not
 *   string dcScaleSIGPrechargeVoltage:   {mV}
 *     Value of precharge voltage (for low/high level test).The format of
 *     input value is like: 500 that means precharge voltage for low or high level
 *     test; (500,3800) that means precharge 500mV for low level test, precharge
 *     3800mV for high level test.
 *     The base unit is mV.
 *   string dcScaleSIGSettlingTime:       {ms}
 *     Value of settling time (low/high level test). The format of input value is
 *     like: 1.2 that means settling time for low or high level test; (1.2,1.5)
 *     that means 1.2ms settling time for low level test, 1.5ms settling time
 *     for high level test.
 *     The base unit is ms.
 *   string dcScaleSIGMeasureMode:          {PAR | SER}
 *     PAR -  parallel
 *     SER -  serial
 *   string dcScaleSIGRelaySwitchMode:      {NO | NT }
 *    "NO - No relay action \n"
 *    "NT - Only have effect for dcScale pins in PMU mode\n");
 *   string dcScaleSIGTestName
 *     Name of limit(s).
 *
 *   // common parameter for all the instruments
 *   string preFunction:          {NO | ALL | ToStopVEC | ToStopCYC}
 *     Select mode of executing the functional pre-test
 *   int stopVecLow:
 *     Number of stop vector(low level test). When select ToStopVEC,this parameter
 *     has effect. It doesn't support multi-port pattern.
 *   int stopVecHigh:
 *     Number of stop vector(high level test). When select ToStopVec, this parameter
 *     has effect. It doesn't support multi-port pattern.
 *   string stopCycLow:
 *     Number of stop cycle(low level test). When select ToStopCYC, thes parameter
 *     has effect. For single port pattern, the format of input value is like: 12
 *     For multi-port pattern, the format is like 12@portName.
 *   string stopCycHigh:
 *     Number of stop cycle(high level test)When select ToStopCYC, thes parameter
 *     has effect. For single port pattern, the format of input value is like: 13
 *     For multi-port pattern, the format is like 13@portName.
 *   string  checkFunctionalResult : {ON | OFF}
 *     the functional test shall contribute to
 *     the overall test result,
 *     OFF is for not.
 *   string output:               {ReportUI | None}
 *     Print message or not. 
 *     ReportUI - for debug mode
 *     None - for production mode
 *   
 * @Note:
 *
 *
 *----------------------------------------------------------------------*
 */

class Leakage: public testmethod::TestMethod
{
protected:

  // ppmu parameter
  string  ppmuUsed;
  string  ppmuPinlist;
  string  ppmuMeasure;
  string  ppmuForceVoltage;
  string  ppmuPrecharge;
  string  ppmuPrechargeVoltage;
  string  ppmuSettlingTime;
  string  ppmuMeasureMode;
  string  ppmuRelaySwitchMode;
  string  ppmuTestName;

  // spmu parameter
  string  spmuUsed;
  string  spmuPinlist;
  string  spmuMeasure;
  string  spmuForceVoltage;
  string  spmuClampCurrent;
  string  spmuPrecharge;
  string  spmuPrechargeVoltage;
  string  spmuSettlingTime;
  string  spmuMeasureMode;
  string  spmuRelaySwitchMode;
  string  spmuTestName;

  // analog pmu parameter
  string  mcxUsed;
  string  mcxPinlist;
  string  mcxMeasure;
  string  mcxForceVoltage;
  string  mcxPrecharge;
  string  mcxPrechargeVoltage;
  string  mcxSettlingTime;
  string  mcxMeasureMode;
  string  mcxTestName;

  // dc scale pin in SIG mode
  string  dcScaleSIGUsed;
  string  dcScaleSIGPinlist;
  string  dcScaleSIGMeasure;
  string  dcScaleSIGForceVoltage;
  string  dcScaleSIGClampCurrent;
  string  dcScaleSIGPrecharge;
  string  dcScaleSIGPrechargeVoltage;
  string  dcScaleSIGSettlingTime;
  string  dcScaleSIGMeasureMode;
  string  dcScaleSIGRelaySwitchMode;
  string  dcScaleSIGTestName;

  // common parameter
  string  preFunction;
  int  stopVecLow;
  int  stopVecHigh;
  string  stopCycLow; // to support multi-port, this parameter format like: 12@port1
  string  stopCycHigh; // to support multi-port, this parameter format like: 13@port2
  string  checkFunctionalResult;
  string  output;

  bool isParameterChanged;
  // Assume all sites' parameters are the same
  LeakageTest::LeakageTestParam param;

protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    // parameters for PPMU
    addParameter("UsePPMU",
                 "string",
                 &ppmuUsed)
      .setDefault("YES")
      .setOptions("YES:NO");
    addParameter("UsePPMU.pinlist",
                 "PinString",
                 &ppmuPinlist)
      .setDefault("");
    addParameter("UsePPMU.measure",
                 "string",
                 &ppmuMeasure)
      .setDefault("BOTH")
      .setComment("LOW: low level test\n"
                  "HIGH: high level test\n"
                  "BOTH: low and high level test");
    addParameter("UsePPMU.forceVoltage_mV",
                 "string",
                 &ppmuForceVoltage)
      .setDefault("(400,3800)")
      .setComment("force voltage for measurement,The format of input value is like:\n"
                  "400 that means force voltage for low or high level test; \n"
                  "(400,3800) that means force 400mV for low level test, \n"
                  "force 3800mV for high level test.");
    addParameter("UsePPMU.preCharge",
                 "string",
                 &ppmuPrecharge)
      .setDefault("ON")
      .setComment("options: ON  OFF");
    addParameter("UsePPMU.prechargeVoltage_mV",
                 "string",
                 &ppmuPrechargeVoltage)
      .setDefault("(0.0, 0.0)")
      .setComment("precharge PPMU for measurement, The format of input value is like:\n"
                  "0.0 that means precharge voltage for low or high level test;\n"
                  "(0.0,0.0) that means precharge 0.0mV for low level test, \n"
                  "precharge 0.0mV for high level test");
    addParameter("UsePPMU.settlingTime_ms",
                 "string",
                 &ppmuSettlingTime)
      .setDefault("(1.0,1.2)")
      .setComment("settling time for measurement,The format of input value is like: \n"
                  "1.2 that means settling time for low or high level test; \n"
                  "(1.2,1.5) that means 1.2ms settling time for low level test,\n"
                  "1.5ms settling time for high level test.");
    addParameter("UsePPMU.measureMode",
                 "string",
                 &ppmuMeasureMode)
      .setDefault("PAR")
      .setComment("options: PAR  SER\n PAR - parallel; SER - serial");
    addParameter("UsePPMU.relaySwitchMode",
                 "string",
                 &ppmuRelaySwitchMode)
      .setDefault("DEFAULT(BBM)")
      .setComment("options: DEFAULT(BBM)  MBB  PARALLEL \n"
                  "only 'PARALLEL' with unterminated works for PS400 pin.\n"
                  "DEFAULT(BBM) - Break before Make(open AC relay, then close PMU relay)\n"
                  "MBB - Make before break(close PMU relay, then open AC relay)\n"
                  "PARALLEL - open AC relay and close PMU relay in parallel");
    addParameter("UsePPMU.testName",
                 "string",
                  &ppmuTestName)
      .setComment("Name of limit(s).");

    // parameter for SPMU
    addParameter("UseSPMU",
                 "string",
                 &spmuUsed)
      .setDefault("NO")
      .setOptions("YES:NO");
    addParameter("UseSPMU.pinlist",
                 "PinString",
                 &spmuPinlist)
      .setDefault("");
    addParameter("UseSPMU.measure",
                 "string",
                 &spmuMeasure)
      .setDefault("BOTH")
      .setComment("LOW: low level test\n"
                  "HIGH: high level test\n"
                  "BOTH: low and high level test");
    addParameter("UseSPMU.forceVoltage_mV",
                 "string",
                 &spmuForceVoltage)
      .setDefault("(400,3800)")
      .setComment("force voltage for measurement,The format of input value is like:\n"
                  "400 that means force voltage for low or high level test; \n"
                  "(400,3800) that means force 400mV for low level test, \n"
                  "force 3800mV for high level test.");
    addParameter("UseSPMU.preCharge",
                 "string",
                 &spmuPrecharge)
      .setDefault("ON")
      .setComment("options: ON  OFF");
    addParameter("UseSPMU.prechargeVoltage_mV",
                 "string",
                 &spmuPrechargeVoltage)
      .setDefault("(0.0, 0.0)")
      .setComment("precharge SPMU for measurement, The format of input value is like:\n"
                  "0.0 that means precharge voltage for low or high level test;\n"
                  "(0.0,0.0) that means precharge 0.0mV for low level test, \n"
                  "precharge 0.0mV for high level test");
    addParameter("UseSPMU.clampCurrent_uA",
                 "string",
                 &spmuClampCurrent)
      .setDefault("(100,300)")
      .setComment("SPMU current clamp for measurement, The format of input value is like: \n"
                  "100 that means clamp current for low or high level test;\n"
                  "(100,300) that means clamp current 100uA for low level test,\n"
                  "clamp current 300uA for high level test.");
    addParameter("UseSPMU.settlingTime_ms",
                 "string",
                 &spmuSettlingTime)
      .setDefault("(1.0,1.2)")
      .setComment("settling time for measurement,The format of input value is like: \n"
                  "1.2 that means settling time for low or high level test; \n"
                  "(1.2,1.5) that means 1.2ms settling time for low level test,\n"
                  "1.5ms settling time for high level test.");
    addParameter("UseSPMU.measureMode",
                 "string",
                 &spmuMeasureMode)
      .setDefault("PAR")
      .setComment("optinos:PAR  SER\n PAR - parallel; SER - serial.");
    addParameter("UseSPMU.relaySwitchMode",
                 "string",
                 &spmuRelaySwitchMode)
      .setDefault("NTBBM")
      .setComment("options: NTBBM  NTMBB\n"
                  "NTBBM - no terminated,Break before Make(open AC relay, then close PMU relay. \n"
                  "NTMBB - no terminated,Make before break(close PMU relay, then open AC relay) \n");
    addParameter("UseSPMU.testName",
                 "string",
                 &spmuTestName)
      .setComment("Name of limit(s).");

    // parameter for Analog PMU
    addParameter("UseMCX-PMU",
                 "string",
                 &mcxUsed)
      .setDefault("NO")
      .setOptions("YES:NO");
    addParameter("UseMCX-PMU.pinlist",
                 "PinString",
                 &mcxPinlist)
      .setDefault("");
    addParameter("UseMCX-PMU.measure",
                 "string",
                 &mcxMeasure)
      .setDefault("BOTH")
      .setComment("LOW: low level test\n"
                  "HIGH: high level test\n"
                  "BOTH: low and high level test");
    addParameter("UseMCX-PMU.forceVoltage_mV",
                 "string",
                 &mcxForceVoltage)
      .setDefault("(400,3800)")
      .setComment("force voltage for measurement,The format of input value is like:\n"
                  "400 that means force voltage for low or high level test; \n"
                  "(400,3800) that means force 400mV for low level test, \n"
                  "force 3800mV for high level test.");
    addParameter("UseMCX-PMU.preCharge",
                 "string",
                 &mcxPrecharge)
      .setDefault("ON")
      .setComment("options: ON  OFF");
    addParameter("UseMCX-PMU.prechargeVoltage_mV",
                 "string",
                 &mcxPrechargeVoltage)
      .setDefault("(0.0, 0.0)")
      .setComment("precharge Analog PMU for measurement, The format of input value is like:\n"
                  "0.0 that means precharge voltage for low or high level test;\n"
                  "(0.0,0.0) that means precharge 0.0mV for low level test, \n"
                  "precharge 0.0mV for high level test");
    addParameter("UseMCX-PMU.measureMode",
                 "string",
                 &mcxMeasureMode)
      .setDefault("PAR")
      .setComment("optinos: PAR  SER\n PAR - paralle; SER - serial");
    addParameter("UseMCX-PMU.settlingTime_ms",
                 "string",
                 &mcxSettlingTime)
      .setDefault("(1.0,1.2)")
      .setComment("settling time for low measurement, The format of input value is like: \n"
                  "1.2 that means settling time for low or high level test; \n"
                  "(1.2,1.5) that means 1.2ms settling time for low level test,\n"
                  "1.5ms settling time for high level test.");
    addParameter("UseMCX-PMU.testName",
                 "string",
                 &mcxTestName)
      .setComment("Name of limit(s).");

    // parameter for dc scale pin in SIG mode
    addParameter("UseDcScaleSIG",
                 "string",
                 &dcScaleSIGUsed)
      .setDefault("NO")
      .setOptions("YES:NO");
    addParameter("UseDcScaleSIG.pinlist",
                 "PinString",
                 &dcScaleSIGPinlist)
      .setDefault("");
    addParameter("UseDcScaleSIG.measure",
                 "string",
                 &dcScaleSIGMeasure)
      .setDefault("BOTH")
      .setComment("LOW: low level test\n"
                  "HIGH: high level test\n"
                  "BOTH: low and high level test");
    addParameter("UseDcScaleSIG.forceVoltage_mV",
                 "string",
                 &dcScaleSIGForceVoltage)
      .setDefault("(400,3800)")
      .setComment("force voltage for measurement,The format of input value is like:\n"
                  "400 that means force voltage for low or high level test; \n"
                  "(400,3800) that means force 400mV for low level test, \n"
                  "force 3800mV for high level test.");
    addParameter("UseDcScaleSIG.preCharge",
                 "string",
                 &dcScaleSIGPrecharge)
      .setDefault("ON")
      .setComment("options: ON  OFF");
    addParameter("UseDcScaleSIG.prechargeVoltage_mV",
                 "string",
                 &dcScaleSIGPrechargeVoltage)
      .setDefault("(0.0,0.0)")
      .setComment("precharge SPMU for measurement, The format of input value is like:\n"
                  "0.0 that means precharge voltage for low or high level test;\n"
                  "(0.0,0.0) that means precharge 0.0mV for low level test, \n"
                  "precharge 0.0mV for high level test");
    addParameter("UseDcScaleSIG.clampCurrent_uA",
                 "string",
                 &dcScaleSIGClampCurrent)
      .setDefault("(100,300)")
      .setComment("Analog PMU current clamp for measurement, The format of input value is like: \n"
                  "100 that means clamp current for low or high level test;\n"
                  "(100,300) that means clamp current 100uA for low level test,\n"
                  "clamp current 300uA for high level test.");
    addParameter("UseDcScaleSIG.settlingTime_ms",
                 "string",
                 &dcScaleSIGSettlingTime)
      .setDefault("(1.0,1.2)")
      .setComment("settling time for measurement,The format of input value is like: \n"
                  "1.2 that means settling time for low or high level test; \n"
                  "(1.2,1.5) that means 1.2ms settling time for low level test,\n"
                  "1.5ms settling time for high level test.");
    addParameter("UseDcScaleSIG.measureMode",
                 "string",
                 &dcScaleSIGMeasureMode)
      .setDefault("PAR")
      .setComment("optinos: PAR SER \n PAR - paralle; SER - serial");
    addParameter("UseDcScaleSIG.relaySwitchMode",
                 "string",
                 &dcScaleSIGRelaySwitchMode)
      .setDefault("NO")
      .setComment("options: NO  NT\n"
                  "NO - No relay action \n"
                  "NT - Only have effect for dcScale pins in PMU mode\n");
    addParameter("UseDcScaleSIG.testName",
                 "string",
                 &dcScaleSIGTestName)
      .setComment("Name of limit(s).");


    // common parameters
    addParameter("preFunction",
                 "string",
                 &preFunction)
      .setDefault("NO")
      .setOptions("NO:ALL:ToStopVEC:ToStopCYC");
    addParameter("stopVecLow",
                 "int",
                 &stopVecLow)
      .setComment("Number of stop vector(low level test).\n"
                  "When select ToStopVec, this parameter has effect.\n"
                  "It doesn't support multi-port pattern.");
    addParameter("stopVecHigh",
                 "int",
                 &stopVecHigh)
      .setComment("Number of stop vector(high level test).\n"
                  "When select ToStopVec, this parameter has effect.\n"
                  "It doesn't support multi-port pattern.");
    addParameter("stopCycLow",
                 "string",
                 &stopCycLow)
      .setComment("Number of stop cycle(low level test). \n"
                  "When select ToStopCYC, this parameter has effect. \n"
                  "For single port pattern, the format of input value is like: 12 \n"
                  "For multi-port pattern, the format is like 12@portName.");
    addParameter("stopCycHigh",
                 "string",
                 &stopCycHigh)
      .setComment("Number of stop cycle(high level test). \n"
                  "When select ToStopCYC, thes parameter has effect. \n"
                  "For single port pattern, the format of input value is like: 12 \n"
                  "For multi-port pattern, the format is like 12@portName.");
    addParameter("checkFunction",
                 "string",
                 &checkFunctionalResult)
      .setDefault("ON")
      .setOptions("ON:OFF")
      .setComment("determine whether the functional test result \n"
                  "shall contribute to the overall test result");
    addParameter("output",
                 "string",
                 &output)
      .setDefault("None")
      .setOptions("ReportUI:None");

    isParameterChanged = true;

  }
  
  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
    static LeakageTest::LeakageTestResult result;
     
    ON_FIRST_INVOCATION_BEGIN();
     /*
      * Process all parameters needed in test. Actually this function is
      * called once under multisite because all input parameters should be
      * the same through all sites. The processed parameters are stored into
      * the static variable 'param' for later reference on all sites.
      */    
      if(isParameterChanged)
      {
        LeakageTest::processParameters(ppmuUsed,  // ppmu parameters block begin
                                       ppmuPinlist,
                                       ppmuMeasure,
                                       ppmuForceVoltage,
                                       ppmuPrecharge,
                                       ppmuPrechargeVoltage,
                                       ppmuSettlingTime,
                                       ppmuMeasureMode,
                                       ppmuRelaySwitchMode,
                                       ppmuTestName, // ppmu parameters block end

                                       spmuUsed, // spmu parameters block begin
                                       spmuPinlist,
                                       spmuMeasure,
                                       spmuForceVoltage,
                                       spmuPrecharge,
                                       spmuPrechargeVoltage,
                                       spmuClampCurrent,
                                       spmuSettlingTime,
                                       spmuMeasureMode,
                                       spmuRelaySwitchMode,
                                       spmuTestName, // spmu parameters block end

                                       mcxUsed, // analog pmu parameters block begin
                                       mcxPinlist,
                                       mcxMeasure,
                                       mcxForceVoltage,
                                       mcxPrecharge,
                                       mcxPrechargeVoltage,
                                       mcxSettlingTime,
                                       mcxMeasureMode,
                                       mcxTestName, // analog pmu paramters block end

                                       dcScaleSIGUsed, // dc scale pin in SIG mode parameters block begin
                                       dcScaleSIGPinlist,
                                       dcScaleSIGMeasure,
                                       dcScaleSIGForceVoltage,
                                       dcScaleSIGPrecharge,
                                       dcScaleSIGPrechargeVoltage,
                                       dcScaleSIGClampCurrent,
                                       dcScaleSIGSettlingTime,
                                       dcScaleSIGMeasureMode,
                                       dcScaleSIGRelaySwitchMode,
                                       dcScaleSIGTestName, // dc scale pin in SIG parameters block end

                                       preFunction,
                                       stopVecLow,
                                       stopVecHigh,
                                       stopCycLow,
                                       stopCycHigh,
                                       checkFunctionalResult,

                                       param);
        isParameterChanged = false;
      }

    ON_FIRST_INVOCATION_END();
    /*
     * Execute measurement with the specified 'param' and store results 
     * into the 'result'. The multisite handling, i.e.
     * ON_FIRST_INVOCATION block are executed inside this function.
     */

    LeakageTest::doMeasurement(param,result);

    /*
     * Judge and datalog based on the 'result'. This function uses
     * testsuite name as test name, so if you'd like to use your own
     * test names for judgement and datalogging it's needed to modify
     * this funciton or create new one.
     */

    LeakageTest::judgeAndDatalog(param,result);

    /*
     * Output contents of the 'result' to Report Window if specified by
     * the "output" parameter.
     */

    LeakageTest::reportToUI(param,result,output);
    
    return ;
  }
  
  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   *
   *Note: TestMethod API should not be used in this method.
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    isParameterChanged = true;
    if("UsePPMU" == parameterIdentifier)
    {
      bool toVisible = ("YES" == ppmuUsed);
      getParameter("UsePPMU.pinlist").setVisible(toVisible);
      getParameter("UsePPMU.measure").setVisible(toVisible);
      getParameter("UsePPMU.forceVoltage_mV").setVisible(toVisible);
      getParameter("UsePPMU.preCharge").setVisible(toVisible);
      getParameter("UsePPMU.prechargeVoltage_mV").setVisible(toVisible);
      getParameter("UsePPMU.settlingTime_ms").setVisible(toVisible);
      getParameter("UsePPMU.measureMode").setVisible(toVisible);
      getParameter("UsePPMU.relaySwitchMode").setVisible(toVisible);
      getParameter("UsePPMU.testName").setVisible(toVisible);
    }
    else if("UseSPMU" == parameterIdentifier)
    {
      bool toVisible = ("YES" == spmuUsed);
      getParameter("UseSPMU.pinlist").setVisible(toVisible);
      getParameter("UseSPMU.measure").setVisible(toVisible);
      getParameter("UseSPMU.forceVoltage_mV").setVisible(toVisible);
      getParameter("UseSPMU.preCharge").setVisible(toVisible);
      getParameter("UseSPMU.prechargeVoltage_mV").setVisible(toVisible);
      getParameter("UseSPMU.clampCurrent_uA").setVisible(toVisible);
      getParameter("UseSPMU.settlingTime_ms").setVisible(toVisible);
      getParameter("UseSPMU.measureMode").setVisible(toVisible);
      getParameter("UseSPMU.relaySwitchMode").setVisible(toVisible);
      getParameter("UseSPMU.testName").setVisible(toVisible);
    }
    else if("UseMCX-PMU" == parameterIdentifier)
    {
      bool toVisible = ("YES" == mcxUsed);
      getParameter("UseMCX-PMU.pinlist").setVisible(toVisible);
      getParameter("UseMCX-PMU.measure").setVisible(toVisible);
      getParameter("UseMCX-PMU.forceVoltage_mV").setVisible(toVisible);
      getParameter("UseMCX-PMU.preCharge").setVisible(toVisible);
      getParameter("UseMCX-PMU.prechargeVoltage_mV").setVisible(toVisible);
      getParameter("UseMCX-PMU.settlingTime_ms").setVisible(toVisible);
      getParameter("UseMCX-PMU.measureMode").setVisible(toVisible);
      getParameter("UseMCX-PMU.testName").setVisible(toVisible);
    }
    else if("UseDcScaleSIG" == parameterIdentifier)
    {
      bool toVisible = ("YES" == dcScaleSIGUsed);
      getParameter("UseDcScaleSIG.pinlist").setVisible(toVisible);
      getParameter("UseDcScaleSIG.measure").setVisible(toVisible);
      getParameter("UseDcScaleSIG.forceVoltage_mV").setVisible(toVisible);
      getParameter("UseDcScaleSIG.preCharge").setVisible(toVisible);
      getParameter("UseDcScaleSIG.prechargeVoltage_mV").setVisible(toVisible);
      getParameter("UseDcScaleSIG.clampCurrent_uA").setVisible(toVisible);
      getParameter("UseDcScaleSIG.settlingTime_ms").setVisible(toVisible);
      getParameter("UseDcScaleSIG.measureMode").setVisible(toVisible);
      getParameter("UseDcScaleSIG.relaySwitchMode").setVisible(toVisible);
      getParameter("UseDcScaleSIG.testName").setVisible(toVisible);
    }
    else if("preFunction" == parameterIdentifier)
    {
      if("NO" == preFunction)
      {
        getParameter("stopVecLow").setVisible(false);
        getParameter("stopVecHigh").setVisible(false);
        getParameter("stopCycLow").setVisible(false);
        getParameter("stopCycHigh").setVisible(false);
        getParameter("checkFunction").setVisible(false);
      }
      else if("ALL" == preFunction)
      {
        getParameter("stopVecLow").setVisible(false);
        getParameter("stopVecHigh").setVisible(false);
        getParameter("stopCycLow").setVisible(false);
        getParameter("stopCycHigh").setVisible(false);
        getParameter("checkFunction").setVisible(true);
      }
      else if("ToStopVEC" == preFunction)
      {
        getParameter("stopVecLow").setVisible(true);
        getParameter("stopVecHigh").setVisible(true);
        getParameter("stopCycLow").setVisible(false);
        getParameter("stopCycHigh").setVisible(false);
        getParameter("checkFunction").setVisible(true);
      }
      else if("ToStopCYC" == preFunction)
      {
        getParameter("stopVecLow").setVisible(false);
        getParameter("stopVecHigh").setVisible(false);
        getParameter("stopCycLow").setVisible(true);
        getParameter("stopCycHigh").setVisible(true);
        getParameter("checkFunction").setVisible(true);
      }
    }
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string  getComment() const
  {
     static string comment = "version: tml_7.1.2_2.1.4";
     return comment;
  }
};

REGISTER_TESTMETHOD("DcTest.Leakage", Leakage);
