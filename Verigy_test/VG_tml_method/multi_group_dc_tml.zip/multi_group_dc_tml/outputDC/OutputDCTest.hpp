#ifndef OUTPUTDCTEST_H_
#define OUTPUTDCTEST_H_

#include "OutputDCTestUtil.hpp"
#include <float.h>

typedef OutputDCTestUtil::MeasurementResultContainer MeasurementResultContainer;

/***************************************************************************
 *                    output dc test class 
 ***************************************************************************
 */  
class OutputDcTest
{
public:
  // two kinds of output level
  enum MeasuredLevelType { LOW_LEVEL = 0, HIGH_LEVEL = 1 };

/*
 *----------------------------------------------------------------------*
 *         test parameters container                                    *
 *----------------------------------------------------------------------*
 */ 

  struct OutputDCTestParam
  {
    string ppmuUsed;
    // original input parameters
    vector<string>  ppmuPinlistVec;
    vector<string>  ppmuMeasuredLevelVec;     // LOW,HIGH,BOTH
    vector<double>  ppmuForceCurrentLowVec;
    vector<double>  ppmuForceCurrentHighVec;
    vector<double>  ppmuSettlingTimeLowVec;
    vector<double>  ppmuSettlingTimeHighVec;
    vector<string>  ppmuTerminationVec;
    vector<LIMIT>   ppmuLimitLowVec;
    vector<LIMIT>   ppmuLimitHighVec;
    vector<string>  ppmuLimitNameLowVec;
    vector<string>  ppmuLimitNameHighVec;

    // new generated parameter for convenience
    vector<bool> ppmuIsMeasureLowVec;
    vector<bool> ppmuIsMeasureHighVec;
    vector<vector<string> >  ppmuExpandedPinsVec; // expanded and validated pins stored in Vector
    vector<bool> ppmuIsHVPinsVec;  //true if pins in the list are all HV pins
    
    bool ppmuMeasureLow;
    bool ppmuMeasureHigh;
    bool isPPMULimitAppliedForAllGroups;

    string spmuUsed;
    // original input parameters
    vector<string>  spmuPinlistVec;
    vector<string>  spmuMeasuredLevelVec;     // LOW,HIGH,BOTH
    vector<double>  spmuForceCurrentLowVec;
    vector<double>  spmuForceCurrentHighVec;
    vector<double>  spmuClampVoltageLowVec;
    vector<double>  spmuClampVoltageHighVec;
    vector<double>  spmuSettlingTimeLowVec;
    vector<double>  spmuSettlingTimeHighVec;
    vector<string>  spmuTerminationVec;
    vector<LIMIT>   spmuLimitLowVec;
    vector<LIMIT>   spmuLimitHighVec;
    vector<string>  spmuLimitNameLowVec;
    vector<string>  spmuLimitNameHighVec;

    // new generated parameter for convenience
    vector<bool> spmuIsMeasureLowVec;
    vector<bool> spmuIsMeasureHighVec;
    vector<vector<string> >  spmuExpandedPinsVec; // expanded and validated pins stored in Vector
    
    bool spmuMeasureLow;
    bool spmuMeasureHigh;
    bool isSPMULimitAppliedForAllGroups;

    string boardADCUsed;
    // original input parameters
    vector<string>  boardADCPinlistVec;
    vector<string>  boardADCMeasuredLevelVec;     // LOW,HIGH,BOTH
    vector<double>  boardADCSettlingTimeLowVec;
    vector<double>  boardADCSettlingTimeHighVec;
    vector<string>  boardADCTerminationVec;
    vector<LIMIT>   boardADCLimitLowVec;
    vector<LIMIT>   boardADCLimitHighVec;
    vector<string>  boardADCLimitNameLowVec;
    vector<string>  boardADCLimitNameHighVec;

    // new generated parameter for convenience
    vector<bool> boardADCIsMeasureLowVec;
    vector<bool> boardADCIsMeasureHighVec;
    vector<vector<string> >  boardADCExpandedPinsVec; // expanded and validated pins stored in Vector
    vector<bool> boardADCIsHVPinsVec;  //true if pins in the list are all HV pins
    bool boardADCMeasureLow;
    bool boardADCMeasureHigh;
    bool isBoardADCLimitAppliedForAllGroups;

    string activeLoadUsed;
    // original input parameters
    vector<string>  activeLoadPinlistVec;
    vector<string>  activeLoadMeasuredLevelVec;     // LOW,HIGH,BOTH
    vector<double>  activeLoadForceCurrentLowVec;
    vector<double>  activeLoadForceCurrentHighVec;
    vector<LIMIT>   activeLoadLimitLowVec;
    vector<LIMIT>   activeLoadLimitHighVec;
    vector<string>  activeLoadLimitNameLowVec;
    vector<string>  activeLoadLimitNameHighVec;

    // new generated parameter for convenience
    vector<bool> activeLoadIsMeasureLowVec;
    vector<bool> activeLoadIsMeasureHighVec;
    vector<vector<string> >  activeLoadExpandedPinsVec; // expanded and validated pins stored in Vector
    
    bool activeLoadMeasureLow;
    bool activeLoadMeasureHigh;
    bool isActiveLoadLimitAppliedForAllGroups;

    // common parameter(s)
    string cycNum[2];
    string searchType;
    string checkFunctionalResult;

    // new generated parameter for convenience
    string testsuiteName;   // current testsuite name
    TM::DCTEST_MODE testMode;
    bool measureLow;
    bool measureHigh;
    bool hasPmuOrBoardADC;
    
    bool isLimitTableUsed;// if limit table is used

    //initialize stuff to some defaults.
    void init()
    {
      ppmuUsed = "";
      ppmuPinlistVec.clear();
      ppmuMeasuredLevelVec.clear();
      ppmuForceCurrentLowVec.clear();
      ppmuForceCurrentHighVec.clear();
      ppmuSettlingTimeLowVec.clear();
      ppmuSettlingTimeHighVec.clear();
      ppmuTerminationVec.clear();
      ppmuLimitLowVec.clear();
      ppmuLimitHighVec.clear();
      ppmuLimitNameLowVec.clear();
      ppmuLimitNameHighVec.clear();
      ppmuExpandedPinsVec.clear();
      ppmuIsHVPinsVec.clear();
      ppmuMeasureLow = false;
      ppmuMeasureHigh = false;
      isPPMULimitAppliedForAllGroups = false;

      spmuUsed = "";
      spmuPinlistVec.clear();
      spmuMeasuredLevelVec.clear();
      spmuForceCurrentLowVec.clear();
      spmuForceCurrentHighVec.clear();
      spmuClampVoltageLowVec.clear();
      spmuClampVoltageHighVec.clear();
      spmuSettlingTimeLowVec.clear();
      spmuSettlingTimeHighVec.clear();
      spmuTerminationVec.clear();
      spmuLimitLowVec.clear();
      spmuLimitHighVec.clear();
      spmuLimitNameLowVec.clear();
      spmuLimitNameHighVec.clear();
      spmuExpandedPinsVec.clear();
      spmuMeasureLow = false;
      spmuMeasureHigh = false;
      isSPMULimitAppliedForAllGroups = false;

      boardADCUsed = "";
      boardADCPinlistVec.clear();
      boardADCMeasuredLevelVec.clear();
      boardADCSettlingTimeLowVec.clear();
      boardADCSettlingTimeHighVec.clear();
      boardADCTerminationVec.clear();
      boardADCLimitLowVec.clear();
      boardADCLimitHighVec.clear();
      boardADCLimitNameLowVec.clear();
      boardADCLimitNameHighVec.clear();
      boardADCExpandedPinsVec.clear();
      boardADCIsHVPinsVec.clear();
      boardADCMeasureLow = false;
      boardADCMeasureHigh = false;
      isBoardADCLimitAppliedForAllGroups = false;

      activeLoadUsed = "";
      activeLoadPinlistVec.clear();
      activeLoadMeasuredLevelVec.clear();
      activeLoadForceCurrentLowVec.clear();
      activeLoadForceCurrentHighVec.clear();
      activeLoadLimitLowVec.clear();
      activeLoadLimitHighVec.clear();
      activeLoadLimitNameLowVec.clear();
      activeLoadLimitNameHighVec.clear();
      activeLoadExpandedPinsVec.clear();
      activeLoadMeasureLow = false;
      activeLoadMeasureHigh = false;
      isActiveLoadLimitAppliedForAllGroups = false;

      testsuiteName = "";
      hasPmuOrBoardADC = false;
      testMode = TM::GPF;
      measureLow = false;
      measureHigh = false;

      cycNum[0] = "";
      cycNum[1] = "";
      searchType = "";
      checkFunctionalResult = "";
      isLimitTableUsed = false;
    }
    // default constructor for intializing parameters
    OutputDCTestParam()
    {        
      init();
    }
  };

/*
 *----------------------------------------------------------------------*
 *         test results container                                       *
 *----------------------------------------------------------------------*
 */
  struct OutputDCTestResult
  {
    /**
     * result container per site:
     * for value, the unit is: V
     */
    vector<MeasurementResultContainer> ppmuMeasureResultLowVec;
    vector<MeasurementResultContainer> ppmuMeasureResultHighVec;

    vector<MeasurementResultContainer> spmuMeasureResultLowVec;
    vector<MeasurementResultContainer> spmuMeasureResultHighVec;

    vector<MeasurementResultContainer> boardADCMeasureResultLowVec;
    vector<MeasurementResultContainer> boardADCMeasureResultHighVec;

    vector<MeasurementResultContainer> activeLoadMeasureResultLowVec;
    vector<MeasurementResultContainer> activeLoadMeasureResultHighVec;

    MeasurementResultContainer activeLoadMeasureGlobleResult[2];

    bool funcResult; //true: PASS, false: FAIL
    
    // initialize all stuffs to some defaults.
    void init()
    {
      ppmuMeasureResultLowVec.clear();
      ppmuMeasureResultHighVec.clear();

      spmuMeasureResultLowVec.clear();
      spmuMeasureResultHighVec.clear();

      boardADCMeasureResultLowVec.clear();
      boardADCMeasureResultHighVec.clear();

      activeLoadMeasureResultLowVec.clear();
      activeLoadMeasureResultHighVec.clear();
      activeLoadMeasureGlobleResult[0].init();
      activeLoadMeasureGlobleResult[1].init();

      funcResult =  true;
    }
    // default constructor
    OutputDCTestResult()
    {
      init();
    }
  };
  

/*
 *----------------------------------------------------------------------*
 *         public interfaces of output dc test                          *
 *----------------------------------------------------------------------*
 */
 
/*
 *----------------------------------------------------------------------*
 * Routine: processParameters
 *
 * Purpose: parse input parameters and setup internal parameters
 *
 *----------------------------------------------------------------------*
 * Description:
 *   
 * Note:
 *----------------------------------------------------------------------*
 */
static void processParameters(
    const string& ppmu_used, // ppmu parameters block begin
    const string& ppmuPinlist,
    const string& ppmuMeasuredLevel,
    const string& ppmuForceCurrent_uA,
    const string& ppmuSettlingTime_ms,
    const string& ppmuTermination,
    const string& ppmuTestName, // ppmu parameters block end

    const string& spmu_used, // spmu parameters block begin
    const string& spmuPinlist,
    const string& spmuMeasuredLevel,
    const string& spmuForceCurrent_uA,
    const string& spmuClampVoltage_mV,
    const string& spmuSettlingTime_ms,
    const string& spmuTermination,
    const string& spmuTestName, // spmu parameters block end

    const string& boardADC_used, // boardADC parameters block begin
    const string& boardADCPinlist,
    const string& boardADCMeasuredLevel,
    const string& boardADCSettlingTime_ms,
    const string& boardADCTermination,
    const string& boardADCTestName, // boardADC parameters block end

    const string& activeLoad_used, // activeLoad parameters block begin
    const string& activeLoadPinlist,
    const string& activeLoadMeasuredLevel,
    const string& activeLoadForceCurrent_uA,
    const string& activeLoadTestName, // activeLoad parameters block end

    const string& vectorRange,
    const string& checkFunctionalResult,
    OutputDCTestParam& param)
{
  //initial param
  param.init();

  GET_TESTSUITE_NAME(param.testsuiteName);
  param.testMode = OutputDCTestUtil::getMode();

  /**
   *this map is used to store the relationship: pin group instrument
   * map< string, pair<string,string> >
   *        |            |        |
   *        |            |        |
   *     pinName     groupName  InstrumentName
   *
   * we use this map to check that whether there are the same pin exist
   * in different groups or not.
   */
  map<string, pair<string, string> > pinAndGroupMap;

  // check whether limit table is used.
  TesttableLimitHelper testtableHelper(param.testsuiteName);

  string tempString = OutputDCTestUtil::trim(ppmu_used);
  if("YES" == tempString || "NO" == tempString )
  {
    param.ppmuUsed = tempString;
  }
  else
  {
    throw Error("OutputDCTest::processParameters()",
                "UsePPMU must be YES or NO",
                "OutputDCTest::processParameters()");
  }

  tempString = OutputDCTestUtil::trim(spmu_used);
  if("YES" == tempString || "NO" == tempString )
  {
    param.spmuUsed = tempString;
  }
  else
  {
    throw Error("OutputDCTest::processParameters()",
                "UseSPMU must be YES or NO",
                "OutputDCTest::processParameters()");
  }

  tempString = OutputDCTestUtil::trim(boardADC_used);
  if("YES" == tempString || "NO" == tempString )
  {
    param.boardADCUsed = tempString;
  }
  else
  {
    throw Error("OutputDCTest::processParameters()",
                "UseBoardADC must be YES or NO",
                "OutputDCTest::processParameters()");
  }

  tempString = OutputDCTestUtil::trim(activeLoad_used);
  if("YES" == tempString || "NO" == tempString )
  {
    param.activeLoadUsed = tempString;
  }
  else
  {
    throw Error("OutputDCTest::processParameters()",
                "UseActiveLoad must be YES or NO",
                "OutputDCTest::processParameters()");
  }

  if("YES" == param.ppmuUsed)
  {
    vector<string> ppmuForceCurrentVec;
    vector<string> ppmuSettlingTimeVec;
    vector<string> ppmuTestNameVec;

    OutputDCTestUtil::parseListOfString(ppmuPinlist,param.ppmuPinlistVec);
    OutputDCTestUtil::parseListOfString(ppmuMeasuredLevel,param.ppmuMeasuredLevelVec);
    OutputDCTestUtil::parseListOfString(ppmuForceCurrent_uA,
                                        ppmuForceCurrentVec,
                                        ',',
                                        true);
    OutputDCTestUtil::parseListOfString(ppmuSettlingTime_ms,
                                        ppmuSettlingTimeVec,
                                        ',',
                                        true);
    OutputDCTestUtil::parseListOfString(ppmuTestName,
                                        ppmuTestNameVec,
                                        ',',
                                        true);
    OutputDCTestUtil::parseListOfString(ppmuTermination,param.ppmuTerminationVec);

    vector<string>::size_type groupSize = param.ppmuPinlistVec.size();
    if(groupSize == 0)
    {
      throw Error("OutputDCTest::processParameters()",
                  "PPMU: the pinlist groups can not be empty.",
                  "OutputDCTest::processParameters()");
    }

    OutputDCTestUtil::checkParameter(groupSize,
                                     param.ppmuMeasuredLevelVec.size(),
                                     "PPMU",
                                     "measuredLevel",
                                     param.ppmuMeasuredLevelVec);

    OutputDCTestUtil::checkParameter(groupSize,
                                     ppmuForceCurrentVec.size(),
                                     "PPMU",
                                     "forceCurrent_uA",
                                     ppmuForceCurrentVec);

    OutputDCTestUtil::checkParameter(groupSize,
                                     ppmuSettlingTimeVec.size(),
                                     "PPMU",
                                     "settlingTime_ms",
                                     ppmuSettlingTimeVec);

    OutputDCTestUtil::checkParameter(groupSize,
                                     param.ppmuTerminationVec.size(),
                                     "PPMU",
                                     "termination",
                                     param.ppmuTerminationVec);

    if(param.ppmuPinlistVec.size() != ppmuTestNameVec.size())
    {
      if(ppmuTestNameVec.size() != 1)
      {
        stringstream errMsg;
        errMsg <<"PPMU: the number of pinlist groups is "
               << param.ppmuPinlistVec.size() <<endl
               <<"      the number of testName groups is "
               << ppmuTestNameVec.size() <<endl
               <<"So the testName groups don't match pinlist groups." <<endl;
        throw Error("OutputDCTest::processParameters()",
                    errMsg.str(),
                    "OutputDCTest::processParameters()");
      }
      else
      {
        param.isPPMULimitAppliedForAllGroups = true;
        for(vector<string>::size_type i = 1; i < param.ppmuPinlistVec.size(); i++)
        {
          ppmuTestNameVec.push_back(ppmuTestNameVec[0]);
        }
      }
    }

    param.hasPmuOrBoardADC = true;

    // the following three variables is used for checking duplicate pins
    pair<map<string, pair<string, string> >::iterator, bool> ret;
    pair<string, string> groupAndInstrument;
    const string instrumentType = "PPMUInstrument";

    // the following variables are used to store HV pins
    vector<long unsigned int>  ppmuHvPinIndexlist;
    vector<vector<string> > ppmuHvExpandedPinsVec;

    ppmuHvPinIndexlist.clear();
    ppmuHvExpandedPinsVec.clear();

    param.ppmuIsHVPinsVec.resize(param.ppmuPinlistVec.size());

    for(vector<string>::size_type  i = 0; i< param.ppmuPinlistVec.size(); i++)
    {
      param.ppmuIsHVPinsVec[i] = false;
      bool isThisGroupNotCommented = ('#' != param.ppmuPinlistVec[i][0]);
      vector<string> expandedPins;
      if(isThisGroupNotCommented)
      {
        expandedPins = PinUtility.getDigitalPinNamesFromPinList(
                                         param.ppmuPinlistVec[i],
                                         TM::IO_PIN|TM::O_PIN, true,true);
        // For checking HV pins
        vector<string> hvPins, nonHvPins;
        hvPins.clear();
        nonHvPins.clear();

        // check the duplicate pins
        for (vector<string>::size_type index = 0; index < expandedPins.size(); index++)
        {
          groupAndInstrument = make_pair(param.ppmuPinlistVec[i], instrumentType);
          ret = pinAndGroupMap.insert(make_pair(expandedPins[index], groupAndInstrument));
          if (!ret.second)
          {
            stringstream errMsg;
            errMsg << "In the PPMUInstrument group: " << param.ppmuPinlistVec[i]<< endl
                   << "   and " << ret.first->second.second << " group: "
                   << ret.first->second.first << endl
                   << "There are the same pin: "
                   << expandedPins[index] << endl;
            throw Error("OutputDCTest::processParameters",
                        errMsg.str(),
                        "OutputDCTest::processParameters");
          }

          if (OutputDCTestUtil::isHighVoltagePin(expandedPins[index]))
          {
            hvPins.push_back(expandedPins[index]);
          }
          else
          {
            nonHvPins.push_back(expandedPins[index]);
          }
        }

        if (hvPins.size() == expandedPins.size())
        {
          param.ppmuIsHVPinsVec[i] = true;
        }
        else if (hvPins.size() == 0)
        {
          param.ppmuIsHVPinsVec[i] = false;
        }
        else if (hvPins.size() > 0 && hvPins.size() < expandedPins.size())
        {
          //adapt current pins
          param.ppmuIsHVPinsVec[i] = false;
          expandedPins = nonHvPins;
          param.ppmuPinlistVec[i] = PinUtility.createPinListFromPinNames(nonHvPins);

          //remember the new one
          ppmuHvPinIndexlist.push_back(i);
          ppmuHvExpandedPinsVec.push_back(hvPins);
        }
      }
      (param.ppmuExpandedPinsVec).push_back(expandedPins);
    }

    // create the new pinlist and its test properties
    if (ppmuHvPinIndexlist.size() > 0)
    {
      vector<string> tmpPinlistVec, tmpMeasuredLevelVec, tmpForceCurrentVec,
                     tmpSettlingTimeVec, tmpTerminationVec, tmpTestNameVec;
      vector<vector<string> >tmpExpandedPinsVec;
      vector<bool> tmpIsHVPinsVec;
      for(vector<string>::size_type  i = 0; i< param.ppmuPinlistVec.size(); i++)
      {
        tmpPinlistVec.push_back(param.ppmuPinlistVec[i]);
        tmpMeasuredLevelVec.push_back(param.ppmuMeasuredLevelVec[i]);
        tmpForceCurrentVec.push_back(ppmuForceCurrentVec[i]);
        tmpSettlingTimeVec.push_back(ppmuSettlingTimeVec[i]);
        tmpTerminationVec.push_back(param.ppmuTerminationVec[i]);
        tmpTestNameVec.push_back(ppmuTestNameVec[i]);
        tmpExpandedPinsVec.push_back(param.ppmuExpandedPinsVec[i]);
        tmpIsHVPinsVec.push_back(param.ppmuIsHVPinsVec[i]);

        vector<long unsigned int>::iterator it = find(ppmuHvPinIndexlist.begin(), ppmuHvPinIndexlist.end(), i);
        if (it != ppmuHvPinIndexlist.end())
        {
          long unsigned int index = it - ppmuHvPinIndexlist.begin();
          tmpPinlistVec.push_back(PinUtility.createPinListFromPinNames(ppmuHvExpandedPinsVec[index]));
          tmpMeasuredLevelVec.push_back(param.ppmuMeasuredLevelVec[i]);
          tmpForceCurrentVec.push_back(ppmuForceCurrentVec[i]);
          tmpSettlingTimeVec.push_back(ppmuSettlingTimeVec[i]);
          tmpTerminationVec.push_back(param.ppmuTerminationVec[i]);
          tmpTestNameVec.push_back(ppmuTestNameVec[i]);
          tmpExpandedPinsVec.push_back(ppmuHvExpandedPinsVec[index]);
          tmpIsHVPinsVec.push_back(true);
        }
      }

      param.ppmuPinlistVec.swap(tmpPinlistVec);
      param.ppmuMeasuredLevelVec.swap(tmpMeasuredLevelVec);
      ppmuForceCurrentVec.swap(tmpForceCurrentVec);
      ppmuSettlingTimeVec.swap(tmpSettlingTimeVec);
      param.ppmuTerminationVec.swap(tmpTerminationVec);
      ppmuTestNameVec.swap(tmpTestNameVec);
      param.ppmuExpandedPinsVec.swap(tmpExpandedPinsVec);
      param.ppmuIsHVPinsVec.swap(tmpIsHVPinsVec);
    }

    for(vector<string>::size_type  i = 0; i< param.ppmuPinlistVec.size(); i++)
    {
      bool isThisGroupNotCommented = ('#' != param.ppmuPinlistVec[i][0]);

      LIMIT limitLow,limitHigh;
      (param.ppmuIsMeasureLowVec).push_back(false);
      (param.ppmuForceCurrentLowVec).push_back(0.0);
      (param.ppmuSettlingTimeLowVec).push_back(0.0);
      (param.ppmuIsMeasureHighVec).push_back(false);
      (param.ppmuForceCurrentHighVec).push_back(0.0);
      (param.ppmuSettlingTimeHighVec).push_back(0.0);
      (param.ppmuLimitLowVec).push_back(limitLow);
      (param.ppmuLimitHighVec).push_back(limitHigh);
      (param.ppmuLimitNameLowVec).push_back("");
      (param.ppmuLimitNameHighVec).push_back("");
      string measureString = param.ppmuMeasuredLevelVec[i];
      if(isThisGroupNotCommented &&
         ("LOW" == measureString ||
          "Low" == measureString ||
          "low" == measureString) )
      {
        param.ppmuMeasuredLevelVec[i] = "LOW";
        param.ppmuMeasureLow = true;
        param.measureLow = true;
        (param.ppmuIsMeasureLowVec)[i] = true;
        (param.ppmuForceCurrentLowVec)[i]
                 = OutputDCTestUtil::string2Double(ppmuForceCurrentVec[i],"ppmuForceCurrent_uA");
        (param.ppmuSettlingTimeLowVec)[i]
                 = OutputDCTestUtil::string2Double(ppmuSettlingTimeVec[i],"ppmuSettlingTime_ms");
        if(param.ppmuSettlingTimeLowVec[i] < 0.0 )
        {
          stringstream errMsg;
          errMsg <<"PPMU: the input of settlingTime_ms for the " << i+1
                 <<" group's is not correct!"<<endl
                 <<"      settlingTime_ms must be positive!"<<endl;
          throw Error("OutputDCTest::processParameters()",
                      errMsg.str(),
                      "OutputDcTest::processParameter()");
        }

        param.ppmuLimitNameLowVec[i] = ppmuTestNameVec[i];
        OutputDCTestUtil::getLimitInfo(ppmuTestNameVec[i],i,
                                       param.ppmuLimitLowVec[i],
                                       testtableHelper);
      }
      else if(isThisGroupNotCommented &&
              ("HIGH" == measureString ||
               "High" == measureString ||
               "high" == measureString) )
      {
        param.ppmuMeasuredLevelVec[i] = "HIGH";
        param.ppmuMeasureHigh = true;
        param.measureHigh = true;
        (param.ppmuIsMeasureHighVec)[i] = true;
        (param.ppmuForceCurrentHighVec)[i]
                 = OutputDCTestUtil::string2Double(ppmuForceCurrentVec[i],"ppmuForceVoltage_uA");
        (param.ppmuSettlingTimeHighVec)[i]
                 = OutputDCTestUtil::string2Double(ppmuSettlingTimeVec[i],"ppmuSettlingTime_ms");
        if(param.ppmuSettlingTimeHighVec[i] < 0.0 )
        {
          stringstream errMsg;
          errMsg <<"PPMU: the input of settlingTime_ms for the " << i+1
                 <<" group's is not correct!"<<endl
                 <<"      settlingTime_ms must be positive!"<<endl;
          throw Error("OutputDCTest::processParameters()",
                      errMsg.str(),
                      "OutputDcTest::processParameter()");
        }

        param.ppmuLimitNameHighVec[i] = ppmuTestNameVec[i];
        OutputDCTestUtil::getLimitInfo(ppmuTestNameVec[i],i,
                                       param.ppmuLimitHighVec[i],
                                       testtableHelper);
      }
      else if (isThisGroupNotCommented &&
               ("BOTH" == measureString ||
                "Both" == measureString ||
                "both" == measureString) )
      {
        param.ppmuMeasuredLevelVec[i] = "BOTH";
        vector<double> forceCurrentVec;
        vector<double> settlingTimeVec;
        vector<string> limitVec;

        forceCurrentVec.clear();
        settlingTimeVec.clear();
        limitVec.clear();

        // parse forceCurrent_uA  and check the format
        OutputDCTestUtil::parseListOfDouble(ppmuForceCurrentVec[i], forceCurrentVec);
        if(2 != forceCurrentVec.size())
        {
          stringstream errMsg;
          errMsg <<"PPMU: the input of forceCurrent_uA for the " << i+1
                 <<" group's format is not correct!"<<endl
                 <<"      Now the measure is for both,"
                 <<"so the input format is like: (10,20)"<<endl;
          throw Error("OutputDCTest::processParameters()",
                      errMsg.str(),
                      "OutputDCTest::processParameters()");
        }

        // parse settlingTime_ms and check the format
        OutputDCTestUtil::parseListOfDouble(ppmuSettlingTimeVec[i], settlingTimeVec);
        if(2 != settlingTimeVec.size())
        {
          stringstream errMsg;
          errMsg <<"PPMU: the input of settlingTime_ms for the " << i+1
                 <<" group's format is not correct!"<<endl
                 <<"      Now the measure is for both,"
                 <<"so the input format is like: (1.5,1.2)"<<endl;
          throw Error("OutputDCTest::processParameters()",
                      errMsg.str(),
                      "OutputDCTest::processParameters()");
        }

        // parse testName and check the format
        OutputDCTestUtil::parseListOfString(ppmuTestNameVec[i], limitVec);

        if(2 != limitVec.size())
        {
          stringstream errMsg;
          errMsg <<"PPMU: the input of testName for the " << i+1
                 <<" group's format is not correct!"<<endl
                 <<"      Now the measure is for both,"
                 <<"so the input format is like: (limitNameLow,limitNameHigh)"<<endl;
          throw Error("OutputDCTest::processParameters()",
                      errMsg.str(),
                      "OutputDCTest::processParameters()");
        }

        (param.ppmuIsMeasureLowVec)[i] = true;      // the low level measurement will be done
        param.ppmuMeasureLow = true;
        param.measureLow = true;
        (param.ppmuForceCurrentLowVec)[i] = forceCurrentVec[0];
        (param.ppmuSettlingTimeLowVec)[i] = settlingTimeVec[0];
        if(param.ppmuSettlingTimeLowVec[i] < 0.0 )
        {
          stringstream errMsg;
          errMsg <<"PPMU: the input of settlingTime_ms for the " << i+1
                 <<" group's low test is not correct!"<<endl
                 <<"      settlingTime_ms must be positive!"<<endl;
          throw Error("OutputDCTest::processParameters()",
                      errMsg.str(),
                      "OutputDcTest::processParameter()");
        }

        param.ppmuLimitNameLowVec[i] = limitVec[0];
        param.ppmuLimitNameHighVec[i] = limitVec[1];
        OutputDCTestUtil::getLimitInfo(limitVec[0],i,
                                       param.ppmuLimitLowVec[i],
                                       testtableHelper);
        OutputDCTestUtil::getLimitInfo(limitVec[1],i,
                                       param.ppmuLimitHighVec[i],
                                       testtableHelper);

        (param.ppmuIsMeasureHighVec)[i] = true;    // the high level measurement will be done
        param.ppmuMeasureHigh = true;
        param.measureHigh = true;
        (param.ppmuForceCurrentHighVec)[i] = forceCurrentVec[1];
        (param.ppmuSettlingTimeHighVec)[i] = settlingTimeVec[1];
        if(param.ppmuSettlingTimeHighVec[i] < 0.0 )
        {
          stringstream errMsg;
          errMsg <<"PPMU: the input of settlingTime_ms for the " << i+1
                 <<" group's high test is not correct!"<<endl
                 <<"      settlingTime_ms must be positive!"<<endl;
          throw Error("OutputDCTest::processParameters()",
                      errMsg.str(),
                      "OutputDcTest::processParameter()");
        }
      }
      else if(isThisGroupNotCommented)
      {
        stringstream errMsg;
        errMsg <<"PPMU: for the " << i+1 << " group setup parameter, measure: "
               <<measureString << " is invalid."<<endl
               <<"measure can only be the following options:" <<endl
               <<"LOW HIGH BOTH" <<endl;
        throw Error("OutputDCTest::processParamters()",
                    errMsg.str(),
                    "OutputDCTest::processParamters()");
      }

      /**
       * If termination is ON for io pins, and for o pins with term type termination,
       * the following formula applies:
       * DUT output current = (PMU current) + (test system driver current)
       * Because the DUT output current in this case can be high enough to damage your device,
       * a warning is generated, reminding you to set the force current to a low value,
       * if the specified current limit is > 1 uA.
       */
      if("ON" == param.ppmuTerminationVec[i])
      {
        if(abs(param.ppmuForceCurrentLowVec[i]) > 1.0 ||
           abs(param.ppmuForceCurrentHighVec[i]) > 1.0 )
        {
          cerr<<"WARNING:\n"
              <<"Force current should be set to a small value,"
              <<" if termination remains connected during measurement."
              <<endl;
        }
      }
      else if("OFF" != param.ppmuTerminationVec[i])
      {
        stringstream errMsg;
        errMsg <<"PPMU: for the " << i+1 << " group setup parameter, termination: "
               <<param.ppmuTerminationVec[i] << " is invalid."<<endl
               <<"termination can only be the following options: ON  OFF" <<endl;
        throw Error("OutputDCTest::processParamters()",
                    errMsg.str(),
                    "OutputDCTest::processParamters()");
      }
    }
  }


  if("YES" == param.spmuUsed)
  {
    vector<string> spmuForceCurrentVec;
    vector<string> spmuClampVoltageVec;
    vector<string> spmuSettlingTimeVec;
    vector<string> spmuTestNameVec;

    OutputDCTestUtil::parseListOfString(spmuPinlist,param.spmuPinlistVec);
    OutputDCTestUtil::parseListOfString(spmuMeasuredLevel,param.spmuMeasuredLevelVec);
    OutputDCTestUtil::parseListOfString(spmuForceCurrent_uA,
                                        spmuForceCurrentVec,
                                        ',',
                                        true);
    OutputDCTestUtil::parseListOfString(spmuClampVoltage_mV,
                                        spmuClampVoltageVec,
                                        ',',
                                        true);
    OutputDCTestUtil::parseListOfString(spmuSettlingTime_ms,
                                        spmuSettlingTimeVec,
                                        ',',
                                        true);
    OutputDCTestUtil::parseListOfString(spmuTestName,
                                        spmuTestNameVec,
                                        ',',
                                        true);
    OutputDCTestUtil::parseListOfString(spmuTermination,param.spmuTerminationVec);

    vector<string>::size_type groupSize = param.spmuPinlistVec.size();
    if(groupSize == 0)
    {
      throw Error("OutputDCTest::processParameters()",
                  "SPMU: the pinlist groups can not be empty.",
                  "OutputDCTest::processParameters()");
    }

    OutputDCTestUtil::checkParameter(groupSize,
                                     param.spmuMeasuredLevelVec.size(),
                                     "SPMU",
                                     "measuredLevel",
                                     param.spmuMeasuredLevelVec);

    OutputDCTestUtil::checkParameter(groupSize,
                                     spmuForceCurrentVec.size(),
                                     "SPMU",
                                     "forceCurrent_uA",
                                     spmuForceCurrentVec);

    OutputDCTestUtil::checkParameter(groupSize,
                                     spmuClampVoltageVec.size(),
                                     "SPMU",
                                     "clampVoltage_mV",
                                     spmuClampVoltageVec);

    OutputDCTestUtil::checkParameter(groupSize,
                                     spmuSettlingTimeVec.size(),
                                     "SPMU",
                                     "settlingTime_ms",
                                     spmuSettlingTimeVec);

    OutputDCTestUtil::checkParameter(groupSize,
                                     param.spmuTerminationVec.size(),
                                     "SPMU",
                                     "termination",
                                     param.spmuTerminationVec);

    if(param.spmuPinlistVec.size() != spmuTestNameVec.size())
    {
      if(spmuTestNameVec.size() != 1)
      {
        stringstream errMsg;
        errMsg <<"SPMU: the number of pinlist groups is "
               << param.spmuPinlistVec.size() <<endl
               <<"      the number of testName groups is "
               << spmuTestNameVec.size() <<endl
               <<"So the testName groups don't match pinlist groups." <<endl;
        throw Error("OutputDCTest::processParameters()",
                    errMsg.str(),
                    "OutputDCTest::processParameters()");
      }
      else
      {
        param.isSPMULimitAppliedForAllGroups = true;
        for(vector<string>::size_type i = 1; i < param.spmuPinlistVec.size(); i++)
        {
          spmuTestNameVec.push_back(spmuTestNameVec[0]);
        }
      }
    }

    param.hasPmuOrBoardADC = true;

    // the following three variables is used for checking duplicate pins
    pair<map<string, pair<string, string> >::iterator, bool> ret;
    pair<string, string> groupAndInstrument;
    const string instrumentType = "SPMUInstrument";
    for(vector<string>::size_type  i = 0; i< param.spmuPinlistVec.size(); i++)
    {
      bool isThisGroupNotCommented = ('#' != param.spmuPinlistVec[i][0]);
      vector<string> expandedPins;
      if(isThisGroupNotCommented)
      {
        expandedPins = PinUtility.getDigitalPinNamesFromPinList(
                                         param.spmuPinlistVec[i],
                                         TM::IO_PIN|TM::O_PIN, true,true);
        // check the duplicate pins
        for (vector<string>::size_type index = 0; index < expandedPins.size(); index++)
        {
          //HV pin cann't perform spmu test
          if (OutputDCTestUtil::isHighVoltagePin(expandedPins[index]))
          {
            stringstream errMsg;
            errMsg << "In the SPMUInstrument group: "
                   << param.spmuPinlistVec[i] << endl
                   << "There is high voltage pin: "
                   << expandedPins[index] << endl;
            throw Error("OutputDCTest::processParameters",
                        errMsg.str(),
                        "OutputDCTest::processParameters");
          }

          groupAndInstrument = make_pair(param.spmuPinlistVec[i], instrumentType);
          ret = pinAndGroupMap.insert(make_pair(expandedPins[index], groupAndInstrument));
          if (!ret.second)
          {
            stringstream errMsg;
            errMsg << "In the SPMUInstrument group: "
                   << param.spmuPinlistVec[i] << endl
                   << "   and " << ret.first->second.second << " group: "
                   << ret.first->second.first << endl
                   << "There are the same pin: "
                   << expandedPins[index] << endl;
            throw Error("OutputDCTest::processParameters",
                        errMsg.str(),
                        "OutputDCTest::processParameters");
          }
        }
      }
      (param.spmuExpandedPinsVec).push_back(expandedPins );


      LIMIT limitLow,limitHigh;
      (param.spmuIsMeasureLowVec).push_back(false);
      (param.spmuForceCurrentLowVec).push_back(0.0);
      (param.spmuClampVoltageLowVec).push_back(0.0);
      (param.spmuSettlingTimeLowVec).push_back(0.0);
      (param.spmuIsMeasureHighVec).push_back(false);
      (param.spmuForceCurrentHighVec).push_back(0.0);
      (param.spmuClampVoltageHighVec).push_back(0.0);
      (param.spmuSettlingTimeHighVec).push_back(0.0);
      (param.spmuLimitLowVec).push_back(limitLow);
      (param.spmuLimitHighVec).push_back(limitHigh);
      (param.spmuLimitNameLowVec).push_back("");
      (param.spmuLimitNameHighVec).push_back("");

      string measureString = param.spmuMeasuredLevelVec[i];
      if(isThisGroupNotCommented &&
         ("LOW" == measureString ||
          "Low" == measureString ||
          "low" == measureString) )
      {
        param.spmuMeasuredLevelVec[i] = "LOW";
        param.spmuMeasureLow = true;
        param.measureLow = true;
        (param.spmuIsMeasureLowVec)[i] = true;
        (param.spmuForceCurrentLowVec)[i]
                 = OutputDCTestUtil::string2Double(spmuForceCurrentVec[i],"spmuForceCurrent_uA");
        (param.spmuClampVoltageLowVec)[i]
                 = OutputDCTestUtil::string2Double(spmuClampVoltageVec[i],"spmuClampVoltage_mV");
        (param.spmuSettlingTimeLowVec)[i]
                 = OutputDCTestUtil::string2Double(spmuSettlingTimeVec[i],"spmuSettlingTime_ms");
        if(param.spmuSettlingTimeLowVec[i] < 0.0 )
        {
          stringstream errMsg;
          errMsg <<"SPMU: the input of settlingTime_ms for the " << i+1
                 <<" group's is not correct!"<<endl
                 <<"      settlingTime_ms must be positive!"<<endl;
          throw Error("OutputDCTest::processParameters()",
                      errMsg.str(),
                      "OutputDcTest::processParameter()");
        }

        param.spmuLimitNameLowVec[i] = spmuTestNameVec[i];
        OutputDCTestUtil::getLimitInfo(spmuTestNameVec[i],i,
                                       param.spmuLimitLowVec[i],
                                       testtableHelper);
      }
      else if(isThisGroupNotCommented &&
              ("HIGH" == measureString ||
               "High" == measureString ||
               "high" == measureString) )
      {
        param.spmuMeasuredLevelVec[i] = "HIGH";
        param.spmuMeasureHigh = true;
        param.measureHigh = true;
        (param.spmuIsMeasureHighVec)[i] = true;
        (param.spmuForceCurrentHighVec)[i]
                 = OutputDCTestUtil::string2Double(spmuForceCurrentVec[i],"spmuForceVoltage_uA");
        (param.spmuClampVoltageHighVec)[i]
                 = OutputDCTestUtil::string2Double(spmuClampVoltageVec[i],"spmuClampVoltage_mV");
        (param.spmuSettlingTimeHighVec)[i]
                 = OutputDCTestUtil::string2Double(spmuSettlingTimeVec[i],"spmuSettlingTime_ms");
        if(param.spmuSettlingTimeHighVec[i] < 0.0 )
        {
          stringstream errMsg;
          errMsg <<"SPMU: the input of settlingTime_ms for the " << i+1
                 <<" group's is not correct!"<<endl
                 <<"      settlingTime_ms must be positive!"<<endl;
          throw Error("OutputDCTest::processParameters()",
                      errMsg.str(),
                      "OutputDcTest::processParameter()");
        }

        param.spmuLimitNameHighVec[i] = spmuTestNameVec[i];
        OutputDCTestUtil::getLimitInfo(spmuTestNameVec[i],i,
                                       param.spmuLimitHighVec[i],
                                       testtableHelper);
      }
      else if (isThisGroupNotCommented &&
               ("BOTH" == measureString ||
                "Both" == measureString ||
                "both" == measureString) )
      {
        param.spmuMeasuredLevelVec[i] = "BOTH";
        vector<double> forceCurrentVec;
        vector<double> clampVoltageVec;
        vector<double> settlingTimeVec;
        vector<string> limitVec;

        forceCurrentVec.clear();
        clampVoltageVec.clear();
        settlingTimeVec.clear();
        limitVec.clear();

        // parse forceCurrent_uA and check the format
        OutputDCTestUtil::parseListOfDouble(spmuForceCurrentVec[i], forceCurrentVec);
        if(2 != forceCurrentVec.size())
        {
          stringstream errMsg;
          errMsg <<"SPMU: the input of forceCurrent_uA for the " << i+1
                 <<" group's format is not correct!"<<endl
                 <<"      Now the measure is for both,"
                 <<"so the input format is like: (10,20)"<<endl;
          throw Error("OutputDCTest::processParameters()",
                      errMsg.str(),
                      "OutputDCTest::processParameters()");
        }

        // parse clampVoltage_mV and check the format
        OutputDCTestUtil::parseListOfDouble(spmuClampVoltageVec[i], clampVoltageVec);
        if(2 != clampVoltageVec.size())
        {
          stringstream errMsg;
          errMsg <<"SPMU: the input of clampVoltage_mV for the " << i+1
                 <<" group's format is not correct!"<<endl
                 <<"      Now the measure is for both,"
                 <<"so the input format is like: (400,3800)"<<endl;
          throw Error("OutputDCTest::processParameters()",
                      errMsg.str(),
                      "OutputDCTest::processParameters()");
        }

        // parse settlingTime_ms and check the format
        OutputDCTestUtil::parseListOfDouble(spmuSettlingTimeVec[i], settlingTimeVec);
        if(2 != settlingTimeVec.size())
        {
          stringstream errMsg;
          errMsg <<"SPMU: the input of settlingTime_ms for the " << i+1
                 <<" group's format is not correct!"<<endl
                 <<"      Now the measure is for both,"
                 <<"so the input format is like: (1.5,1.2)"<<endl;
          throw Error("OutputDCTest::processParameters()",
                      errMsg.str(),
                      "OutputDCTest::processParameters()");
        }

        // parse testName and check the format
        OutputDCTestUtil::parseListOfString(spmuTestNameVec[i], limitVec);
        if(2 != limitVec.size())
        {
          stringstream errMsg;
          errMsg <<"SPMU: the input of testName for the " << i+1
                 <<" group's format is not correct!"<<endl
                 <<"      Now the measure is for both,"
                 <<"so the input format is like: (limitNameLow,limitNameHigh)"<<endl;
          throw Error("OutputDCTest::processParameters()",
                      errMsg.str(),
                      "OutputDCTest::processParameters()");
        }

        (param.spmuIsMeasureLowVec)[i] = true;      // the low level measurement will be done
        param.spmuMeasureLow = true;
        param.measureLow = true;
        (param.spmuForceCurrentLowVec)[i] = forceCurrentVec[0];
        (param.spmuClampVoltageLowVec)[i] = clampVoltageVec[0];
        (param.spmuSettlingTimeLowVec)[i] = settlingTimeVec[0];
        if(param.spmuSettlingTimeLowVec[i] < 0.0 )
        {
          stringstream errMsg;
          errMsg <<"SPMU: the input of settlingTime_ms for the " << i+1
                 <<" group's low test is not correct!"<<endl
                 <<"      settlingTime_ms must be positive!"<<endl;
          throw Error("OutputDCTest::processParameters()",
                      errMsg.str(),
                      "OutputDcTest::processParameter()");
        }

        (param.spmuLimitNameLowVec)[i] = limitVec[0];
        (param.spmuLimitNameHighVec)[i] = limitVec[1];
        OutputDCTestUtil::getLimitInfo(limitVec[0],i,
                                       param.spmuLimitLowVec[i],
                                       testtableHelper);
        OutputDCTestUtil::getLimitInfo(limitVec[1],i,
                                       param.spmuLimitHighVec[i],
                                       testtableHelper);

        (param.spmuIsMeasureHighVec)[i] = true;    // the high level measurement will be done
        param.spmuMeasureHigh = true;
        param.measureHigh = true;
        (param.spmuForceCurrentHighVec)[i] = forceCurrentVec[1];
        (param.spmuClampVoltageHighVec)[i] = clampVoltageVec[1];
        (param.spmuSettlingTimeHighVec)[i] = settlingTimeVec[1];
        if(param.spmuSettlingTimeHighVec[i] < 0.0 )
        {
          stringstream errMsg;
          errMsg <<"SPMU: the input of settlingTime_ms for the " << i+1
                 <<" group's high test is not correct!"<<endl
                 <<"      settlingTime_ms must be positive!"<<endl;
          throw Error("OutputDCTest::processParameters()",
                      errMsg.str(),
                      "OutputDcTest::processParameter()");
        }
      }
      else if(isThisGroupNotCommented)
      {
        stringstream errMsg;
        errMsg <<"SPMU: for the " << i+1 << " group setup parameter, measure: "
               <<measureString << " is invalid."<<endl
               <<"measure can only be the following options:" <<endl
               <<"LOW HIGH BOTH" <<endl;
        throw Error("OutputDCTest::processParamters()",
                    errMsg.str(),
                    "OutputDCTest::processParamters()");
      }


      if("OFF" != param.spmuTerminationVec[i] &&
         "ON" != param.spmuTerminationVec[i])
      {
        stringstream errMsg;
        errMsg <<"SPMU: for the " << i+1 << " group setup parameter, termination: "
               <<param.spmuTerminationVec[i] << " is invalid."<<endl
               <<"termination can only be the following options: ON  OFF" <<endl;
        throw Error("OutputDCTest::processParamters()",
                    errMsg.str(),
                    "OutputDCTest::processParamters()");
      }

    }
  }


  if("YES" == param.boardADCUsed)
  {
    vector<string> boardADCSettlingTimeVec;
    vector<string> boardADCTestNameVec;

    OutputDCTestUtil::parseListOfString(boardADCPinlist,param.boardADCPinlistVec);
    OutputDCTestUtil::parseListOfString(boardADCMeasuredLevel,param.boardADCMeasuredLevelVec);
    OutputDCTestUtil::parseListOfString(boardADCSettlingTime_ms,
                                        boardADCSettlingTimeVec,
                                        ',',
                                        true);
    OutputDCTestUtil::parseListOfString(boardADCTestName,
                                        boardADCTestNameVec,
                                        ',',
                                        true);
    OutputDCTestUtil::parseListOfString(boardADCTermination,param.boardADCTerminationVec);

    vector<string>::size_type groupSize = param.boardADCPinlistVec.size();
    if(groupSize == 0)
    {
      throw Error("OutputDCTest::processParameters()",
                  "BoardADC: the pinlist groups can not be empty.",
                  "OutputDCTest::processParameters()");
    }

    OutputDCTestUtil::checkParameter(groupSize,
                                     param.boardADCMeasuredLevelVec.size(),
                                     "BoardADC",
                                     "measuredLevel",
                                     param.boardADCMeasuredLevelVec);

    OutputDCTestUtil::checkParameter(groupSize,
                                     boardADCSettlingTimeVec.size(),
                                     "BoardADC",
                                     "settlingTime_ms",
                                     boardADCSettlingTimeVec);

    OutputDCTestUtil::checkParameter(groupSize,
                                     param.boardADCTerminationVec.size(),
                                     "BoardADC",
                                     "termination",
                                     param.boardADCTerminationVec);

    if(param.boardADCPinlistVec.size() != boardADCTestNameVec.size())
    {
      if(boardADCTestNameVec.size() != 1)
      {
        stringstream errMsg;
        errMsg <<"BoardADC: the number of pinlist groups is "
               << param.boardADCPinlistVec.size() <<endl
               <<"      the number of testName groups is "
               << boardADCTestNameVec.size() <<endl
               <<"So the testName groups don't match pinlist groups." <<endl;
        throw Error("OutputDCTest::processParameters()",
                    errMsg.str(),
                    "OutputDCTest::processParameters()");
      }
      else
      {
        param.isBoardADCLimitAppliedForAllGroups = true;
        for(vector<string>::size_type i = 1; i < param.boardADCPinlistVec.size(); i++)
        {
          boardADCTestNameVec.push_back(boardADCTestNameVec[0]);
        }
      }
    }

    param.hasPmuOrBoardADC = true;

    // the following three variables is used for checking duplicate pins
    pair<map<string, pair<string, string> >::iterator, bool> ret;
    pair<string, string> groupAndInstrument;
    const string instrumentType = "BoardADCInstrument";

    // the following variables are used to store HV pins
    vector<long unsigned int>  boardADCHvPinIndexlist;
    vector<vector<string> > boardADCHvExpandedPinsVec;

    boardADCHvPinIndexlist.clear();
    boardADCHvExpandedPinsVec.clear();

    param.boardADCIsHVPinsVec.resize(param.boardADCPinlistVec.size());

    for(vector<string>::size_type  i = 0; i< param.boardADCPinlistVec.size(); i++)
    {
      param.boardADCIsHVPinsVec[i] = false;
      bool isThisGroupNotCommented = ('#' != param.boardADCPinlistVec[i][0]);
      vector<string> expandedPins;
      if(isThisGroupNotCommented )
      {
        expandedPins = PinUtility.getDigitalPinNamesFromPinList(
                                         param.boardADCPinlistVec[i],
                                         TM::IO_PIN|TM::O_PIN, true,true);
        // For checking HV pins
        vector<string> hvPins, nonHvPins;
        hvPins.clear();
        nonHvPins.clear();

        // check the duplicate pins
        for (vector<string>::size_type index = 0; index < expandedPins.size(); index++)
        {
          groupAndInstrument = make_pair(param.boardADCPinlistVec[i], instrumentType);
          ret = pinAndGroupMap.insert(make_pair(expandedPins[index], groupAndInstrument));
          if (!ret.second)
          {
            stringstream errMsg;
            errMsg << "In the BoardADCInstrument group: "
                   << param.boardADCPinlistVec[i] << endl << "   and "
                   << ret.first->second.second << " group: " << ret.first->second.first
                   << endl << "There are the same pin: " << expandedPins[index] << endl;
            throw Error("OutputDCTest::processParameters",
                        errMsg.str(),
                        "OutputDCTest::processParameters");
          }

          if (OutputDCTestUtil::isHighVoltagePin(expandedPins[index]))
          {
            hvPins.push_back(expandedPins[index]);
          }
          else
          {
            nonHvPins.push_back(expandedPins[index]);
          }
        }

        if (hvPins.size() == expandedPins.size())
        {
          param.boardADCIsHVPinsVec[i] = true;
        }
        else if (hvPins.size() == 0)
        {
          param.boardADCIsHVPinsVec[i] = false;
        }
        else if (hvPins.size() > 0 && hvPins.size() < expandedPins.size())
        {
          //adapt current pins
          param.boardADCIsHVPinsVec[i] = false;
          expandedPins = nonHvPins;
          param.boardADCPinlistVec[i] = PinUtility.createPinListFromPinNames(nonHvPins);

          //remember the new one
          boardADCHvPinIndexlist.push_back(i);
          boardADCHvExpandedPinsVec.push_back(hvPins);
        }
      }
      (param.boardADCExpandedPinsVec).push_back(expandedPins );
    }

    // create the new pinlist and its test properties
    if (boardADCHvPinIndexlist.size() > 0)
    {
      vector<string> tmpPinlistVec, tmpMeasuredLevelVec,
                     tmpSettlingTimeVec, tmpTerminationVec, tmpTestNameVec;
      vector<vector<string> >tmpExpandedPinsVec;
      vector<bool> tmpIsHVPinsVec;
      for(vector<string>::size_type  i = 0; i< param.boardADCPinlistVec.size(); i++)
      {
        tmpPinlistVec.push_back(param.boardADCPinlistVec[i]);
        tmpMeasuredLevelVec.push_back(param.boardADCMeasuredLevelVec[i]);
        tmpSettlingTimeVec.push_back(boardADCSettlingTimeVec[i]);
        tmpTerminationVec.push_back(param.boardADCTerminationVec[i]);
        tmpTestNameVec.push_back(boardADCTestNameVec[i]);
        tmpExpandedPinsVec.push_back(param.boardADCExpandedPinsVec[i]);
        tmpIsHVPinsVec.push_back(param.boardADCIsHVPinsVec[i]);

        vector<long unsigned int>::iterator it = find(boardADCHvPinIndexlist.begin(), boardADCHvPinIndexlist.end(), i);
        if (it != boardADCHvPinIndexlist.end())
        {
          long unsigned int index = it - boardADCHvPinIndexlist.begin();
          tmpPinlistVec.push_back(PinUtility.createPinListFromPinNames(boardADCHvExpandedPinsVec[index]));
          tmpMeasuredLevelVec.push_back(param.boardADCMeasuredLevelVec[i]);
          tmpSettlingTimeVec.push_back(boardADCSettlingTimeVec[i]);
          tmpTerminationVec.push_back(param.boardADCTerminationVec[i]);
          tmpTestNameVec.push_back(boardADCTestNameVec[i]);
          tmpExpandedPinsVec.push_back(boardADCHvExpandedPinsVec[index]);
          tmpIsHVPinsVec.push_back(true);
        }
      }

      param.boardADCPinlistVec.swap(tmpPinlistVec);
      param.boardADCMeasuredLevelVec.swap(tmpMeasuredLevelVec);
      boardADCSettlingTimeVec.swap(tmpSettlingTimeVec);
      param.boardADCTerminationVec.swap(tmpTerminationVec);
      boardADCTestNameVec.swap(tmpTestNameVec);
      param.boardADCExpandedPinsVec.swap(tmpExpandedPinsVec);
      param.boardADCIsHVPinsVec.swap(tmpIsHVPinsVec);
    }

    for(vector<string>::size_type  i = 0; i< param.boardADCPinlistVec.size(); i++)
    {
      bool isThisGroupNotCommented = ('#' != param.boardADCPinlistVec[i][0]);

      LIMIT limitLow,limitHigh;
      (param.boardADCIsMeasureLowVec).push_back(false);
      (param.boardADCSettlingTimeLowVec).push_back(0.0);
      (param.boardADCIsMeasureHighVec).push_back(false);
      (param.boardADCSettlingTimeHighVec).push_back(0.0);
      (param.boardADCLimitLowVec).push_back(limitLow);
      (param.boardADCLimitHighVec).push_back(limitHigh);
      (param.boardADCLimitNameLowVec).push_back("");
      (param.boardADCLimitNameHighVec).push_back("");

      string measureString = param.boardADCMeasuredLevelVec[i];
      if(isThisGroupNotCommented &&
         ("LOW" == measureString ||
          "Low" == measureString ||
          "low" == measureString) )
      {
        param.boardADCMeasuredLevelVec[i] = "LOW";
        param.boardADCMeasureLow = true;
        param.measureLow = true;
        (param.boardADCIsMeasureLowVec)[i] = true;
        (param.boardADCSettlingTimeLowVec)[i]
                 = OutputDCTestUtil::string2Double(boardADCSettlingTimeVec[i],"boardADCSettlingTime_ms");
        if(param.boardADCSettlingTimeLowVec[i] < 0.0 )
        {
          stringstream errMsg;
          errMsg <<"BoardADC: the input of settlingTime_ms for the " << i+1
                 <<" group's is not correct!"<<endl
                 <<"      settlingTime_ms must be positive!"<<endl;
          throw Error("OutputDCTest::processParameters()",
                      errMsg.str(),
                      "OutputDcTest::processParameter()");
        }

        param.boardADCLimitNameLowVec[i] = boardADCTestNameVec[i];
        OutputDCTestUtil::getLimitInfo(boardADCTestNameVec[i],i,
                                       param.boardADCLimitLowVec[i],
                                       testtableHelper);
      }
      else if(isThisGroupNotCommented &&
              ("HIGH" == measureString ||
               "High" == measureString ||
               "high" == measureString) )
      {
        param.boardADCMeasuredLevelVec[i] = "HIGH";
        param.boardADCMeasureHigh = true;
        param.measureHigh = true;
        (param.boardADCIsMeasureHighVec)[i] = true;
        (param.boardADCSettlingTimeHighVec)[i]
                 = OutputDCTestUtil::string2Double(boardADCSettlingTimeVec[i],"boardADCSettlingTime_ms");
        if(param.boardADCSettlingTimeHighVec[i] < 0.0 )
        {
          stringstream errMsg;
          errMsg <<"BoardADC: the input of settlingTime_ms for the " << i+1
                 <<" group's is not correct!"<<endl
                 <<"      settlingTime_ms must be positive!"<<endl;
          throw Error("OutputDCTest::processParameters()",
                      errMsg.str(),
                      "OutputDcTest::processParameter()");
        }

        param.boardADCLimitNameHighVec[i] = boardADCTestNameVec[i];
        OutputDCTestUtil::getLimitInfo(boardADCTestNameVec[i],i,
                                       param.boardADCLimitHighVec[i],
                                       testtableHelper);
      }
      else if (isThisGroupNotCommented &&
               ("BOTH" == measureString ||
                "Both" == measureString ||
                "both" == measureString) )
      {
        param.boardADCMeasuredLevelVec[i] = "BOTH";
        vector<double> settlingTimeVec;
        vector<string> limitVec;

        settlingTimeVec.clear();
        limitVec.clear();

        // parse settlingTime_ms and check the format
        OutputDCTestUtil::parseListOfDouble(boardADCSettlingTimeVec[i], settlingTimeVec);
        if(2 != settlingTimeVec.size())
        {
          stringstream errMsg;
          errMsg <<"BoardADC: the input of settlingTime_ms for the " << i+1
                 <<" group's format is not correct!"<<endl
                 <<"      Now the measure is for both,"
                 <<"so the input format is like: (1.5,1.2)"<<endl;
          throw Error("OutputDCTest::processParameters()",
                      errMsg.str(),
                      "OutputDCTest::processParameters()");
        }

        // parse testName and check the format
        OutputDCTestUtil::parseListOfString(boardADCTestNameVec[i], limitVec);

        if(2 != limitVec.size())
        {
          stringstream errMsg;
          errMsg <<"BoardADC: the input of testName for the " << i+1
                 <<" group's format is not correct!"<<endl
                 <<"      Now the measure is for both,"
                 <<"so the input format is like: (limitLowName,limitHighName)"<<endl;
          throw Error("OutputDCTest::processParameters()",
                      errMsg.str(),
                      "OutputDCTest::processParameters()");
        }

        (param.boardADCIsMeasureLowVec)[i] = true;      // the low level measurement will be done
        param.boardADCMeasureLow = true;
        param.measureLow = true;
        (param.boardADCSettlingTimeLowVec)[i] = settlingTimeVec[0];
        if(param.boardADCSettlingTimeLowVec[i] < 0.0 )
        {
          stringstream errMsg;
          errMsg <<"BoardADC: the input of settlingTime_ms for the " << i+1
                 <<" group's low test is not correct!"<<endl
                 <<"      settlingTime_ms must be positive!"<<endl;
          throw Error("OutputDCTest::processParameters()",
                      errMsg.str(),
                      "OutputDcTest::processParameter()");
        }

        param.boardADCLimitNameLowVec[i] = limitVec[0];
        param.boardADCLimitNameHighVec[i] = limitVec[1];
        OutputDCTestUtil::getLimitInfo(limitVec[0],i,
                                       param.boardADCLimitLowVec[i],
                                       testtableHelper);
        OutputDCTestUtil::getLimitInfo(limitVec[1],i,
                                       param.boardADCLimitHighVec[i],
                                       testtableHelper);

        (param.boardADCIsMeasureHighVec)[i] = true;    // the high level measurement will be done
        param.boardADCMeasureHigh = true;
        param.measureHigh = true;
        (param.boardADCSettlingTimeHighVec)[i] = settlingTimeVec[1];
        if(param.boardADCSettlingTimeHighVec[i] < 0.0 )
        {
          stringstream errMsg;
          errMsg <<"BoardADC: the input of settlingTime_ms for the " << i+1
                 <<" group's high test is not correct!"<<endl
                 <<"      settlingTime_ms must be positive!"<<endl;
          throw Error("OutputDCTest::processParameters()",
                      errMsg.str(),
                      "OutputDcTest::processParameter()");
        }
      }
      else if(isThisGroupNotCommented)
      {
        stringstream errMsg;
        errMsg <<"BoardADC: for the " << i+1 << " group setup parameter, measure: "
               <<measureString << " is invalid."<<endl
               <<"measure can only be the following options:" <<endl
               <<"LOW HIGH BOTH" <<endl;
        throw Error("OutputDCTest::processParamters()",
                    errMsg.str(),
                    "OutputDCTest::processParamters()");
      }


      if("OFF" != param.boardADCTerminationVec[i] &&
         "ON" != param.boardADCTerminationVec[i])
      {
        stringstream errMsg;
        errMsg <<"BoardADC: for the " << i+1 << " group setup parameter, termination: "
               <<param.boardADCTerminationVec[i] << " is invalid."<<endl
               <<"termination can only be the following options: ON  OFF" <<endl;
        throw Error("OutputDCTest::processParamters()",
                    errMsg.str(),
                    "OutputDCTest::processParamters()");
      }

    }
  }

  if("YES" == param.activeLoadUsed)
  {
    vector<string> activeLoadForceCurrentVec;
    vector<string> activeLoadTestNameVec;

    OutputDCTestUtil::parseListOfString(activeLoadPinlist,param.activeLoadPinlistVec);
    OutputDCTestUtil::parseListOfString(activeLoadMeasuredLevel,param.activeLoadMeasuredLevelVec);
    OutputDCTestUtil::parseListOfString(activeLoadForceCurrent_uA,
                                        activeLoadForceCurrentVec,
                                        ',',
                                        true);
    OutputDCTestUtil::parseListOfString(activeLoadTestName,
                                        activeLoadTestNameVec,
                                        ',',
                                        true);

    vector<string>::size_type groupSize = param.activeLoadPinlistVec.size();
    if(groupSize == 0)
    {
      throw Error("OutputDCTest::processParameters()",
                  "ActiveLoad: the pinlist groups can not be empty.",
                  "OutputDCTest::processParameters()");
    }

    OutputDCTestUtil::checkParameter(groupSize,
                                     param.activeLoadMeasuredLevelVec.size(),
                                     "ActiveLoad",
                                     "measuredLevel",
                                     param.activeLoadMeasuredLevelVec);

    OutputDCTestUtil::checkParameter(groupSize,
                                     activeLoadForceCurrentVec.size(),
                                     "ActiveLoad",
                                     "forceCurrent_uA",
                                     activeLoadForceCurrentVec);

    if(param.activeLoadPinlistVec.size() != activeLoadTestNameVec.size())
    {
      if(activeLoadTestNameVec.size() != 1)
      {
        stringstream errMsg;
        errMsg <<"ActiveLoad: the number of pinlist groups is "
               << param.activeLoadPinlistVec.size() <<endl
               <<"      the number of testName groups is "
               << activeLoadTestNameVec.size() <<endl
               <<"So the testName groups don't match pinlist groups." <<endl;
        throw Error("OutputDCTest::processParameters()",
                    errMsg.str(),
                    "OutputDCTest::processParameters()");
      }
      else
      {
        param.isActiveLoadLimitAppliedForAllGroups = true;
        for(vector<string>::size_type i = 1; i < param.activeLoadPinlistVec.size(); i++)
        {
          activeLoadTestNameVec.push_back(activeLoadTestNameVec[0]);
        }
      }
    }

    // the following three variables is used for checking duplicate pins
    pair<map<string, pair<string, string> >::iterator, bool> ret;
    pair<string, string> groupAndInstrument;
    const string instrumentType = "ActiveLoadInstrument";
    for(vector<string>::size_type  i = 0; i< param.activeLoadPinlistVec.size(); i++)
    {
      bool isThisGroupNotCommented = ('#' != param.activeLoadPinlistVec[i][0]);
      vector<string> expandedPins;
      if(isThisGroupNotCommented)
      {
        expandedPins = PinUtility.getDigitalPinNamesFromPinList(
                                         param.activeLoadPinlistVec[i],
                                         TM::IO_PIN|TM::O_PIN, true,true);
        // check the duplicate pins
        for (vector<string>::size_type index = 0; index < expandedPins.size(); index++)
        {
          //HV pin cann't perform active-load test
          if (OutputDCTestUtil::isHighVoltagePin(expandedPins[index]))
          {
            stringstream errMsg;
            errMsg << "In the ActiveLoadInstrument group: "
                   << param.activeLoadPinlistVec[i] << endl
                   << "There is high voltage pin: "
                   << expandedPins[index] << endl;
            throw Error("OutputDCTest::processParameters",
                        errMsg.str(),
                        "OutputDCTest::processParameters");
          }

          groupAndInstrument = make_pair(param.activeLoadPinlistVec[i], instrumentType);
          ret = pinAndGroupMap.insert(make_pair(expandedPins[index], groupAndInstrument));
          if (!ret.second)
          {
            stringstream errMsg;
            errMsg << "In the ActiveLoadInstrument group: "
                   << param.activeLoadPinlistVec[i] << endl << "   and "
                   << ret.first->second.second << " group: " << ret.first->second.first
                   << endl << "There are the same pin: " << expandedPins[index] << endl;
            throw Error("OutputDCTest::processParameters",
                        errMsg.str(),
                        "OutputDCTest::processParameters");
          }
        }
      }
      (param.activeLoadExpandedPinsVec).push_back(expandedPins );


      LIMIT limitLow,limitHigh;
      (param.activeLoadIsMeasureLowVec).push_back(false);
      (param.activeLoadForceCurrentLowVec).push_back(0.0);
      (param.activeLoadIsMeasureHighVec).push_back(false);
      (param.activeLoadForceCurrentHighVec).push_back(0.0);
      (param.activeLoadLimitLowVec).push_back(limitLow);
      (param.activeLoadLimitHighVec).push_back(limitHigh);
      (param.activeLoadLimitNameLowVec).push_back("");
      (param.activeLoadLimitNameHighVec).push_back("");

      string measureString = param.activeLoadMeasuredLevelVec[i];
      if(isThisGroupNotCommented &&
         ("LOW" == measureString ||
          "Low" == measureString ||
          "low" == measureString) )
      {
        param.activeLoadMeasuredLevelVec[i] = "LOW";
        param.activeLoadMeasureLow = true;
        param.measureLow = true;
        (param.activeLoadIsMeasureLowVec)[i] = true;
        (param.activeLoadForceCurrentLowVec)[i]
                 = OutputDCTestUtil::string2Double(activeLoadForceCurrentVec[i],"activeLoadForceCurrent_uA");

        param.activeLoadLimitNameLowVec[i] = activeLoadTestNameVec[i];
        OutputDCTestUtil::getLimitInfo(activeLoadTestNameVec[i],i,
                                       param.activeLoadLimitLowVec[i],
                                       testtableHelper);
      }
      else if(isThisGroupNotCommented &&
              ("HIGH" == measureString ||
               "High" == measureString ||
               "high" == measureString) )
      {
        param.activeLoadMeasuredLevelVec[i] = "HIGH";
        param.activeLoadMeasureHigh = true;
        param.measureHigh = true;
        (param.activeLoadIsMeasureHighVec)[i] = true;
        (param.activeLoadForceCurrentHighVec)[i]
                 = OutputDCTestUtil::string2Double(activeLoadForceCurrentVec[i],"activeLoadForceVoltage_uA");

        param.activeLoadLimitNameHighVec[i] = activeLoadTestNameVec[i];
        OutputDCTestUtil::getLimitInfo(activeLoadTestNameVec[i],i,
                                       param.activeLoadLimitHighVec[i],
                                       testtableHelper);
      }
      else if (isThisGroupNotCommented &&
               ("BOTH" == measureString ||
                "Both" == measureString ||
                "both" == measureString) )
      {
        param.activeLoadMeasuredLevelVec[i] = "BOTH";
        vector<double> forceCurrentVec;
        vector<string> limitVec;

        forceCurrentVec.clear();
        limitVec.clear();

        // parse forceCurrent_uA and check the format
        OutputDCTestUtil::parseListOfDouble(activeLoadForceCurrentVec[i], forceCurrentVec);
        if(2 != forceCurrentVec.size())
        {
          stringstream errMsg;
          errMsg <<"ActiveLoad: the input of forceCurrent_uA for the " << i+1
                 <<" group's format is not correct!"<<endl
                 <<"      Now the measure is for both,"
                 <<"so the input format is like: (10,20)"<<endl;
          throw Error("OutputDCTest::processParameters()",
                      errMsg.str(),
                      "OutputDCTest::processParameters()");
        }

        // parse testName and check the format
        OutputDCTestUtil::parseListOfString(activeLoadTestNameVec[i], limitVec);
        if(2 != limitVec.size())
        {
          stringstream errMsg;
          errMsg <<"ActiveLoad: the input of testName for the " << i+1
                 <<" group's format is not correct!"<<endl
                 <<"      Now the measure is for both,"
                 <<"so the input format is like: (limitNameLow,limitNameHigh)"<<endl;
          throw Error("OutputDCTest::processParameters()",
                      errMsg.str(),
                      "OutputDCTest::processParameters()");
        }

        (param.activeLoadIsMeasureLowVec)[i] = true;      // the low level measurement will be done
        param.activeLoadMeasureLow = true;
        param.measureLow = true;
        (param.activeLoadForceCurrentLowVec)[i] = forceCurrentVec[0];

        (param.activeLoadLimitNameLowVec)[i] = limitVec[0];
        (param.activeLoadLimitNameHighVec)[i] = limitVec[1];
        OutputDCTestUtil::getLimitInfo(limitVec[0],i,
                                       param.activeLoadLimitLowVec[i],
                                       testtableHelper);
        OutputDCTestUtil::getLimitInfo(limitVec[1],i,
                                       param.activeLoadLimitHighVec[i],
                                       testtableHelper);

        (param.activeLoadIsMeasureHighVec)[i] = true;    // the high level measurement will be done
        param.activeLoadMeasureHigh = true;
        param.measureHigh = true;
        (param.activeLoadForceCurrentHighVec)[i] = forceCurrentVec[1];
      }
      else if(isThisGroupNotCommented)
      {
        stringstream errMsg;
        errMsg <<"ActiveLoad: for the " << i+1 << " group setup parameter, measure: "
               <<measureString << " is invalid."<<endl
               <<"measure can only be the following options:" <<endl
               <<"LOW HIGH BOTH" <<endl;
        throw Error("OutputDCTest::processParamters()",
                    errMsg.str(),
                    "OutputDCTest::processParamters()");
      }
    }
  }


  //process vector range
  string tempVectorRange = OutputDCTestUtil::trim(vectorRange);
  vector<string> numVec;
  string::size_type pos = 0;
  if (tempVectorRange.empty())
  {
    throw Error("OutputDcTest::processParamters()",
                "Miss searched vector range parameter.",
                "OutputDcTest::processParamters()");
  }

  //Just separate the input by ',', '-'. OUTS? can validate the number.
  if ((pos = tempVectorRange.find_first_of(",",0)) != string::npos)
  {
    //two number: num1,num2
    OutputDCTestUtil::parseListOfString(tempVectorRange,numVec,',');
    param.cycNum[0] = numVec[0];
    param.cycNum[1] = numVec[1];
    param.searchType = "SNGL";
  }
  else if ((pos = tempVectorRange.find_first_of("-",0)) != string::npos)
  {
    //range from num1 to num2: num1-num2
    OutputDCTestUtil::parseListOfString(tempVectorRange,numVec,'-');
    param.cycNum[0] = numVec[0];
    param.cycNum[1] = numVec[1];
    param.searchType = "RNG";
  }
  else
  {
    //only start number: num1
    param.cycNum[0] = tempVectorRange;
    param.cycNum[1] = "";
    param.searchType = "DPTH";
  }

  param.checkFunctionalResult = OutputDCTestUtil::trim(checkFunctionalResult);
  param.isLimitTableUsed = testtableHelper.isAllInTable();
}


/*
 *----------------------------------------------------------------------*
 * Routine: doMeasurement
 *
 * Purpose: execute measurement by instrument(s) and store results
 *
 *----------------------------------------------------------------------*
 * Description:
 *   INPUT:  param       - test parameters
 *           result      - result container
 *
 *   OUTPUT:
 *   RETURN:
 *----------------------------------------------------------------------*
 */
static void doMeasurement(const OutputDCTestParam& param,
                          OutputDCTestResult& result)
{
  /***
   * measurement points map contain:
   * first:   the n-th cycle number.
   * second:  different instrument
   *          0: for ppmu instrument;
   *          1: for spmu instrument;
   *          2: for boardADC instrument;
   * third:   low or high level {0: low, 1: high}
   * fourth:  the vector contains pins which should
   *          be measured at that cycle number.
   * e.g. pins: I/O1 ~I/O9
   * for ppmu instrument:
   *   low level:
   *     cycle 1:
   *       measurePositions[1][0][0][0]  = "I/O0"
   *       measurePositions[1][0][0][1]  = "I/O1"
   *       measurePositions[1][0][0][2]  = "I/O2"
   *     cycle 12:
   *       measurePositions[12][0][0][0]  = "I/O3"
   *       measurePositions[12][0][0][1]  = "I/O4"
   *       measurePositions[12][0][0][2]  = "I/O5"
   *   high level:
   *     cycle 3:
   *       measurePositions[3][0][1][0]  = "I/O0"
   *       measurePositions[3][0][1][1]  = "I/O1"
   *       measurePositions[3][0][1][2]  = "I/O2"
   *     cycle 15:
   *       measurePositions[15][1][0]  = "I/O3"
   *       measurePositions[15][0][1][1]  = "I/O4"
   *       measurePositions[15][0][1][2]  = "I/O5"
   * for spmu instrument
   *   low level:
   *     cycle 8:
   *       measurePositions[8][1][0][0]  = "I/O6"
   *       measurePositions[8][1][0][1]  = "I/O7"
   *     cycle 18:
   *       measurePositions[18][1][0][0]  = "I/O8"
   *       measurePositions[18][1][0][1]  = "I/O9"
   *   high level:
   *     cycle 33:
   *       measurePositions[33][1][1][0]  = "I/O6"
   *       measurePositions[33][1][1][1]  = "I/O7"
   *     cycle 35:
   *       measurePositions[35][1][1][0]  = "I/O8"
   *       measurePositions[35][1][1][1]  = "I/O9"
   *
   */
  static map<int, map<int, map<int,vector<string> > > >  measurePositions;

  ON_FIRST_INVOCATION_BEGIN();

  // init result;
  result.init();

  // connect: first try to connect
  CONNECT();

  //setup: measurement positions
  measurePositions.clear();

  if(param.hasPmuOrBoardADC)
  {
    /***
     * Default is to use OUTS? command to query the cycle number
     * for Low/High measurements.
     * In case of knowing those points, this function can be
     * omitted and directly fill in the map according to
     * the map definitions described above.
     */
    searchOutputLevelByOUTS(param,measurePositions);
  }

  ON_FIRST_INVOCATION_END();

  // EXECUTE & RESULT HANDLING
  // init funcResult for this site
  result.funcResult = true;

  // measure for all measurement positions
  map<int,map<int,map<int, vector<string> > > >::iterator it = measurePositions.begin();
  for (;it != measurePositions.end(); ++it )
  {
    if(it->first == -1)
    {
      continue;
    }

    ON_FIRST_INVOCATION_BEGIN();
      // run to the specified cycle
      Sequencer.stopCycle(it->first);
      FUNCTIONAL_TEST();
    ON_FIRST_INVOCATION_END();

    //record functional result
    result.funcResult &= GET_FUNCTIONAL_RESULT();

    SPMU_TASK spForceONLow;
    SPMU_TASK spMeasureLow;
    SPMU_TASK spForceOFFLow;
    PPMU_MEASURE ppmuMeasureLow;
    HV_DC_TASK   ppmuHVMeasureLow;
    HV_DC_TASK   boardADCHVMeasureLow;
    bool hasParallelGroupForPpmuMeasure = false;
    bool hasParallelGroupForPpmuHVMeasure = false;
    bool hasParallelGroupForSpmuTask = false;
    bool hasParallelGroupForBoardADCHVTask = false;

    vector<vector<string> > expandedPinsLowForPPMUVec;
    vector<vector<string> > expandedPinsHighForPPMUVec;
    vector<vector<string> > expandedPinsLowForSPMUVec;
    vector<vector<string> > expandedPinsHighForSPMUVec;
    vector<vector<string> > expandedPinsLowForBoardADCVec;
    vector<vector<string> > expandedPinsHighForBoardADCVec;

    vector<bool>   tempIsMeasuredLowForPPMUVec;
    vector<bool>   tempIsMeasuredHighForPPMUVec;
    vector<bool>   tempIsMeasuredLowForSPMUVec;
    vector<bool>   tempIsMeasuredHighForSPMUVec;
    vector<bool>   tempIsMeasuredLowForBoardADCVec;
    vector<bool>   tempIsMeasuredHighForBoardADCVec;


    ON_FIRST_INVOCATION_BEGIN();

    PPMU_SETTING ppmuSettingLow;
    PPMU_RELAY   ppmuRelayLowStep1,ppmuRelayLowStep2;
    PPMU_RELAY   ppmuRelayRestoreLowStep1,ppmuRelayRestoreLowStep2;
    PPMU_CLAMP   ppmuClampOnLow, ppmuClampOffLow;
    TASK_LIST    taskListLow;

    if(param.ppmuMeasureLow)
    {
      vector<string> expandedPins;
      vector<string> tempPinlistVec;
      for(vector<string>::size_type i = 0; i < param.ppmuPinlistVec.size(); i++)
      {
        expandedPinsLowForPPMUVec.push_back(expandedPins);
        tempPinlistVec.push_back("");
        tempIsMeasuredLowForPPMUVec.push_back(false);
      }
      vector<string> pinlistVec = (it->second)[0][0];
      for(vector<string>::size_type j = 0; j < param.ppmuPinlistVec.size(); j++)
      {
        vector<string>::const_iterator begin = param.ppmuExpandedPinsVec[j].begin();
        vector<string>::const_iterator end = param.ppmuExpandedPinsVec[j].end();

        bool isFirstTime = true;
        for(vector<string>::size_type i = 0; i< pinlistVec.size(); i++)
        {
          vector<string>::const_iterator pinIt = find(begin,end,pinlistVec[i]);
          if(pinIt != end)
          {
            expandedPinsLowForPPMUVec[j].push_back(pinlistVec[i]);

            if(isFirstTime)
            {
              tempPinlistVec[j] += pinlistVec[i];
              isFirstTime = false;

              tempIsMeasuredLowForPPMUVec[j] = true;
            }
            else
            {
              tempPinlistVec[j] += "," + pinlistVec[i];
            }

          }
        }
      }

      OutputDCTestUtil::ppmuInstrumentVoltageMeasurementSetup(
          tempPinlistVec,
          tempIsMeasuredLowForPPMUVec,
          param.ppmuForceCurrentLowVec,
          param.ppmuSettlingTimeLowVec,
          param.ppmuTerminationVec,
          param.ppmuLimitLowVec,
          param.ppmuIsHVPinsVec,
          param.testMode,
          ppmuSettingLow,
          ppmuClampOnLow,
          ppmuClampOffLow,
          ppmuRelayLowStep1,
          ppmuRelayLowStep2,
          ppmuRelayRestoreLowStep1,
          ppmuRelayRestoreLowStep2,
          ppmuMeasureLow,
          ppmuHVMeasureLow,
          hasParallelGroupForPpmuMeasure,
          hasParallelGroupForPpmuHVMeasure);
    }


    if(param.spmuMeasureLow)
    {
      vector<string> expandedPins;
      vector<string> tempPinlistVec;
      for(vector<string>::size_type i = 0; i < param.spmuPinlistVec.size(); i++)
      {
        expandedPinsLowForSPMUVec.push_back(expandedPins);
        tempPinlistVec.push_back("");
        tempIsMeasuredLowForSPMUVec.push_back(false);
      }
      vector<string> pinlistVec = (it->second)[1][0];
      for(vector<string>::size_type j = 0; j < param.spmuPinlistVec.size(); j++)
      {
        vector<string>::const_iterator begin = param.spmuExpandedPinsVec[j].begin();
        vector<string>::const_iterator end = param.spmuExpandedPinsVec[j].end();

        bool isFirstTime = true;
        for(vector<string>::size_type i = 0; i< pinlistVec.size(); i++)
        {
          vector<string>::const_iterator pinIt = find(begin,end,pinlistVec[i]);
          if(pinIt != end)
          {
            expandedPinsLowForSPMUVec[j].push_back(pinlistVec[i]);
            if(isFirstTime)
            {
              tempPinlistVec[j] += pinlistVec[i];
              isFirstTime = false;
              tempIsMeasuredLowForSPMUVec[j] = true;
            }
            else
            {
              tempPinlistVec[j] += "," +  pinlistVec[i];
            }
          }
        }
      }

      OutputDCTestUtil::spmuInstrumentVoltageMeasurementSetup(
          tempPinlistVec,
          tempIsMeasuredLowForSPMUVec,
          param.spmuForceCurrentLowVec,
          param.spmuClampVoltageLowVec,
          param.spmuSettlingTimeLowVec,
          param.spmuTerminationVec,
          param.spmuLimitLowVec,
          param.testMode,
          spMeasureLow,
          hasParallelGroupForSpmuTask);
    }


    if(param.boardADCMeasureLow)
    {
      vector<string> expandedPins;
      vector<string> tempPinlistVec;
      for(vector<string>::size_type i = 0; i < param.boardADCPinlistVec.size(); i++)
      {
        expandedPinsLowForBoardADCVec.push_back(expandedPins);
        tempPinlistVec.push_back("");
        tempIsMeasuredLowForBoardADCVec.push_back(false);
      }
      vector<string> pinlistVec = (it->second)[2][0];
      for(vector<string>::size_type j = 0; j < param.boardADCPinlistVec.size(); j++)
      {
        vector<string>::const_iterator begin = param.boardADCExpandedPinsVec[j].begin();
        vector<string>::const_iterator end = param.boardADCExpandedPinsVec[j].end();

        bool isFirstTime = true;
        for(vector<string>::size_type i = 0; i< pinlistVec.size(); i++)
        {
          vector<string>::const_iterator pinIt = find(begin,end,pinlistVec[i]);
          if(pinIt != end)
          {
            expandedPinsLowForBoardADCVec[j].push_back(pinlistVec[i]);
            if(isFirstTime)
            {
              tempPinlistVec[j] += pinlistVec[i];
              isFirstTime = false;
              tempIsMeasuredLowForBoardADCVec[j] = true;
            }
            else
            {
              tempPinlistVec[j] += "," + pinlistVec[i];
            }
          }
        }
      }

      OutputDCTestUtil::boardADCInstrumentVoltageMeasurementSetup(
          tempPinlistVec,
          tempIsMeasuredLowForBoardADCVec,
          param.boardADCSettlingTimeLowVec,
          param.boardADCTerminationVec,
          param.boardADCLimitLowVec,
          param.boardADCIsHVPinsVec,
          param.testMode,
          spForceONLow,
          spMeasureLow,
          spForceOFFLow,
          boardADCHVMeasureLow,
          hasParallelGroupForSpmuTask,
          hasParallelGroupForBoardADCHVTask);
    }


    if(hasParallelGroupForPpmuMeasure && hasParallelGroupForSpmuTask)
    {
      taskListLow.add(ppmuSettingLow)
                 .add(ppmuClampOnLow)
                 .add(ppmuRelayLowStep1)
                 .add(ppmuRelayLowStep2)
                 .add(ppmuClampOffLow)
                 .add(spForceONLow);

      //HV test should be put before PPMU_MEASURE
      if (hasParallelGroupForPpmuHVMeasure)
      {
        taskListLow.add(ppmuHVMeasureLow);
      }
      if (hasParallelGroupForBoardADCHVTask)
      {
        taskListLow.add(boardADCHVMeasureLow);
      }

      taskListLow.add(ppmuMeasureLow)
                 .add(ppmuRelayRestoreLowStep1)
                 .add(ppmuRelayRestoreLowStep2)
                 .add(spMeasureLow)
                 .add(spForceOFFLow);
    }
    else if(hasParallelGroupForPpmuMeasure)
    {
      taskListLow.add(ppmuSettingLow)
                 .add(ppmuClampOnLow)
                 .add(ppmuRelayLowStep1)
                 .add(ppmuRelayLowStep2)
                 .add(ppmuClampOffLow);

      //HV test should be put before PPMU_MEASURE
      if (hasParallelGroupForPpmuHVMeasure)
      {
        taskListLow.add(ppmuHVMeasureLow);
      }
      if (hasParallelGroupForBoardADCHVTask)
      {
        taskListLow.add(boardADCHVMeasureLow);
      }

      taskListLow.add(ppmuMeasureLow)
                 .add(ppmuRelayRestoreLowStep1)
                 .add(ppmuRelayRestoreLowStep2);
    }
    else if(hasParallelGroupForSpmuTask)
    {
      taskListLow.add(spForceONLow);

      //HV test should be put before SPMU_TASK
      if (hasParallelGroupForPpmuHVMeasure)
      {
        taskListLow.add(ppmuHVMeasureLow);
      }
      if (hasParallelGroupForBoardADCHVTask)
      {
        taskListLow.add(boardADCHVMeasureLow);
      }

      taskListLow.add(spMeasureLow)
                 .add(spForceOFFLow);
    }
    else if (hasParallelGroupForPpmuHVMeasure || hasParallelGroupForBoardADCHVTask)
    {
      if (hasParallelGroupForPpmuHVMeasure)
      {
        taskListLow.add(ppmuHVMeasureLow);
      }

      if (hasParallelGroupForBoardADCHVTask)
      {
        taskListLow.add(boardADCHVMeasureLow);
      }
    }

    taskListLow.execute();


    if(param.ppmuMeasureLow)
    {
      FOR_EACH_SITE_BEGIN();
      processResultForXPMU(param.ppmuPinlistVec,
                           tempIsMeasuredLowForPPMUVec,
                           expandedPinsLowForPPMUVec,
                           param.testMode,
                           ppmuMeasureLow,
                           result.ppmuMeasureResultLowVec,
                           &(param.ppmuIsHVPinsVec),
                           &ppmuHVMeasureLow);
      FOR_EACH_SITE_END();
    }

    if(param.spmuMeasureLow)
    {
      FOR_EACH_SITE_BEGIN();
      processResultForXPMU(param.spmuPinlistVec,
                           tempIsMeasuredLowForSPMUVec,
                           expandedPinsLowForSPMUVec,
                           param.testMode,
                           spMeasureLow,
                           result.spmuMeasureResultLowVec);
      FOR_EACH_SITE_END();
    }


    if(param.boardADCMeasureLow)
    {
      FOR_EACH_SITE_BEGIN();
      processResultForXPMU(param.boardADCPinlistVec,
                           tempIsMeasuredLowForBoardADCVec,
                           expandedPinsLowForBoardADCVec,
                           param.testMode,
                           spMeasureLow,
                           result.boardADCMeasureResultLowVec,
                           &(param.boardADCIsHVPinsVec),
                           &boardADCHVMeasureLow);
      FOR_EACH_SITE_END();
    }

    ON_FIRST_INVOCATION_END();


    hasParallelGroupForPpmuMeasure = false;
    hasParallelGroupForPpmuHVMeasure = false;
    hasParallelGroupForSpmuTask = false;
    hasParallelGroupForBoardADCHVTask = false;

    SPMU_TASK spForceONHigh;
    SPMU_TASK spMeasureHigh;
    SPMU_TASK spForceOFFHigh;
    PPMU_MEASURE ppmuMeasureHigh;
    HV_DC_TASK   ppmuHVMeasureHigh;
    HV_DC_TASK   boardADCHVMeasureHigh;
    ON_FIRST_INVOCATION_BEGIN();

    PPMU_SETTING ppmuSettingHigh;
    PPMU_RELAY   ppmuRelayHighStep1,ppmuRelayHighStep2;
    PPMU_RELAY   ppmuRelayRestoreHighStep1,ppmuRelayRestoreHighStep2;
    PPMU_CLAMP   ppmuClampOnHigh, ppmuClampOffHigh;
    TASK_LIST    taskListHigh;

    if(param.ppmuMeasureHigh)
    {
      vector<string> expandedPins;
      vector<string> tempPinlistVec;
      for(vector<string>::size_type i = 0; i < param.ppmuPinlistVec.size(); i++)
      {
        expandedPinsHighForPPMUVec.push_back(expandedPins);
        tempPinlistVec.push_back("");
        tempIsMeasuredHighForPPMUVec.push_back(false);
      }
      vector<string> pinlistVec = (it->second)[0][1];
      for(vector<string>::size_type j = 0; j < param.ppmuPinlistVec.size(); j++)
      {
        vector<string>::const_iterator begin = param.ppmuExpandedPinsVec[j].begin();
        vector<string>::const_iterator end = param.ppmuExpandedPinsVec[j].end();

        bool isFirstTime = true;
        for(vector<string>::size_type i = 0; i< pinlistVec.size(); i++)
        {
          vector<string>::const_iterator pinIt = find(begin,end,pinlistVec[i]);
          if(pinIt != end)
          {
            expandedPinsHighForPPMUVec[j].push_back(pinlistVec[i]);
            if(isFirstTime)
            {
              tempPinlistVec[j] += pinlistVec[i];
              isFirstTime = false;
              tempIsMeasuredHighForPPMUVec[j] = true;
            }
            else
            {
              tempPinlistVec[j] +=  "," + pinlistVec[i];
            }
          }
        }
      }

      OutputDCTestUtil::ppmuInstrumentVoltageMeasurementSetup(
          tempPinlistVec,
          tempIsMeasuredHighForPPMUVec,
          param.ppmuForceCurrentHighVec,
          param.ppmuSettlingTimeHighVec,
          param.ppmuTerminationVec,
          param.ppmuLimitHighVec,
          param.ppmuIsHVPinsVec,
          param.testMode,
          ppmuSettingHigh,
          ppmuClampOnHigh,
          ppmuClampOffHigh,
          ppmuRelayHighStep1,
          ppmuRelayHighStep2,
          ppmuRelayRestoreHighStep1,
          ppmuRelayRestoreHighStep2,
          ppmuMeasureHigh,
          ppmuHVMeasureHigh,
          hasParallelGroupForPpmuMeasure,
          hasParallelGroupForPpmuHVMeasure);
    }

    if(param.spmuMeasureHigh)
    {
      vector<string> expandedPins;
      vector<string> tempPinlistVec;
      tempIsMeasuredHighForSPMUVec.clear();
      for(vector<string>::size_type i = 0; i < param.spmuPinlistVec.size(); i++)
      {
        expandedPinsHighForSPMUVec.push_back(expandedPins);
        tempPinlistVec.push_back("");
        tempIsMeasuredHighForSPMUVec.push_back(false);
      }
      vector<string> pinlistVec = (it->second)[1][1];
      for(vector<string>::size_type j = 0; j < param.spmuPinlistVec.size(); j++)
      {
        vector<string>::const_iterator begin = param.spmuExpandedPinsVec[j].begin();
        vector<string>::const_iterator end = param.spmuExpandedPinsVec[j].end();

        bool isFirstTime = true;
        for(vector<string>::size_type i = 0; i< pinlistVec.size(); i++)
        {
          vector<string>::const_iterator pinIt = find(begin,end,pinlistVec[i]);
          if(pinIt != end)
          {
            expandedPinsHighForSPMUVec[j].push_back(pinlistVec[i]);
            if(isFirstTime)
            {
              tempPinlistVec[j] += pinlistVec[i];
              isFirstTime = false;
              tempIsMeasuredHighForSPMUVec[j] = true;
            }
            else
            {
              tempPinlistVec[j] += "," + pinlistVec[i];
            }
          }
        }
      }

      OutputDCTestUtil::spmuInstrumentVoltageMeasurementSetup(
          tempPinlistVec,
          tempIsMeasuredHighForSPMUVec,
          param.spmuForceCurrentHighVec,
          param.spmuClampVoltageHighVec,
          param.spmuSettlingTimeHighVec,
          param.spmuTerminationVec,
          param.spmuLimitHighVec,
          param.testMode,
          spMeasureHigh,
          hasParallelGroupForSpmuTask);
    }

    if(param.boardADCMeasureHigh)
    {
      vector<string> expandedPins;
      vector<string> tempPinlistVec;
      for(vector<string>::size_type i = 0; i < param.boardADCPinlistVec.size(); i++)
      {
        expandedPinsHighForBoardADCVec.push_back(expandedPins);
        tempPinlistVec.push_back("");
        tempIsMeasuredHighForBoardADCVec.push_back(false);
      }
      vector<string> pinlistVec = (it->second)[2][1];
      for(vector<string>::size_type j = 0; j < param.boardADCPinlistVec.size(); j++)
      {
        vector<string>::const_iterator begin = param.boardADCExpandedPinsVec[j].begin();
        vector<string>::const_iterator end = param.boardADCExpandedPinsVec[j].end();

        bool isFirstTime = true;
        for(vector<string>::size_type i = 0; i< pinlistVec.size(); i++)
        {
          vector<string>::const_iterator pinIt = find(begin,end,pinlistVec[i]);
          if(pinIt != end)
          {
            expandedPinsHighForBoardADCVec[j].push_back(pinlistVec[i]);
            if(isFirstTime)
            {
              tempPinlistVec[j] += pinlistVec[i];
              isFirstTime = false;

              tempIsMeasuredHighForBoardADCVec[j] = true;
            }
            else
            {
              tempPinlistVec[j] += "," + pinlistVec[i];
            }
          }
        }
      }

      OutputDCTestUtil::boardADCInstrumentVoltageMeasurementSetup(
          tempPinlistVec,
          tempIsMeasuredHighForBoardADCVec,
          param.boardADCSettlingTimeHighVec,
          param.boardADCTerminationVec,
          param.boardADCLimitHighVec,
          param.boardADCIsHVPinsVec,
          param.testMode,
          spForceONHigh,
          spMeasureHigh,
          spForceOFFHigh,
          boardADCHVMeasureHigh,
          hasParallelGroupForSpmuTask,
          hasParallelGroupForBoardADCHVTask);
    }

    if(hasParallelGroupForPpmuMeasure && hasParallelGroupForSpmuTask)
    {
      taskListHigh.add(ppmuSettingHigh)
                  .add(ppmuClampOnHigh)
                  .add(ppmuRelayHighStep1)
                  .add(ppmuRelayHighStep2)
                  .add(ppmuClampOffHigh)
                  .add(spForceONHigh);

      //HV test should be put before PPMU_MEASURE.
      if (hasParallelGroupForPpmuHVMeasure)
      {
        taskListHigh.add(ppmuHVMeasureHigh);
      }
      if (hasParallelGroupForBoardADCHVTask)
      {
        taskListHigh.add(boardADCHVMeasureHigh);
      }

      taskListHigh.add(ppmuMeasureHigh)
                  .add(ppmuRelayRestoreHighStep1)
                  .add(ppmuRelayRestoreHighStep2)
                  .add(spMeasureHigh)
                  .add(spForceOFFHigh);
    }
    else if(hasParallelGroupForPpmuMeasure)
    {
      taskListHigh.add(ppmuSettingHigh)
                  .add(ppmuClampOnHigh)
                  .add(ppmuRelayHighStep1)
                  .add(ppmuRelayHighStep2)
                  .add(ppmuClampOffHigh);

      //HV test should be put before PPMU_MEASURE.
      if (hasParallelGroupForPpmuHVMeasure)
      {
        taskListHigh.add(ppmuHVMeasureHigh);
      }
      if (hasParallelGroupForBoardADCHVTask)
      {
        taskListHigh.add(boardADCHVMeasureHigh);
      }

      taskListHigh.add(ppmuMeasureHigh)
                  .add(ppmuRelayRestoreHighStep1)
                  .add(ppmuRelayRestoreHighStep2);
    }
    else if(hasParallelGroupForSpmuTask)
    {
      taskListHigh.add(spForceONHigh);

      //HV test should be put before SPMU_TASK.
      if (hasParallelGroupForPpmuHVMeasure)
      {
        taskListHigh.add(ppmuHVMeasureHigh);
      }
      if (hasParallelGroupForBoardADCHVTask)
      {
        taskListHigh.add(boardADCHVMeasureHigh);
      }

      taskListHigh.add(spMeasureHigh)
                  .add(spForceOFFHigh);
    }
    else if (hasParallelGroupForPpmuHVMeasure || hasParallelGroupForBoardADCHVTask)
    {
      if (hasParallelGroupForPpmuHVMeasure)
      {
        taskListHigh.add(ppmuHVMeasureHigh);
      }

      if (hasParallelGroupForBoardADCHVTask)
      {
        taskListHigh.add(boardADCHVMeasureHigh);
      }
    }

    taskListHigh.execute();

    if(param.ppmuMeasureHigh)
     {
       FOR_EACH_SITE_BEGIN();
       processResultForXPMU(param.ppmuPinlistVec,
                            tempIsMeasuredHighForPPMUVec,
                            expandedPinsHighForPPMUVec,
                            param.testMode,
                            ppmuMeasureHigh,
                            result.ppmuMeasureResultHighVec,
                            &(param.ppmuIsHVPinsVec),
                            &ppmuHVMeasureHigh
                            );
       FOR_EACH_SITE_END();
     }

     if(param.spmuMeasureHigh)
     {
       FOR_EACH_SITE_BEGIN();
       processResultForXPMU(param.spmuPinlistVec,
                            tempIsMeasuredHighForSPMUVec,
                            expandedPinsHighForSPMUVec,
                            param.testMode,
                            spMeasureHigh,
                            result.spmuMeasureResultHighVec);
       FOR_EACH_SITE_END();
     }


     if(param.boardADCMeasureHigh)
     {
       FOR_EACH_SITE_BEGIN();
       processResultForXPMU(param.boardADCPinlistVec,
                            tempIsMeasuredHighForBoardADCVec,
                            expandedPinsHighForBoardADCVec,
                            param.testMode,
                            spMeasureHigh,
                            result.boardADCMeasureResultHighVec,
                            &(param.boardADCIsHVPinsVec),
                            &boardADCHVMeasureHigh
                            );
       FOR_EACH_SITE_END();
     }

    ON_FIRST_INVOCATION_END();
  }// end-for

  if(param.activeLoadMeasureLow || param.activeLoadMeasureHigh)
  {
    doMeasurementByActiveLoad(param,result);
  }

  // reset sequencer's status
  ON_FIRST_INVOCATION_BEGIN();
    Sequencer.reset();
  ON_FIRST_INVOCATION_END();
}

/*
 *----------------------------------------------------------------------*
 * Routine: doMeasurementByActiveLoad
 *
 * Purpose: execute measurement by active load and store results
 *
 *----------------------------------------------------------------------*
 * Description:
 *   INPUT:  param       - test parameters
 *   OUTPUT: result      - result container
 *   RETURN:
 * Note:
 *   In case of GPF, please refer to following test setup tips!
 *----------------------------------------------------------------------*
 */
static void doMeasurementByActiveLoad(
    const OutputDCTestParam& param,
    OutputDCTestResult& result)
{
  string testCmd = "",answer = "";
  string originalStatus = "";
  /*
   * In case of GPF, you can make it faster:
   * HOW-TO:
   * 1.create new level sets with:
   *    primary VOH = pass min voltage.
   *    primary VOL = pass max voltage.
   * 2.select the new primary level set for testsuite.
   * 3.setup SPRM with new level sets(see example code below)
   *  3.1) for both levels test, input two level sets
   *  3.2) for single level test, input the specific level set only.
   * 4.enable this flowing code by '#define USE_OPTIMIZED_OUTPUTDC_TF_WAY'
   * 5.rebuild testmethod and run
   */

//  #define USE_OPTIMIZED_OUTPUTDC_TF_WAY

  #ifdef  USE_OPTIMIZED_OUTPUTDC_TF_WAY
  if ( TM::GPF == param.testMode)
  {
    ON_FIRST_INVOCATION_BEGIN();

      /***
       * SETUP:
       * apply optimized commands stuffs
       * it depends on your own output dc test parameters
       */
      string optimizedOutputDCTFStuffs;

      int level = 0;
      if (param.activeLoadMeasureLow && param.activeLoadMeasureHigh)
      {
        /***
         * case3.1 both levles:
         * THIS IS JUST AN EXAMPLE CODE!!! Please refer to above tips.
         */
        optimizedOutputDCTFStuffs =
          "SPRM 1,1,6,1;FTST? ;PRLT? ALL;SPRM 1,1,7,1;FTST? ;PRLT? ALL;";
      }
      else
      {
        //case3.2 single level
        optimizedOutputDCTFStuffs = "FTST?;PRLT? ALL;";

        if (param.activeLoadMeasureHigh)
        {
          level = 1;
        }
      }

      //EXECUTE
      FW_TASK(optimizedOutputDCTFStuffs,answer);

      //RESULT: get,parse and cache the results
      string::size_type  pos = answer.find("PRLT",0);
      string prltResult;
      while (pos != string::npos)
      {
        retrieveStringWithinDelimiters(answer,"\"","\"",pos+1,prltResult);
        for (string::size_type index = 0; index < prltResult.length(); ++index)
        {
          if (prltResult[index] != '0')
          {
            bool isPass = (prltResult[index] == 'P')?true:false;
            // the "index+1" of rclsResult is related to site number
            result.activeLoadMeasureGlobleResult[level].setGlobalPassFail(isPass,index+1);
          }
          else
          {
            //otherwise: the site is masked out
          }
        }
        level =  1;
        pos = answer.find("PRLT",pos+1);
      }
    ON_FIRST_INVOCATION_END();
  }
  else
  #undef USE_OPTIMIZED_OUTPUTDC_TF_WAY
  #endif
  {
    ON_FIRST_INVOCATION_BEGIN();

    string pinlist;
    vector<string>::size_type length = param.activeLoadPinlistVec.size() -1;

    for(vector<string>::size_type i= 0; i < length; i++)
    {
      pinlist += param.activeLoadPinlistVec[i] + ",";
    }
    pinlist += param.activeLoadPinlistVec[length];
      // QUERY: current status
      FW_TASK("TERM? PRM,(" + pinlist +");"+"SPST? LEV,PRM,;UPTD? LEV\n",
        originalStatus);

      // QUERY: primary receive level*/
      FW_TASK("RCLV? PRM,(" + param.activeLoadExpandedPinsVec[0][0] +")\n",answer);

      /**
       * Parse the primary receive level
       * For above command, the answer should be in format:
       * RCLV PRM,logic0Level,logic1Level,(pin)
       */
      string primaryLogic0Level,primaryLogic1Level;
      string::size_type pos =
        retrieveStringWithinDelimiters(answer,",",",",0,primaryLogic0Level);

      retrieveStringWithinDelimiters(answer,",",",",pos,primaryLogic1Level);


      if (param.activeLoadMeasureLow)
      {
        // SETUP: RCLS or RCLV,FTST,PRLT commands
        testCmd = setupActiveLoadMeasurement(
                    param.activeLoadPinlistVec,
                    param.activeLoadIsMeasureLowVec,
                    param.activeLoadForceCurrentLowVec,
                    param.activeLoadForceCurrentHighVec,
                    param.activeLoadMeasuredLevelVec,
                    param.activeLoadLimitLowVec,
                    param.activeLoadExpandedPinsVec,
                    param.testMode,
                    LOW_LEVEL,
                    primaryLogic0Level,
                    primaryLogic1Level);
        // EXECUTE:  send commands and get answer
        FW_TASK(testCmd,answer);

        // RESULT: get,parse and cache the results
        processResultForActiveLoad(param.activeLoadPinlistVec,
                                   param.activeLoadIsMeasureLowVec,
                                   param.activeLoadExpandedPinsVec,
                                   param.testMode,
                                   answer,
                                   LOW_LEVEL,
                                   result.activeLoadMeasureResultLowVec,
                                   result.activeLoadMeasureGlobleResult[0]);
      }

      if (param.activeLoadMeasureHigh)
      {
        // SETUP: RCLS or RCLV,FTST,PRLT commands
        testCmd = setupActiveLoadMeasurement(
                    param.activeLoadPinlistVec,
                    param.activeLoadIsMeasureHighVec,
                    param.activeLoadForceCurrentLowVec,
                    param.activeLoadForceCurrentHighVec,
                    param.activeLoadMeasuredLevelVec,
                    param.activeLoadLimitHighVec,
                    param.activeLoadExpandedPinsVec,
                    param.testMode,
                    HIGH_LEVEL,
                    primaryLogic0Level,
                    primaryLogic1Level);
        // EXECUTE:  send commands and get answer
        FW_TASK(testCmd,answer);

        // RESULT: get,parse and cache the results
        processResultForActiveLoad(param.activeLoadPinlistVec,
                                   param.activeLoadIsMeasureHighVec,
                                   param.activeLoadExpandedPinsVec,
                                   param.testMode,
                                   answer,
                                   HIGH_LEVEL,
                                   result.activeLoadMeasureResultHighVec,
                                   result.activeLoadMeasureGlobleResult[1]);
      }

      // RESTORE: restore to original settings*/
      if (TM::GPF == param.testMode)
      {
        /**
         * In case of GPF, Level set is changed and restored.
         * Please refer to setupActiveLoadMeasurement().
         * Now, we MUST set "UPTD LEV,1\n" to eliminate side-effect.
         */
        originalStatus.replace(originalStatus.size()-2,2,"1\n");
      }
      FW_TASK(originalStatus);
    ON_FIRST_INVOCATION_END();
//    }
  }
}

/*
 *----------------------------------------------------------------------*
 * Routine: judgeAndDatalog
 *
 * Purpose: judge and put result into event datalog stream.
 *
 *----------------------------------------------------------------------*
 * Description:
 *   judge results of 'result' with pass limits from 'param'
 *
 *   INPUT:  param       - test parameters
 *           result      - result container
 *   OUTPUT:
 *   RETURN:
 * Note:
 *----------------------------------------------------------------------*
 */
static void judgeAndDatalog(const OutputDCTestParam & param,
                            const OutputDCTestResult& result)
{
  bool hasBined = false;
  if("YES" == param.ppmuUsed)
  {
    OutputDCJudgeAndLogUtil(
        param.ppmuIsMeasureLowVec,
        param.ppmuIsMeasureHighVec,
        param.ppmuPinlistVec,
        param.ppmuExpandedPinsVec,
        param.ppmuLimitLowVec,
        param.ppmuLimitHighVec,
        param.ppmuLimitNameLowVec,
        param.ppmuLimitNameHighVec,
        result.ppmuMeasureResultLowVec,
        result.ppmuMeasureResultHighVec,
        param.testMode,
        param.testsuiteName,
        param.isPPMULimitAppliedForAllGroups,
        param.isLimitTableUsed,
        hasBined);
  }

  if("YES" == param.spmuUsed)
  {
    OutputDCJudgeAndLogUtil(
        param.spmuIsMeasureLowVec,
        param.spmuIsMeasureHighVec,
        param.spmuPinlistVec,
        param.spmuExpandedPinsVec,
        param.spmuLimitLowVec,
        param.spmuLimitHighVec,
        param.spmuLimitNameLowVec,
        param.spmuLimitNameHighVec,
        result.spmuMeasureResultLowVec,
        result.spmuMeasureResultHighVec,
        param.testMode,
        param.testsuiteName,
        param.isSPMULimitAppliedForAllGroups,
        param.isLimitTableUsed,
        hasBined);

  }

  if("YES" == param.boardADCUsed)
  {
    OutputDCJudgeAndLogUtil(
        param.boardADCIsMeasureLowVec,
        param.boardADCIsMeasureHighVec,
        param.boardADCPinlistVec,
        param.boardADCExpandedPinsVec,
        param.boardADCLimitLowVec,
        param.boardADCLimitHighVec,
        param.boardADCLimitNameLowVec,
        param.boardADCLimitNameHighVec,
        result.boardADCMeasureResultLowVec,
        result.boardADCMeasureResultHighVec,
        param.testMode,
        param.testsuiteName,
        param.isBoardADCLimitAppliedForAllGroups,
        param.isLimitTableUsed,
        hasBined);
  }

  if("YES" == param.activeLoadUsed)
  {
    OutputDCJudgeAndLogUtilForActiveLoad(
        param.activeLoadIsMeasureLowVec,
        param.activeLoadIsMeasureHighVec,
        param.activeLoadPinlistVec,
        param.activeLoadExpandedPinsVec,
        param.activeLoadLimitLowVec,
        param.activeLoadLimitHighVec,
        param.activeLoadLimitNameLowVec,
        param.activeLoadLimitNameHighVec,
        result.activeLoadMeasureResultLowVec,
        result.activeLoadMeasureResultHighVec,
        result.activeLoadMeasureGlobleResult[0],
        result.activeLoadMeasureGlobleResult[1],
        param.testMode,
        param.testsuiteName,
        param.isActiveLoadLimitAppliedForAllGroups,
        param.isLimitTableUsed,
        hasBined);
  }

  if(param.checkFunctionalResult == "ON")
  {
    //Log functional result for whole test.
    TESTSET().cont(TM::CONTINUE)
             .judgeAndLog_ParametricTest(param.testsuiteName,
                                         "FUNCTIONAL TEST ",
                                         result.funcResult?TM::Pass:TM::Fail,
                                         0.0);
  }
}



/*
 *----------------------------------------------------------------------*
 * Routine: reportToUI
 *
 * Purpose: output result to UIWindow
 *
 *----------------------------------------------------------------------*
 * Description:
 *   display:
 *       a) results from result,
 *       b) pass range from pass limits of param,
 *       c) pass or fail
 *
 *   INPUT:  param              - test parameters
 *           output             - "None" or "ReportUI"
 *           result             - result container
 *   OUTPUT:
 *   RETURN:
 * Note:
 *----------------------------------------------------------------------*
 */
static void reportToUI(const OutputDCTestParam& param,
                       const string& output,
                       const OutputDCTestResult& result)
{
  if (output == "None")
  {
    return;
  }

  if (param.hasPmuOrBoardADC)
  {
    OutputDCTestUtil::datalogToWindow(
                                "outputDC (Functional result): ",
                                 result.funcResult);
  }

  int nSiteNumber = CURRENT_SITE_NUMBER();
  if(param.measureLow)
  {
    cout << "outputDC (VOL)'" << param.testsuiteName << "'";
    cout << " Site: " << nSiteNumber << endl;
  }
  if(param.ppmuMeasureLow)
  {
    OutputDCReportToUIUtil(param.ppmuIsMeasureLowVec,
                           param.ppmuPinlistVec,
                           param.ppmuExpandedPinsVec,
                           param.ppmuLimitLowVec,
                           result.ppmuMeasureResultLowVec,
                           param.testMode,
                           param.testsuiteName,
                           output);
  }
  if(param.spmuMeasureLow)
  {
    OutputDCReportToUIUtil(param.spmuIsMeasureLowVec,
                           param.spmuPinlistVec,
                           param.spmuExpandedPinsVec,
                           param.spmuLimitLowVec,
                           result.spmuMeasureResultLowVec,
                           param.testMode,
                           param.testsuiteName,
                           output);

  }
  if(param.boardADCMeasureLow)
  {
    OutputDCReportToUIUtil(param.boardADCIsMeasureLowVec,
                           param.boardADCPinlistVec,
                           param.boardADCExpandedPinsVec,
                           param.boardADCLimitLowVec,
                           result.boardADCMeasureResultLowVec,
                           param.testMode,
                           param.testsuiteName,
                           output);
  }
  if(param.activeLoadMeasureLow)
  {
    OutputDCReportToUIUtilForActiveLoad(param.activeLoadIsMeasureLowVec,
                                        param.activeLoadPinlistVec,
                                        param.activeLoadExpandedPinsVec,
                                        param.activeLoadLimitLowVec,
                                        result.activeLoadMeasureResultLowVec,
                                        result.activeLoadMeasureGlobleResult[0],
                                        param.testMode,
                                        param.testsuiteName,
                                        output);
  }


  if(param.measureHigh)
  {
    cout << "outputDC (VOH)'" << param.testsuiteName << "'";
    cout << " Site: " << nSiteNumber << endl;
  }
  if(param.ppmuMeasureHigh)
  {
    OutputDCReportToUIUtil(param.ppmuIsMeasureHighVec,
                           param.ppmuPinlistVec,
                           param.ppmuExpandedPinsVec,
                           param.ppmuLimitHighVec,
                           result.ppmuMeasureResultHighVec,
                           param.testMode,
                           param.testsuiteName,
                           output);
  }
  if(param.spmuMeasureHigh)
  {
    OutputDCReportToUIUtil(param.spmuIsMeasureHighVec,
                           param.spmuPinlistVec,
                           param.spmuExpandedPinsVec,
                           param.spmuLimitHighVec,
                           result.spmuMeasureResultHighVec,
                           param.testMode,
                           param.testsuiteName,
                           output);
  }
  if(param.boardADCMeasureHigh)
  {
    OutputDCReportToUIUtil(param.boardADCIsMeasureHighVec,
                           param.boardADCPinlistVec,
                           param.boardADCExpandedPinsVec,
                           param.boardADCLimitHighVec,
                           result.boardADCMeasureResultHighVec,
                           param.testMode,
                           param.testsuiteName,
                           output);
  }
  if(param.activeLoadMeasureHigh)
  {
    OutputDCReportToUIUtilForActiveLoad(param.activeLoadIsMeasureHighVec,
                                        param.activeLoadPinlistVec,
                                        param.activeLoadExpandedPinsVec,
                                        param.activeLoadLimitHighVec,
                                        result.activeLoadMeasureResultHighVec,
                                        result.activeLoadMeasureGlobleResult[1],
                                        param.testMode,
                                        param.testsuiteName,
                                        output);
  }
}

private:
/*
 *----------------------------------------------------------------------*
 * Routine: OutputDcTest()
 *
 * Purpose: private default constructor of OutputDcTest Class
 *----------------------------------------------------------------------*
 * Description:
 *
 * Note:
 *----------------------------------------------------------------------*
 */
OutputDcTest();

static void OutputDCReportToUIUtil(
    const vector<bool> &isMeasuredVec,
    const vector<string> &pinlistVec,
    const vector<vector<string> > &expandedPinsVec,
    const vector<LIMIT> &limitVec,
    const vector<MeasurementResultContainer> &resultVec,
    const TM::DCTEST_MODE& mode,
    const string& testsuiteName,
    const string& output)
{
  vector<string>::size_type j = 0;
  bool bPass = true;
  int siteNumber = CURRENT_SITE_NUMBER();

  for(string::size_type i = 0; i < expandedPinsVec.size(); i++)
  {
    if (isMeasuredVec[i])
    { //report measurement result to UI window
      switch ( mode )
      {
      case TM::PVAL:
        for ( j = 0; j < expandedPinsVec[i].size(); ++j )
        {
          double dMeasValue = resultVec[i].getPinsValue(expandedPinsVec[i][j],siteNumber);
          OutputDCTestUtil::datalogToWindow(
              expandedPinsVec[i][j],
              dMeasValue,
              limitVec[i]);
        }
        break;

      case TM::PPF:
        for ( j = 0; j < expandedPinsVec[i].size(); ++j )
        {
          bPass = resultVec[i].getPinPassFail(expandedPinsVec[i][j],siteNumber);
          OutputDCTestUtil::datalogToWindow(expandedPinsVec[i][j], bPass);
        }
        break;

      case TM::GPF:
        bPass = resultVec[i].getGlobalPassFail(siteNumber);
        OutputDCTestUtil::datalogToWindow(pinlistVec[i],bPass);
        break;

      default:
        throw Error("OutputDCTest::OutputDCReportToUIUtil",
                    "Unknown Test Mode",
                    "OutputDCTest::OutputDCReportToUIUtil");
      }// end switch
    }
  }
}


static void OutputDCReportToUIUtilForActiveLoad(
    const vector<bool> &isMeasuredVec,
    const vector<string> &pinlistVec,
    const vector<vector<string> > &expandedPinsVec,
    const vector<LIMIT> &limitVec,
    const vector<MeasurementResultContainer> &resultVec,
    const MeasurementResultContainer &globalResult,
    const TM::DCTEST_MODE& mode,
    const string& testsuiteName,
    const string& output)
{
  vector<string>::size_type j = 0;
  string pinlistStr = "";
  bool bPass = true;
  bool isGPFMeasured = false;
  int siteNumber = CURRENT_SITE_NUMBER();

  for(string::size_type i = 0; i < expandedPinsVec.size(); i++)
  {
    if (isMeasuredVec[i])
    { //report measurement result to UI window
      switch ( mode )
      {
      case TM::PVAL:
        for ( j = 0; j < expandedPinsVec[i].size(); ++j )
        {
          double dMeasValue = resultVec[i].getPinsValue(expandedPinsVec[i][j],siteNumber);
          OutputDCTestUtil::datalogToWindow(
              expandedPinsVec[i][j],
              dMeasValue,
              limitVec[i]);
        }
        break;

      case TM::PPF:
        for ( j = 0; j < expandedPinsVec[i].size(); ++j )
        {
          bPass = resultVec[i].getPinPassFail(expandedPinsVec[i][j],siteNumber);
          OutputDCTestUtil::datalogToWindow(expandedPinsVec[i][j], bPass);
        }
        break;

      case TM::GPF:
        if(!isGPFMeasured)
        {
          isGPFMeasured = true;
          pinlistStr = pinlistVec[i];
        }
        else
        {
          pinlistStr += "," + pinlistVec[i];
        }
        break;

      default:
        throw Error("OutputDCTest::OutputDCReportToUIUtilForActiveLoad",
                    "Unknown Test Mode",
                    "OutputDCTest::OutputDCReportToUIUtilForActiveLoad");
      }// end switch
    }
  }
  if(isGPFMeasured)
  {
    bPass = globalResult.getGlobalPassFail(siteNumber);
    OutputDCTestUtil::datalogToWindow(pinlistStr,bPass);
  }
}


static void OutputDCJudgeAndLogUtil(
    const vector<bool> &isMeasuredLow,
    const vector<bool> &isMeasuredHigh,
    const vector<string> &pinlistVec,
    const vector<vector<string> > &expandedPinsVec,
    const vector<LIMIT> &limitLowVec,
    const vector<LIMIT> &limitHighVec,
    const vector<string> &limitNameLowVec,
    const vector<string> &limitNameHighVec,
    const vector<MeasurementResultContainer> &resultLow,
    const vector<MeasurementResultContainer> &resultHigh,
    const TM::DCTEST_MODE& mode,
    const string& testsuiteName,
    const bool isLimitAppliedForAllGroups,
    const bool isLimitTableUsed,
    bool& hasBined)
{
  int siteNumber = CURRENT_SITE_NUMBER();

  if (isLimitTableUsed)
  {
    if(!isLimitAppliedForAllGroups)
    {
      OutputDCTestUtil::judgeAndLogUtil(isMeasuredLow,
                                        isMeasuredHigh,
                                        pinlistVec,
                                        expandedPinsVec,
                                        limitLowVec,
                                        limitHighVec,
                                        limitNameLowVec,
                                        limitNameHighVec,
                                        resultLow,
                                        resultHigh,
                                        mode,
                                        testsuiteName,
                                        true,
                                        siteNumber,
                                        hasBined);
    }
    else  // one limit is applied for all groups
    {
      OutputDCTestUtil::judgeAndLogUtilForAllGroups(
                                          isMeasuredLow,
                                          isMeasuredHigh,
                                          pinlistVec,
                                          expandedPinsVec,
                                          limitLowVec,
                                          limitHighVec,
                                          limitNameLowVec,
                                          limitNameHighVec,
                                          resultLow,
                                          resultHigh,
                                          mode,
                                          testsuiteName,
                                          true,
                                          siteNumber,
                                          hasBined);
    }
  }
  else // use testflow's limit
  {
    if(!isLimitAppliedForAllGroups)
    {
      OutputDCTestUtil::judgeAndLogUtil(isMeasuredLow,
                                        isMeasuredHigh,
                                        pinlistVec,
                                        expandedPinsVec,
                                        limitLowVec,
                                        limitHighVec,
                                        limitNameLowVec,
                                        limitNameHighVec,
                                        resultLow,
                                        resultHigh,
                                        mode,
                                        testsuiteName,
                                        false,
                                        siteNumber,
                                        hasBined);
    }
    else  // one limit is applied for all groups
    {
      OutputDCTestUtil::judgeAndLogUtilForAllGroups(
                                          isMeasuredLow,
                                          isMeasuredHigh,
                                          pinlistVec,
                                          expandedPinsVec,
                                          limitLowVec,
                                          limitHighVec,
                                          limitNameLowVec,
                                          limitNameHighVec,
                                          resultLow,
                                          resultHigh,
                                          mode,
                                          testsuiteName,
                                          false,
                                          siteNumber,
                                          hasBined);
    }
  }
}


static void OutputDCJudgeAndLogUtilForActiveLoad(
    const vector<bool> &isMeasuredLow,
    const vector<bool> &isMeasuredHigh,
    const vector<string> &pinlistVec,
    const vector<vector<string> > &expandedPinsVec,
    const vector<LIMIT> &limitLowVec,
    const vector<LIMIT> &limitHighVec,
    const vector<string> &limitNameLowVec,
    const vector<string> &limitNameHighVec,
    const vector<MeasurementResultContainer> &resultLow,
    const vector<MeasurementResultContainer> &resultHigh,
    const MeasurementResultContainer& globalResultLow,
    const MeasurementResultContainer& globalResultHigh,
    const TM::DCTEST_MODE& mode,
    const string& testsuiteName,
    const bool isLimitAppliedForAllGroups,
    const bool isLimitTableUsed,
    bool hasBined)
{
  vector<string>::size_type j = 0;
  string pinlistStrLow;
  string pinlistStrHigh;
  bool isGPFMeasuredLow = false;
  bool isGPFMeasuredHigh = false;
  int siteNumber = CURRENT_SITE_NUMBER();

  bool isPassLow = true;
  bool isPassHigh = true;
  bool retLow = true;
  bool retHigh = true;
  ARRAY_D lowResultArray;
  ARRAY_D highResultArray;

  if (isLimitTableUsed) // use limit table
  {
    V93kLimits::TMLimits::LimitInfo limitInfoLow;
    V93kLimits::TMLimits::LimitInfo limitInfoHigh;
    double factorLow = 1.0;
    double factorHigh = 1.0;

    if(!isLimitAppliedForAllGroups)
    {
      for (string::size_type i = 0; i < expandedPinsVec.size(); ++i)
      {
        // restore it for every group
        retLow = true;
        retHigh = true;

        if (isMeasuredLow[i]) // judge and datalog low level measurement
        {
          limitInfoLow = V93kLimits::tmLimits.getLimit(testsuiteName + ":" + limitNameLowVec[i]);
          testmethod::SpecValue specValue;
          switch ( mode )
          {
          case TM::PVAL:
            lowResultArray.resizeNoKeep(expandedPinsVec[i].size());
            if( (limitInfoLow.Units).find('V') != string::npos)
            {
              specValue.setBaseUnit("V");
              specValue.inputValueUnit("1[V]");
              factorLow = specValue.getValueAsTargetUnit(limitInfoLow.Units);
            }
            else if(limitInfoLow.Units.empty())
            {
              factorLow = 1e3;
            }
            else
            {
              stringstream errMsg;
              errMsg << "the low limit's unit: " << limitInfoLow.Units << " is not a valid unit." <<endl
                     << "current the valid units are: mV,uV..." <<endl;
              throw Error("OutputDCTestUtil::OutputDCJudgeAndLogUtilForActiveLoad",
                          errMsg.str(),
                          "OutputDCTestUtil::OutputDCJudgeAndLogUtilForActiveLoad");
            }

            for ( j = 0; j< expandedPinsVec[i].size(); ++j )
            {
              lowResultArray[j] = resultLow[i].getPinsValue(expandedPinsVec[i][j],siteNumber) * factorLow;
            }

            TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                          expandedPinsVec[i],
                                          limitNameLowVec[i],
                                          V93kLimits::tmLimits,
                                          lowResultArray);
            break;

          case TM::PPF:
            lowResultArray.resizeNoKeep(expandedPinsVec[i].size());
            for (j = 0; j < expandedPinsVec[i].size(); ++j )
            {
              isPassLow = resultLow[i].getPinPassFail(expandedPinsVec[i][j],siteNumber);
              if(isPassLow) // for pass pin, in PPF mode, we will write 0.0 to MPR
              {
                lowResultArray[j] = 0.0;
              }
              else // for fail pin, in PPF mode, we will write 1.0 to MPR
              {
                lowResultArray[j] = 1.0;
              }
              retLow = isPassLow && retLow;
            }
              
            TESTSET().cont(TM::CONTINUE).testnumber(limitInfoLow.TestNumber)
                                        .judgeAndLog_ParametricTest(
                                            expandedPinsVec[i],
                                            limitNameLowVec[i],
                                            retLow ? TM::Pass : TM::Fail,
                                            lowResultArray);
            if(!retLow && !hasBined && limitInfoLow.BinsNumString.size() > 0)
            {
              hasBined = true;
              SET_MULTIBIN(limitInfoLow.BinsNumString,limitInfoLow.BinhNum);
            }  
            break;

          case TM::GPF:
            if (!isGPFMeasuredLow)
            {
              isGPFMeasuredLow = true;
              pinlistStrLow = pinlistVec[i];
            }
            else
            {
              pinlistStrLow += "," + pinlistVec[i];
            }
            break;

          default:
            throw Error("OutputDcTest::OutputDCJudgeAndLogUtilForActiveLoad",
                        "Unknown Test Mode",
                        "OutputDcTest::OutputDCJudgeAndLogUtilForActiveLoad");
          } // end switch
        }

        if ( isMeasuredHigh[i]) //judge and datalog high level measurement
        {
          limitInfoHigh = V93kLimits::tmLimits.getLimit(testsuiteName + ":" + limitNameHighVec[i]);
          testmethod::SpecValue specValue;
          switch ( mode )
          {
          case TM::PVAL:
            highResultArray.resizeNoKeep(expandedPinsVec[i].size());
            if( (limitInfoHigh.Units).find('V') != string::npos)
            {
              specValue.setBaseUnit("V");
              specValue.inputValueUnit("1[V]");
              factorHigh = specValue.getValueAsTargetUnit(limitInfoHigh.Units);
            }
            else if(limitInfoHigh.Units.empty())
            {
              factorHigh = 1e3;
            }
            else
            {
              stringstream errMsg;
              errMsg << "the high limit's unit: " << limitInfoHigh.Units << " is not a valid unit." <<endl
                     << "current the valid units are: mV,uV..." <<endl;
              throw Error("OutputDCTestUtil::OutputDCJudgeAndLogUtilForActiveLoad",
                          errMsg.str(),
                          "OutputDCTestUtil::OutputDCJudgeAndLogUtilForActiveLoad");
            }
            for ( j = 0; j< expandedPinsVec[i].size(); ++j )
            {
              highResultArray[j] = resultHigh[i].getPinsValue(expandedPinsVec[i][j],siteNumber) * factorHigh;
            }

            TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                          expandedPinsVec[i],
                                          limitNameHighVec[i],
                                          V93kLimits::tmLimits,
                                          highResultArray);
            break;

          case TM::PPF:
            highResultArray.resizeNoKeep(expandedPinsVec[i].size());
            for (j = 0; j < expandedPinsVec[i].size(); ++j )
            {
              isPassHigh = resultHigh[i].getPinPassFail(expandedPinsVec[i][j],siteNumber);
              if(isPassHigh) // for pass pin, in PPF mode, we will write 0.0 to MPR
              {
                highResultArray[j] = 0.0;
              }
              else // for fail pin, in PPF mode, we will write 1.0 to MPR
              {
                highResultArray[j] = 1.0;
              }
              retHigh = isPassHigh && retHigh;
            }
                 
            TESTSET().cont(TM::CONTINUE).testnumber(limitInfoHigh.TestNumber)
                                        .judgeAndLog_ParametricTest(
                                            expandedPinsVec[i],
                                            limitNameHighVec[i],
                                            retHigh ? TM::Pass : TM::Fail,
                                            highResultArray);
            if(!retHigh && !hasBined && limitInfoHigh.BinsNumString.size() > 0)
            {
              hasBined = true;
              SET_MULTIBIN(limitInfoHigh.BinsNumString,limitInfoHigh.BinhNum);
            }  
            break;

          case TM::GPF:
            if (!isGPFMeasuredHigh)
            {
              isGPFMeasuredHigh = true;
              pinlistStrHigh = pinlistVec[i];
            }
            else
            {
              pinlistStrHigh += "," + pinlistVec[i];
            }
            break;

          default:
            throw Error("OutputDcTest::OutputDCJudgeAndLogUtilForActiveLoad",
                        "Unknown Test Mode",
                        "OutputDcTest::OutputDCJudgeAndLogUtilForActiveLoad");
          }  // end switch
        }
      }// end for all groups
      if (isGPFMeasuredLow)
      {
        isPassLow = globalResultLow.getGlobalPassFail(siteNumber);
        TESTSET().cont(TM::CONTINUE).testnumber(limitInfoLow.TestNumber)
                                    .judgeAndLog_ParametricTest(
                                        pinlistStrLow,
                                        limitNameLowVec[0],
                                        isPassLow ? TM::Pass : TM::Fail,
                                        0.0);
      }
      if(!isPassLow && !hasBined && limitInfoLow.BinsNumString.size() > 0)
      {
        hasBined = true;
        SET_MULTIBIN(limitInfoLow.BinsNumString,limitInfoLow.BinhNum);
      }
      if (isGPFMeasuredHigh)
      {
        isPassHigh = globalResultHigh.getGlobalPassFail(siteNumber);
        TESTSET().cont(TM::CONTINUE).testnumber(limitInfoHigh.TestNumber)
                                    .judgeAndLog_ParametricTest(
                                        pinlistStrHigh,
                                        limitNameHighVec[0],
                                        isPassHigh ? TM::Pass : TM::Fail,
                                        0.0);
      }
      if(!isPassHigh && !hasBined && limitInfoHigh.BinsNumString.size() > 0)
      {
        hasBined = true;
        SET_MULTIBIN(limitInfoHigh.BinsNumString,limitInfoHigh.BinhNum);
      }
    }
    else // one limit is applied for all groups
    {
      int sizeOfLowArray = 0;
      int sizeOfHighArray = 0;
      vector<string> lowPinVec;
      vector<string> highPinVec;
      string lowStringPinlist;
      string highStringPinlist;
            
      int counterLow = 0;
      int counterHigh = 0;
      for(vector<string>::size_type i = 0; i < expandedPinsVec.size(); ++i)
      {
        if(isMeasuredLow[i])
        {
          sizeOfLowArray += expandedPinsVec[i].size();
          counterLow = i;
        }
        if(isMeasuredHigh[i])
        {
          sizeOfHighArray += expandedPinsVec[i].size();
          counterHigh = i;
        }
      } // end for: every group
      limitInfoLow = V93kLimits::tmLimits.getLimit(testsuiteName + ":" + limitNameLowVec[counterLow]);
      limitInfoHigh = V93kLimits::tmLimits.getLimit(testsuiteName + ":" + limitNameHighVec[counterHigh]);
      testmethod::SpecValue specValue;

      int indexLow = 0;
      int indexHigh = 0;

      switch(mode)
      {
      case TM::PVAL:
        lowResultArray.resizeNoKeep(sizeOfLowArray);
        highResultArray.resizeNoKeep(sizeOfHighArray);

        if( (limitInfoLow.Units).find('V') != string::npos)
        {
          specValue.setBaseUnit("V");
          specValue.inputValueUnit("1[V]");
          factorLow = specValue.getValueAsTargetUnit(limitInfoLow.Units);
        }
        else if(limitInfoLow.Units.empty())
        {
          factorLow = 1e3;
        }
        else
        {
          stringstream errMsg;
          errMsg << "the low limit's unit: " << limitInfoLow.Units << " is not a valid unit." <<endl
                 << "current the valid units are: mV,uV..." <<endl;
          throw Error("OutputDCTestUtil::OutputDCJudgeAndLogUtilForActiveLoad",
                      errMsg.str(),
                      "OutputDCTestUtil::OutputDCJudgeAndLogUtilForActiveLoad");
        }
        if( (limitInfoHigh.Units).find('V') != string::npos)
        {
          specValue.setBaseUnit("V");
          specValue.inputValueUnit("1[V]");
          factorHigh = specValue.getValueAsTargetUnit(limitInfoHigh.Units);
        }
        else if(limitInfoHigh.Units.empty())
        {
          factorHigh = 1e3;
        }
        else
        {
          stringstream errMsg;
          errMsg << "the high limit's unit: " << limitInfoHigh.Units << " is not a valid unit." <<endl
                 << "current the valid units are: mV,uV..." <<endl;
          throw Error("OutputDCTestUtil::OutputDCJudgeAndLogUtilForActiveLoad",
                      errMsg.str(),
                      "OutputDCTestUtil::OutputDCJudgeAndLogUtilForActiveLoad");
        }
        for(vector<string>::size_type i = 0; i < expandedPinsVec.size(); ++i)
        {
          if(isMeasuredLow[i])
          {
            for (j = 0; j < expandedPinsVec[i].size(); ++j)
            {
              lowResultArray[indexLow] =
                       resultLow[i].getPinsValue(expandedPinsVec[i][j],siteNumber) * factorLow;
              lowPinVec.push_back(expandedPinsVec[i][j]);
              indexLow++;
            } // end for: every pin
          }// end if
          if(isMeasuredHigh[i])
          {
            for (j = 0; j < expandedPinsVec[i].size(); ++j)
            {
              highResultArray[indexHigh] =
                        resultHigh[i].getPinsValue(expandedPinsVec[i][j],siteNumber) * factorHigh;
              highPinVec.push_back(expandedPinsVec[i][j]);
              indexHigh++;
            } // end for: every pin
          }// end if
        }// end for: every group
      
        if(lowPinVec.size() > 0)
        {
          TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                        lowPinVec,
                                        limitNameLowVec[0],
                                        V93kLimits::tmLimits,
                                        lowResultArray);
        }
        if(highPinVec.size() > 0)
        {
          TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                        highPinVec,
                                        limitNameHighVec[0],
                                        V93kLimits::tmLimits,
                                        highResultArray);
        }
        
        break;
          
      case TM::PPF:
        lowResultArray.resizeNoKeep(sizeOfLowArray);
        highResultArray.resizeNoKeep(sizeOfHighArray);
        for(vector<string>::size_type i = 0; i < expandedPinsVec.size(); ++i)
        {
          if(isMeasuredLow[i])
          {
            for(j = 0; j < expandedPinsVec[i].size(); ++j)
            {
              isPassLow = resultLow[i].getPinPassFail(expandedPinsVec[i][j],siteNumber);
              if(isPassLow) // for pass pin, in PPF mode, we will write 0.0 to MPR
              {
                lowResultArray[indexLow] = 0.0;
              }
              else // for fail pin, in PPF mode, we will write 1.0 to MPR
              {
                lowResultArray[indexLow] = 1.0;
              }
              retLow = isPassLow && retLow;
              lowPinVec.push_back(expandedPinsVec[i][j]);
              indexLow++;
                  
            } // end for: every pin
          } //end if 

          if(isMeasuredHigh[i])
          {
            for(j = 0; j < expandedPinsVec[i].size(); ++j)
            {
              isPassHigh = resultHigh[i].getPinPassFail(expandedPinsVec[i][j],siteNumber);
              if(isPassHigh) // for pass pin, in PPF mode, we will write 0.0 to MPR
              {
                highResultArray[indexHigh] = 0.0;
              }
              else // for fail pin, in PPF mode, we will write 1.0 to MPR
              {
                highResultArray[indexHigh] = 1.0;
              }
              retHigh = isPassHigh && retHigh;
              highPinVec.push_back(expandedPinsVec[i][j]);
              indexHigh++;
                   
            } // end for: every pin
          } //end if 
            
        } // end for: every group

        if(lowPinVec.size() > 0)
        {
          TESTSET().cont(TM::CONTINUE).testnumber(limitInfoLow.TestNumber)
                                      .judgeAndLog_ParametricTest(
                                          lowPinVec,
                                          limitNameLowVec[0],
                                          retLow ? TM::Pass : TM::Fail,
                                          lowResultArray);
        }
        if(!hasBined && !retLow && limitInfoLow.BinsNumString.size() > 0)
        {
          hasBined = true;
          SET_MULTIBIN(limitInfoLow.BinsNumString,limitInfoLow.BinhNum);
        }     
        if(highPinVec.size() > 0)
        {
          TESTSET().cont(TM::CONTINUE).testnumber(limitInfoHigh.TestNumber)
                                      .judgeAndLog_ParametricTest(
                                          highPinVec,
                                          limitNameHighVec[0],
                                          retHigh ? TM::Pass : TM::Fail,
                                          highResultArray);
        }
        if(!hasBined && !retHigh && limitInfoHigh.BinsNumString.size() > 0)
        {
          hasBined = true;
          SET_MULTIBIN(limitInfoHigh.BinsNumString,limitInfoHigh.BinhNum);
        }        
        break;
          
      case TM::GPF:
        for(vector<string>::size_type i = 0; i < expandedPinsVec.size(); ++i)
        {
          if(isMeasuredLow[i])
          {
            if (!isGPFMeasuredLow)
            {
              isGPFMeasuredLow = true;
              pinlistStrLow = pinlistVec[i];
            }
            else
            {
              pinlistStrLow += "," + pinlistVec[i];
            }
          }
          if(isMeasuredHigh[i])
          {
            if (!isGPFMeasuredHigh)
            {
              isGPFMeasuredHigh = true;
              pinlistStrHigh = pinlistVec[i];
            }
            else
            {
              pinlistStrHigh += "," + pinlistVec[i];
            }
          }
        }
            
        if(isGPFMeasuredLow)
        {
          isPassLow = globalResultLow.getGlobalPassFail(siteNumber);
          TESTSET().cont(TM::CONTINUE).testnumber(limitInfoLow.TestNumber)
                                      .judgeAndLog_ParametricTest(
                                          pinlistStrLow,
                                          limitNameLowVec[0],
                                          isPassLow ? TM::Pass : TM::Fail,
                                          0.0);
        }
        if(!hasBined && !isPassLow  && limitInfoLow.BinsNumString.size() > 0)
        {
          hasBined = true;
          SET_MULTIBIN(limitInfoLow.BinsNumString,limitInfoLow.BinhNum);
        }
        if(isGPFMeasuredHigh)
        {
          isPassHigh = globalResultHigh.getGlobalPassFail(siteNumber);
          TESTSET().cont(TM::CONTINUE).testnumber(limitInfoHigh.TestNumber)
                                      .judgeAndLog_ParametricTest(
                                          pinlistStrHigh,
                                          limitNameHighVec[0],
                                          isPassHigh ? TM::Pass : TM::Fail,
                                          0.0);
        }
        if(!hasBined && !isPassHigh && limitInfoHigh.BinsNumString.size() > 0)
        {
          hasBined = true;
          SET_MULTIBIN(limitInfoHigh.BinsNumString,limitInfoHigh.BinhNum);
        }

        break;
      default:
        throw Error("OutputDCTest::OutputDCJudgeAndLogUtilForActiveLoad",
                    "Unknown Test Mode",
                    "OUtputDCTest::OutputDCJudgeAndLogUtilForActiveLoad");
          
      } // end switch
    }
  }
  else // use testflow limits
  {
    if(!isLimitAppliedForAllGroups)
    {
      for (string::size_type i = 0; i < expandedPinsVec.size(); ++i)
      {
        // restore it for every group
        retLow = true;
        retHigh = true;
        if (isMeasuredLow[i]) // judge and datalog low level measurement
        {
          switch ( mode )
          {
          case TM::PVAL:
            lowResultArray.resizeNoKeep(expandedPinsVec[i].size());
            for (j = 0; j < expandedPinsVec[i].size(); ++j)
            {
              lowResultArray[j] = resultLow[i].getPinsValue(expandedPinsVec[i][j],siteNumber);
            }
            TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                            expandedPinsVec[i],
                                            limitNameLowVec[i],
                                            limitLowVec[i],
                                            lowResultArray); 
            break;

          case TM::PPF:
            lowResultArray.resizeNoKeep(expandedPinsVec[i].size());  
            for (j = 0; j < expandedPinsVec[i].size(); ++j )
            {
              isPassLow = resultLow[i].getPinPassFail(expandedPinsVec[i][j],siteNumber);
              if(isPassLow) // for pass pin, in PPF mode, we will write 0.0 to MPR
              {
                lowResultArray[j] = 0.0;
              }
              else // for fail pin, in PPF mode, we will write 1.0 to MPR
              {
                lowResultArray[j] = 1.0;
              }
              retLow = isPassLow && retLow;
            }
            TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                            expandedPinsVec[i],
                                            limitNameLowVec[i],
                                            retLow ? TM::Pass : TM::Fail,
                                            lowResultArray);
            break;

          case TM::GPF:
            if (!isGPFMeasuredLow)
            {
              isGPFMeasuredLow = true;
              pinlistStrLow = pinlistVec[i];
            }
            else
            {
              pinlistStrLow += "," + pinlistVec[i];
            }
            break;

          default:
            throw Error("OutputDcTest::OutputDCJudgeAndLogUtilForActiveLoad",
                        "Unknown Test Mode",
                        "OutputDcTest::OutputDCJudgeAndLogUtilForActiveLoad");
          } // end switch
        }

        if ( isMeasuredHigh[i]) //judge and datalog high level measurement
        {
          switch ( mode )
          {
          case TM::PVAL:
            highResultArray.resizeNoKeep(expandedPinsVec[i].size());
            for (j = 0; j < expandedPinsVec[i].size(); ++j)
            {
              highResultArray[j] = resultHigh[i].getPinsValue(expandedPinsVec[i][j],siteNumber);
            }
            TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                            expandedPinsVec[i],
                                            limitNameHighVec[i],
                                            limitHighVec[i],
                                            highResultArray); 
            break;

          case TM::PPF:
            highResultArray.resizeNoKeep(expandedPinsVec[i].size());  
            for (j = 0; j < expandedPinsVec[i].size(); ++j )
            {
              isPassHigh = resultHigh[i].getPinPassFail(expandedPinsVec[i][j],siteNumber);
              if(isPassHigh) // for pass pin, in PPF mode, we will write 0.0 to MPR
              {
                highResultArray[j] = 0.0;
              }
              else // for fail pin, in PPF mode, we will write 1.0 to MPR
              {
                highResultArray[j] = 1.0;
              }
              retHigh = isPassHigh && retHigh;
            }
            TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                            expandedPinsVec[i],
                                            limitNameHighVec[i],
                                            retHigh ? TM::Pass : TM::Fail,
                                            highResultArray);
            break;

          case TM::GPF:
            if (!isGPFMeasuredHigh)
            {
              isGPFMeasuredHigh = true;
              pinlistStrHigh = pinlistVec[i];
            }
            else
            {
              pinlistStrHigh += "," + pinlistVec[i];
            }
            break;
          default:
            throw Error("OutputDcTest::OutputDCJudgeAndLogUtilForActiveLoad",
                        "Unknown Test Mode",
                        "OutputDcTest::OutputDCJudgeAndLogUtilForActiveLoad");
          }  // end switch
        }
      } // end for all groups

      if (isGPFMeasuredLow)
      {
        isPassLow = globalResultLow.getGlobalPassFail(siteNumber);
        TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                        pinlistStrLow,
                                        limitNameLowVec[0],
                                        isPassLow ? TM::Pass : TM::Fail,
                                        0.0);
      }
      if (isGPFMeasuredHigh)
      {
        isPassHigh = globalResultHigh.getGlobalPassFail(siteNumber);
        TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                        pinlistStrHigh,
                                        limitNameHighVec[0],
                                        isPassHigh ? TM::Pass : TM::Fail,
                                        0.0);
      }
    }
    else // one limit is applied for all groups
    {
      int sizeOfLowArray = 0;
      int sizeOfHighArray = 0;
      vector<string> lowPinVec;
      vector<string> highPinVec;
            
      for(vector<string>::size_type i = 0; i < expandedPinsVec.size(); ++i)
      {
        if(isMeasuredLow[i])
        {
          sizeOfLowArray += expandedPinsVec[i].size();
        }
        if(isMeasuredHigh[i])
        {
          sizeOfHighArray += expandedPinsVec[i].size();
        }
      } // end for: every group
           
      int indexLow = 0;
      int indexHigh = 0;
      switch(mode)
      {
      case TM::PVAL:
        lowResultArray.resizeNoKeep(sizeOfLowArray);
        highResultArray.resizeNoKeep(sizeOfHighArray);
        for(vector<string>::size_type i = 0; i < expandedPinsVec.size(); ++i)
        {
          if(isMeasuredLow[i])
          {
            for (j = 0; j < expandedPinsVec[i].size(); ++j)
            {
              lowResultArray[indexLow] = resultLow[i].getPinsValue(expandedPinsVec[i][j],siteNumber);
              lowPinVec.push_back(expandedPinsVec[i][j]);
              indexLow++;
            } // end for: every pin
          }// end if  
          if(isMeasuredHigh[i])
          {
            for (j = 0; j < expandedPinsVec[i].size(); ++j)
            {
              highResultArray[indexHigh] = resultHigh[i].getPinsValue(expandedPinsVec[i][j],siteNumber);
              highPinVec.push_back(expandedPinsVec[i][j]);
              indexHigh++;
            } // end for: every pin
          }// end if
        }// end for: every group
          
        if(lowPinVec.size() > 0)
        {
          TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                          lowPinVec,
                                          limitNameLowVec[0],
                                          limitLowVec[0],
                                          lowResultArray);
        }
        if(highPinVec.size() > 0)
        {
          TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                          highPinVec,
                                          limitNameHighVec[0],
                                          limitHighVec[0],
                                          highResultArray);
        }
          
        break;
              
      case TM::PPF:
        lowResultArray.resizeNoKeep(sizeOfLowArray);
        highResultArray.resizeNoKeep(sizeOfHighArray);
        for(vector<string>::size_type i = 0; i < expandedPinsVec.size(); ++i)
        {
          if(isMeasuredLow[i])
          {
            for(j = 0; j < expandedPinsVec[i].size(); ++j)
            {
              isPassLow = resultLow[i].getPinPassFail(expandedPinsVec[i][j],siteNumber);
              if(isPassLow) // for pass pin, in PPF mode, we will write 0.0 to MPR
              {
                lowResultArray[indexLow] = 0.0;
              }
              else // for fail pin, in PPF mode, we will write 1.0 to MPR
              {
                lowResultArray[indexLow] = 1.0;
              }
              retLow = isPassLow && retLow;
              lowPinVec.push_back(expandedPinsVec[i][j]);
              indexLow++;
                 
            } // end for: every pin
          } //end if 

          if(isMeasuredHigh[i])
          {
            for(j = 0; j < expandedPinsVec[i].size(); ++j)
            {
              isPassHigh = resultHigh[i].getPinPassFail(expandedPinsVec[i][j],siteNumber);
              if(isPassHigh) // for pass pin, in PPF mode, we will write 0.0 to MPR
              {
                highResultArray[indexHigh] = 0.0;
              }
              else // for fail pin, in PPF mode, we will write 1.0 to MPR
              {
                highResultArray[indexHigh] = 1.0;
              }
              retHigh = isPassHigh && retHigh;
              highPinVec.push_back(expandedPinsVec[i][j]);
              indexHigh++;
                  
            } // end for: every pin
          } //end if 
            
        } // end for: every group

        if(lowPinVec.size() > 0)
        {
          TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                          lowPinVec,
                                          limitNameLowVec[0],
                                          retLow ? TM::Pass : TM::Fail,
                                          lowResultArray);
        }
        if(highPinVec.size() > 0)
        {
          TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                          highPinVec,
                                          limitNameHighVec[0],
                                          retHigh ? TM::Pass : TM::Fail,
                                          highResultArray);
        }       
        break;
              
      case TM::GPF:
        for(vector<string>::size_type i = 0; i < expandedPinsVec.size(); ++i)
        {
          if(isMeasuredLow[i])
          {
            if (!isGPFMeasuredLow)
            {
              isGPFMeasuredLow = true;
              pinlistStrLow = pinlistVec[i];
            }
            else
            {
              pinlistStrLow += "," + pinlistVec[i];
            }
          }
          if(isMeasuredHigh[i])
          {
            if (!isGPFMeasuredHigh)
            {
              isGPFMeasuredHigh = true;
              pinlistStrHigh = pinlistVec[i];
            }
            else
            {
              pinlistStrHigh += "," + pinlistVec[i];
            }
          }
        }
              
        if(isGPFMeasuredLow)
        {
          isPassLow = globalResultLow.getGlobalPassFail(siteNumber);
          TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                          pinlistStrLow,
                                          limitNameLowVec[0],
                                          isPassLow ? TM::Pass : TM::Fail,
                                          0.0);
        }
        if(isGPFMeasuredHigh)
        {
          isPassHigh = globalResultHigh.getGlobalPassFail(siteNumber);
          TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                          pinlistStrHigh,
                                          limitNameHighVec[0],
                                          isPassHigh ? TM::Pass : TM::Fail,
                                          0.0);
        }
        break;
        
      default:
        throw Error("OutputDcTest::OutputDCJudgeAndLogUtilForActiveLoad",
                    "Unknown Test Mode",
                    "OutputDcTest::OutputDCJudgeAndLogUtilForActiveLoad");
            
      } // end switch    
    
    }
  }

}


/*
 *----------------------------------------------------------------------*
 * Routine: processResultForXPMU
 *
 * Purpose: retrieve and store test results for PMU or SPMU measurement.
 *
 *----------------------------------------------------------------------*
 * Description:
 *   INPUT:  pinlist  - the measured pinlist
 *           param    - test parameters
 *           xpmuTask - object of PPMU_MEASURE or SPMU_TASK.
 *           level    - LOW_LEVEL or HIGH_LEVEL
 *   OUTPUT: results  - result container in which results are stored.
 *   RETURN: none
 * Note:
 *   xpmutTaskType must be
 *          PPMU_MEASURE or SPMU_TASK,
 *   which have same operation interfaces for retrieving test result.
 *----------------------------------------------------------------------*
 */
template<class xpmuTaskType>
static void processResultForXPMU(
    const vector<string>& pinlistVec,
    const vector<bool>&   isMeasuredVec,
    const vector<vector<string> >& expandedPinsVec,
    const TM::DCTEST_MODE& testMode,
    const xpmuTaskType&   measurePmu,
    vector<MeasurementResultContainer>&  resultVec,
    const vector<bool> *isHVPinVec = NULL,
    const HV_DC_TASK *hvMeasurePmu = NULL
    )
{
  // get test result
  MeasurementResultContainer everyGroupResult;
  int siteNumber = CURRENT_SITE_NUMBER();
  for(vector<string>::size_type i = 0; i < pinlistVec.size(); i++)
  {
    if(resultVec.size() <= i)
    {
      everyGroupResult.init();
      resultVec.push_back(everyGroupResult);
    }
    if(isMeasuredVec[i])
    {
      vector<string>::size_type  j = 0;
      bool isPass = true;
      switch ( testMode )
      {
      case TM::PVAL:
        if (isHVPinVec != NULL && (*isHVPinVec)[i])
        {
          if (hvMeasurePmu != NULL)
          {
            for ( j = 0; j < expandedPinsVec[i].size(); j++ )
            {
              isPass = hvMeasurePmu->getPassFail(expandedPinsVec[i][j]);
              double dMeasValue = hvMeasurePmu->getValue(expandedPinsVec[i][j]);

              resultVec[i].setPinPassFail(expandedPinsVec[i][j],isPass,siteNumber);
              resultVec[i].setPinsValue(expandedPinsVec[i][j],dMeasValue,siteNumber);
            }
          }
        }
        else
        {
          for ( j = 0; j < expandedPinsVec[i].size(); j++ )
          {
            isPass = measurePmu.getPassFail(expandedPinsVec[i][j]);
            double dMeasValue = measurePmu.getValue(expandedPinsVec[i][j]);

            resultVec[i].setPinPassFail(expandedPinsVec[i][j],isPass,siteNumber);
            resultVec[i].setPinsValue(expandedPinsVec[i][j],dMeasValue,siteNumber);
          }
        }
        break;
      case TM::PPF:
        if (isHVPinVec != NULL && (*isHVPinVec)[i])
        {
          if (hvMeasurePmu != NULL)
          {
            for ( j = 0; j < expandedPinsVec[i].size(); j++ )
            {
              isPass = hvMeasurePmu->getPassFail(expandedPinsVec[i][j]);
              resultVec[i].setPinPassFail(expandedPinsVec[i][j],isPass,siteNumber);
            }
          }
        }
        else
        {
          for ( j = 0; j < expandedPinsVec[i].size(); j++ )
          {
            isPass = measurePmu.getPassFail(expandedPinsVec[i][j]);
            resultVec[i].setPinPassFail(expandedPinsVec[i][j],isPass,siteNumber);
          }
        }
        break;
      case TM::GPF:
        if (isHVPinVec != NULL && (*isHVPinVec)[i])
        {
          if (hvMeasurePmu != NULL)
          {
            isPass = hvMeasurePmu->getPassFail();
            resultVec[i].setGlobalPassFail(isPass,siteNumber);
          }
        }
        else
        {
          isPass = measurePmu.getPassFail();
          resultVec[i].setGlobalPassFail(isPass,siteNumber);
        }
        break;
      default:
        throw Error("OutputDcUtil::processResultForXPMU",
                    "Unknown Measure Mode",
                    "OutputDcUtil::processResultForXPMU");
      }
    }
  }
}


/*
 *----------------------------------------------------------------------*
 * Routine: retrieveStringWithinDelimiters
 *
 * Purpose: retrieve substring within 'start' and 'stop' delimiters.
 *
 *----------------------------------------------------------------------*
 * Description:
 *   INPUT:  originalString - parsed string.
 *           startDelimiter - test parameters
 *           stopDelimiter  - LOW_LEVEL or HIGH_LEVEL
 *           startPos       - starting pos for searching startDelimiter.
 *   OUTPUT: returnString   - target substring between start and stop
 *                            delimiters.
 *   RETURN: pos            - the position of stop delimiter.
 * Note:
 *
 *----------------------------------------------------------------------*
 */
static string::size_type retrieveStringWithinDelimiters(const string& originalString,
                                                        const string& startDelimiter,
                                                        const string& stopDelimiter,
                                                        const string::size_type startPos,
                                                        string& returnString)
{
  string::size_type startDelimPos = string::npos;
  string::size_type stopDelimPos = string::npos;
  returnString = "";
  startDelimPos = originalString.find_first_of(startDelimiter,startPos);
  stopDelimPos = originalString.find_first_of(stopDelimiter,startDelimPos+1);
  if (startDelimPos != STRING::npos && stopDelimPos != STRING::npos)
  {
    returnString = originalString.substr(startDelimPos+1,stopDelimPos-startDelimPos-1);
  }
  return stopDelimPos;
}

/*
 *----------------------------------------------------------------------*
 * Routine: searchOutputLevelByOUTS
 *
 * Purpose: search Low and/or High output level by OUTS?.
 *
 *----------------------------------------------------------------------*
 * Description:
 *   INPUT:  param                - test parameters
 *
 *   OUTPUT: measurePositions      - map of measurement positions of pins
 *   RETURN: None.
 * Note:
 *
 *----------------------------------------------------------------------*
 */
static void searchOutputLevelByOUTS(
    const OutputDCTestParam& param,
    map<int,map<int,map<int,vector<string> > > >& measurePositions)
{
  string testCmd,commonCmd,commandForLow,commandForHigh,answer;
  string token;
  int cycNum = 0;
  
  //QUERY: measurement positions
  commonCmd = "OUTS? ";
  commonCmd += param.cycNum[0] + ",";
  commonCmd += param.cycNum[1] + ",";
  commonCmd += param.searchType+ ",";
  commandForLow = "LOW,(";
  commandForHigh = "HIGH,(";
  if("YES" == param.ppmuUsed)
  {
    for(vector<bool>::size_type i = 0; i < param.ppmuPinlistVec.size() ; i++)
    {
      if(param.ppmuIsMeasureLowVec[i])
      {
        commandForLow += PinUtility.createPinListFromPinNames(param.ppmuExpandedPinsVec[i]);
        commandForLow += ",";
      }
      if(param.ppmuIsMeasureHighVec[i])
      {
        commandForHigh += PinUtility.createPinListFromPinNames(param.ppmuExpandedPinsVec[i]);
        commandForHigh += ",";
      }
    }

    if(param.ppmuMeasureLow)
    {
      commandForLow.replace(commandForLow.size()-1,1,1,')');
      commandForLow += ";";

      testCmd = testCmd + commonCmd + commandForLow;
    }


    if(param.ppmuMeasureHigh)
    {
      testCmd += "NOOP?,,,;";
      commandForHigh.replace(commandForHigh.size()-1,1,1,')');
      commandForHigh += ";";

      testCmd += commonCmd + commandForHigh;
    }

  }

  testCmd = testCmd + "ECHO?" + ";";

  commandForLow = "LOW,(";
  commandForHigh = "HIGH,(";
  if("YES" == param.spmuUsed)
  {
    for(vector<bool>::size_type i = 0; i < param.spmuPinlistVec.size() ; i++)
    {
      if(param.spmuIsMeasureLowVec[i])
      {
        commandForLow += PinUtility.createPinListFromPinNames(param.spmuExpandedPinsVec[i]);
        commandForLow += ",";
      }
      if(param.spmuIsMeasureHighVec[i])
      {
        commandForHigh += PinUtility.createPinListFromPinNames(param.spmuExpandedPinsVec[i]);
        commandForHigh += ",";
      }
    }

    if(param.spmuMeasureLow)
    {
      commandForLow.replace(commandForLow.size()-1,1,1,')');
      commandForLow += ";";

      testCmd = testCmd + commonCmd + commandForLow;
    }


    if(param.spmuMeasureHigh)
    {
      testCmd += "NOOP?,,,;";
      commandForHigh.replace(commandForHigh.size()-1,1,1,')');
      commandForHigh += ";";

      testCmd += commonCmd + commandForHigh;
    }

  }

  testCmd = testCmd + "ECHO?" + ";";

  commandForLow = "LOW,(";
  commandForHigh = "HIGH,(";
  if("YES" == param.boardADCUsed)
  {
    for(vector<bool>::size_type i = 0; i < param.boardADCPinlistVec.size() ; i++)
    {
      if(param.boardADCIsMeasureLowVec[i])
      {
        commandForLow += PinUtility.createPinListFromPinNames(param.boardADCExpandedPinsVec[i]);
        commandForLow += ",";
      }
      if(param.boardADCIsMeasureHighVec[i])
      {
        commandForHigh += PinUtility.createPinListFromPinNames(param.boardADCExpandedPinsVec[i]);
        commandForHigh += ",";
      }
    }

    if(param.boardADCMeasureLow)
    {
      commandForLow.replace(commandForLow.size()-1,1,1,')');
      commandForLow += ";";

      testCmd = testCmd + commonCmd + commandForLow;
    }

    if(param.boardADCMeasureHigh)
    {
      testCmd += "NOOP?,,,;";
      commandForHigh.replace(commandForHigh.size()-1,1,1,')');
      commandForHigh += ";";

      testCmd += commonCmd + commandForHigh;
    }
  }
  FW_TASK(testCmd,answer);
  

  // PARSE: measurement points
  string::size_type pos = 0;

  vector<string> instrumentAnswerVec;
  OutputDCTestUtil::splitString(answer,instrumentAnswerVec,"ECHO \n");
  for(vector<string>::size_type index = 0;
      index < instrumentAnswerVec.size();
      index++)
  {
    if(instrumentAnswerVec[index].empty())
    {
      measurePositions[-1][index][-1].push_back("dummy");
      continue;
    }
    vector<string> levelAnswerVec;
    OutputDCTestUtil::splitString(instrumentAnswerVec[index],levelAnswerVec,"NOOP ,,,\n");
    for(vector<string>::size_type i = 0; i < levelAnswerVec.size(); i++)
    {
      if(levelAnswerVec[i].empty())
      {
        measurePositions[-1][index][-1].push_back("dummy");
        continue;
      }

      pos = 0;
      while((pos = levelAnswerVec[i].find("OUTS",pos)) != string::npos)
      {
        //get cycle number
        pos = retrieveStringWithinDelimiters(levelAnswerVec[i]," ",",",pos,token);
        cycNum = static_cast<int>( OutputDCTestUtil::string2Long(token,"OUTS amount number till this cycles"));
        cycNum = cycNum -1;  // convert amount of cycles to the cycle number

        //get pinlist
        pos = retrieveStringWithinDelimiters(levelAnswerVec[i],"(",")",pos,token);
        vector<string> pinVec;
        OutputDCTestUtil::parseListOfString(token,pinVec,',');
        for(vector<string>::size_type k = 0; k < pinVec.size(); k++)
        {
          measurePositions[cycNum][index][i].push_back(pinVec[k]);
        }
      }
    }
  }

}

/*
 *----------------------------------------------------------------------*
 * Routine: setupActiveLoadMeasurement
 *
 * Purpose: construct FW commands string for active load measurement
 *
 *----------------------------------------------------------------------*
 * Description:
 *   INPUT:  pinlistVec         - pinlist parameters vector
 *           isMeasuredVec      - every element in this parameter indicate
 *                                whether this group will be measured
 *           forceCurrentVec    - force current for every group
 *           limitVec           - limit for every group
 *           expandedPinsVec    - expanded pins of every group
 *           testMode           - test mode: PVAL  PPF  GPF
 *           measuredLevel      - LOW_LEVEL or HIGH_LEVEL
 *           primaryLogic0Level - primary VOL
 *           primaryLogic1Level - primary VOH
 *   OUTPUT:
 *   RETURN: FW commands string for measurement
 * Note:
 *   1. works for each specific level: LOW_LEVEL or HIGH_LEVEL.
 *   2. must be called inside ON_FIRST_INVOCATION_BEGIN/END block,
 *      because FOR_EACH_SITE_BEGIN/END block is used below.
 *----------------------------------------------------------------------*
 */
static const string setupActiveLoadMeasurement(
    const vector<string>& pinlistVec,
    const vector<bool>&   isMeasuredVec,
    const vector<double>& forceCurrentLowVec,
    const vector<double>& forceCurrentHighVec,
    const vector<string>& measureLevelVec,
    const vector<LIMIT>&  limitVec,
    const vector<vector<string> > expandedPinsVec,
    const TM::DCTEST_MODE& testMode,
    const MeasuredLevelType levelType,
    const string& primaryLogic0Level,
    const string& primaryLogic1Level)
{
  string rclsCmd = ""; //local variable
  string testCmd = ""; //returned variable
  string pinlist = "";
  double commVoltage_mV = 0.0;
  double Iol_uA = 0.0;
  double Ioh_uA = 0.0;

  for(vector<string>::size_type i = 0; i < pinlistVec.size(); i++)
  {
    if(isMeasuredVec[i])
    {
      rclsCmd = "";

      // currently actual measure level
      if(LOW_LEVEL == levelType)
      {
        double high = 0.0;
        limitVec[i].getHigh(&high);
        commVoltage_mV = (forceCurrentLowVec[i] < 0)?
                         (high*1000 - 1000)
                         :(high*1000 + 1000);
      }
      else
      {
        double low = 0.0;
        limitVec[i].getLow(&low);
        commVoltage_mV = (forceCurrentHighVec[i] < 0)?
                         (low*1000 - 1000)
                         :(low*1000 + 1000);

      }

      // input measure level
      if ("LOW" == measureLevelVec[i])
      {
        // input measure level
        Iol_uA = abs(forceCurrentLowVec[i]);
        // set Ioh same as Iol for TERM commands.
        Ioh_uA = Iol_uA;
      }
      else if("HIGH" == measureLevelVec[i])
      {
        // input measure level
        Ioh_uA = abs(forceCurrentHighVec[i]);
        // set Iol same as Iol for TERM commands.
        Iol_uA = Ioh_uA;
      }
      else
      {
        // input measure level
        Iol_uA = abs(forceCurrentLowVec[i]);
        Ioh_uA = abs(forceCurrentHighVec[i]);

      }

      testCmd += "TERM PRM,A,";
      testCmd += OutputDCTestUtil::double2String(commVoltage_mV) + ",";
      testCmd += OutputDCTestUtil::double2String(Iol_uA) + ",";
      testCmd += OutputDCTestUtil::double2String(Ioh_uA) + ",";
      testCmd += "AUTO,AUTO,("+ pinlistVec[i] + ")\n";

      if(TM::PVAL == testMode)
      {
        if (LOW_LEVEL == levelType)
        {
          for (vector<string>::size_type index = 0;
               index < expandedPinsVec[i].size();
               ++index)
          {
            rclsCmd += "RCLS? ";
            rclsCmd += "L," + primaryLogic0Level + "," + primaryLogic0Level + ",";
            rclsCmd += "(" + expandedPinsVec[i][index] + ")\n";
          }
        }
        else
        {
          for (STRING::size_type index = 0;
               index < expandedPinsVec[i].size();
               ++index)
          {
            rclsCmd += "RCLS? ";
            rclsCmd += "H," + primaryLogic1Level + "," + primaryLogic1Level + ",";
            rclsCmd += "(" + expandedPinsVec[i][index] + ")\n";
          }
        }
        // combine command with query site focus
        FOR_EACH_SITE_BEGIN();
          testCmd += "PQFC "
                     +OutputDCTestUtil::double2String(CURRENT_SITE_NUMBER())
                     +"\n";
          testCmd += rclsCmd;
        FOR_EACH_SITE_END();
      }
      else if(TM::PPF == testMode)
      {
        if (LOW_LEVEL == levelType)
        {
          double high = 0.0;
          limitVec[i].getHigh(&high);
          for (vector<string>::size_type index = 0;
               index < expandedPinsVec[i].size();
               ++index)
          {
            rclsCmd += "RCLS? ";
            rclsCmd += "L,"
                       +OutputDCTestUtil::double2String(high*1e3)
                       +",,";
            rclsCmd += "(" + expandedPinsVec[i][index] + ")\n";
          }
        }
        else
        {
          for (vector<string>::size_type index = 0;
               index < expandedPinsVec[i].size();
               ++index)
          {
            double low = 0.0;
            limitVec[i].getLow(&low);
            rclsCmd += "RCLS? ";
            rclsCmd += "H,"
                       +OutputDCTestUtil::double2String(low*1e3)
                       +",,";
            rclsCmd += "(" + expandedPinsVec[i][index] + ")\n";
          }
        }
        // combine command with query site focus
        FOR_EACH_SITE_BEGIN();
          testCmd += "PQFC "
                     +OutputDCTestUtil::double2String(CURRENT_SITE_NUMBER())
                     +"\n";
          testCmd += rclsCmd;
        FOR_EACH_SITE_END();
      }
      else  // GPF: Gloabl Pass Fail
      {
        if (LOW_LEVEL == levelType)
        {
          double high = 0.0;
          limitVec[i].getHigh(&high);
          testCmd += "RCLV PRM,";
          testCmd += OutputDCTestUtil::double2String(high*1e3)
                     +",";
          testCmd += primaryLogic1Level + ",";
        }
        else
        {
          double low = 0.0;
          limitVec[i].getLow(&low);
          testCmd += "RCLV PRM,";
          testCmd += primaryLogic0Level + ",";
          testCmd += OutputDCTestUtil::double2String(low*1e3)
                     +",";
        }

//        testCmd += "("+pinlistVec[i]+");";
        pinlist += pinlistVec[i] + ",";
      }
    }
  }

  if(TM::GPF == testMode)
  {
    // to remove the last character ','
    pinlist = pinlist.substr(0,pinlist.length() -1);
    testCmd += "(" + pinlist + ");";
    testCmd += "FTST?;PRLT? ALL\n";
    // restore receive level settings
    testCmd += "RCLV PRM,"+primaryLogic0Level+","+primaryLogic1Level
               +",(" + pinlist + ")\n";

    /* NOTE!!!
     * Level set is changed by RCLV command which MUST be restored after this test,
     * and should set "UPTD LEV,1\n" anyway to avoid interruption to others.
     * NOTE!!!
     * this is done in doMeasurementByActiveLoad()
     */
  }
  return testCmd;
}

/*
 *----------------------------------------------------------------------*
 * Routine: processResultForActiveLoad
 *
 * Purpose: parse and record test result
 *
 *----------------------------------------------------------------------*
 * Description:
 *   INPUT:  pinlistVec         - pinlist parameters vector
 *           isMeasuredVec      - every element in this parameter indicate
 *                                whether this group will be measured
 *           expandedPinsVec    - expanded pins of every group
 *           testMode           - test mode: PVAL  PPF  GPF
 *           answer - FW answer after measurement which is parsed.
 *           level  - LOW_LEVEL or HIGH_LEVEL
 *
 *   OUTPUT: result - result container in which results are stored.
 *   RETURN: none
 * Note:
 *   1. works for each specific level: LOW_LEVEL or HIGH_LEVEL.
 *   2. must be called inside ON_FIRST_INVOCATION_BEGIN/END block,
 *      because FOR_EACH_SITE_BEGIN/END block is used below.
 *----------------------------------------------------------------------*
 */
static void processResultForActiveLoad(
    const vector<string>& pinlistVec,
    const vector<bool>&   isMeasuredVec,
    const vector<vector<string> >&  expandedPinsVec,
    const TM::DCTEST_MODE& testMode,
    const string& answer,
    const MeasuredLevelType level,
    vector<MeasurementResultContainer>& resultVec,
    MeasurementResultContainer& globalResult)
{
  string::size_type pos = 0, posEnd = 0;
  string resultToken = "";

  // get test result
  MeasurementResultContainer everyGroupResult;
  for(vector<string>::size_type i = 0; i < pinlistVec.size(); i++)
  {
    if(resultVec.size() <= i)
    {
      everyGroupResult.init();
      resultVec.push_back(everyGroupResult);
    }
    if(isMeasuredVec[i])
    {
      if (TM::PVAL == testMode)  // Value Per Pin
      {
        FOR_EACH_SITE_BEGIN();
          for(vector<string>::size_type index = 0;
              index < expandedPinsVec[i].size();
              index++)
          {
            pos = answer.find("RCLS",pos);
            if (pos != STRING::npos)
            {
              pos = answer.find_first_not_of(" \t",pos+4);
              posEnd = answer.find_first_of(",",pos+1);
              resultToken = answer.substr(pos,posEnd-pos);
              DOUBLE value = 0.0;
              if (resultToken == "EQ")
              {
                pos = retrieveStringWithinDelimiters(answer,
                                                    ",",
                                                    "\n",
                                                    posEnd,
                                                    resultToken);
                //put result value*/
                if (pos != STRING::npos)
                {
                  value = OutputDCTestUtil::string2Double(resultToken,"resultToken");
                  value = value * 1e-3; //convert value from 'mV' to 'V'
                }
              }
              else
              {
                cout<<"RCLS? cannot get test value for pin(s): "
                    <<expandedPinsVec[i][index]<<endl;
                value = -DBL_MAX;
              }
              resultVec[i].setPinsValue(expandedPinsVec[i][index],
                                        value,
                                        CURRENT_SITE_NUMBER());
            }
          }
        FOR_EACH_SITE_END();
      }
      else if (TM::PPF == testMode)  // PPF: Pass Fail Per Pin
      {
        FOR_EACH_SITE_BEGIN();
          for(vector<string>::size_type index = 0;
              index < expandedPinsVec[i].size();
              index++)
          {
            pos = answer.find("RCLS",pos);
            if (pos != STRING::npos)
            {
              pos = answer.find_first_of(" \t",pos+1);
              pos = answer.find_first_not_of(" \t",pos+1);
              posEnd = answer.find_first_of(",",pos+1);
              resultToken = answer.substr(pos,posEnd-pos);
              resultVec[i].setPinPassFail(expandedPinsVec[i][index],
                                          (resultToken == "P")?true:false,
                                          CURRENT_SITE_NUMBER());
            }
          }
        FOR_EACH_SITE_END();
      }
      else  //GPF: Gloabl Pass Fail
      {
        pos = answer.find("PRLT",0);
        if (pos != string::npos)
        {
          retrieveStringWithinDelimiters(answer,"\"","\"",pos+1,resultToken);
          for (STRING::size_type index = 0; index < resultToken.length(); ++index)
          {
            if (resultToken[index] != '0')
            {
              Boolean isPass = (resultToken[index] == 'P')?true:false;
              // the "index+1" of rclsResult is related to site number
              globalResult.setGlobalPassFail(isPass,index+1);
            }
            else
            {
              // otherwise: the site is masked out
            }
          }
        }
        else
        {
          throw Error("OutputDcTest::processResultForActiveLoad()",
                      "cannot find result of PRLT? command",
                      "OutputDcTest::processResultForActiveLoad()");
        }
        break;
      }
    }
  }
}
};

#endif /*OUTPUTDCTEST_H_*/
