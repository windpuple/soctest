#ifndef OUTPUTDCTESTUTIL_HPP_
#define OUTPUTDCTESTUTIL_HPP_

#include "testmethod.hpp"

/**
 * try to get all required test names from test table
 * record valid test name and invalid test name
 */
class TesttableLimitHelper
{
  private:
    std::vector<std::string> mTestnameNotInTable;
    std::vector<std::string> mTestnameInTable;
    std::string mTestsuiteName;
    bool mIsLimitCsvFileLoad;
  public:
    explicit TesttableLimitHelper(const string& testsuitename)
      :mTestsuiteName(testsuitename),mIsLimitCsvFileLoad(false)
    {
      TestTable* pLimitTable = TestTable::getDefaultInstance();
      pLimitTable->readCsvFile();
      mIsLimitCsvFileLoad = pLimitTable->isTmLimitsCsvFile();

      mTestnameNotInTable.clear();
      mTestnameInTable.clear();
    }

    ~TesttableLimitHelper()
    {
    }

    const std::vector<std::string>& getInvalidTestnames()
    {
      return mTestnameNotInTable;
    }

    const std::vector<std::string>& getValidTestnames()
    {
      return mTestnameInTable;
    }

    //return if all test names are valid in CSV file
    const bool isAllInTable()
    {
      return (mIsLimitCsvFileLoad &&
              !mTestnameInTable.empty() &&
              mTestnameNotInTable.empty());
    }

    const bool isLimitCsvFileLoad()
    {
      return mIsLimitCsvFileLoad;
    }

    /**
     * for the current testsuite, the method try to get the limit object from test table
     * by the specified test name (i.e. name for limit).
     * @param:
     *    testname: the specific test name defined for the testsuite
     *    toLimit: the target limit object defined in test table
     * @note:
     *   1) if the test name is defined in test table,
     *      the target limit object is got from table;
     *      otherwise, the limit object is untouched as it is.
     *   2) exceptional case:
     *      a) if the csv file is not loaded, exception is thrown.
     *
     *      b) if there are multiple limits needed for this testsuite,
     *      and only if some testname are valid but others are NOT valid,
     *      one exception is thrown out!
     */
    void getLimit(const std::string& testname, LIMIT& toLimit)throw(Error)
    {
      if (!mIsLimitCsvFileLoad)
      {
        throw Error("TesttableLimitHelper",
          "no limit CSV file is loaded!",
          "TesttableLimitHelper");
      }

      try
      {
        V93kLimits::TMLimits::LimitInfo& limitInfo =
          V93kLimits::tmLimits.getLimit(mTestsuiteName,testname);

        toLimit = limitInfo.TEST_API_LIMIT;
        mTestnameInTable.push_back(testname);
      }
      catch (Error& e)
      {
        mTestnameNotInTable.push_back(testname);
      }

      //confiliction: some limits are valid but others are not
      if (!mTestnameInTable.empty() && !mTestnameNotInTable.empty())
      {
        throw Error("TesttableLimitHelper",
          "[testsuite: \""+mTestsuiteName+"\"]: test name \""+testname
          +"\" is not found in test table!");
      }
    }
}; //class TesttableLimitHelper


class OutputDCTestUtil
{
public:
  /*
   *---------------------------------------------------------------------*
   *MeasurementResultContainer:
   *  This class is used to hold and output
   *  global or per pin result: pass/fail, values.
   *---------------------------------------------------------------------*
   *  Notes:
   *  If the results of all sites are cached in Testmethod, not in
   *  TestmethodAPI, this class can store results for each specific site.
   *
   *  Typical use case is to directly use firmware commands to test and get
   *  result for all sites in Testmethod, then use this class to store and
   *  retrieve result for all sites.
   *---------------------------------------------------------------------*
   */
  struct MeasurementResultContainer
  {
    MeasurementResultContainer()
    {
      init();
    };
    ~MeasurementResultContainer() {};
    void setGlobalPassFail(bool isPass,int siteNumber = 0 )
    {
      mMultiSiteGlobalPassFail[siteNumber] = isPass;
    };
    void setPinPassFail(const string& pin,bool isPass,int siteNumber = 0)
    {
      mMultiSitePinPassFail[siteNumber][pin]= isPass;
    };
    void setPinsValue(const string& pins,double value,int siteNumber = 0)
    {
      mMultiSitePinsValue[siteNumber][pins]= value;
    };
    bool getGlobalPassFail(int siteNumber = 0) const
    {
      map< int,bool >::const_iterator it =
                          mMultiSiteGlobalPassFail.find(siteNumber);
      if ( it != mMultiSiteGlobalPassFail.end() )
      {
        return it->second;
      }
      else
      {
        throw Error("MeasurementResultContainer::getGlobalPassFail",
                    "No global result for this site!",
                    "MeasurementResultContainer::getGlobalPassFail");
      }
    };
    bool getPinPassFail(const string& pin,int siteNumber = 0) const
    {
      map< int,map<string,bool> >::const_iterator it =
                                      mMultiSitePinPassFail.find(siteNumber);

      // get the result of the specified site
      if ( it != mMultiSitePinPassFail.end() )
      {
        const map< string,bool >& tmpPinResult = it->second;
        map< string,bool >::const_iterator itPinResult = tmpPinResult.find(pin);

        // get the result of the specified pin
        if ( itPinResult != tmpPinResult.end() )
        {
          return itPinResult->second;
        }
        else
        {
          throw Error("MeasurementResultContainer::getPinPassFail",
                      "No result for this pin: "+pin+".",
                      "MeasurementResultContainer::getPinPassFail");
        }
      }
      else
      {
        throw Error("MeasurementResultContainer::getPinPassFail",
                    "No per pin result for this site!",
                    "MeasurementResultContainer::getPinPassFail");
      }
    };
    double getPinsValue(const string& pins,int siteNumber = 0) const
    {
      map< int,map<string,double> >::const_iterator it =
                                      mMultiSitePinsValue.find(siteNumber);

      // get the result of the specified site
      if ( it != mMultiSitePinsValue.end() )
      {
        const map< string,double >& tmpPinResult = it->second;
        map< string,double >::const_iterator itPinResult = tmpPinResult.find(pins);

        //* get the result of the specified pins
        if ( itPinResult != tmpPinResult.end() )
        {
          return itPinResult->second;
        }
        else
        {
          throw Error("MeasurementResultContainer::getPinsValue",
                      "No result for this pin(s): "+pins+".",
                      "MeasurementResultContainer::getPinsValue");
        }
      }
      else
      {
        throw Error("MeasurementResultContainer::getPinsValue",
                    "No result for this site!",
                    "MeasurementResultContainer::getPinsValue");
      }
    };

    void init()
    {
      mMultiSitePinsValue.clear();
      mMultiSitePinPassFail.clear();
      mMultiSiteGlobalPassFail.clear();
    };
  private:

    /*
     *********************************************
     * Record value for pin(s) per site, e.g.
     *   mMultiSitePinsValue[1] = {"I/O1",2.50}
     *   mMultiSitePinsValue[1] = {"I/O0",1.30}
     *   mMultiSitePinsValue[2] = {"I/O1",2.52}
     *   mMultiSitePinsValue[2] = {"I/O0",1.33}
     *********************************************
     */
    map< INT,map< STRING,DOUBLE > > mMultiSitePinsValue;

    /*
     *********************************************
     * Record pass/fail for each pin per site, e.g.
     *   TRUE: pass; FALSE: fail.
     *   mMultiSitePinPassFail[1] = {"Vcc",FALSE}
     *   mMultiSitePinPassFail[1] = {"Vee",FALSE}
     *   mMultiSitePinPassFail[2] = {"Vcc",TRUE}
     *   mMultiSitePinPassFail[2] = {"Vee",FALSE}
     *********************************************
     */
    map< INT,map< STRING,Boolean > > mMultiSitePinPassFail;
    /*
     *********************************************
     * Record global pass/fail per site, e.g.
     *   TRUE: pass; FALSE: fail.
     *   mMultiSiteGlobalPassFail[1] = TRUE
     *   mMultiSiteGlobalPassFail[2] = FALSE
     *********************************************
     */
    map< INT, Boolean > mMultiSiteGlobalPassFail;

  };

  /*
   *----------------------------------------------------------------------*
   * Routine: getMode
   *
   * Purpose: define to use PVAL|PPF|GPF according test suite flag
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note:
   *
   *----------------------------------------------------------------------*
   */
  static TM::DCTEST_MODE getMode()
  {
    string testSuiteName = "";

    int valueOnPass = 0;
    int perPinOnPass = 0;
    int valueOnFail = 0;
    int perPinOnFail = 0;

    GET_TESTSUITE_NAME(testSuiteName);
    GET_TESTSUITE_FLAG(testSuiteName, "value_on_pass",   &valueOnPass);
    GET_TESTSUITE_FLAG(testSuiteName, "value_on_fail",   &valueOnFail);
    GET_TESTSUITE_FLAG(testSuiteName, "per_pin_on_pass", &perPinOnPass);
    GET_TESTSUITE_FLAG(testSuiteName, "per_pin_on_fail", &perPinOnFail);

    if ( 1 == valueOnPass || 1 == valueOnFail )
    {
      return TM::PVAL;
    }
    else if ( 1 == perPinOnPass || 1 == perPinOnFail )
    {
      return TM::PPF;
    }

    return TM::GPF;
  }


  /*
   *----------------------------------------------------------------------*
   * Routine: trim
   *
   * Purpose: get rid of head and tail space of input
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note:
   *
   * Return Value: new string
   *----------------------------------------------------------------------*
   */
  static string trim(const string& str)
  {
    int iStart = 0;
    int iStop = 0;
    int i = 0;
    int length = static_cast<int>(str.length());

    for(i=0;i< length;i++)
    {
      if(str[i] != ' ')
      {
        iStart = i;
        break;
      }
    }

    for(i=length-1;i>=0;i--)
    {
      if(str[i] != ' ')
      {
        iStop = i+1;
        break;
      }
    }

    return str.substr(iStart,iStop-iStart);
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: datalogToWindow
   *
   * Purpose: print datalog To report Window
   *
   *----------------------------------------------------------------------*
   * Description:
   *   this prototype only for TM::PVAL
   * Note:
   *   measuredValue and limit parameter always use default unit,
   *       that's, "V" for voltage.
   *----------------------------------------------------------------------*
   */
  static void datalogToWindow(const string& pin,
                              const double  measuredValue,
                              const LIMIT&  limit)
  {
    string PFjudge = limit.pass(measuredValue)?"P":"F";
    string opl_str, oph_str;

    double lowVal  = 0.0,highVal = 0.0;
    TM::COMPARE lowCmp = TM::NA, highCmp = TM::NA;
    limit.get(lowCmp, lowVal, highCmp, highVal);

    double factor = 1.0;
    if(!(limit.unit().empty()))
    {
      testmethod::SpecValue specValue;
      specValue.setBaseUnit("V");
      specValue.inputValueUnit("1[V]");
      factor = specValue.getValueAsTargetUnit(limit.unit());
    }
    lowVal = lowVal * factor;
    highVal = highVal * factor;

    switch (lowCmp)
    {
      case TM::GT:
        opl_str = "< ";
        break;

      case TM::GE:
        opl_str = "<=";
        break;

      case TM::NA:
        opl_str = "";
        break;

      default:
        throw Error("OutputDCTestUtil::datalogToWindow",
                    "Unknown Compare Mode of opl",
                    "OutputDCTestUtil::datalogToWindow");

    }
    switch (highCmp)
    {
      case TM::LT:
        oph_str = "< ";
        break;

      case TM::LE:
        oph_str = "<=";
        break;

      case TM::NA:
        oph_str = "";
        break;

      default:
        throw Error("OutputDCTestUtil::datalogToWindow",
                    "Unknown Compare Mode of opl",
                    "OutputDCTestUtil::datalogToWindow");

    }

    ostringstream buf;
    buf << left << setw(16) << pin;
    cout << buf.str() << "\t";

    // value of lower limit
    if ( opl_str != "" )
    {
      cout << "min:";
      printValue(lowVal, FALSE);
      cout << '\t' << opl_str << '\t';
    }

    // measured value
    printValue(measuredValue, TRUE);
    cout << '\t';

    // value of higher limit
    if ( oph_str != "" )
    {
      cout << oph_str << '\t' << "max:";
      printValue(highVal, FALSE);
      cout << '\t';
    }

    // Pass or Fail Info
    cout << PFjudge <<endl;
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: datalogToWindow
   *
   * Purpose: print datalog To report Window
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note:
   *   this protoype only for TM::PPF
   *----------------------------------------------------------------------*
   */
  static void datalogToWindow(const string& pin, const bool bPass)
  {
    ostringstream buf;
    buf << left << setw(16) << pin;
    cout << buf.str() << "\t";
    cout << (bPass? "P": "F") <<endl;
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: printValue
   *
   * Purpose: print result value
   *
   *----------------------------------------------------------------------*
   *
   * Note:
   *      the parameter "val" always use default unit, that's, "V" for voltage.
   *----------------------------------------------------------------------*
   */
  static void printValue(double val,const bool bFormat)
  {
    double dVal = val * 1e3;

    if ( bFormat )
    {
      ostringstream buf;
      buf << setprecision(10) << dVal << " mV";
      cout << right << setw(14) << buf.str() << '\t' << left;
    }
    else
    {
      cout << right << setw(10) << dVal << " mV" << left;
    }
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: splitString
   *
   * Purpose: split one string to a string vector by key word
   *
   *----------------------------------------------------------------------*
   * Description:
   *    e.g.    the original string is:
   *                "pin1;pin2,pin3;pin4"
   *            and the delimiter string is: ";"
   *    yields the following string vector results:
   *                "pin1", "pin2,pin3", "pin4"
   *
   *
   *----------------------------------------------------------------------*
   */
  static void splitString(const string& originalString,
                          vector<string>& stringVec,
                          const string& delimiter)
  {
    if(originalString.empty())
    {
      stringVec.clear();
      return;
    }
    string::size_type pos1 = 0, pos2 = 0;
    string tmp;
    pos1 = originalString.find(delimiter, 0);
    if(pos1 != string::npos)
    {
      tmp = originalString.substr(0,pos1);
      stringVec.push_back(trim(tmp));

      pos2 = pos1;
      pos1 = originalString.find(delimiter,pos2 + 1);
      while (pos1 != string::npos)
      {
        tmp = originalString.substr(pos2 + delimiter.length(), pos1 - pos2 - delimiter.length());
        stringVec.push_back(trim(tmp));
        pos2 = pos1;
        pos1 = originalString.find(delimiter, pos2 + 1);
      }
      tmp = originalString.substr(pos2 + delimiter.length(),originalString.length() - pos2 - delimiter.length());
      stringVec.push_back(trim(tmp));
    }
    else
    {
      stringVec.push_back(trim(originalString));
    }

    return;
  }


  /*
   *----------------------------------------------------------------------*
   * Routine: parseListOfString
   *
   * Purpose: parse one string to a string vector
   *
   *----------------------------------------------------------------------*
   * Description:
   *    e.g.    the original string is:
   *                "pin1,(pin2,pin3),pin4"
   *            and the delimiter char is: ','
   *    yields the following string vector results:
   *                "pin1", "pin2,pin3", "pin4"
   *
   *
   *----------------------------------------------------------------------*
   */
  static void parseListOfString(const string& originalString,
                                vector<string>& stringVec,
                                const char delimiter = ',',
                                const bool isParenthesesSupported = false)
  {
    if(originalString.empty())
    {
      stringVec.clear();
      return;
    }
    bool isWithinParentheses = false;
    bool isLeftParenthesesExist = false;
    string word;
    const char* str = originalString.c_str();

    for ( int i = 0 ; *(str+i) != 0 ; ++i )
    {
      char ch = str[i];

      if( ch == delimiter )
      {
        if ( isWithinParentheses && isParenthesesSupported )
        {
          word += ch;
        }
        else 
        {
          stringVec.push_back(trim(word));
          word = "";
        }
      }
      else if (isParenthesesSupported && ch == '(')
      {
        isWithinParentheses = true;
        isLeftParenthesesExist = true;
      }
      else if (isParenthesesSupported && ch == ')') 
      {
        isWithinParentheses = false;
        if(!isLeftParenthesesExist)
        { 
          throw Error("OutputDCTestUtil::parseListOfString",
                      "the parentheses mismatch.The correct format is like:()",
                      "OutputDCTestUtil::parseListOfString");
        }
        isLeftParenthesesExist = false;
      }
      else 
      {
        word += ch;
      }
    }

    if(isLeftParenthesesExist)
    {
      throw Error("OutputDCTestUtil::parseListOfString",
                  "the parentheses mismatch.The correct format is like:()",
                  "OutputDCTestUtil::parseListOfString");    
    }  
    stringVec.push_back(trim(word));

    return;
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: parseListOfDouble
   *
   * Purpose: parse one string to a double vector
   *
   *----------------------------------------------------------------------*
   * Description:
   *    e.g.    the original string is:
   *                "1.5,2.8,5.6"
   *            and the delimiter char is: ','
   *    yields the following double vector results:
   *                "1.5", "2.8", "5.6"
   *
   *
   *----------------------------------------------------------------------*
   */
  static void parseListOfDouble(const string& originalString,
                                vector<double>& doubleVec,
                                const char delimiter = ',')
  {
    if(originalString.empty())
    {
      doubleVec.clear();
      return;
    }
    
    string word;
    double tempValue;
    const char* str = originalString.c_str();

    for ( int i = 0 ; *(str+i) != 0 ; ++i )
    {
      char ch = str[i];
      if( ch == delimiter )
      {
        string tempString = trim(word);
        if(tempString.empty())
        {
          doubleVec.push_back(0.0);
        }
        else
        {
          istringstream stream(word);
          stream >> tempValue;
          doubleVec.push_back(tempValue);
        }
        word = "";
      }
      else 
      {
        word += ch;
      }
    }
    
    string tempString = trim(word);
    if(tempString.empty())
    {
      doubleVec.push_back(0.0);
    }
    else
    {
      istringstream stream(word);
      stream >> tempValue;
      doubleVec.push_back(tempValue);
    }
    return;    
  }

  
  /*
   *----------------------------------------------------------------------*
   * Routine: getLimitInfo
   *
   * Purpose: get limit from limit table or get limit information from testflow
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note:
   *
   *----------------------------------------------------------------------*
   */
  static void getLimitInfo(
      const string& testName,
      const int groupNumber,
      LIMIT& limit,
      TesttableLimitHelper& testtableHelper)
  {
    TM::COMPARE lowCmp = TM::NA,highCmp = TM::NA;
    double lowVal = 0.0, highVal = 0.0;

    if(testtableHelper.isLimitCsvFileLoad())
    {
      testtableHelper.getLimit(testName,limit);
    }

    if(!testtableHelper.isAllInTable())
    {
      // this API has some issue, it converts the value according
      // to the unit, but it doesn't set the correct unit
      // e.g.  0 mV  <<  limit << 700 mV, using this API to get the limit
      // the lowValue of this limit is 0
      // the highValue of this limit is 0.7
      // but the current unit of this limit still is mV.
      limit = GET_LIMIT_OBJECT(testName);
      if(!(limit.unit().empty()))
      {
        limit.unit("V");
      }
    }

    limit.get(lowCmp,lowVal,highCmp,highVal);
    if ( lowCmp == TM::NA || highCmp == TM::NA )
    {
      throw Error("OutputDCTestUtil::getLimitInfo",
                  testName + " is not specified",
                  "OutputDCTestUtil::getLimitInfo");
    }
    string unitInLimit = limit.unit();
    if(unitInLimit.empty())
    {
      limit.low(lowCmp, lowVal * 1e-3);
      limit.high(highCmp, highVal * 1e-3);
      limit.unit("V");
    }
    else
    {
      testmethod::SpecValue specValue;
      specValue.setBaseUnit("V");
      specValue.inputValueUnit("1[V]");
      double factor = specValue.getValueAsTargetUnit(unitInLimit);
      limit.low(lowCmp,lowVal / factor);
      limit.high(highCmp,highVal / factor);
      limit.unit("V");
    }
    return;
  }
 

  /*
   *----------------------------------------------------------------------*
   * Routine: string2Long
   *
   * Purpose: convert a string to long int, if the string content is not a
   *          long int,throw an error
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Parameters:  1. string input :
   *                 string need to convert to long int
   *              2. string name :
   *                 parameters name, need for output error message
   *
   * Return Value: output long int value
   *----------------------------------------------------------------------*
   */
  static long string2Long(const string& input,const string& name)
  {
    long result = 0;
    char* pEnd;
    result = strtol(input.c_str(),&pEnd,10);

    if((result == 0 && atol(input.c_str()) != 0) ||
       (pEnd[0] != '\0' && pEnd[0] != '\n'))
    {
      string api = "Convert parameter["+name+"] :"+input + " to long fail";
      string msg = "it is not a long int!";
      throw Error(api.c_str(),msg.c_str(),api.c_str());
    }

    return result;
  }



  /*
   *----------------------------------------------------------------------*
   * Routine: string2Double
   *
   * Purpose: convert a string to double, if the string content is not a
   *          double,throw an error
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Parameters:  1. string input :
   *                 string need to convert to double
   *              2. string name :
   *                 parameters name, need for output error message
   *
   * Return Value: output double value
   *----------------------------------------------------------------------*
   */
  static double string2Double(const string& input, const string& name)
  {
    double result = 0.0;
    char* pEnd;
    result = strtod(input.c_str(), &pEnd);

    if((result == 0 && atof(input.c_str())!= 0)
       || pEnd[0] != '\0')
    {
      string api = "Convert parameter["+name+"] :"+ input + " to DOUBLE fail";
      string msg = "it is not a double!";
      throw Error(api.c_str(),msg.c_str(),api.c_str());
    }

    return result;
  }


  /*
   *----------------------------------------------------------------------*
   * Routine: double2String
   *
   * Purpose: convert a double to string
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note:
   *
   *----------------------------------------------------------------------*
   */
  static const string double2String(double number)
  {
    char outStr[41] = "\0"; // the buffer len is enough to contain numbers
    if ( snprintf(outStr,40,"%.15g",number) < 0) // precision is enough
    {
      throw Error("OutputDCTestUtil::double2String",
                  "error happened when convert!",
                  "OutputDCTestUtil::double2String");
    }

    return outStr;
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: isHighVoltagePin
   *
   * Purpose: check if the specified pin is high voltage pin
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note:
   *
   *----------------------------------------------------------------------*
   */
  static bool isHighVoltagePin(const string & pinName)
  {
    string strFwAnswer = "";
    FW_TASK("CONF? (" + pinName + ")\n",strFwAnswer);
    string::size_type iPos = strFwAnswer.find(",");
    if (iPos != string::npos)
    {
      string mode = strFwAnswer.substr(iPos + 1, 2);
      if (mode.compare("HV") == 0)
      {
        return true;
      }
    }
    return false;
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: getMeasureModeForHVPin
   *
   * Purpose: map the normal measurement mode to HV mode
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note:
   *
   *----------------------------------------------------------------------*
   */
  static const string & getMeasureModeForHVPin(const TM::DCTEST_MODE & testMode)
  {
    static string HV_PPMU_PPF = "HV_PPMU_PPF";
    static string HV_PPMU_GPF = "HV_PPMU_GPF";
    static string HV_PPMU_BADC_VAL = "HV_PPMU_BADC_VAL";
    static string NOT_MATCH = "";

    switch(testMode)
    {
      case TM::PVAL:
        return HV_PPMU_BADC_VAL;
      case TM::GPF:
        return HV_PPMU_GPF;
      case TM::PPF:
        return HV_PPMU_PPF;
      default:
        return NOT_MATCH;
    }
  }

  /*
   *----------------------------------------------------------------------*
   * Routine: parameterCheck
   *
   * Purpose: check whether parameter groups match
   *
   *----------------------------------------------------------------------*
   *
   * Note:
   *
   *----------------------------------------------------------------------*
   */
  static void checkParameter(const unsigned int lSize,
                             const unsigned int rSize,
                             const string& type,
                             const string& parameter,
                             vector<string>& valueVec )
  {
    if(lSize != rSize)
    {
      if(rSize != 1)
      {
        stringstream errMsg;
        errMsg << type <<": the number of pinlist groups is " << lSize <<endl
               <<"      the number of " << parameter << " groups is " << rSize <<endl
               <<"So the " << parameter << " groups don't match pinlist groups." <<endl;
        throw Error("OutputDCTestUtil::checkParameter()",
                    errMsg.str(),
                    "OutputDCTestUtil::checkParameter()");
      }
      else
      {
        for(vector<string>::size_type i = 1; i < lSize; i++)
        {
          valueVec.push_back(valueVec[0]);
        }
      }
    }
  }


  /*
   *----------------------------------------------------------------------*
   * Routine: judgeAndLogUtil
   *
   * Purpose: utility function for judgement and data log.
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note:
   *
   *----------------------------------------------------------------------*
   */
  static void judgeAndLogUtil(
    const vector<bool> &isMeasuredLow,
    const vector<bool> &isMeasuredHigh,
    const vector<string> &pinlistVec,
    const vector<vector<string> > &expandedPinsVec,
    const vector<LIMIT> &limitLowVec,
    const vector<LIMIT> &limitHighVec,
    const vector<string> &limitNameLowVec,
    const vector<string> &limitNameHighVec,
    const vector<MeasurementResultContainer> &resultLow,
    const vector<MeasurementResultContainer> &resultHigh,
    const TM::DCTEST_MODE& mode,
    const string& testsuiteName,
    const bool isLimitTableUsed,
    const int siteNumber,
    bool& hasBined)
  {
    vector<string>::size_type j = 0;
    bool isPassLow = true;
    bool isPassHigh = true;
    bool retLow = true;
    bool retHigh = true;
    ARRAY_D lowResultArray;
    ARRAY_D highResultArray;

    V93kLimits::TMLimits::LimitInfo limitInfoLow;
    V93kLimits::TMLimits::LimitInfo limitInfoHigh;
    double factor = 1.0;

    for(vector<string>::size_type i = 0; i < expandedPinsVec.size(); ++i)
    {
      // restore it for every group
      retLow = true;
      retHigh = true;
      if (isMeasuredLow[i]) // judge and datalog low level measurement
      {
        if(isLimitTableUsed)
        {
          limitInfoLow = V93kLimits::tmLimits.getLimit(testsuiteName + ":" + limitNameLowVec[i]);
        }
        switch ( mode )
        {
        case TM::PVAL:
          lowResultArray.resizeNoKeep(expandedPinsVec[i].size());
          if(isLimitTableUsed)
          {
            testmethod::SpecValue specValue;
            if( (limitInfoLow.Units).find('V') != string::npos)
            {
              specValue.setBaseUnit("V");
              specValue.inputValueUnit("1[V]");
              factor = specValue.getValueAsTargetUnit(limitInfoLow.Units);
            }
            else if(limitInfoLow.Units.empty())
            {
              factor = 1e3;
            }
            else
            {
              stringstream errMsg;
              errMsg << "the low limit's unit: " << limitInfoLow.Units << " is not a valid unit." <<endl
                     << "current the valid units are: mV,uV..." <<endl;
              throw Error("OutputDCTestUtil::judgeAndLogUtil",
                          errMsg.str(),
                          "OutputDCTestUtil::judgeAndLogUtil");
            }
          }

          if (resultLow.size() != expandedPinsVec.size())
          {
            throw Error("OutputDCTestUtil::judgeAndLogUtil",
                        "Abnormal size of resultLow, maybe there is no measurement performed.",
                        "OutputDCTestUtil::judgeAndLogUtil");
          }
          for ( j = 0; j< expandedPinsVec[i].size(); ++j )
          {
            lowResultArray[j] = resultLow[i].getPinsValue(expandedPinsVec[i][j],siteNumber) * factor;
          }

          if(isLimitTableUsed)
          {
            TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                          expandedPinsVec[i],
                                          limitNameLowVec[i],
                                          V93kLimits::tmLimits,
                                          lowResultArray);
          }
          else
          {
            TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                            expandedPinsVec[i],
                                            limitNameLowVec[i],
                                            limitLowVec[i],
                                            lowResultArray);
          }
          break;

        case TM::PPF:
          lowResultArray.resizeNoKeep(expandedPinsVec[i].size());
          for (j = 0; j < expandedPinsVec[i].size(); ++j )
          {
            isPassLow = resultLow[i].getPinPassFail(expandedPinsVec[i][j],siteNumber);
            if(isPassLow) // for pass pin, in PPF mode, we will write 0.0 to MPR
            {
              lowResultArray[j] = 0.0;
            }
            else // for fail pin, in PPF mode, we will write 1.0 to MPR
            {
              lowResultArray[j] = 1.0;
            }
            retLow = isPassLow && retLow;
          }

          if(isLimitTableUsed)
          {
            TESTSET().cont(TM::CONTINUE).testnumber(limitInfoLow.TestNumber)
                                        .judgeAndLog_ParametricTest(
                                            expandedPinsVec[i],
                                            limitNameLowVec[i],
                                            retLow ? TM::Pass : TM::Fail,
                                            lowResultArray);
            if(!retLow && !hasBined && limitInfoLow.BinsNumString.size() > 0)
            {
              hasBined = true;
              SET_MULTIBIN(limitInfoLow.BinsNumString,limitInfoLow.BinhNum);
            }
          }
          else
          {
            TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                            expandedPinsVec[i],
                                            limitNameLowVec[i],
                                            retLow ? TM::Pass : TM::Fail,
                                            lowResultArray);
          }
          break;

        case TM::GPF:
          isPassLow = resultLow[i].getGlobalPassFail(siteNumber);
          if(isLimitTableUsed)
          {
            TESTSET().cont(TM::CONTINUE).testnumber(limitInfoLow.TestNumber)
                                        .judgeAndLog_ParametricTest(
                                            pinlistVec[i],
                                            limitNameLowVec[i],
                                            isPassLow ? TM::Pass : TM::Fail,
                                            0.0);

            if(!isPassLow && !hasBined && limitInfoLow.BinsNumString.size() > 0)
            {
              hasBined = true;
              SET_MULTIBIN(limitInfoLow.BinsNumString,limitInfoLow.BinhNum);
            }
          }
          else
          {
            TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                            pinlistVec[i],
                                            limitNameLowVec[i],
                                            isPassLow ? TM::Pass : TM::Fail,
                                            0.0);
          }
          break;
        default:
          throw Error("OutputDCTestUtil::judgeAndLogUtil",
                      "Unknown Test Mode",
                      "OutputDCTestUtil::judgeAndLogUtil");
        } // end switch
      } // end if: low

      if (isMeasuredHigh[i]) //judge and datalog high level measurement
      {
        if(isLimitTableUsed)
        {
          limitInfoHigh = V93kLimits::tmLimits.getLimit(testsuiteName + ":" + limitNameHighVec[i]);
        }

        switch ( mode )
        {
        case TM::PVAL:
          highResultArray.resizeNoKeep(expandedPinsVec[i].size());
          if(isLimitTableUsed)
          {
            testmethod::SpecValue specValue;
            if( (limitInfoHigh.Units).find('V') != string::npos)
            {
              specValue.setBaseUnit("V");
              specValue.inputValueUnit("1[V]");
              factor = specValue.getValueAsTargetUnit(limitInfoHigh.Units);
            }
            else if(limitInfoHigh.Units.empty())
            {
              factor = 1e3;
            }
            else
            {
              stringstream errMsg;
              errMsg << "the high limit's unit: " << limitInfoHigh.Units << " is not a valid unit." <<endl
                     << "current the valid units are: mV,uV..." <<endl;
              throw Error("OutputDCTestUtil::judgeAndLogUtil",
                          errMsg.str(),
                          "OutputDCTestUtil::judgeAndLogUtil");
            }
          }

          for ( j = 0; j< expandedPinsVec[i].size(); ++j )
          {
            highResultArray[j] = resultHigh[i].getPinsValue(expandedPinsVec[i][j],siteNumber) * factor;
          }

          if(isLimitTableUsed)
          {
            TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                          expandedPinsVec[i],
                                          limitNameHighVec[i],
                                          V93kLimits::tmLimits,
                                          highResultArray);
          }
          else
          {
            TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                            expandedPinsVec[i],
                                            limitNameHighVec[i],
                                            limitHighVec[i],
                                            highResultArray);
          }
          break;

        case TM::PPF:
          highResultArray.resizeNoKeep(expandedPinsVec[i].size());
          for (j = 0; j < expandedPinsVec[i].size(); ++j )
          {
            isPassHigh = resultHigh[i].getPinPassFail(expandedPinsVec[i][j],siteNumber);
            if(isPassHigh) // for pass pin, in PPF mode, we will write 0.0 to MPR
            {
              highResultArray[j] = 0.0;
            }
            else // for fail pin, in PPF mode, we will write 1.0 to MPR
            {
              highResultArray[j] = 1.0;
            }
            retHigh = isPassHigh && retHigh;
          }

          if(isLimitTableUsed)
          {
            TESTSET().cont(TM::CONTINUE).testnumber(limitInfoHigh.TestNumber)
                                        .judgeAndLog_ParametricTest(
                                            expandedPinsVec[i],
                                            limitNameHighVec[i],
                                            retHigh ? TM::Pass : TM::Fail,
                                            highResultArray);
            if(!retHigh && !hasBined && limitInfoHigh.BinsNumString.size() > 0)
            {
              hasBined = true;
              SET_MULTIBIN(limitInfoHigh.BinsNumString,limitInfoHigh.BinhNum);
            }
          }
          else
          {
            TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                            expandedPinsVec[i],
                                            limitNameHighVec[i],
                                            retHigh ? TM::Pass : TM::Fail,
                                            highResultArray);
          }
          break;

        case TM::GPF:
          isPassHigh = resultHigh[i].getGlobalPassFail(siteNumber);
          if(isLimitTableUsed)
          {
            TESTSET().cont(TM::CONTINUE).testnumber(limitInfoHigh.TestNumber)
                                        .judgeAndLog_ParametricTest(
                                            pinlistVec[i],
                                            limitNameHighVec[i],
                                            isPassHigh ? TM::Pass : TM::Fail,
                                            0.0);

            if(!isPassHigh && !hasBined && limitInfoHigh.BinsNumString.size() > 0)
            {
              hasBined = true;
              SET_MULTIBIN(limitInfoHigh.BinsNumString,limitInfoHigh.BinhNum);
            }
          }
          else
          {
            TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                            pinlistVec[i],
                                            limitNameHighVec[i],
                                            isPassHigh ? TM::Pass : TM::Fail,
                                            0.0);
          }
          break;
        default:
          throw Error("OutputDCTestUtil::judgeAndLogUtil",
                      "Unknown Test Mode",
                      "OutputDCTestUtil::judgeAndLogUtil");
        } //end switch

      }//end if: high
    }// end for every group
  }
  /*
   *----------------------------------------------------------------------*
   * Routine: judgeAndLogUtilForAllGroups
   *
   * Purpose: judgement and data log.for: one limit is applied for all groups
   *
   *----------------------------------------------------------------------*
   * Description:
   *
   * Note:
   *
   *----------------------------------------------------------------------*
   */
  static void judgeAndLogUtilForAllGroups(
    const vector<bool> &isMeasuredLow,
    const vector<bool> &isMeasuredHigh,
    const vector<string> &pinlistVec,
    const vector<vector<string> > &expandedPinsVec,
    const vector<LIMIT> &limitLowVec,
    const vector<LIMIT> &limitHighVec,
    const vector<string> &limitNameLowVec,
    const vector<string> &limitNameHighVec,
    const vector<MeasurementResultContainer> &resultLow,
    const vector<MeasurementResultContainer> &resultHigh,
    const TM::DCTEST_MODE& mode,
    const string& testsuiteName,
    const bool isLimitTableUsed,
    const int siteNumber,
    bool& hasBined)
  {
    vector<string>::size_type j = 0;
    bool isPassLow = true;
    bool isPassHigh = true;
    bool retLow = true;
    bool retHigh = true;
    ARRAY_D lowResultArray;
    ARRAY_D highResultArray;

    int sizeOfLowArray = 0;
    int sizeOfHighArray = 0;
    int indexLow = 0;
    int indexHigh = 0;
    vector<string> lowPinVec;
    vector<string> highPinVec;
    string lowStringPinlist;
    string highStringPinlist;

    for(vector<string>::size_type i = 0; i < expandedPinsVec.size(); ++i)
    {
      if(isMeasuredLow[i])
      {
        sizeOfLowArray += expandedPinsVec[i].size();
        indexLow = i;
      }
      if(isMeasuredHigh[i])
      {
        sizeOfHighArray += expandedPinsVec[i].size();
        indexHigh = i;
      }
    } // end for: every group

    V93kLimits::TMLimits::LimitInfo limitInfoLow;
    V93kLimits::TMLimits::LimitInfo limitInfoHigh;
    if(isLimitTableUsed)
    {
      if(sizeOfLowArray > 0)
      {
        limitInfoLow = V93kLimits::tmLimits.getLimit(testsuiteName + ":" + limitNameLowVec[indexLow]);
      }
      if(sizeOfHighArray > 0)
      {
        limitInfoHigh = V93kLimits::tmLimits.getLimit(testsuiteName + ":" + limitNameHighVec[indexHigh]);
      }
    }
    double factorLow = 1.0;
    double factorHigh = 1.0;

    switch(mode)
    {
    case TM::PVAL:
      lowResultArray.resizeNoKeep(sizeOfLowArray);
      highResultArray.resizeNoKeep(sizeOfHighArray);

      if(isLimitTableUsed)
      {
        testmethod::SpecValue specValue;
        if(sizeOfLowArray > 0)
        {
          if( (limitInfoLow.Units).find('V') != string::npos)
          {
            specValue.setBaseUnit("V");
            specValue.inputValueUnit("1[V]");
            factorLow = specValue.getValueAsTargetUnit(limitInfoLow.Units);
          }
          else if(limitInfoLow.Units.empty())
          {
            factorLow = 1e3;
          }
          else
          {
            stringstream errMsg;
            errMsg << "the low limit's unit: " << limitInfoLow.Units << " is not a valid unit." <<endl
                   << "current the valid units are: mV,uV..." <<endl;
            throw Error("OutputDCTestUtil::judgeAndLogUtil",
                        errMsg.str(),
                        "OutputDCTestUtil::judgeAndLogUtil");
          }
        }

        if(sizeOfHighArray > 0)
        {
          if( (limitInfoHigh.Units).find('V') != string::npos)
          {
            specValue.setBaseUnit("V");
            specValue.inputValueUnit("1[V]");
            factorHigh = specValue.getValueAsTargetUnit(limitInfoHigh.Units);
          }
          else if(limitInfoHigh.Units.empty())
          {
            factorHigh = 1e3;
          }
          else
          {
            stringstream errMsg;
            errMsg << "the hight limit's unit: " << limitInfoHigh.Units << " is not a valid unit." <<endl
                   << "current the valid units are: mV,uV..." <<endl;
            throw Error("OutputDCTestUtil::judgeAndLogUtil",
                        errMsg.str(),
                        "OutputDCTestUtil::judgeAndLogUtil");
          }
        }
      }
 
      for(vector<string>::size_type i = 0; i < expandedPinsVec.size(); ++i)
      {
        int counterLow = 0;
        int counterHigh = 0;
        if(isMeasuredLow[i])
        {
          for (j = 0; j < expandedPinsVec[i].size(); ++j)
          {
            lowResultArray[counterLow] = resultLow[i].getPinsValue(expandedPinsVec[i][j],siteNumber) * factorLow;
            lowPinVec.push_back(expandedPinsVec[i][j]);
            counterLow++;
          } // end for: every pin
        }// end if: low
        if(isMeasuredHigh[i])
        {
          for (j = 0; j < expandedPinsVec[i].size(); ++j)
          {
            highResultArray[counterHigh] = resultHigh[i].getPinsValue(expandedPinsVec[i][j],siteNumber) * factorHigh;
            highPinVec.push_back(expandedPinsVec[i][j]);
            counterHigh++;
          } // end for: every pin
        }// end if: high
      }// end for: every group

      if(isLimitTableUsed)
      {
        if(lowPinVec.size() > 0)
        {
          TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                        lowPinVec,
                                        limitNameLowVec[indexLow],
                                        V93kLimits::tmLimits,
                                        lowResultArray);
        }
        if(highPinVec.size() > 0)
        {
          TestSet.cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                        highPinVec,
                                        limitNameHighVec[indexHigh],
                                        V93kLimits::tmLimits,
                                        highResultArray);
        }
      }
      else // use test flow's limits
      {
        if(lowPinVec.size() > 0)
        {
          TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                          lowPinVec,
                                          limitNameLowVec[indexLow],
                                          limitLowVec[indexLow],
                                          lowResultArray);
        }
        if(highPinVec.size() > 0)
        {
          TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                          highPinVec,
                                          limitNameHighVec[indexHigh],
                                          limitHighVec[indexHigh],
                                          highResultArray);
        }
      }

      break;

    case TM::PPF:
      lowResultArray.resizeNoKeep(sizeOfLowArray);
      highResultArray.resizeNoKeep(sizeOfHighArray);
      for(vector<string>::size_type i = 0; i < expandedPinsVec.size(); ++i)
      {
        int counterLow = 0;
        int counterHigh = 0;
        if(isMeasuredLow[i])
        {
          for(j = 0; j < expandedPinsVec[i].size(); ++j)
          {
            isPassLow = resultLow[i].getPinPassFail(expandedPinsVec[i][j],siteNumber);
            if(isPassLow) // for pass pin, in PPF mode, we will write 0.0 to MPR
            {
              lowResultArray[counterLow] = 0.0;
            }
            else // for fail pin, in PPF mode, we will write 1.0 to MPR
            {
              lowResultArray[counterLow] = 1.0;
            }
            retLow = isPassLow && retLow;
            lowPinVec.push_back(expandedPinsVec[i][j]);
            counterLow++;
          } // end for: every pin
        } //end if

        if(isMeasuredHigh[i])
        {
          for(j = 0; j < expandedPinsVec[i].size(); ++j)
          {
            isPassHigh = resultHigh[i].getPinPassFail(expandedPinsVec[i][j],siteNumber);
            if(isPassHigh) // for pass pin, in PPF mode, we will write 0.0 to MPR
            {
              highResultArray[counterHigh] = 0.0;
            }
            else // for fail pin, in PPF mode, we will write 1.0 to MPR
            {
              highResultArray[counterHigh] = 1.0;
            }
            retHigh = isPassHigh && retHigh;
            highPinVec.push_back(expandedPinsVec[i][j]);
            counterHigh++;
          } // end for: every pin
        } //end if
      } // end for: every group

      if(isLimitTableUsed)
      {
        if(lowPinVec.size() > 0)
        {
          TESTSET().cont(TM::CONTINUE).testnumber(limitInfoLow.TestNumber)
                                      .judgeAndLog_ParametricTest(
                                          lowPinVec,
                                          limitNameLowVec[indexLow],
                                          retLow ? TM::Pass : TM::Fail,
                                          lowResultArray);
        }
        if(!hasBined && !retLow && limitInfoLow.BinsNumString.size() > 0)
        {
          hasBined = true;
          SET_MULTIBIN(limitInfoLow.BinsNumString,limitInfoLow.BinhNum);
        }
        if(highPinVec.size() > 0)
        {
          TESTSET().cont(TM::CONTINUE).testnumber(limitInfoHigh.TestNumber)
                                      .judgeAndLog_ParametricTest(
                                          highPinVec,
                                          limitNameHighVec[indexHigh],
                                          retHigh ? TM::Pass : TM::Fail,
                                          highResultArray);
        }
        if(!hasBined && !retHigh && limitInfoHigh.BinsNumString.size() > 0)
        {
          hasBined = true;
          SET_MULTIBIN(limitInfoHigh.BinsNumString,limitInfoHigh.BinhNum);
        }
      }
      else // use test flow's limits
      {
        if(lowPinVec.size() > 0)
        {
          TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                          lowPinVec,
                                          limitNameLowVec[indexLow],
                                          retLow ? TM::Pass : TM::Fail,
                                          lowResultArray);
        }
        if(highPinVec.size() > 0)
        {
          TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                          highPinVec,
                                          limitNameHighVec[indexHigh],
                                          retHigh ? TM::Pass : TM::Fail,
                                          highResultArray);
        }
      }
      break;

    case TM::GPF:
      for(vector<string>::size_type i = 0; i < expandedPinsVec.size(); ++i)
      {
        if(isMeasuredLow[i])
        {
          retLow = retLow && resultLow[i].getGlobalPassFail(siteNumber);
          lowStringPinlist = lowStringPinlist + pinlistVec[i] + ",";
        }
        if(isMeasuredHigh[i])
        {
          retHigh = retHigh && resultHigh[i].getGlobalPassFail(siteNumber);
          highStringPinlist = highStringPinlist + pinlistVec[i] + ",";
        }
      }

      if(isLimitTableUsed)
      {
        if(!lowStringPinlist.empty())
        {
          lowStringPinlist = lowStringPinlist.substr(0,lowStringPinlist.length()-1);
          TESTSET().cont(TM::CONTINUE).testnumber(limitInfoLow.TestNumber)
                                      .judgeAndLog_ParametricTest(
                                          lowStringPinlist,
                                          limitNameLowVec[indexLow],
                                          retLow ? TM::Pass : TM::Fail,
                                          0.0);
        }
        if(!hasBined && !retLow  && limitInfoLow.BinsNumString.size() > 0)
        {
          hasBined = true;
          SET_MULTIBIN(limitInfoLow.BinsNumString,limitInfoLow.BinhNum);
        }
        if(!highStringPinlist.empty())
        {
          highStringPinlist = highStringPinlist.substr(0,highStringPinlist.length()-1);
          TESTSET().cont(TM::CONTINUE).testnumber(limitInfoHigh.BinsNum)
                                      .judgeAndLog_ParametricTest(
                                          highStringPinlist,
                                          limitNameHighVec[indexHigh],
                                          retHigh ? TM::Pass : TM::Fail,
                                          0.0);
        }
        if(!hasBined && !retHigh && limitInfoHigh.BinsNumString.size() > 0)
        {
          hasBined = true;
          SET_MULTIBIN(limitInfoHigh.BinsNumString,limitInfoHigh.BinhNum);
        }
      }
      else // use test flow's limits
      {
        if(!lowStringPinlist.empty())
        {
          lowStringPinlist = lowStringPinlist.substr(0,lowStringPinlist.length() -1);
          TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                          lowStringPinlist,
                                          limitNameLowVec[indexLow],
                                          retLow ? TM::Pass : TM::Fail,
                                          0.0);
        }
        if(!highStringPinlist.empty())
        {
          highStringPinlist = highStringPinlist.substr(0,highStringPinlist.length() -1);
          TESTSET().cont(TM::CONTINUE).judgeAndLog_ParametricTest(
                                          highStringPinlist,
                                          limitNameHighVec[indexHigh],
                                          retHigh ? TM::Pass : TM::Fail,
                                          0.0);
        }
      }

      break;
    default:
      throw Error("OutputDCTestUtil::judgeAndLogUtilForAllGroups",
                  "Unknown Test Mode",
                  "OutputDCTestUtil::judgeAndLogUtilForAllGroups");

    } // end switch
  }

  static void ppmuInstrumentVoltageMeasurementSetup(
      const vector<string>  &pinlistVec,
      const vector<bool>    &isMeasuredVec,
      const vector<double>  &forceCurrentVec,
      const vector<double>  &settlingTimeVec,
      const vector<string>  &terminationVec,
      const vector<LIMIT>   &limitVec,
      const vector<bool>    &isHVPinsVec,
      const TM::DCTEST_MODE &mode,
      PPMU_SETTING          &ppmuSetting,
      PPMU_CLAMP            &ppmuClampOn,
      PPMU_CLAMP            &ppmuClampOff,
      PPMU_RELAY            &ppmuRelayStep1,
      PPMU_RELAY            &ppmuRelayStep2,
      PPMU_RELAY            &ppmuRelayRestoreStep1,
      PPMU_RELAY            &ppmuRelayRestoreStep2,
      PPMU_MEASURE          &ppmuMeasure,
      HV_DC_TASK            &ppmuHVMeasure,
      bool &hasPpmuParallelGroup,
      bool &hasHVppmuParallelGroup);

  static void ppmuVoltageMeasurementUpdateTestResult(
      const vector<string>  &pinlistVec,
      const vector<bool>    &isMeasuredVec,
      const vector<vector<string> > &expandedPinsVec,
      const TM::DCTEST_MODE &mode,
      const PPMU_MEASURE    &ppmuMeasure,
      vector<MeasurementResultContainer> &result);

  static void spmuInstrumentVoltageMeasurementSetup(
      const vector<string>& pinlistVec,
      const vector<bool>&   isMeasuredVec,
      const vector<double>& forceCurrentVec,
      const vector<double>& clampVoltageVec,
      const vector<double>& settlingTimeVec,
      const vector<string>& terminationVec,
      const vector<LIMIT>&  limitVec,
      const TM::DCTEST_MODE& mode,
      SPMU_TASK& spmuTaskMeasure,
      bool&  hasParallelGroup);

   static void spmuVoltageMeasurementUpdateTestResult(
       const vector<string>&  pinlistVec,
       const vector<bool>&    isMeasuredVec,
       const vector<vector<string> >& expandedPinsVec,
       const TM::DCTEST_MODE& testMode,
       SPMU_TASK& spmuMeasure,
       vector<MeasurementResultContainer>& result);

   static void boardADCInstrumentVoltageMeasurementSetup(
       const vector<string>&  pinlistVec,
       const vector<bool>  &  isMeasuredVec,
       const vector<double>&  settlingTimeVec,
       const vector<string>&  terminationVec,
       const vector<LIMIT>&   limitVec,
       const vector<bool>&    isHVPinVec,
       const TM::DCTEST_MODE& testMode,
       SPMU_TASK&  spmuTaskForceOn,
       SPMU_TASK&  spmuTaskMeasure,
       SPMU_TASK&  spmuTaskForceOff,
       HV_DC_TASK& hvDcTask,
       bool& hasParallelGroup,
       bool& hasParallelHVTask);


   static void boardADCVoltageMeasurementUpdateTestResult(
       const vector<string>&  pinlistVec,
       const vector<bool>&    isMeasuredVec,
       const vector<vector<string> >& expandedPinsVec,
       const TM::DCTEST_MODE& testMode,
       const SPMU_TASK&  spmuTask,
       vector<MeasurementResultContainer>& resultVec);

private:
  OutputDCTestUtil() {} //private constructor to prevent instantiation.

  template<class T>
  static void getTestResultForEveryGroup(
      const vector<string>&   pinList,
      const TM::DCTEST_MODE& testMode,
      const T&    measurePpmu,
      MeasurementResultContainer& result);
};


inline void
OutputDCTestUtil::ppmuInstrumentVoltageMeasurementSetup(
    const vector<string>  &pinlistVec,
    const vector<bool>    &isMeasuredVec,
    const vector<double>  &forceCurrentVec,
    const vector<double>  &settlingTimeVec,
    const vector<string>  &terminationVec,
    const vector<LIMIT>   &limitVec,
    const vector<bool>    &isHVPinsVec,
    const TM::DCTEST_MODE &testMode,
    PPMU_SETTING          &ppmuSetting,
    PPMU_CLAMP            &ppmuClampOn,
    PPMU_CLAMP            &ppmuClampOff,
    PPMU_RELAY            &ppmuRelayStep1,
    PPMU_RELAY            &ppmuRelayStep2,
    PPMU_RELAY            &ppmuRelayRestoreStep1,
    PPMU_RELAY            &ppmuRelayRestoreStep2,
    PPMU_MEASURE          &ppmuMeasure,
    HV_DC_TASK            &ppmuHVMeasure,
    bool &hasPpmuParallelGroup,
    bool &hasHVppmuParallelGroup)
{
  double low = 0.0, high = 0.0;
  double clampLow = 0.0, clampHigh = 0.0;
  double currentRange = 0.0;
  double settling = 0.0;
  bool hasParallelGroup = false;
  bool hasNoTerminationGroup = false;
  string hvTestMode = getMeasureModeForHVPin(testMode);

  for(vector<string>::size_type i = 0; i < pinlistVec.size(); i++)
  {
    if(isMeasuredVec[i])
    {
      limitVec[i].getLow(&low);
      limitVec[i].getHigh(&high);
      currentRange = fabs(forceCurrentVec[i]);

      if (isHVPinsVec[i])  // HV pins
      {
        hasHVppmuParallelGroup = true;

        ppmuHVMeasure.pin(pinlistVec[i])
                     .iForceRange(currentRange uA)
                     .min(low)
                     .max(high)
                     .iForce(forceCurrentVec[i] uA)
                     .settling(settlingTimeVec[i] ms)
                     .execMode(hvTestMode);
      }
      else   //non HV pins
      {
        hasPpmuParallelGroup = true;
        hasParallelGroup = true;

        // 1. ppmu setting
        ppmuSetting.pin(pinlistVec[i])
                   .iRange(currentRange uA)
                   .min(low)
                   .max(high)
                   .iForce(forceCurrentVec[i] uA);


        clampLow = -0.1;
        clampHigh = 0.1;

        // 2. switch clamp on
        ppmuClampOn.pin(pinlistVec[i])
                   .status("CLAMP_ON")
                   .low(clampLow V)
                   .high(clampHigh V);
        ppmuClampOn.wait(1 ms);

        // 3.relay switch
        if("OFF" == terminationVec[i])
        {
          hasNoTerminationGroup = true;
          ppmuRelayStep1.pin(pinlistVec[i]).status("AC_OFF");
          ppmuRelayStep2.pin(pinlistVec[i]).status("PPMU_ON");
        }
        else
        {
          ppmuRelayStep1.pin(pinlistVec[i]).status("OPM_ON");
        }

        // 4. switch clamp off
        ppmuClampOff.pin(pinlistVec[i]).status("CLAMP_OFF");
        if(settling < settlingTimeVec[i] + 1)
        {
          settling = settlingTimeVec[i] + 1;
          ppmuClampOff.wait(settling ms);
        }

        // 5. determine measure
        // PVAL or PPF or GPF is defined by TestSuite Flag
        ppmuMeasure.pin(pinlistVec[i]).execMode(testMode);

        // relay restore
        if("OFF" == terminationVec[i])
        {
          ppmuRelayRestoreStep1.pin(pinlistVec[i]).status("PPMU_OFF");
          ppmuRelayRestoreStep2.pin(pinlistVec[i]).status("AC_ON");
        }
        else
        {
          ppmuRelayRestoreStep1.pin(pinlistVec[i]).status("OPM_OFF");
        }
      }
    }
  }

  if(hasParallelGroup)
  {
    ppmuRelayStep1.wait(0.3 ms);
    ppmuRelayRestoreStep1.wait(0.3 ms);
    if(hasNoTerminationGroup)
    {
      ppmuRelayStep2.wait(0.3 ms);
      ppmuRelayRestoreStep2.wait(0.3 ms);
    }
  }
}



inline void
OutputDCTestUtil::ppmuVoltageMeasurementUpdateTestResult(
    const vector<string>  &pinlistVec,
    const vector<bool>    &isMeasuredVec,
    const vector<vector<string> > &expandedPinsVec,
    const TM::DCTEST_MODE &testMode,
    const PPMU_MEASURE    &ppmuMeasure,
    vector<MeasurementResultContainer> &result)
{
  // get test result
  MeasurementResultContainer everyGroupResult;
  for(vector<string>::size_type i = 0; i < pinlistVec.size(); i++)
  {
    if(result.size() <= i)
    {
      everyGroupResult.init();
      result.push_back(everyGroupResult);
    }
    if(isMeasuredVec[i])
    {
      getTestResultForEveryGroup(
          expandedPinsVec[i],testMode,ppmuMeasure,result[i]);
    }
  }
}

template<class T> inline void
OutputDCTestUtil::getTestResultForEveryGroup(
    const vector<string>&   pinlist,
    const TM::DCTEST_MODE& testMode,
    const T&    measureXpmu,
    MeasurementResultContainer& result)
{
  vector<string>::size_type  j = 0;
  bool isPass = true;
  switch ( testMode )
  {
  case TM::PVAL:
    for ( j = 0; j < pinlist.size(); j++ )
    {
      isPass = measureXpmu.getPassFail(pinlist[j]);
      double dMeasValue = measureXpmu.getValue(pinlist[j]);

      result.setPinPassFail(pinlist[j],isPass);
      result.setPinsValue(pinlist[j],dMeasValue);
    }
    break;
  case TM::PPF:
    for ( j = 0; j < pinlist.size(); j++ )
    {
      isPass = measureXpmu.getPassFail(pinlist[j]);
      result.setPinPassFail(pinlist[j],isPass);
    }
    break;
  case TM::GPF:
      isPass = measureXpmu.getPassFail();
      result.setGlobalPassFail(isPass);
    break;
  default:
    throw Error("OutputDCTestUtil::getTestResultForEveryGroup",
                "Unknown Measure Mode",
                "OutputDCTestUtil::getTestResultForEveryGroup");
  }
}



inline void
OutputDCTestUtil::spmuInstrumentVoltageMeasurementSetup(
    const vector<string>&  pinlistVec,
    const vector<bool>&    isMeasuredVec,
    const vector<double>&  forceCurrentVec,
    const vector<double>&  clampValueVec,
    const vector<double>&  settlingTimeVec,
    const vector<string>&  terminationVec,
    const vector<LIMIT>&   limitVec,
    const TM::DCTEST_MODE& testMode,
    SPMU_TASK& spmuTask,
    bool&  hasParallelGroup)
{
  for(unsigned i = 0; i < pinlistVec.size(); i++)
  {
    if(isMeasuredVec[i])
    {
      hasParallelGroup = true;
      double low, high;
      limitVec[i].getLow(&low);
      limitVec[i].getHigh(&high);

      if("ON" == terminationVec[i]) // use termination
      {
        spmuTask.pin(pinlistVec[i])
                .max(high)
                .min(low)
                .mode("IFVM")
                .iForce(forceCurrentVec[i] uA)
                .clamp(clampValueVec[i] mV)
                .execMode("SER")
                .settling(settlingTimeVec[i] ms)
                .relay("TERM");
        spmuTask.execMode(testMode);
      }
      else if("OFF" == terminationVec[i]) // no termination
      {
        spmuTask.pin(pinlistVec[i])
                .max(high)
                .min(low)
                .mode("IFVM")
                .iForce(forceCurrentVec[i] uA)
                .clamp(clampValueVec[i] mV)
                .execMode("SER")
                .settling(settlingTimeVec[i] ms)
                .relay("NTBBM");
        spmuTask.execMode(testMode);
      }
      else
      {
        throw Error("OutputDCTestUtil::spmuInstrumentVoltageMeasurementSetup",
                    "Unknown termination mode",
                    "OutputDCTestUtil::spmuInstrumentVoltageMeasurementSetup");
      }
    }
  }
}

inline void
OutputDCTestUtil::spmuVoltageMeasurementUpdateTestResult(
    const vector<string>&  pinlistVec,
    const vector<bool>&    isMeasuredVec,
    const vector<vector<string> >& expandedPinsVec,
    const TM::DCTEST_MODE& testMode,
    SPMU_TASK& spmuMeasure,
    vector<MeasurementResultContainer>& result)
{
  // get test result
  MeasurementResultContainer everyGroupResult;
  for(vector<string>::size_type i = 0; i < pinlistVec.size(); i++)
  {
    if(result.size() <= i)
    {
      everyGroupResult.init();
      result.push_back(everyGroupResult);
    }

    if(isMeasuredVec[i])
    {
      getTestResultForEveryGroup(
          expandedPinsVec[i],testMode,spmuMeasure,result[i]);
    }
  }
}


inline void
OutputDCTestUtil::boardADCInstrumentVoltageMeasurementSetup(
    const vector<string>&  pinlistVec,
    const vector<bool>&    isMeasuredVec,
    const vector<double>&  settlingTimeVec,
    const vector<string>&  terminationVec,
    const vector<LIMIT>&   limitVec,
    const vector<bool>&    isHVPinVec,
    const TM::DCTEST_MODE& testMode,
    SPMU_TASK&  spmuTaskForceOn,
    SPMU_TASK&  spmuTaskMeasure,
    SPMU_TASK&  spmuTaskForceOff,
    HV_DC_TASK& hvDcTask,
    bool& hasParallelGroup,
    bool& hasParallelHVTask)
{
  for(vector<string>::size_type i = 0; i < pinlistVec.size(); i++)
  {
    if(isMeasuredVec[i])
    {
      double low = 0.0, high = 0.0;
      limitVec[i].getLow(&low);
      limitVec[i].getHigh(&high);

      if (isHVPinVec[i])  // HV pins
      {
        hasParallelHVTask = true;

        hvDcTask.pin(pinlistVec[i])
                .settling(settlingTimeVec[i] ms)
                .min(low)
                .max(high)
                .execMode("VM_HIZ");
      }
      else
      {
        hasParallelGroup = true;

        if("ON" == terminationVec[i])
        {
          spmuTaskForceOn.pin(pinlistVec[i])
                         .max(high)
                         .min(low)
                         .mode("VM_HIZ")
                         .execMode("PAR")
                         .relay("TERM")
                         .settling(settlingTimeVec[i] ms);
          spmuTaskForceOn.execMode("FORCE_ON");
          spmuTaskMeasure.pin(pinlistVec[i])
                         .max(high)
                         .min(low)
                         .mode("VM_HIZ")
                         .execMode("PAR")
                         .relay("TERM");
          spmuTaskMeasure.execMode(testMode);
          spmuTaskForceOff.pin(pinlistVec[i])
                          .max(high)
                          .min(low)
                          .mode("VM_HIZ")
                          .execMode("PAR")
                          .relay("TERM");
          spmuTaskForceOff.execMode("FORCE_OFF");
        }
        else if("OFF" == terminationVec[i])
        {
          spmuTaskForceOn.pin(pinlistVec[i])
                         .max(high)
                         .min(low)
                         .mode("VM_HIZ")
                         .execMode("PAR")
                         .relay("NTMBB")
                         .settling(settlingTimeVec[i] ms);
          spmuTaskForceOn.execMode("FORCE_ON");
          spmuTaskMeasure.pin(pinlistVec[i])
                         .max(high)
                         .min(low)
                         .mode("VM_HIZ")
                         .execMode("PAR")
                         .relay("NTMBB");
          spmuTaskMeasure.execMode(testMode);
          spmuTaskForceOff.pin(pinlistVec[i])
                          .max(high)
                          .min(low)
                          .mode("VM_HIZ")
                          .execMode("PAR")
                          .relay("NTMBB");
          spmuTaskForceOff.execMode("FORCE_OFF");
        }
        else
        {
          throw Error("OutputDCTestUtil::boardADCInstrumentVoltageMeasurementSetup",
                      "Unknown termination mode",
                      "OutputDCTestUtil::boardADCInstrumentVoltageMeasurementSetup");
        }
      }
    }
  }
}

inline void
OutputDCTestUtil::boardADCVoltageMeasurementUpdateTestResult(
    const vector<string>&  pinlistVec,
    const vector<bool>&    isMeasuredVec,
    const vector<vector<string> >& expandedPinsVec,
    const TM::DCTEST_MODE& testMode,
    const SPMU_TASK&  spmuTask,
    vector<MeasurementResultContainer>& resultVec)
{
  // get test result
  MeasurementResultContainer everyGroupResult;
  for(vector<string>::size_type i = 0; i < pinlistVec.size(); i++)
  {
    if(resultVec.size() <= i)
    {
      everyGroupResult.init();
      resultVec.push_back(everyGroupResult);
    }

    if(isMeasuredVec[i])
    {
      getTestResultForEveryGroup(
          expandedPinsVec[i],testMode,spmuTask,resultVec[i]);
    }
  }
}

#endif /* OUTPUTDCTESTUTIL_HPP_ */
