/**
 * (c) Copyright 2011, Verigy Technologies, all rights reserved.
 *
 * Modification History:
 *
 *
 */

//for testmethod framework interfaces
#include "testmethod.hpp"
//for testmethod API interfaces
#include "mapi.hpp"

#include "OutputDCTest.hpp"

 /**
  *----------------------------------------------------------------------*
  * @testmethod class: OutputDC
  *
  * @Purpose: measure output level 
  *
  *----------------------------------------------------------------------*
  * @Description:
  *   ppmu instrument parameter
  *   string ppmuUsed:            {YES | NO }
  *     indicate whether use ppmu to do test or not.
  *   string ppmuPinlist:              {@ | pinlist}
  *     Name of pins to be tested.
  *     valid pin types: O,IO
  *   string ppmuMeasuredLevel         {LOW,HIGH,BOTH}
  *     LOW         - output low level
  *     HIGH        - output high level
  *     BOTH        - output low and high level
  *   string ppmuForceCurrent_uA    {uA}
  *     Value of force voltage (for low/high level test).The format of
  *     input value like: 10 that means force voltage for low or high level
  *     test; (10,20) that means force 10uA for low level test, force
  *     20uA for high level test.
  *     The unit is uA.
  *   string ppmuSettlingTime_ms    {ms}
  *     The settling time before measurement, and the unit is ms.
  *     The format of input value is like:
  *      1.2 that means settling time for low or high level test;
  *      (1.2,1.5)that means 1.2ms settling time for low level test,
  *      1.5ms settling time for high level test.
  *   string ppmuTermination     {ON | OFF}
  *       "ON" for measurement with termination
  *       "OFF" for no termination
  *   string ppmuTestName
  *     Name of limit(s).
  *
  *   spmu instrument parameter
  *   string spmuUsed:            {YES | NO }
  *     indicate whether use spmu to do test or not.
  *   string spmuPinlist:              {@ | pinlist}
  *     Name of pins to be tested.
  *     valid pin types: O,IO
  *   string spmuMeasuredLevel         {LOW,HIGH,BOTH}
  *     LOW         - output low level
  *     HIGH        - output high level
  *     BOTH        - output low and high level
  *   string spmuForceCurrent_uA    {uA}
  *     Value of force voltage (for low/high level test).
  *     The format of input value like:
  *     10 that means force voltage for low or high level test;
  *     (10,20) that means force 10uA for low level test, force
  *     20uA for high level test.
  *     The unit is uA.
  *   string spmuClampVoltage_mV  {mV}
  *     clamp voltage for spmu measurement, and the unit is mV.
  *     The format of input value like:
  *     500 that means clamp voltage for low or high level test;
 *      (500,3800) that means clamp voltage 500mV for low level test, clamp
 *      voltage 3800mV for high level test.
  *   string spmuSettlingTime_ms    {ms}
  *     The settling time before measurement, and the unit is ms.
  *     The format of input value is like:
  *      1.2 that means settling time for low or high level test;
  *      (1.2,1.5)that means 1.2ms settling time for low level test,
  *      1.5ms settling time for high level test.
  *   string spmuTermination     {ON | OFF}
  *       "ON" for measurement with termination
  *       "OFF" for no termination
  *   string spmuTestName
  *     Name of limit(s).
  *
  *   boardADC instrument parameter
  *   string boardADCUsed:            {YES | NO }
  *     indicate whether use boardADC to do test or not.
  *   string boardADCPinlist:              {@ | pinlist}
  *     Name of pins to be tested.
  *     valid pin types: O,IO
  *   string boardADCMeasuredLevel         {LOW,HIGH,BOTH}
  *     LOW         - output low level
  *     HIGH        - output high level
  *     BOTH        - output low and high level
  *   string boardADCSettlingTime_ms    {ms}
  *     The settling time before measurement, and the unit is ms.
  *     The format of input value is like:
  *      1.2 that means settling time for low or high level test;
  *      (1.2,1.5)that means 1.2ms settling time for low level test,
  *      1.5ms settling time for high level test.
  *   string boardADCTermination     {ON | OFF}
  *       "ON" for measurement with termination
  *       "OFF" for no termination
  *   string boardADCTestName
  *     Name of limit(s).
  *
  *   activeLoad instrument parameter
  *   string activeLoadUsed:            {YES | NO }
  *     indicate whether use activeLoad to do test or not.
  *   string activeLoadPinlist:              {@ | pinlist}
  *     Name of pins to be tested.
  *     valid pin types: O,IO
  *   string activeLoadMeasuredLevel         {LOW,HIGH,BOTH}
  *     LOW         - output low level
  *     HIGH        - output high level
  *     BOTH        - output low and high level
  *   string activeLoadForceCurrent_uA    {uA}
  *     Value of force voltage (for low/high level test).
  *     The format of input value like:
  *     10 that means force voltage for low or high level test;
  *     (10,20) that means force 10uA for low level test, force
  *     20uA for high level test.
  *     The unit is uA.
  *   string activeLoadTestName
  *     Name of limit(s).
  *
  *   //common parameter for different instruments.
  *   string vectorRange
  *     vector range to be scanned for low or high output.
  *     valid input format:
  *       number
  *       number1,number2
  *       number1-number2    
 *   string  checkFunctionalResult : {ON | OFF}
 *     the functional test shall contribute to
 *     the overall test result,
 *     OFF is for not.
  *   string output:               {ReportUI | None}
  *     Print message or not. 
  *     ReportUI - for debug mode
  *     None     - for production mode
  *
  * @Note:
  *
  *----------------------------------------------------------------------*
  */

class OutputDC: public testmethod::TestMethod
{
protected:
  // ppmu parameters
  string  ppmuUsed;
  string  ppmuPinlist;
  string  ppmuMeasuredLevel;
  string  ppmuForceCurrent_uA;
  string  ppmuSettlingTime_ms;
  string  ppmuTermination;
  string  ppmuTestName;

  // spmu parameters
  string  spmuUsed;
  string  spmuPinlist;
  string  spmuMeasuredLevel;
  string  spmuForceCurrent_uA;
  string  spmuClampVoltage_mV;
  string  spmuSettlingTime_ms;
  string  spmuTermination;
  string  spmuTestName;

  // boardADC parameters
  string  boardADCUsed;
  string  boardADCPinlist;
  string  boardADCMeasuredLevel;
  string  boardADCSettlingTime_ms;
  string  boardADCTermination;
  string  boardADCTestName;

  // activeLoad parameters
  string  activeLoadUsed;
  string  activeLoadPinlist;
  string  activeLoadMeasuredLevel;
  string  activeLoadForceCurrent_uA;
  string  activeLoadTestName;

  // common parameters
  string  vectorRange;
  string  checkFunctionalResult;
  string  output;

  bool isParameterChanged;

  // Assume all sites' parameters are the same
  OutputDcTest::OutputDCTestParam param;

protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {	  

    // parameters for PPMU
    addParameter("UsePPMU",
                 "string",
                 &ppmuUsed)
      .setDefault("YES")
      .setOptions("YES:NO");
    addParameter("UsePPMU.pinlist",
                 "PinString",
                 &ppmuPinlist)
      .setDefault("")
      .setComment("O or IO pins");
    addParameter("UsePPMU.measuredLevel",
                 "string",
                 &ppmuMeasuredLevel)
      .setDefault("BOTH")
      .setComment("LOW: low level test\n"
                  "HIGH: high level test\n"
                  "BOTH: low and high level test");
    addParameter("UsePPMU.forceCurrent_uA",
                 "string",
                 &ppmuForceCurrent_uA)
      .setDefault("(10,20)")
      .setComment("force current for measurement,The format of input value is like:\n"
                  "10 that means force current for low or high level test; \n"
                  "(10,20) that means force 10uA for low level test, \n"
                  "force 20uA for high level test.");
    addParameter("UsePPMU.settlingTime_ms",
                 "string",
                 &ppmuSettlingTime_ms)
      .setDefault("(1.0,1.2)")
      .setComment("settling time for measurement,The format of input value is like: \n"
                  "1.2 that means settling time for low or high level test; \n"
                  "(1.2,1.5) that means 1.2ms settling time for low level test,\n"
                  "1.5ms settling time for high level test.");
    addParameter("UsePPMU.termination",
                 "string",
                 &ppmuTermination)
      .setDefault("OFF")
      .setComment("Options: ON  OFF");
    addParameter("UsePPMU.testName",
                 "string",
                 &ppmuTestName)
      .setComment("Name of limit(s).");


    // parameters for SPMU
    addParameter("UseSPMU",
                 "string",
                 &spmuUsed)
      .setDefault("NO")
      .setOptions("YES:NO");
    addParameter("UseSPMU.pinlist",
                 "PinString",
                 &spmuPinlist)
      .setDefault("")
      .setComment("O or IO pins");
    addParameter("UseSPMU.measuredLevel",
                 "string",
                 &spmuMeasuredLevel)
      .setDefault("BOTH")
      .setComment("LOW: low level test\n"
                  "HIGH: high level test\n"
                  "BOTH: low and high level test");
    addParameter("UseSPMU.forceCurrent_uA",
                 "string",
                 &spmuForceCurrent_uA)
      .setDefault("(10,20)")
      .setComment("force current for measurement,The format of input value is like:\n"
                  "10 that means force current for low or high level test; \n"
                  "(10,20) that means force 10uA for low level test, \n"
                  "force 20uA for high level test.");
    addParameter("UseSPMU.clampVoltage_mV",
                 "string",
                 &spmuClampVoltage_mV)
      .setDefault("(400,3800)")
      .setComment("SPMU voltage clamp for measurement, The format of input value is like: \n"
                  "400 that means clamp voltage for low or high level test;\n"
                  "(400,3800) that means clamp voltage 400mV for low level test,\n"
                  "clamp voltage 3800mV for high level test.");
    addParameter("UseSPMU.settlingTime_ms",
                 "string",
                 &spmuSettlingTime_ms)
      .setDefault("(1.0,1.2)")
      .setComment("settling time for measurement,The format of input value is like: \n"
                  "1.2 that means settling time for low or high level test; \n"
                  "(1.2,1.5) that means 1.2ms settling time for low level test,\n"
                  "1.5ms settling time for high level test.");
    addParameter("UseSPMU.termination",
                 "string",
                 &spmuTermination)
      .setDefault("OFF")
      .setComment("Options: ON  OFF");
    addParameter("UseSPMU.testName",
                 "string",
                 &spmuTestName)
      .setComment("Name of limit(s).");


    // parameters for BoardADC
    addParameter("UseBoardADC",
                 "string",
                 &boardADCUsed)
      .setDefault("NO")
      .setOptions("YES:NO");
    addParameter("UseBoardADC.pinlist",
                 "PinString",
                 &boardADCPinlist)
      .setDefault("")
      .setComment("O or IO pins");
    addParameter("UseBoardADC.measuredLevel",
                 "string",
                 &boardADCMeasuredLevel)
      .setDefault("BOTH")
      .setComment("LOW: low level test\n"
                  "HIGH: high level test\n"
                  "BOTH: low and high level test");
    addParameter("UseBoardADC.settlingTime_ms",
                 "string",
                 &boardADCSettlingTime_ms)
      .setDefault("(1.0,1.2)")
      .setComment("settling time for measurement,The format of input value is like: \n"
                  "1.2 that means settling time for low or high level test; \n"
                  "(1.2,1.5) that means 1.2ms settling time for low level test,\n"
                  "1.5ms settling time for high level test.");
    addParameter("UseBoardADC.termination",
                 "string",
                 &boardADCTermination)
      .setDefault("OFF")
      .setComment("Options: ON  OFF");
    addParameter("UseBoardADC.testName",
                 "string",
                 &boardADCTestName)
      .setComment("Name of limit(s).");

    // parameters for ActiveLoad
    addParameter("UseActiveLoad",
                 "string",
                 &activeLoadUsed)
      .setDefault("NO")
      .setOptions("YES:NO");
    addParameter("UseActiveLoad.pinlist",
                 "PinString",
                 &activeLoadPinlist)
      .setDefault("")
      .setComment("O or IO pins");
    addParameter("UseActiveLoad.measuredLevel",
                 "string",
                 &activeLoadMeasuredLevel)
      .setDefault("BOTH")
      .setComment("LOW: low level test\n"
                  "HIGH: high level test\n"
                  "BOTH: low and high level test");
    addParameter("UseActiveLoad.forceCurrent_uA",
                 "string",
                 &activeLoadForceCurrent_uA)
      .setDefault("(10,20)")
      .setComment("force current for measurement,The format of input value is like:\n"
                  "10 that means force current for low or high level test; \n"
                  "(10,20) that means force 10uA for low level test, \n"
                  "force 20uA for high level test.");
    addParameter("UseActiveLoad.testName",
                 "string",
                 &activeLoadTestName)
      .setComment("Name of limit(s).");


    // common parameter
    addParameter("vectorRange",
                 "string",
                 &vectorRange)
      .setComment("vector range to be scanned for low or high output.\n"
                  "valid input format:\n"
                  "1) number\n"
                  "2) number1,number2\n"
                  "3) number1-number2");
    addParameter("checkFunction",
                 "string",
                 &checkFunctionalResult)
      .setDefault("ON")
      .setOptions("ON:OFF")
      .setComment("determine whether the functional test result \n"
                  "shall contribute to the overall test result or not");
    addParameter("output",
                 "string",
                 &output)
      .setDefault("None")
      .setOptions("ReportUI:None")
      .setComment("Print message on UI report window if 'ReportUI'");

    isParameterChanged = true;
  }
  
  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
    /*
     * For output dc test with programmeable load,
     * all sites' result are stored in 'result' locally, but not in API.
     * here use 'static' direction to sustain these values of variables for all sites.
     */
    static OutputDcTest::OutputDCTestResult result;
  
      /*
       * Process all parameters needed in test. Actually this function is
       * called once under multisite because all input parameters should be
       * the same through all sites. The processed parameters are stored into
       * the static variable 'param' for later reference on all sites.
       */     
    ON_FIRST_INVOCATION_BEGIN();  
      if(isParameterChanged)
      {
        OutputDcTest::processParameters(ppmuUsed,
                                        ppmuPinlist,
                                        ppmuMeasuredLevel,
                                        ppmuForceCurrent_uA,
                                        ppmuSettlingTime_ms,
                                        ppmuTermination,
                                        ppmuTestName,

                                        spmuUsed,
                                        spmuPinlist,
                                        spmuMeasuredLevel,
                                        spmuForceCurrent_uA,
                                        spmuClampVoltage_mV,
                                        spmuSettlingTime_ms,
                                        spmuTermination,
                                        spmuTestName,

                                        boardADCUsed,
                                        boardADCPinlist,
                                        boardADCMeasuredLevel,
                                        boardADCSettlingTime_ms,
                                        boardADCTermination,
                                        boardADCTestName,

                                        activeLoadUsed,
                                        activeLoadPinlist,
                                        activeLoadMeasuredLevel,
                                        activeLoadForceCurrent_uA,
                                        activeLoadTestName,

                                        vectorRange,
                                        checkFunctionalResult,
                                        param);
        isParameterChanged = false;
      }
    ON_FIRST_INVOCATION_END();
    
    /*
     * Execute measurement with the specified 'param' and store results 
     * into the 'result' judged with 'limit'. The multisite handling, i.e. 
     * ON_FIRST_INVOCATION block are executed inside this function.
     */
    OutputDcTest::doMeasurement(param,result);

  
    /*
     * Judge and datalog based on the 'result'. This function uses
     * testsuite name as test name, so if you'd like to use your own
     * test names for judgement and datalogging it's needed to modify
     * this funciton or create new one.
     */    
    OutputDcTest::judgeAndDatalog(param,result);
  
    /*
     * Output contents of the 'result' to Report Window if specified by
     * the "output" parameter.
     */
    OutputDcTest::reportToUI(param,output,result);
      
    return ;
  }
  
  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   *
   *Note: TestMethod API should not be used in this method.
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    isParameterChanged = true;
    if("UsePPMU" == parameterIdentifier)
    {
      bool toVisible = ("YES" == ppmuUsed);
      getParameter("UsePPMU.pinlist").setVisible(toVisible);
      getParameter("UsePPMU.measuredLevel").setVisible(toVisible);
      getParameter("UsePPMU.forceCurrent_uA").setVisible(toVisible);
      getParameter("UsePPMU.settlingTime_ms").setVisible(toVisible);
      getParameter("UsePPMU.termination").setVisible(toVisible);
      getParameter("UsePPMU.testName").setVisible(toVisible);
    }
    else if("UseSPMU" == parameterIdentifier)
    {
      bool toVisible = ("YES" == spmuUsed);
      getParameter("UseSPMU.pinlist").setVisible(toVisible);
      getParameter("UseSPMU.measuredLevel").setVisible(toVisible);
      getParameter("UseSPMU.forceCurrent_uA").setVisible(toVisible);
      getParameter("UseSPMU.clampVoltage_mV").setVisible(toVisible);
      getParameter("UseSPMU.settlingTime_ms").setVisible(toVisible);
      getParameter("UseSPMU.termination").setVisible(toVisible);
      getParameter("UseSPMU.testName").setVisible(toVisible);
    }
    else if("UseBoardADC" == parameterIdentifier)
    {
      bool toVisible = ("YES" == boardADCUsed);
      getParameter("UseBoardADC.pinlist").setVisible(toVisible);
      getParameter("UseBoardADC.measuredLevel").setVisible(toVisible);
      getParameter("UseBoardADC.settlingTime_ms").setVisible(toVisible);
      getParameter("UseBoardADC.termination").setVisible(toVisible);
      getParameter("UseBoardADC.testName").setVisible(toVisible);
    }
    else if("UseActiveLoad" == parameterIdentifier)
    {
      bool toVisible = ("YES" == activeLoadUsed);
      getParameter("UseActiveLoad.pinlist").setVisible(toVisible);
      getParameter("UseActiveLoad.measuredLevel").setVisible(toVisible);
      getParameter("UseActiveLoad.forceCurrent_uA").setVisible(toVisible);
      getParameter("UseActiveLoad.testName").setVisible(toVisible);
    }
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string  getComment() const
  {
     static string comment = "version: tml_7.1.2_2.1.4";
     return comment;
  }
};

REGISTER_TESTMETHOD("DcTest.OutputDC", OutputDC);
