#ifndef PPTIAJITTER_H_
#define PPTIAJITTER_H_

#include <float.h>
#include "CommonUtil.hpp"

class PptiaJitterUtil
{
public:

  /*
   *----------------------------------------------------------------------*
   * Struct: JitterParameter
   *
   * Purpose: Container to store jitter measurement parameters
   *
   *----------------------------------------------------------------------*
   * Description:
   *   The members in this structure can be categorized into 3 groups
   *     1. specified by a user
   *     2. specified by a user, possibly modified by processParameters()
   *     3. set by processParameters()
   * 
   *   The following parameters belong to group 1.
   *
   *   STRING pins:                  {@ | pin and/or pin group list}
   *     Name of pin(s) and/or pin group(s) to be measured
   *     Valid pins: all digital pins.
   *   STRING mode:     {PER+(M1) | PER-(M1) | PER+(M2) | PER-(M2) | PW+ | PW-}
   *     Measurement mode for jitter measurement
   *     PER+(M1): period (from rising edge to rising edge), Method M1
   *     PER-(M1): period (from falling edge to falling edge), Method M1
   *     PER+(M2): period (from rising edge to rising edge), Method M2
   *     PER-(M2): period (from falling edge to falling edge), Method M2
   *     PW+: pulse width (from rising edge to falling edge)
   *     PW-: pulse width (from falling edge to rising edge)
   *    notes: M1 is optimized mode for PS800 and PS3600, don't use with PS400
   *           M2 is compatible mode for all PS400/PS800/PS3600
   *   DOUBLE threshold_mV:          {mV}
   *     Value of threshold voltage.
   *   INT sampleSize:               {}
   *     # of samples to be taken per measurement.
   *   DOUBLE randomizeRatio:        {}
   *     Value of sample randomization ratio. By specifying positve value
   *     (0 < randomizeRatio < 1), it's possible to move each sampling timing
   *     randomly. If 0 is specified, no randomization is performed.
   *   STRING startMethod:           {DIRECT | SEQ_PROG}
   *     How to start measurement.
   *     In case of DIRECT, measurement is performed immediately.
   *     In case of SEQ_PROG, measurement is performed at the point
   *     where TIAS is specified in sequencer program during functional test.
   *   INT toggleTIAMode:            {0 | 1}
   *     Flag to specify whether switching TIA mode on (and off)
   *     before (and after) measurement.
   *     For consecutive TIA measurements it's possible to skip this switching
   *     by setting TIA mode in advance, resetting it after all measurements.
   *   INT jitterHistogram:          {0 | 1}
   *     Flag to specify whether jitter histogram is created and logged into
   *     datalog stream. min and max value, bin size are automatically set.
   *   INT ftstResult:               {0 | 1}
   *     Flag to specify whether taking functional test result into account
   *     for pass/fail judging and datalogging.
   *   DOUBLE signal_freq_MHz:
   *     This parameter must be set approximately to the clock signal frequency
   *     and it is needed for filter algorithm to know the good population
   *     of samples. Only required for M2 modes
   *   
   *   The following parameters belong to group 2.
   *
   *   DOUBLE delayTime_ms:          {ms}
   *     Value of time to delay start of measurement.
   *     This is only effective when startMethod == DIRECT, otherwise
   *     it's set to 0 by processParameters()
   *   INT measurements:             {}
   *     # of measurements. This value is applicable when startMethod is
   *     SEQ_PROG and should be identical to # of TIAS in sequencer program.
   *     When startMethod == DIRECT, it's set to 1 by processParameters()
   *
   *   The following parameters belong to group 3.
   *
   *   STRING_VECTOR pinVector:
   *     Contains all pins specified by pins as STRING_VECTOR
   *   TM::PPTIA_SLOPE slopeA:
   *     Event slope of event A. It's determined from the mode parameter
   *   TM::PPTIA_SLOPE slopeB:
   *     Event slope of event B. It's determined from the mode parameter
   *   INT eventBCount:
   *     Event count of event B. It's determined from the mode and 
   *     measuredRange parameter
   *   INT sampleSizeToMeasure:
   *     Sample size which is actually taken during measurement. It's
   *     determined from the mode and measuredRange parameter.
   *   Boolean swFilter:
   *     Flag to execute SW filtering to measured values. It's determined
   *     from the mode and measuredRange parameter
   *   TM::PPTIA_ARM_METHOD armingMethod: {TM::EVENT_A | TM::EVENT_B | TM::EVENT_A_FIRST}
   *     TM::EVENT_A: Event A is used as the start or stop signal.
   *     TM::EVENT_B: A user defined reference signal is used as the 
   *                  start or stop event.
   *     TM::EVENT_A_FIRST: Event A is used as the arming event and the
   *                        start event.
   *   DOUBLE thresholdA_mv:
   *     The threshold voltage for event A in[mv].
   *   DOUBLE thresholdB_mv:
   *     The threshold voltage for event B in[mv].

   *
   * Note:
   *   When you create an instance of this class, appropriate default values
   *   except pins are set to each variables in the class.
   *
   *----------------------------------------------------------------------*
   */
  struct JitterParameter
  {
      // Parameters specified by a user
      STRING pins;
      STRING mode;
      DOUBLE threshold_mV;
      INT sampleSize;
      DOUBLE randomizeRatio;
      STRING startMethod;
      INT toggleTIAMode;
      INT jitterHistogram;
      INT ftstResult;
      DOUBLE signal_freq_MHz;

      // Parameters specified by a user, possibly modified by processParameters
      DOUBLE delayTime_ms;
      INT measurements;

      // Parameters set by processParameters()
      STRING_VECTOR pinVector;
      TM::PPTIA_SLOPE slopeA;
      TM::PPTIA_SLOPE slopeB;
      INT eventBCount;
      INT sampleSizeToMeasure;
      Boolean swFilter;
      TM::PPTIA_ARM_METHOD armingMethod;
      DOUBLE thresholdA_mV;
      DOUBLE thresholdB_mV;
      
      // Default constructor
      // all parameters are set to default values
      JitterParameter()
      : pins(""),
        mode("PER+(M1)"),
        threshold_mV(0),
        sampleSize(1024),
        randomizeRatio(0),
        startMethod("DIRECT"),
        toggleTIAMode(0),
        jitterHistogram(0),
        ftstResult(1),
        signal_freq_MHz(0),
        delayTime_ms(0),
        measurements(1),
        slopeA(TM::RISE),
        slopeB(TM::RISE),
        eventBCount(0),
        sampleSizeToMeasure(1024),
        swFilter(FALSE),
        armingMethod(TM::EVENT_B),
        thresholdA_mV(0),
        thresholdB_mV(0)
        {}
  };
  
  /*
   *----------------------------------------------------------------------*
   * Struct: JitterResult
   *
   * Purpose: Container to store jitter measurement results
   *
   *----------------------------------------------------------------------*
   * Description:
   *   map<STRING, map<INT, PinResult> > valueResult;
   *     Contains all results per pin and per measurement. Please see
   *     the note below how to access each result.
   *   STRING_VECTOR pinVector
   *     Contains all pins for which value results are available.
   *   Boolean funcTestResult;
   *     Global pass/fail results of functional test
   *   
   * Note:
   *   To access each result, e.g. a rms jitter result for pin pinVector[j]
   *   from i-th measurement, valueResult[pinVector[j]][i].rms.
   *
   *----------------------------------------------------------------------*
   */
  struct JitterResult
  {
      struct PinResult {
          DOUBLE rms;
          DOUBLE pp;
          LONG_VECTOR histogram;

          // all values are initialized maximum value of DOUBLE
          PinResult() : rms(DBL_MAX), pp(DBL_MAX) {}

          // function to return if the result is valid or not
          Boolean isValid() const { return rms != DBL_MAX && pp != DBL_MAX; }
          
          // contains the error text in case the results are not valid
          STRING errorText;
      };

      map<STRING, map<INT, PinResult> > valueResult;
      STRING_VECTOR pinVector;
      Boolean funcTestResult;

      // constructor
      JitterResult() : funcTestResult(FALSE) {}
  };
  
  
/*
 *----------------------------------------------------------------------*
 * Utility functions for Jitter measurements
 *----------------------------------------------------------------------*
 */

  /*
   *----------------------------------------------------------------------*
   * Routine:PptiaJitterUtil::processParameters
   *
   * Purpose: Store given measurement parameters to the specified
   *          placeholder and determine addtional parameters
   *          which is necessary to execute measurement.
   *          Also performs some error checks on parameters.
   *
   *----------------------------------------------------------------------*
   * Description:
   *   const STRING& pins:
   *   const STRING& mode: {PER+(M1) | PER-(M1) | PER+(M2) | PER-(M2) | PW+ | PW-}
   *   DOUBLE threshold_mV:
   *   INT sampleSize;
   *   DOUBLE randomizeRatio:
   *   const STRING& startMethod:    {DIRECT | SEQ_PROG}
   *   DOUBLE delayTime_ms:
   *   INT measurements:
   *   INT toggleTIAMode:            {0 | 1}
   *   INT jitterHistogram:          {0 | 1}
   *   INT ftstResult:               {0 | 1}
   *   DOUBLE signal_freq_MHz: 
   *   DOUBLE signal_swing_mV: 
   *   DOUBLE threshold_offset:
   *     Those are parameters for jitter measurement.
   *     See the descriptions in JitterParameter definition.
   *   JitterParameter& params:
   *     Container to hold parameters for the measurement.
   *   
   * Note:
   *
   *----------------------------------------------------------------------*
   */
  static void processParameters(const STRING& pins,
                                const STRING& mode,
                                DOUBLE threshold_mV,
                                INT sampleSize,
                                DOUBLE randomizeRatio,
                                const STRING& startMethod,
                                DOUBLE delayTime_ms,
                                INT measurements,
                                INT toggleTIAMode,
                                INT jitterHistogram,
                                INT ftstResult,
                                DOUBLE signal_freq_MHz,
                                DOUBLE signal_swing_mV,
                                DOUBLE threshold_offset,
                                JitterParameter& params)
  {
      // 5% of total raw samples are discarded by default
      static const DOUBLE SAMPLE_DISCARD_RATIO = 0.05;

      // default threshold offset if not specified
      static const DOUBLE THRESHOLD_OFFSET_DEFAULT = 0.05;
      
      // base threshold offset
      static const DOUBLE BASE_THRESHOLD_OFFSET_MILIVOLT = 10;

      // default delay time, unit is ms 
      static const DOUBLE DELAY_TIME_DEFAULT_MILI_SEC = 0.1;
 
      // If no pin for pins is specified, an exception is thrown.
      if (pins.size() == 0) {
          throw Error("PptiaJitterUtil::processParameters()",
                      "Empty pins parameter.");
      }
  
      // Expand the given comma-separated pinlist in STRING to STRING_VECTOR
      params.pinVector =
          PinUtility.expandDigitalPinNamesFromPinList(pins,
                                             TM::ALL_DIGITAL,
                                             TM::EXCEPTION_ON_MISSING_PIN_NAMES);
      // Determine which event slope (TM::RISE or TM::FALL) should be used
      // based on the given measurement mode. 

      if (mode == "PER+(M1)"){
          // Measurement method M1
          params.slopeA = params.slopeB = TM::RISE;
          params.armingMethod = TM::EVENT_A_FIRST;
          params.thresholdA_mV = params.thresholdB_mV =  threshold_mV;
                    // Take more samples (SAMPLE_DISCARD_RATIO %) than specified by a user
          params.sampleSizeToMeasure =
              (INT)(sampleSize * (1 + SAMPLE_DISCARD_RATIO));
          params.swFilter = TRUE;

      } else if (mode == "PER+(M2)") {
          // Measurement method M2
          params.slopeA = params.slopeB = TM::RISE;
          params.signal_freq_MHz = signal_freq_MHz;
          threshold_offset = ( (threshold_offset<0.0 ) or (threshold_offset>1.0) ? THRESHOLD_OFFSET_DEFAULT : threshold_offset );
          params.thresholdA_mV = threshold_mV + threshold_offset * signal_swing_mV / 2.0 + BASE_THRESHOLD_OFFSET_MILIVOLT;
          params.thresholdB_mV = threshold_mV - ( threshold_offset * signal_swing_mV / 2.0 + BASE_THRESHOLD_OFFSET_MILIVOLT );
          params.armingMethod = TM::EVENT_B;
                    // Take more samples (SAMPLE_DISCARD_RATIO %) than specified by a user
          params.sampleSizeToMeasure =
              (INT)(sampleSize * (1 + SAMPLE_DISCARD_RATIO));
          params.swFilter = TRUE;

      } else if (mode == "PER-(M1)"){
          // Measurement method M1
          params.slopeA = params.slopeB = TM::FALL;         
          params.armingMethod = TM::EVENT_A_FIRST;
          params.thresholdA_mV = params.thresholdB_mV =  threshold_mV;
                    // Take more samples (SAMPLE_DISCARD_RATIO %) than specified by a user
          params.sampleSizeToMeasure =
              (INT)(sampleSize * (1 + SAMPLE_DISCARD_RATIO));
          params.swFilter = TRUE;

      } else if (mode == "PER-(M2)") {
          // Measurement method M2
          params.slopeA = params.slopeB = TM::FALL;
          params.signal_freq_MHz = signal_freq_MHz;
          threshold_offset = ( (threshold_offset<0.0) or (threshold_offset>1.0) ? THRESHOLD_OFFSET_DEFAULT : threshold_offset );
          params.thresholdA_mV = threshold_mV - ( threshold_offset * signal_swing_mV / 2.0 + BASE_THRESHOLD_OFFSET_MILIVOLT );
          params.thresholdB_mV = threshold_mV + threshold_offset * signal_swing_mV / 2.0 + BASE_THRESHOLD_OFFSET_MILIVOLT;
          params.armingMethod = TM::EVENT_B;
                    // Take more samples (SAMPLE_DISCARD_RATIO %) than specified by a user
          params.sampleSizeToMeasure =
              (INT)(sampleSize * (1 + SAMPLE_DISCARD_RATIO));
          params.swFilter = TRUE;

      } else if (mode == "PW+") {
          params.slopeA = TM::RISE; params.slopeB = TM::FALL;
          params.thresholdA_mV = params.thresholdB_mV =  threshold_mV;
          params.sampleSizeToMeasure = sampleSize;
          params.swFilter = FALSE;

      } else if (mode == "PW-") {
          params.slopeA = TM::FALL; params.slopeB = TM::RISE;
          params.thresholdA_mV = params.thresholdB_mV =  threshold_mV;
          params.sampleSizeToMeasure = sampleSize;
          params.swFilter = FALSE;

      } else {
          // If the specified mode is not supported in this function,
          // an exception is thrown.
          throw Error("PptiaJitterUtil::jitter_processParameters()",
                      "Illegal mode parameter.");
      }

      params.eventBCount = 0;
 
      // Copy startMethod and determine # of measurements and delay time
      // If startMethod is "DIRECT", always measurements = 1 because
      // it's only possible to execute a single measurement and copy delayTime
      // If startMethod is "SEQ_PROG", always delayTime = 0 because it makes
      // no sense and copy measurements
      if (startMethod == "DIRECT") {
          params.delayTime_ms = delayTime_ms;
          params.measurements = 1;
      } else if (startMethod == "SEQ_PROG") {
          params.delayTime_ms = DELAY_TIME_DEFAULT_MILI_SEC;
          params.measurements = measurements;
      } else {
          // If the specified startMethod is not supported in this function,
          // an exception is thrown.
          throw Error("PptiaJitter::processParameters()",
                      "Illegal startMethod parameter.");
      }        
  
      // Copy other parameters
      params.pins = pins;
      params.mode = mode;
      params.sampleSize = sampleSize;
      params.randomizeRatio = randomizeRatio;
      params.startMethod = startMethod;
      params.toggleTIAMode = toggleTIAMode;
      params.jitterHistogram = jitterHistogram;
      params.ftstResult = ftstResult;
  }
  
  /*
   *----------------------------------------------------------------------*
   * Routine: PptiaJitterUtil::doMeasurement
   *
   * Purpose: Perform setup, execution and result retrieval
   *          for rise/fall time measurement with per pin TIA
   *
   *----------------------------------------------------------------------*
   *
   * Description:
   *   const JitterParameter& params:
   *     Container to hold parameters for the measurement.
   *   JitterResult& results:
   *     Container to store measurement results
   *
   * Note:
   *   'static' variables are used in this function to keep some information
   *   which is refered in the execution for sites where ON_FIRST_INVOCATION 
   *   block is not executed.
   *
   *----------------------------------------------------------------------*
   */
  static void doMeasurement(const JitterParameter& params,
                            JitterResult& results)
  {
      // Measurement setup, execution and result retrieval are done
      // through task object
      PPTIA_TASK task;
  
      ON_FIRST_INVOCATION_BEGIN();
  
        /*
         * TIA measurement setup
         */
        // For eventA, event count is 0, and TM::EVENT is used
        // (i.e. no reference signal). Other parameters are given.
        task.pin(params.pins).eventA(params.slopeA, 0,
                                     params.thresholdA_mV mV, TM::EVENT);
        // For eventB, and TM::EVENT is used (i.e. no reference signal).
        // Other parameters are given.
        task.pin(params.pins).eventB(params.slopeB, params.eventBCount,
                                     params.thresholdB_mV mV, TM::EVENT);
        task.pin(params.pins).numberOfSamples(params.sampleSizeToMeasure);
        task.pin(params.pins).sampleRandomizeRatio(params.randomizeRatio);
        task.pin(params.pins).armingMethod(params.armingMethod);
  
        if (params.swFilter) {
            // Only upload raw result because software filtering is necessary
            // which will be done by this function later
            task.pin(params.pins).resultType(TM::RAW, TRUE);
        } else {
            TM::PPTIA_RESULT_TYPE rslts = TM::STDEV|TM::MINMAX;
            if (params.jitterHistogram) {
                // Need to add following results to create jitter histogram
                rslts |= TM::RAW|TM::MIN|TM::MAX;
            }
            task.pin(params.pins).resultType(rslts);
        }
  
        // Setup non per-pin parameters 
        task.numberOfMeasurements(params.measurements);
        task.delay(params.delayTime_ms msec);
        task.execMode(params.startMethod);
        task.preAction(params.toggleTIAMode ? TM::SET_TIA_MODE : TM::TIA_NONE);
        task.functionalTestMode(params.ftstResult ? "GPF" : "NO_RESULT");
        // Enable a timeout flag so that the execution won't abort by timeout
        task.enableTimeoutFlag();
  
        /*
         * TIA measurement execution
         */
        task.execute();
  
      ON_FIRST_INVOCATION_END();
  
      /*
       * TIA measurement result retrieval
       */
      // Expand pinlist to get/store per-pin value results
      results.pinVector = params.pinVector;
      INT numberOfPins = results.pinVector.size();
  
      // Iterate all measurements
      for (INT i = 0; i < params.measurements; ++i) {
          // Iterate all pins in pinVector
          for (INT j = 0; j < numberOfPins; ++j) {
              const STRING& pinName = results.pinVector[j];
              JitterResult::PinResult& pinResult =
                  results.valueResult[pinName][i];
  
              // Check whether a timeout occurred on this pin
              // because there is no result available in case of a timeout
              if (task.getTimeoutFlag(pinName, i + 1)) {
                  // A timeout occured, so skip this pin
                  continue;
              }

              try {
                  ARRAY_D raw;
                  DOUBLE min = 0.0, max = 0.0;
                  if (params.swFilter) {
                      // Get raw results and id values
                      ARRAY_D rawAll;
                      ARRAY_I id;
                      rawAll = task.getResult(pinName, i + 1);
                      id = task.getId(pinName, i + 1);
  
                      // Make SW filtering to retrieved raw results with id values
                      if( params.mode.find("M2") != STRING::npos ) {         
                          //  SW filter for modes PER+(M2), and PER-(M2)
                          applySwFilterM2(rawAll, id, raw, params.sampleSize, params.signal_freq_MHz );
                      } else {                  
                          //  SW filter for all other modes except PER+(M2), and PER-(M2)
                          applySwFilter(rawAll, id, raw, params.sampleSize );
                      }

                      // Calculate jitter values
                      DOUBLE stdev;
                      TM::PPTIA_RESULT_TYPE rtype = TM::MIN|TM::MAX|TM::STDEV;
                      calculateResultValues(raw, rtype,
                                            &min, &max, NULL, NULL, &stdev);
  
                      // Store value results
                      pinResult.rms = stdev;
                      pinResult.pp = max - min;
                  } else {
                      // Get and store value results for each result type
                      pinResult.rms = task.getValue(pinName, TM::STDEV, i + 1);
                      pinResult.pp = task.getValue(pinName, TM::MINMAX, i + 1);
  
                      if (params.jitterHistogram) {
                          raw = task.getResult(pinName, i + 1);
                          min = task.getValue(pinName, TM::MIN, i + 1);
                          max = task.getValue(pinName, TM::MAX, i + 1);
                      }
                  }

                  // Generate jitter histogram if specified.
                  if (params.jitterHistogram) {
                      makeHistogram(raw, min, max, pinResult.histogram);
                  }

              } catch ( const Error& err ) {
            
                  cerr << "Error in " << err.getApi() 
                       << " on pin " << pinName 
                       << " for site " << CURRENT_SITE_NUMBER()
                       << "\n\t *** " << err.getOrigin() << " ***" <<endl;
                 
                  pinResult.rms = DBL_MAX;
                  pinResult.pp = DBL_MAX;
                  pinResult.errorText = "error";
              }              
          }// end for: numberOfPins
      }//end for: params.measurements 
  
      // Get the p/f result from functional test if specified.
      if (params.ftstResult) {
          results.funcTestResult = task.getFunctionalResult();
      }
  }
      
  /*
   *----------------------------------------------------------------------*
   * Routine: PptiaJitterUtil::judgeAndDatalog
   *
   * Purpose: Perform pass / fail judgement and datalogging
   *          for jitter measurement
   *
   *----------------------------------------------------------------------*
   * Description:
   *   string& testname:
   *     names of limits.      
   *   JitterResult& results:
   *     Container to store measurement results
   *   INT jitterHistogram:          {0 | 1}
   *     Flag to specify whether jitter histogram is logged
   *   INT ftstResult:               {0 | 1}
   *     Flag to specify whether taking functional test result into account
   *     for pass/fail judging and datalogging.
   *   
   * Note:
   *   Jitter histogram is logged first.
   *   judgeAndLog_ParametricTest() is called for results in the order of
   *   TM::STDEV, TM::MINMAX, and finally functional test
   *   results. Even if one of results is FAIL, test method is executed
   *   until all avaiable results are logged.
   *
   *----------------------------------------------------------------------*
   */
  static void judgeAndDatalog(const string& testname,
                              JitterResult& results,
                              INT jitterHistogram, INT ftstResult)
  {
      static string ppJitterTestname;
      static string rmsJitterTestname;
      static bool sIsLimitTableUsed = false;
      ON_FIRST_INVOCATION_BEGIN();
        string::size_type leadPos = testname.find("(");
        string::size_type postPos = testname.find(")");
        if (leadPos != string::npos && postPos != string::npos && leadPos < postPos)
        {
          string validName = testname.substr(leadPos+1,postPos-leadPos-1);
          vector<string> names;
          CommonUtil::splitStr(validName,',',names);
          if (names.size() != 2) {
           throw Error("PptiaJitterUtil::judgeAndDatalog()",
                       "Invalid test name parameter.");
          }
          ppJitterTestname = names.at(0);
          rmsJitterTestname = names.at(1);
        }
        
        //check whether limit table is used.
        string testsuiteName;
        GET_TESTSUITE_NAME(testsuiteName);
        TesttableLimitHelper ttlHelper(testsuiteName);

        LIMIT limitPP;
        LIMIT limitRMS;
        if(ttlHelper.isLimitCsvFileLoad()){
            ttlHelper.getLimit(ppJitterTestname,limitPP);
            ttlHelper.getLimit(rmsJitterTestname,limitRMS);
        }

        sIsLimitTableUsed = ttlHelper.isAllInTable();
        if(!sIsLimitTableUsed)
        {
          limitPP = GET_LIMIT_OBJECT(ppJitterTestname);
          limitRMS = GET_LIMIT_OBJECT(rmsJitterTestname);
        }
      ON_FIRST_INVOCATION_END(); 
      // Get the number of pins and if there is no pin contained in results,
      // just return
      INT numberOfPins = results.pinVector.size();
      if (numberOfPins < 1) {
          return;
      }
  
      // Get the number of measurements from size of valueResult[0].
      INT measurements = results.valueResult[results.pinVector[0]].size();
      if (measurements < 1) {
          return;
      }

      ARRAY_D resultArrayForRMS(numberOfPins);
      ARRAY_D resultArrayForPP(numberOfPins);
      if (sIsLimitTableUsed) {
        // Iterate all available measurements
        for (INT i = 0; i < measurements; ++i) {
          // Iterate all pins in pinVector
          for (INT j = 0; j < numberOfPins; ++j) {
  
            const JitterResult::PinResult& pinResult =
                results.valueResult[results.pinVector[j]][i];
  
            if (pinResult.isValid()) {
              // Log jitter histogram if available
              if (jitterHistogram) {
                char buf[64];
                sprintf(buf, "Jitter Histogram [%d]", i + 1);
                ARRAY_I histogram;
                histogram.resize(pinResult.histogram.size());
                for (int k = 0; k < histogram.size(); ++k) {
                histogram[k] = pinResult.histogram[k];
                }
                WAVE_LOG logData(histogram);
                PUT_DATALOG(results.pinVector[j], buf, logData);
              }

              resultArrayForRMS[j] = pinResult.rms;

              resultArrayForPP[j] = pinResult.pp;
            } else {
              // No valid result is available
              resultArrayForRMS[j] = NAN;
              resultArrayForPP[j] = NAN;
            }
          }
          // Judge and log the "rmsJitter" result if available
          TestSet.cont(TM::CONTINUE).
                  judgeAndLog_ParametricTest(results.pinVector,
                                             rmsJitterTestname,
                                             V93kLimits::tmLimits,
                                             resultArrayForRMS);
          // Judge and log the "ppJitter" result if available
          TestSet.cont(TM::CONTINUE).
                  judgeAndLog_ParametricTest(results.pinVector,
                                             ppJitterTestname,
                                             V93kLimits::tmLimits,
                                             resultArrayForPP);
        }
      } else { 
        // Iterate all available measurements
        for (INT i = 0; i < measurements; ++i) {
          // Iterate all pins in pinVector
          for (INT j = 0; j < numberOfPins; ++j) {
  
              const JitterResult::PinResult& pinResult =
                  results.valueResult[results.pinVector[j]][i];
  
              if (pinResult.isValid()) {
                  // Log jitter histogram if available
                  if (jitterHistogram) {
                      char buf[64];
                      sprintf(buf, "Jitter Histogram [%d]", i + 1);
                      ARRAY_I histogram;
                      histogram.resize(pinResult.histogram.size());
                      for (int k = 0; k < histogram.size(); ++k) {
                          histogram[k] = pinResult.histogram[k];
                      }
                      WAVE_LOG logData(histogram);
                      PUT_DATALOG(results.pinVector[j], buf, logData);
                  }

                  resultArrayForRMS[j] = pinResult.rms;
                  resultArrayForPP[j] = pinResult.pp;
              } else {
                  // No valid result is available
                  resultArrayForRMS[j] = NAN;
                  resultArrayForPP[j] = NAN;
              }
          }
          // Judge and log the "rmsJitter" result
          TESTSET().cont(TM::CONTINUE).
              judgeAndLog_ParametricTest(results.pinVector,
                                         rmsJitterTestname, resultArrayForRMS);

          // Judge and log the "ppJitter" result
          TESTSET().cont(TM::CONTINUE).
              judgeAndLog_ParametricTest(results.pinVector,
                                         ppJitterTestname, resultArrayForPP);
        }
      }
  
      // Finally judge and log the functional test result if available
      if (ftstResult) {
          if (results.funcTestResult) {
              TESTSET().cont(TM::CONTINUE).
                  judgeAndLog_ParametricTest("", "", TM::Pass, 0);
          } else {
              TESTSET().cont(TM::CONTINUE).
                  judgeAndLog_ParametricTest("", "", TM::Fail, 0);
          }
      }
  }
  
  /*
   *----------------------------------------------------------------------*
   * Routine: PptiaJitterUtil::reportToUI
   *
   * Purpose: Output jitter measurement results to Report Window
   *
   *----------------------------------------------------------------------*
   * Description:
   *   JitterResult& results:
   *     Container to store measurement results
   *   INT ftstResult:               {0 | 1}
   *     Flag to specify whether to output functional test result
   *   const STRING& output          {None | ReportUI}
   *     Flag to specify whether to output 
   *     "None" means no output and "ReportUI" means to do output
   *
   * Note:
   *   "debug_analog" testflow flag should be set to see the jitter histogram
   *   on the singal analyzer
   *
   *----------------------------------------------------------------------*
   */
  static void reportToUI(JitterResult& results,
                         const STRING& output,
                         INT jitterHistogram,
                         INT ftstResult)                  
  {
      // If output parameter is different from "ReportUI", just retun
      if ( output != "ReportUI" ) {
          return;  
      }
  
      // Get the number of pins and if there is no pin contained in results,
      // just return
      INT numberOfPins = results.pinVector.size();
      if (numberOfPins < 1) {
          return;
      }
  
      // Get the number of measurements from size of valueResult[0].
      INT measurements = results.valueResult[results.pinVector[0]].size();
      if (measurements < 1) {
          return;
      }
  
      // Iterate all available measurements
      for (INT i = 0; i < measurements; ++i) {
          // Iterate all pins in pinVector
          for (INT j = 0; j < numberOfPins; ++j) {
          
              const JitterResult::PinResult& pinResult =
                  results.valueResult[results.pinVector[j]][i];
  
              // send jitter histogram to signal analyzer if available
              if (jitterHistogram && pinResult.isValid()) {
                  char buf[64];
                  sprintf(buf, "Jitter Histogram [%d]", i + 1);
                  ARRAY_I histogram;
                  histogram.resize(pinResult.histogram.size());
                  for (int k = 0; k < histogram.size(); ++k) {
                      histogram[k] = pinResult.histogram[k];
                  }
                  PUT_DEBUG(results.pinVector[j].c_str(), buf, histogram);
              }
  
              // output the pin name and measurement index
              printf("Pin: [%s]   Measurement: [%d]\n",
                     results.pinVector[j].c_str(), i + 1);
              if (pinResult.isValid()) {
                  // output the "rmsJitter" result
                  printf("rmsJitter = %-10g   nsec\n", pinResult.rms * 1e9);
                  // output the "ppJitter" result
                  printf(" ppJitter = %-10g   nsec\n", pinResult.pp * 1e9);
              } else {
                
                  if ( pinResult.errorText.size() == 0 ) {
                    
                  // use the default error output text 
                  // output the "rmsJitter" result
                  printf("rmsJitter = **********   nsec\t*** TIMEOUT ***\n");
                  // output the "ppJitter" result
                  printf(" ppJitter = **********   nsec\t*** TIMEOUT ***\n");
                  
                  } else {
                      printf("rmsJitter = **********   nsec\t*** %s ***\n", pinResult.errorText.c_str());
                      // output the "ppJitter" result
                      printf(" ppJitter = **********   nsec\t*** %s ***\n", pinResult.errorText.c_str());
                  }
              }
          }
      }
  
      // Finally output functional test result if available
      if (ftstResult) {
          printf("Functional Test:\n"
                 "%-16s\t%c\n", "@", results.funcTestResult ? 'P' : 'F');
      }
  
      fflush(stdout);
  }
    
  /*
   *----------------------------------------------------------------------*
   * Routine: PptiaJitterUtil::applySwFilter
   *
   * Purpose: Applies the SW filter to raw results from jitter measurements
   *
   *----------------------------------------------------------------------*
   * Description:
   *   const ARRAY_D& rawSource:
   *     Source result array to which the SW filter applys
   *   const ARRAY_I& id:
   *     ID values for each result in source result array 'rawSource'
   *     Elements which have the same index in 'rawSource' and 'id' are
   *     corresponding each other.
   *   ARRAY_D& rawDist:
   *     Place holder where the filtered results are stored.
   *   INT rawDistSize:
   *     Expected size of the filtered results rawDist
   *     Usually this is smaller than the size of rawSource, i.e.
   *     some samples in rawSource are discarded for better accuracy
   *
   * Note:
   *
   *----------------------------------------------------------------------*
   */
  static void applySwFilter(const ARRAY_D& rawSource, const ARRAY_I& id,
                            ARRAY_D& rawDist, INT rawDistSize)
  {
      const INT rawSourceSize = rawSource.size();
      // samplesDiscarded is # of samples to be discarded from rawSource
      INT samplesDiscarded = rawSourceSize - rawDistSize;
  
      // Separate raw samples into 2 groups based on id
      DOUBLE* rawGroupA = new DOUBLE[rawSourceSize];
      DOUBLE* rawGroupB = new DOUBLE[rawSourceSize];
      INT rawGroupASize = 0, rawGroupBSize = 0;
      for (INT j = 0; j < rawSourceSize; ++j) {
          if (id[j] == 0) {
              rawGroupA[rawGroupASize] = rawSource[j];
              ++rawGroupASize;
          } else {
              rawGroupB[rawGroupBSize] = rawSource[j];
              ++rawGroupBSize;
          }
      }
  
      // LargerGroup stands for group which contains more samples
      // SmallerGroup stands for group which contains less samples
      DOUBLE* rawLargerGroup;
      DOUBLE* rawSmallerGroup;
      INT rawLargerGroupSize, rawSmallerGroupSize;
      if (rawGroupASize < rawGroupBSize) {
          rawLargerGroup = rawGroupB;
          rawLargerGroupSize = rawGroupBSize;
          rawSmallerGroup = rawGroupA;
          rawSmallerGroupSize = rawGroupASize;
      } else {
          rawLargerGroup = rawGroupA;
          rawLargerGroupSize = rawGroupASize;
          rawSmallerGroup = rawGroupB;
          rawSmallerGroupSize = rawGroupBSize;
      }
  
      if (rawSmallerGroupSize < samplesDiscarded) {
          // Just discard whole samples in SmallerGroup
          samplesDiscarded -= rawSmallerGroupSize;
  
          // Remove # of samplesDiscarded from rawLargerGroup
          srand48(time(0));
          for (INT j = 0; j < samplesDiscarded; ++j) {
              // swapIndex is where the sample is to be removed
              INT swapIndex = (rawLargerGroupSize-j == 0) ? 0 : (lrand48() % (rawLargerGroupSize-j));
              // swapIndex2 is where the removed sample is to be placed
              INT swapIndex2 = rawLargerGroupSize - j - 1;
              if (swapIndex != swapIndex2) {
                  DOUBLE swapVal = rawLargerGroup[swapIndex];
                  rawLargerGroup[swapIndex] = rawLargerGroup[swapIndex2];
                  rawLargerGroup[swapIndex2] = swapVal;
              }
          }
      } else { // rawSmallerGroupSize >= samplesDiscarded
          // Calculate average for LargerGroup
          DOUBLE averageLargerGroup = 0;
          for (INT j = 0; j < rawLargerGroupSize; ++j) {
              averageLargerGroup += rawLargerGroup[j];
          }
          averageLargerGroup = (rawLargerGroupSize == 0) ? 0 : (averageLargerGroup/rawLargerGroupSize);
  
          // Calculate average for SmallerGroup
          DOUBLE averageSmallerGroup = 0;
          for (INT j = 0; j < rawSmallerGroupSize; ++j) {
              averageSmallerGroup += rawSmallerGroup[j];
          }
          averageSmallerGroup = (rawSmallerGroupSize == 0) ? 0 : (averageSmallerGroup/rawSmallerGroupSize);
  
          // Remove #samplesDiscarded from rawSmallerGroup
          srand48(time(0));
          for (INT j = 0; j < samplesDiscarded; ++j) {
              // swapIndex is where the sample is to be removed
              INT swapIndex = lrand48() % (rawSmallerGroupSize - j);
              // swapIndex2 is where the removed sample is to be placed
              INT swapIndex2 = rawSmallerGroupSize - j - 1;
              if (swapIndex != swapIndex2) {
                  DOUBLE swapVal = rawSmallerGroup[swapIndex];
                  rawSmallerGroup[swapIndex] = rawSmallerGroup[swapIndex2];
                  rawSmallerGroup[swapIndex2] = swapVal;
              }
          }
  
          // Merge SmallerGroup into LargeGroup
          DOUBLE offset = averageSmallerGroup - averageLargerGroup;
          for (INT j = rawLargerGroupSize; j < rawDistSize; ++j) {
              rawLargerGroup[j] =
                  rawSmallerGroup[j - rawLargerGroupSize] - offset;
          }
      }
  
      // Copy modified raw results to given array (dummy constructor, but &dst= is a copy operator)
      rawDist = ARRAY_D(rawLargerGroup, rawDistSize);

      // Clean up arrays
      delete [] rawGroupA;
      delete [] rawGroupB;
  }
   
  /*
   *----------------------------------------------------------------------*
   * Routine: PptiaJitter::applySwFilterM2
   *
   * Purpose: Applies the SW filter to raw results from jitter measurements
   *
   *----------------------------------------------------------------------*
   * Description:
   *   const ARRAY_D& rawSource:
   *     Source result array to which the SW filter applys
   *   const ARRAY_I& id:
   *     ID values for each result in source result array 'rawSource'
   *     Elements which have the same index in 'rawSource' and 'id' are
   *     corresponding each other.
   *   ARRAY_D& rawDist:
   *     Place holder where the filtered results are stored.
   *   INT rawDistSize:
   *     Expected size of the filtered results rawDist
   *     Usually this is smaller than the size of rawSource, i.e.
   *     some samples in rawSource are discarded for better accuracy
   *
   * Note:
   *
   *----------------------------------------------------------------------*
   */
  static void applySwFilterM2(const ARRAY_D& rawSource, const ARRAY_I& id,
                              ARRAY_D& rawDist, INT rawDistSize, DOUBLE signal_freq_MHz )
  {
      static const char* WARNING_INSUFFICIENT_SAMPLES = "Insufficent number of samples for jitter measurement. Try to increase the threshold offset.";
      static const char* API = "PptiaJitter::applySwFilter()";
        
      const INT rawSourceSize = rawSource.size();
      // samplesDiscarded is # of samples to be discarded from rawSource
      INT samplesDiscarded = rawSourceSize - rawDistSize;
  
      // Separate raw samples into 2 groups based on id
      DOUBLE* rawGroupA = new DOUBLE[rawSourceSize];
      DOUBLE* rawGroupB = new DOUBLE[rawSourceSize];
      INT rawGroupASize = 0, rawGroupBSize = 0;
      for (INT j = 0; j < rawSourceSize; ++j) {
          if (id[j] == 0) {
              rawGroupA[rawGroupASize] = rawSource[j];
              ++rawGroupASize;
          } else {
              rawGroupB[rawGroupBSize] = rawSource[j];
              ++rawGroupBSize;
          }
      }
  
      // LargerGroup stands for group which contains more samples
      // SmallerGroup stands for group which contains less samples
      DOUBLE* rawLargerGroup;
      DOUBLE* rawSmallerGroup;
      INT rawLargerGroupSize, rawSmallerGroupSize;
      if (rawGroupASize < rawGroupBSize) {
          rawLargerGroup = rawGroupB;
          rawLargerGroupSize = rawGroupBSize;
          rawSmallerGroup = rawGroupA;
          rawSmallerGroupSize = rawGroupASize;
      } else {
          rawLargerGroup = rawGroupA;
          rawLargerGroupSize = rawGroupASize;
          rawSmallerGroup = rawGroupB;
          rawSmallerGroupSize = rawGroupBSize;
      }     
      // Calculate average for LargerGroup
      DOUBLE averageLargerGroup = 0;
          
      for (INT j = 0; j < rawLargerGroupSize; ++j) {
          averageLargerGroup += rawLargerGroup[j];
      }
      averageLargerGroup = ( rawLargerGroupSize > 0 ? averageLargerGroup / rawLargerGroupSize : averageLargerGroup);
  
      // Calculate average for SmallerGroup
      DOUBLE averageSmallerGroup = 0;
      for (INT j = 0; j < rawSmallerGroupSize; ++j) {
          averageSmallerGroup += rawSmallerGroup[j];
      }
      averageSmallerGroup = ( rawSmallerGroupSize > 0 ? averageSmallerGroup / rawSmallerGroupSize : averageSmallerGroup );
                
      // decide which group is "the right one" based on the signal frequency
      const DOUBLE period = 1.0 / ( signal_freq_MHz MHz );
      
      DOUBLE diffL, diffS;
      
      // calculate the distances of the average values of the two groups 
      // to the expected signal period ...
      diffL = fabs ( averageLargerGroup - period );
      diffS = fabs ( averageSmallerGroup - period );           
      
      // find out which group is nearer to the expected period
      if ( diffL < diffS ) {
        // the larger group is nearer to the expected period
        
        // the distancence must be smaller than one half period
        if ( diffL > ( period / 2.0 ) ) {
            // Error we have most probably non sense values here ...
            throw Error( WARNING_INSUFFICIENT_SAMPLES, 
                         WARNING_INSUFFICIENT_SAMPLES,
                         API );        
        }
      } else {
        // the smaller group is nearer to the expected period                
        // the distancence must be smaller than one half period
        if ( diffS > ( period / 2.0 ) ) {
            // Error we have most probably non sense values here ...            
            throw Error( WARNING_INSUFFICIENT_SAMPLES, 
                         WARNING_INSUFFICIENT_SAMPLES,
                         API );        
        }
      
        // swap the groups         
        DOUBLE * tmp = rawSmallerGroup;
        INT tmpSize = rawSmallerGroupSize;
        
        rawSmallerGroup = rawLargerGroup;        
        rawLargerGroup = tmp;

        rawSmallerGroupSize = rawLargerGroupSize;                
        rawLargerGroupSize = tmpSize;        
      }
              
      if (rawSmallerGroupSize < samplesDiscarded) {
          // Just discard whole samples in SmallerGroup
          samplesDiscarded -= rawSmallerGroupSize;
      } else {
            throw Error( WARNING_INSUFFICIENT_SAMPLES, 
                         WARNING_INSUFFICIENT_SAMPLES,
                         API );      
      }
      
      // Remove # of samplesDiscarded from rawLargerGroup
      srand48(time(0));
      for (INT j = 0; j < samplesDiscarded; ++j) {
          // swapIndex is where the sample is to be removed
          INT swapIndex = (rawLargerGroupSize-j == 0) ? 0 : (lrand48() % (rawLargerGroupSize-j));
          // swapIndex2 is where the removed sample is to be placed
          INT swapIndex2 = rawLargerGroupSize - j - 1;
          if (swapIndex != swapIndex2) {
              DOUBLE swapVal = rawLargerGroup[swapIndex];
              rawLargerGroup[swapIndex] = rawLargerGroup[swapIndex2];
              rawLargerGroup[swapIndex2] = swapVal;
          }
      }     
  
      // Copy modified raw results to given array (dummy constructor, but &dst= is a copy operator)
      rawDist = ARRAY_D(rawLargerGroup, rawDistSize);

      // Clean up arrays
      delete [] rawGroupA;
      delete [] rawGroupB;
  }
  
  
  /*
   *----------------------------------------------------------------------*
   * Routine: PptiaJitterUtil::makeHistogram
   *
   * Purpose: Create histogram for jitter measurements
   *
   *----------------------------------------------------------------------*
   * Description:
   *   const ARRAY_D& raw:
   *     Source result array from which the histogram is created.
   *   DOUBLE min:
   *     Minimum value in source results, i.e. 'raw'
   *   DOUBLE max:
   *     Maximum value in source results, i.e. 'raw'
   *   ARRAY_I& histogram:
   *     Place holder where the histogram is stored.
   *
   * Note:
   *
   *----------------------------------------------------------------------*
   */
  static void makeHistogram(const ARRAY_D& raw, DOUBLE min, DOUBLE max,
                            LONG_VECTOR& histogram)
  {
      // Calculate # of bins
      INT nBins =
          (INT) floor(sqrt((DOUBLE)(raw.size() - 1))) - 1;
      // Calculate bin width
      DOUBLE binWidth = (max - min) / nBins;
  
      // Make histogram
      ARRAY_I histo;
      DSP_HISTOGRAM(raw, histo, min + binWidth,
                    max - binWidth, nBins > 2 ? nBins : 2);
  
      // Copy histogram to result vector
      histogram.resize(histo.size());
      for (int i = 0; i < histo.size(); ++i) {
          histogram[i] = histo[i];
      }
  }
  
private :
  static void calculateResultValues(const ARRAY_D& rawResults,
                                    TM::PPTIA_RESULT_TYPE resultType,
                                    DOUBLE* min,
                                    DOUBLE* max,
                                    DOUBLE* mean,
                                    DOUBLE* median,
                                    DOUBLE* stdev);
  static int compareLess(const DOUBLE *lhs, const DOUBLE *rhs);
};

/*
 *----------------------------------------------------------------------*
 * Internal functions
 *----------------------------------------------------------------------*
 */

/*
 *----------------------------------------------------------------------*
 * Routine: PptiaJitterUtil::calculateResultValues
 *
 * Purpose: Calculates various values (min, max, etc.) from the given
 *          ARRAY_D depending on resultType.
 *
 *----------------------------------------------------------------------*
 * Description:
 *   ARRAY_D& rawResults:
 *     Source result array from which various values are calculated
 *   TM::PPTIA_RESULT_TYPE resultType:
 *     Specify which results to be calculated.
 *   DOUBLE* min:
 *     Placeholder for calculated min value
 *   DOUBLE* max:
 *     Placeholder for calculated max value
 *   DOUBLE* mean:
 *     Placeholder for calculated mean value
 *   DOUBLE* median:
 *     Placeholder for calculated median value
 *   DOUBLE* stdev:
 *     Placeholder for calculated standard deviation value
 *
 * Note:
 *    Only values specified by resultType are calculated.
 *
 *    Other values not specified by resultType remains unchanged.
 *
 *    It's not possible to specify NULL-pointer to placeholders
 *    for calculated value because there is no NULL-pointer check
 *    done by this function.
 *
 *----------------------------------------------------------------------*
 */
inline INT PptiaJitterUtil::compareLess(const DOUBLE *lhs, const DOUBLE *rhs)
{
    return (INT)(*lhs - *rhs);
}

inline void PptiaJitterUtil::calculateResultValues(
                                const ARRAY_D& rawResults,
                                TM::PPTIA_RESULT_TYPE resultType,
                                DOUBLE* min, DOUBLE* max,
                                DOUBLE* mean, DOUBLE* median, DOUBLE* stdev)
{
    INT arraySize = rawResults.size();
    DOUBLE minVal = 0, maxVal = 0, meanVal = 0, medianVal = 0, stdevVal = 0;

    // For arraySize < 2, special handling is necessary
    switch (arraySize) {
      case 0:
        minVal = maxVal = meanVal = medianVal = stdevVal = 0;
        goto end;
      case 1:
        minVal = maxVal = meanVal = medianVal = rawResults[0];
        stdevVal = 0;
        goto end;
    }

    if (resultType & TM::MEDIAN) {
        // Copy the given raw results to DOUBLE array
        DOUBLE* array = new DOUBLE[arraySize];
        memcpy(array, (const DOUBLE*)rawResults, arraySize);
        // Sort array in ascending order
        qsort(array, arraySize, sizeof(DOUBLE),
              (INT(*)(const void*, const void*))compareLess);

        // Get min result
        minVal = array[0];
        // Get max result
        maxVal = array[arraySize - 1];
        // Get median result
        medianVal = array[arraySize / 2 - 1];

        if (resultType & TM::STDEV) {
            // Get mean and stdev result
            DSP_MEAN(array, mean, stdev, arraySize);
        } else if (resultType & TM::MEAN) {
            meanVal = 0;
            for (INT i = 0; i < arraySize; ++i) {
                meanVal += array[i];
            }
            // Get mean result
            meanVal /= arraySize;
        }
        
        //delete array to avoid memory leak
        delete[] array;
    } else {
        minVal = maxVal = rawResults[0];
        meanVal = 0;
        for (INT i = 0; i < arraySize; ++i) {
            // Get min result
            if (minVal > rawResults[i]) minVal = rawResults[i];
            // Get max result
            if (maxVal < rawResults[i]) maxVal = rawResults[i];
            meanVal += rawResults[i];
        }
        // Get mean result
        meanVal /= arraySize;

        if (resultType & TM::STDEV) {
            DOUBLE buffer = 0;
            for (INT i = 0; i < arraySize; ++i) {
                buffer += pow(rawResults[i] - meanVal, 2);
            }                
            // Get stdev result
            stdevVal = sqrt(buffer / arraySize);
        }
    }

  end:
    // Copy calculated values to specified placeholders
    if (resultType & TM::MIN) *min = minVal;
    if (resultType & TM::MAX) *max = maxVal;
    if (resultType & TM::MEAN) *mean = meanVal;
    if (resultType & TM::MEDIAN) *median = medianVal;
    if (resultType & TM::STDEV) *stdev = stdevVal;
}
  
#endif /*PPTIAJITTER_H_*/
