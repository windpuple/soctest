/**
 * (c) Copyright 2011, Verigy Technologies, all rights reserved.
 *
 * Modification History:
 *
 *
 */

//for testmethod framework interfaces
#include "testmethod.hpp"
//for testmethod API interfaces
#include "mapi.hpp"

#include "PptiaRiseFallTimeUtil.hpp"

/**
  *----------------------------------------------------------------------*
  * @Testmethod Class: RiseFallTime
  *
  * @Purpose: rise time and fall time measurement with per pin TIA
  *
  *----------------------------------------------------------------------*
  *
  * @Description:
  *   STRING& pins:                 {@ | pin and/or pin group list}
  *     Name of pin(s) and/or pin group(s) to be measured
  *     Valid pins: all digital pins.
  *   STRING& mode:                 {TR | TF}
  *     Measurement mode.
  *     TR: Rise time
  *     TF: Fall time
  *   DOUBLE lowThreshold_mV:       {mV}
  *     Value of low threshold voltage.
  *   DOUBLE highThreshold_mV:      {mV}
  *     Value of high threshold voltage.
  *   INT sampleSize:               {}
  *     # of samples to be taken per measurement.
  *   STRING& startMethod:          {DIRECT | SEQ_PROG}
  *     How to start measurement.
  *     In case of DIRECT, measurement is performed immediately.
  *     In case of SEQ_PROG, measurement is performed at the point
  *     where TIAS is specified in sequencer program during functional test.
  *   DOUBLE delayTime_ms:          {ms}
  *     Value of time to delay start of measurement.
  *     This is only effective when startMethod == DIRECT
  *   INT measurements:             {}
  *     # of measurements. This value is applicable when startMethod is
  *     SEQ_PROG and should be identical to # of TIAS in sequencer program.
  *   INT toggleTIAMode:            {0 | 1}
  *     Flag to specify whether switching TIA mode on (and off)
  *     before (and after) measurement.
  *     For consecutive TIA measurements it's possible to skip this switching
  *     by setting TIA mode in advance, resetting it after all TIA measurements.
  *   INT ftstResult:               {0 | 1}
  *     Flag to specify whether taking functional test result into account
  *     for pass/fail judging and datalogging.
  *   
  * @Note:
  *
  *----------------------------------------------------------------------*
  */

class RiseFallTime: public testmethod::TestMethod
{
protected:
  string  pins;
  string  mode;
  double  lowThreshold_mV;
  double  highThreshold_mV;
  int  sampleSize;
  string  startMethod;
  double  delayTime_ms;
  int  measurements;
  int  toggleTIAMode;
  int  ftstResult;
  string  output;
  string  mTestName;
protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    addParameter("pins",
                 "PinString",
                 &pins)
      .setComment("Pin(s) and/or pin group(s) to be measured");
    addParameter("mode",
                 "string",
                 &mode)
      .setOptions("TR:TF")
      .setComment("Measurement mode");
    addParameter("lowThreshold_mV",
                 "double",
                 &lowThreshold_mV)
      .setComment("Low threshold voltage in [mV]");
    addParameter("highThreshold_mV",
                 "double",
                 &highThreshold_mV)
      .setComment("High threshold voltage in [mV]");
    addParameter("sampleSize",
                 "int",
                 &sampleSize)
      .setDefault("1")
      .setComment("# of samples per measurement");
    addParameter("startMethod",
                 "string",
                 &startMethod)
      .setDefault("DIRECT")
      .setOptions("DIRECT:SEQ_PROG")
      .setComment("How to start measurement");
    addParameter("delayTime_ms",
                 "double",
                 &delayTime_ms)
      .setDefault("0")
      .setComment("Delay time to start measurement in [msec]");
    addParameter("measurements",
                 "int",
                 &measurements)
      .setDefault("1")
      .setComment("# of measurements");
    addParameter("toggleTIAMode",
                 "int",
                 &toggleTIAMode)
      .setDefault("0")
      .setOptions("0:1")
      .setComment("Toggle TIA mode on/off for pins?");
    addParameter("ftstResult",
                 "int",
                 &ftstResult)
      .setDefault("1")
      .setOptions("0:1")
      .setComment("Check p/f result of functional test?");
    addParameter("output",
                 "string",
                 &output)
      .setDefault("None")
      .setOptions("None:ReportUI")
      .setComment("Print results to UI report window");
    addParameter("testName",
                 "string",
                 &mTestName)
      .setDefault("(minValue,maxValue,meanValue)")
      .setComment("three test limits' names in pairs, "
         "like \"(min,max,mean)\"\n"
         "pair is ordered:\n" 
         "  pair.first is for minimum value\n"
         "  pair.second is for maximum value\n"
         "  pair.third is for mean value\n"
         "if test table is used, the limit is defined in file\n"
         "if predefined limit is used, the limit name must be as same as default.");

    addLimit("minValue");
    addLimit("maxValue");
    addLimit("meanValue");
  }
  
  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
      static PptiaRiseFallTimeUtil::RiseFallTimeParameter params;
      PptiaRiseFallTimeUtil::RiseFallTimeResult results;
      
      ON_FIRST_INVOCATION_BEGIN();
        /*
         * Process all parameters needed in test. Actually this function is
         * called once under multisite because all input parameters should be
         * the same through all sites. The processed parameters are stored into
         * the static variable 'params' and it's refered by the doMeasurement() 
         * for every site.
         */
        PptiaRiseFallTimeUtil::processParameters(pins, 
                                                 mode,
                                                 lowThreshold_mV,
                                                 highThreshold_mV,
                                                 sampleSize, 
                                                 startMethod,
                                                 delayTime_ms,
                                                 measurements,
                                                 toggleTIAMode, 
                                                 ftstResult,
                                                 params);
      ON_FIRST_INVOCATION_END();
  
      /*
       * Execute measurement with the specified 'params' and store results
       * into the 'results'. The multisite handling, i.e. ON_FIRST_INVOCATION
       * block are executed inside this function.
       */
      PptiaRiseFallTimeUtil::doMeasurement(params, results);
  
      /*
       * Judge and datalog based on the 'results'. This function accepts
       * test name (e.g. "(minValue,maxValue,meanValue)" ), so if
       * you'd like to use your own test names for judgement and datalogging
       * it's needed to modify the value of "testName" parameter according to 
       * the defined limits.
       */
      PptiaRiseFallTimeUtil::judgeAndDatalog(mTestName, results, params.ftstResult);
                                      
      /*
       * Output contents of the 'results' to Report Window if specified by
       * the "output" parameter.
       */
      PptiaRiseFallTimeUtil::reportToUI(results, output, params.ftstResult);
  
      return ;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   *
   *Note: TestMethod API should not be used in this method.
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string  getComment() const
  {
     static string comment = _TML_VERSION;
     return comment;
  }
};

REGISTER_TESTMETHOD("PptiaTest.RiseFallTime", RiseFallTime);
