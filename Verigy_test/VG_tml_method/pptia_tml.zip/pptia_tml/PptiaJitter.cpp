/**
 * (c) Copyright 2011, Verigy Technologies, all rights reserved.
 *
 * Modification History:
 *
 *
 */

//for testmethod framework interfaces
#include "testmethod.hpp"
//for testmethod framework interfaces
#include "mapi.hpp"

#include "PptiaJitterUtil.hpp"
/**
 *----------------------------------------------------------------------*
 * @Testmethod Class: Jitter
 *
 * @Purpose: jitter measurement with per pin TIA
 *
 *----------------------------------------------------------------------*
 *
 * @Description:
 *   STRING& pins:                 {@ | pin and/or pin group list}
 *     Name of pin(s) and/or pin group(s) to be measured
 *     Valid pins: all digital pins.
 *   STRING& mode: {PER+(M1) | PER-(M1) | PER+(M2) | PER-(M2) | PW+ | PW-}
 *     Measurement mode for jitter measurement
 *     PER+(M1): period (from rising edge to rising edge),Method M1
 *     PER-(M1): period (from falling edge to falling edge),Method M1
 *     PER+(M2): period (from rising edge to rising edge),Method M2
 *     PER-(M2): period (from falling edge to falling edge),Method M2
 *          PW+: pulse width (from rising edge to falling edge)
 *          PW-: pulse width (from falling edge to rising edge)
 *     notes: M1 is optimized mode for PS800 and PS3600, don't use with PS400
 *            M2 is compatible mode for all PS400/PS800/PS3600
 *   DOUBLE threshold_mV:          {mV}
 *     Value of threshold voltage.
 *   INT sampleSize:               {}
 *     # of samples to be taken per measurement.
 *   DOUBLE randomizeRatio:        {}
 *     Value of sample randomization ratio. By specifying positve value
 *     (0 < randomizeRatio < 1), it's possible to move each sampling timing
 *     randomly. If 0 is specified, no randomization is performed.
 *   STRING& startMethod:          {DIRECT | SEQ_PROG}
 *     How to start measurement.
 *     In case of DIRECT, measurement is performed immediately.
 *     In case of SEQ_PROG, measurement is performed at the point
 *     where TIAS is specified in sequencer program during functional test.
 *   DOUBLE delayTime_ms:          {ms}
 *     Value of time to delay start of measurement.
 *     This is only effective when startMethod == DIRECT
 *   INT measurements:             {}
 *     # of measurements. This value is applicable when startMethod is
 *     SEQ_PROG and should be identical to # of TIAS in sequencer program.
 *   INT toggleTIAMode:            {0 | 1}
 *     Flag to specify whether switching TIA mode on (and off)
 *     before (and after) measurement.
 *     For consecutive TIA measurements it's possible to skip this switching
 *     by setting TIA mode in advance, resetting it after all TIA measurements.
 *   INT jitterHistogram:          {0 | 1}
 *     Flag to specify whether jitter histogram is created and logged into
 *     datalog stream. min and max value, bin size are automatically set.
 *   INT ftstResult:               {0 | 1}
 *     Flag to specify whether taking functional test result into account
 *     for pass/fail judging and datalogging.
 *   DOUBLE signal_freq_MHz:
 *     This parameter must be set approximately to the clock signal frequency
 *     and it is needed for filter algorithm to know the good population
 *     of samples. Only required for M2 modes
 *   DOUBLE signal_swing_mV:
 *     The signal swing (peak to peak) as seen by the recerver
 *     only required for M2 modes
 *   DOUBLE threshold_offset:
 *     As fraction of signal swing. Only required for M2 modes.
 *
 * @Note:
 *
 *----------------------------------------------------------------------*
 */

class Jitter: public testmethod::TestMethod
{
protected:
  string  pins;
  string  mode;
  double  threshold_mV;
  int  sampleSize;
  double  randomizeRatio;
  string  startMethod;
  double  delayTime_ms;
  int  measurements;
  int  toggleTIAMode;
  int  jitterHistogram;
  int  ftstResult;
  double signal_freq_MHz;
  double signal_swing_mV;
  double threshold_offset;
  string  output;
  string mTestName;
protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    addParameter("pins",
                 "PinString",
                 &pins)
      .setComment("Pin(s) and/or pin group(s) to be measured");
    addParameter("mode",
                 "string",
                 &mode)
      .setOptions("PER+:PER-:PW+:PW-")
      .setComment("Measurement mode");
    addParameter("threshold_mV",
                 "double",
                 &threshold_mV)
      .setComment("Threshold voltage in [mV]");
    addParameter("sampleSize",
                 "int",
                 &sampleSize)
      .setDefault("1024")
      .setComment("# of samples, +5% samples taken in RANGE_2");
    addParameter("randomizeRatio",
                 "double",
                 &randomizeRatio)
      .setDefault("0")
      .setComment("Sample randomization ratio");
    addParameter("startMethod",
                 "string",
                 &startMethod)
      .setDefault("DIRECT")
      .setOptions("DIRECT:SEQ_PROG")
      .setComment("How to start measurement");
    addParameter("delayTime_ms",
                 "double",
                 &delayTime_ms)
      .setDefault("0")
      .setComment("Delay time to start measurement in [msec]");
    addParameter("measurements",
                 "int",
                 &measurements)
      .setDefault("1")
      .setComment("# of measurements");
    addParameter("toggleTIAMode",
                 "int",
                 &toggleTIAMode)
      .setDefault("0")
      .setOptions("0:1")
      .setComment("Toggle TIA mode on/off for pins?");
    addParameter("jitterHistogram",
                 "int",
                 &jitterHistogram)
      .setDefault("0")
      .setOptions("0:1")
      .setComment("Enable jitter histogram datalog?");
    addParameter("ftstResult",
                 "int",
                 &ftstResult)
      .setDefault("1")
      .setOptions("0:1")
      .setComment("Check p/f result of functional test?");
    addParameter("signal_freq_MHz",
                 "double",
                 &signal_freq_MHz)
      .setDefault("0")
      .setComment("must be set approximately to the clock signal frequency.\n"
                  "only required for M2 modes"); 
    addParameter("signal_swing_mV",
                 "double",
                 &signal_swing_mV)
      .setComment("The signal swing(peak to peak) as seen by the receiver.\n"
                  "only required for M2 modes");
    addParameter("threshold_offset",
                 "double",
                 &threshold_offset)
      .setComment("As fraction of signal swing. Only required for M2 modes.");
    addParameter("output",
                 "string",
                 &output)
      .setDefault("None")
      .setOptions("None:ReportUI")
      .setComment("Print results to UI report window");
    addParameter("testName",
                 "string",
                 &mTestName)
      .setDefault("(rmsJitter,ppJitter)")
      .setComment("two test limits' names in pairs, "
         "like \"(name for rms jitter, name for peak2peak jitter)\"\n"
         "pair.first is for rms jitter\n"
         "pair.second is for peak to peak jitter\n"
         "if test table is used, the limit is defined in file\n"
         "if predefined limit is used, the limit name must be as same as default.");

    addLimit("rmsJitter");
    addLimit("ppJitter");
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
      static PptiaJitterUtil::JitterParameter params;
      PptiaJitterUtil::JitterResult results;
  
      ON_FIRST_INVOCATION_BEGIN();
        /*
         * Process all parameters needed in test. Actually this function is
         * called once under multisite because all input parameters should be
         * the same through all sites. The processed parameters are stored into
         * the static variable 'params' and it's refered by the doMeasurement() 
         * for every site.
         */
        PptiaJitterUtil::processParameters(pins, 
                                           mode, 
                                           threshold_mV,
                                           sampleSize, 
                                           randomizeRatio,
                                           startMethod, 
                                           delayTime_ms,
                                           measurements, 
                                           toggleTIAMode,
                                           jitterHistogram, 
                                           ftstResult,
                                           signal_freq_MHz,
                                           signal_swing_mV,
                                           threshold_offset, 
                                           params);
      ON_FIRST_INVOCATION_END();
  
      /*
       * Execute measurement with the specified 'params' and store results
       * into the 'results'. The multisite handling, i.e. ON_FIRST_INVOCATION
       * block are executed inside this function.
       */
      PptiaJitterUtil::doMeasurement(params, results);
  
      /*
       * Judge and datalog based on the 'results'. This function accepts 
       * test name (e.g. "(rmsJitter,ppJitter)" ), so if
       * you'd like to use your own test names for judgement and datalogging
       * it's needed to modify the value of "testName" parameter according to
       * the defined limits.
       */
      PptiaJitterUtil::judgeAndDatalog(mTestName,
                                       results, 
                                       params.jitterHistogram,
                                       params.ftstResult);
                             
      /*
       * Output contents of the 'results' to Report Window if specified by
       * the "output" parameter.
       */
      PptiaJitterUtil::reportToUI(results, 
                                  output,
                                  params.jitterHistogram,
                                  params.ftstResult);
  
      return ;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   *
   *Note: TestMethod API should not be used in this method.
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string  getComment() const
  {
     static string comment = _TML_VERSION;
     return comment;
  }
};

REGISTER_TESTMETHOD("PptiaTest.Jitter", Jitter);
