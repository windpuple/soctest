/**
 * (c) Copyright 2011, Verigy Technologies, all rights reserved.
 *
 * Modification History:
 * 
 * 
 */

//for testmethod framework interfaces
#include "testmethod.hpp"
//for testmethod API interfaces
#include "mapi.hpp"

#include "PptiaFrequencyUtil.hpp"
/**
 *----------------------------------------------------------------------*
 * @Testmethod Class: Frequency
 *
 * @Purpose: frequency and period measurement with per pin TIA
 *
 *----------------------------------------------------------------------*
 *
 * @Description:
 *   STRING& pins:                 {@ | pin and/or pin group list}
 *     Name of pin(s) and/or pin group(s) to be measured
 *     Valid pins: all digital pins.
 *   STRING& mode:                 {FREQ+ | FREQ- | PER+ | PER-}
 *     Measurement mode.
 *     FREQ+: frequency (from rising edge to rising edge)
 *     FREQ-: frequency (from falling edge to falling edge)
 *     PER+: period (from rising edge to rising edge)
 *     PER-: period (from falling edge to falling edge)
 *   DOUBLE threshold_mV:          {mV}
 *     Value of threshold voltage.
 *   INT dutCycles:                {}
 *     # of signal cycles to be taken
 *   STRING& startMethod:          {DIRECT | SEQ_PROG}
 *     How to start measurement.
 *     In case of DIRECT, measurement is performed immediately.
 *     In case of SEQ_PROG, measurement is performed at the point
 *     where TIAS is specified in sequencer program during functional test.
 *   DOUBLE delayTime_ms:          {ms}
 *     Value of time to delay start of measurement.
 *     This is only effective when startMethod == DIRECT
 *   INT measurements:             {}
 *     # of measurements. This value is applicable when startMethod is
 *     SEQ_PROG and should be identical to # of TIAS in sequencer program.
 *   INT toggleTIAMode:            {0 | 1}
 *     Flag to specify whether switching TIA mode on (and off)
 *     before (and after) measurement.
 *     For consecutive TIA measurements it's possible to skip this switching
 *     by setting TIA mode in advance, resetting it after all TIA measurements.
 *   INT dutyCycle
 *     Expected duty cycle of the measured signal. This (D) is defined as
 *       D = PW+/PER
 *     while PW+ is a positive pulse width, PER is an expected period
 *     Used to compensate a measured value.
 *   INT ftstResult:               {0 | 1}
 *     Flag to specify whether taking functional test result into account
 *     for pass/fail judging and datalogging.
 *     
 * @Note:
 *
 *----------------------------------------------------------------------*
 */

class Frequency: public testmethod::TestMethod
{
protected:
  string  pins;
  string  mode;
  double  threshold_mV;
  int  dutCycles;
  string  startMethod;
  double  delayTime_ms;
  int  measurements;
  int  toggleTIAMode;
  double  dutyCycle;
  int  ftstResult;
  string  output;
  string mTestName; 
protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   */
  virtual void initialize()
  {
    addParameter("pins",
                 "PinString",
                 &pins)
      .setComment("Pin(s) and/or pin group(s) to be measured");
    addParameter("mode",
                 "string",
                 &mode)
      .setOptions("FREQ+:FREQ-:PER+:PER-")
      .setComment("Measurement mode");
    addParameter("threshold_mV",
                 "double",
                 &threshold_mV)
      .setComment("Threshold voltage in [mV]");
    addParameter("dutCycles",
                 "int",
                 &dutCycles)
      .setDefault("1")
      .setComment("# of cycles to be averaged");
    addParameter("startMethod",
                 "string",
                 &startMethod)
      .setDefault("DIRECT")
      .setOptions("DIRECT:SEQ_PROG")
      .setComment("How to start measurement");
    addParameter("delayTime_ms",
                 "double",
                 &delayTime_ms)
      .setDefault("0")
      .setComment("Delay time to start measurement in [msec]");
    addParameter("measurements",
                 "int",
                 &measurements)
      .setDefault("1")
      .setComment("# of measurements in seq program");
    addParameter("toggleTIAMode",
                 "int",
                 &toggleTIAMode)
      .setDefault("0")
      .setOptions("0:1")
      .setComment("Toggle TIA mode on/off for pins?");
    addParameter("dutyCycle",
                 "double",
                 &dutyCycle)
      .setDefault("0.5")
      .setComment("Expected duty cycle (= PW+/PER)");
    addParameter("ftstResult",
                 "int",
                 &ftstResult)
      .setDefault("1")
      .setOptions("0:1")
      .setComment("Check p/f result of functional test?");
    addParameter("output",
                 "string",
                 &output)
      .setDefault("None")
      .setOptions("None:ReportUI")
      .setComment("Print results to UI report window");

    addParameter("testName",
                 "string",
                 &mTestName)
      .setDefault("meanValue")
      .setComment("test limit's name, default is \"meanValue\"\n"
         "if test table is used, the limit is defined in file\n"
         "if predefined limit is used, the limit name must be as same as default.");

    addLimit("meanValue");
  }
  
  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
      static PptiaFrequencyUtil::FrequencyParameter params;
      PptiaFrequencyUtil::FrequencyResult results;
  
      ON_FIRST_INVOCATION_BEGIN();
        /*
         * Process all parameters needed in test. Actually this function is
         * called once under multisite because all input parameters should be
         * the same through all sites. The processed parameters are stored into
         * the static variable 'params' and it's refered by the doMeasurement() 
         * for every site.
         */
        PptiaFrequencyUtil::processParameters(pins, 
                                              mode, 
                                              threshold_mV,
                                              dutCycles, 
                                              startMethod,
                                              delayTime_ms, 
                                              measurements,
                                              toggleTIAMode, 
                                              dutyCycle,
                                              ftstResult, 
                                              params);
      ON_FIRST_INVOCATION_END();
  
      /*
       * Execute measurement with the specified 'params' and store results
       * into the 'results'. The multisite handling, i.e. ON_FIRST_INVOCATION
       * block are executed inside this function.
       */
      PptiaFrequencyUtil::doMeasurement(params, results);
  
      /*
       * Judge and datalog based on the 'results'. This function accepts
       * test name (e.g. "meanValue"), so if
       * you'd like to use your own test names for judgement and datalogging
       * it's needed to modify the value of the "testName" parameter according
       * to the defined limit.
       */
      PptiaFrequencyUtil::judgeAndDatalog(mTestName,
                                          results, 
                                          params.isFrequency,
                                          params.ftstResult);
  
      /*
       * Output contents of the 'results' to Report Window if specified by
       * the "output" parameter.
       */
      PptiaFrequencyUtil::reportToUI(results, 
                                     output, 
                                     params.isFrequency,
                                     params.ftstResult);
  
      return ;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   *
   *Note: TestMethod API should not be used in this method.
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string  getComment() const
  {
     static string comment = _TML_VERSION;
     return comment;
  }
};

REGISTER_TESTMETHOD("PptiaTest.Frequency", Frequency);
