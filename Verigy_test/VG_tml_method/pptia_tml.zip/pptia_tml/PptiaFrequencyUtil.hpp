#ifndef PPTIAFREQUENCY_H_
#define PPTIAFREQUENCY_H_

#include <float.h>
#include "CommonUtil.hpp"

class PptiaFrequencyUtil
{
public:

  /*
   *----------------------------------------------------------------------*
   * Struct: FrequencyParameter
   *
   * Purpose: Container to store frequency/period measurement parameters
   *
   *----------------------------------------------------------------------*
   * Description:
   *   The members in this structure can be categorized into 3 groups
   *     1. specified by a user
   *     2. specified by a user, possibly modified by processParameters()
   *     3. set by processParameters()
   * 
   *   The following parameters belong to group 1.
   *
   *   STRING pins:                  {@ | pin and/or pin group list}
   *     Name of pin(s) and/or pin group(s) to be measured
   *     Valid pins: all digital pins.
   *   STRING mode:                  {FREQ+ | FREQ- | PER+ | PER-}
   *     Measurement mode.
   *     FREQ+: frequency (from rising edge to rising edge)
   *     FREQ-: frequency (from falling edge to falling edge)
   *     PER+: period (from rising edge to rising edge)
   *     PER-: period (from falling edge to falling edge)
   *   DOUBLE threshold_mV:          {mV}
   *     Value of threshold voltage.
   *   INT dutCycles:                {}
   *     # of signal cycles to be taken
   *   STRING startMethod:           {DIRECT | SEQ_PROG}
   *     How to start measurement.
   *     In case of DIRECT, measurement is performed immediately.
   *     In case of SEQ_PROG, measurement is performed at the point
   *     where TIAS is specified in sequencer program during functional test.
   *   INT toggleTIAMode:            {0 | 1}
   *     Flag to specify whether switching TIA mode on (and off)
   *     before (and after) measurement.
   *     For consecutive TIA measurements it's possible to skip this switching
   *     by setting TIA mode in advance, resetting it after all measurements.
   *   INT dutyCycle
   *     Expected duty cycle of the measured signal. This (D) is defined as
   *       D = PW+/PER
   *     where PW+ is positive pulse width, PER is period
   *   INT ftstResult:               {0 | 1}
   *     Flag to specify whether taking functional test result into account
   *     for pass/fail judging and datalogging.
   *   
   *   The following parameters belong to group 2.
   *
   *   DOUBLE delayTime_ms           {ms}
   *     Value of time to delay start of measurement.
   *     This is only effective when startMethod == DIRECT, otherwise
   *     it's set to 0 by processParameters()
   *   INT measurements:             {}
   *     # of measurements. This value is applicable when startMethod is
   *     SEQ_PROG and should be identical to # of TIAS in sequencer program.
   *     When startMethod == DIRECT, it's set to 1 by processParameters()
   *
   *   The following parameters belong to group 3.
   *
   *   STRING_VECTOR pinVector:
   *     Contains all pins specified by pins as STRING_VECTOR
   *   TM::PPTIA_SLOPE slopeA:
   *     Event slope of event A. It's determined from the mode parameter
   *   TM::PPTIA_SLOPE slopeB:
   *     Event slope of event B. It's determined from the mode parameter
   *   Boolean isFrequency:
   *     Flag to indicate whether frequency or period is measured or not
   *     It's determined from the mode parameter
   *   DOUBLE cycleCompensation:
   *     A value used to compensate the measured value
   *     It's determined from the mode and dutyCycle parameter
   *
   * Note:
   *   When you create an instance of this class, appropriate default values
   *   except pins are set to each variables in the class.
   *
   *----------------------------------------------------------------------*
   */
  struct FrequencyParameter
  {
      // Parameters specified by a user
      STRING pins;
      STRING mode;
      DOUBLE threshold_mV;
      INT dutCycles;
      STRING startMethod;
      INT toggleTIAMode;
      DOUBLE dutyCycle;
      INT ftstResult;

      // Parameters specified by a user, possibly modified by processParameters
      DOUBLE delayTime_ms;
      INT measurements;

      // Parameters set by processParameters()
      STRING_VECTOR pinVector;
      TM::PPTIA_SLOPE slopeA;
      TM::PPTIA_SLOPE slopeB;
      Boolean isFrequency;
      DOUBLE cycleCompensation;

      // Default constructor
      // all parameters are set to default values
      FrequencyParameter()
      : pins(""),
        mode("FREQ+"),
        threshold_mV(0),
        dutCycles(1),
        startMethod("DIRECT"),
        toggleTIAMode(0),
        dutyCycle(0.5),
        ftstResult(1),
        delayTime_ms(0),
        measurements(1),
        slopeA(TM::FALL),
        slopeB(TM::RISE),
        isFrequency(TRUE),
        cycleCompensation(0.5) {}
  };
  
    
  /*
   *----------------------------------------------------------------------*
   * Struct: FrequencyResult
   *
   * Purpose: Container to store pptia measurement results
   *
   *----------------------------------------------------------------------*
   * Description:
   *   map<STRING, map<INT, PinResult> > valueResult;
   *     Contains all results per pin and per measurement. Please see
   *     the note below how to access each result.
   *   STRING_VECTOR pinVector
   *     Contains all pins for which value results are available.
   *   Boolean funcTestResult;
   *     Global pass/fail results of functional test
   *   
   * Note:
   *   To access each result, e.g. a mean value result for pin pinVector[j]
   *   from i-th measurement, valueResult[pinVector[j]][i].mean.
   *
   *----------------------------------------------------------------------*
   */
  struct FrequencyResult
  {
      struct PinResult {
          DOUBLE mean;

          // all values are initialized maximum value of DOUBLE
          PinResult() : mean(DBL_MAX) {}

          // function to return if the result is valid or not
          Boolean isValid() const { return mean != DBL_MAX; }
      };

      map<STRING, map<INT, PinResult> > valueResult;
      STRING_VECTOR pinVector;
      Boolean funcTestResult;

      // constructor
      FrequencyResult() : funcTestResult(false) {}
  };
  
  
/*
 *----------------------------------------------------------------------*
 * Utility functions for Frequency/Period measurements
 *----------------------------------------------------------------------*
 */

  /*
   *----------------------------------------------------------------------*
   * Routine: PptiaFrequencyUtil::processParameters
   *
   * Purpose: Store given measurement parameters to the specified
   *          placeholder and determine addtional parameters
   *          which is necessary to execute measurement.
   *          Also performs some error checks on parameters.
   *
   *----------------------------------------------------------------------*
   * Description:
   *   const STRING& pins:
   *   const STRING& mode:           {FREQ+ | FREQ- | PER+ | PER-}
   *   DOUBLE threshold_mV:
   *   INT dutCycles:
   *   const STRING& startMethod:    {DIRECT | SEQ_PROG}
   *   DOUBLE delayTime_ms:
   *   INT measurements:
   *   INT toggleTIAMode:            {0 | 1}
   *   DOUBLE dutyCycle
   *   INT ftstResult:               {0 | 1}
   *     Those are parameters for frequency/period measurement.
   *     See the descriptions in FrequencyParameter definition.
   *   FrequencyParameter& params:
   *     Container to hold parameters for the measurement.
   *   
   * Note:
   *
   *----------------------------------------------------------------------*
   */
  static void processParameters(
                                  const STRING& pins,
                                  const STRING& mode,
                                  DOUBLE threshold_mV,
                                  INT dutCycles,
                                  const STRING& startMethod,
                                  DOUBLE delayTime_ms,
                                  INT measurements,
                                  INT toggleTIAMode,
                                  DOUBLE dutyCycle,
                                  INT ftstResult,
                                  FrequencyParameter& params)
  {
      // If no pin for pins is specified, an exception is thrown.
      if (pins.size() == 0) {
          throw Error("PptiaFrequencyUtil::processParameters()",
                      "Empty pins parameter.");
      }
  
      // If dutCyles is smaller than 1, an exception is thrown.
      if (dutCycles < 1) {
          throw Error("PptiaFrequencyUtil::processParameters()",
                      "dutCycles should be greater than 0.");
      }        
  
      // If dutCyles is not between 0 than 1, an exception is thrown.
      if (!(0 < dutyCycle && dutyCycle < 1)) {
          throw Error("PptiaFrequencyUtil::processParameters()",
                      "dutyCycle should be between 0 and 1.");
      }        
  
      // Expand the given comma-separated pinlist in STRING to STRING_VECTOR
      params.pinVector =
          PinUtility.expandDigitalPinNamesFromPinList(pins,
                                             TM::ALL_DIGITAL,
                                             TM::EXCEPTION_ON_MISSING_PIN_NAMES);
  
      // Determine which event slope (TM::RISE or TM::FALL) should be used
      // based on the given measurement mode.
      // And also a compentation value is determined based on the given
      // duty cycle and mode
      //
      // 1. FREQ+ or PER+ measuerement
      //      __       __       __       __
      //     |  |     |  |     |  |     |  
      // ____|  |_____|  |_____|  |_____|  
      //     A  A     A        A        A  
      //     |  |<--->|<------>|<------>|
      // arming | PW-    PER+     PER+  |
      //        |<--------------------->|
      //        |         MEAS          |
      //      eventA                  eventB
      //
      // MEAS = dutCycles * PER+ + PW-
      //      = dutCycles * PER+ + (PER - PW+)
      //      = PER+ * (dutCycles + 1 - PW+/PER)
      //      = PER+ * (dutCycles + 1 - dutyCycle)
      //  i.e.,
      //  PER+ = MEAS / (dutCycles + cycleCompensation)
      //  where cycleCompensation = 1 - dutyCycle.
      //
      // 2. FREQ- or PER- measuerement
      // ____    _____    _____    _____ 
      //     |  |     |  |     |  |     |  
      //     |__|     |__|     |__|     |__
      //     A  A     A        A        A  
      //     |  |<--->|<------>|<------>|
      // arming | PW+    PER-     PER-  |
      //        |<--------------------->|
      //        |         MEAS          |
      //      eventA                  eventB
      //
      // MEAS = dutCycles * PER- + PW+
      //      = PER * (dutCycles + PW+/PER)
      //      = PER * (dutCycles + dutyCycle)
      //  i.e.,
      //  PER = MEAS / (dutCycles + cycleCompensation)
      //  where cycleCompensation = dutyCycle.
      if (mode == "FREQ+") {
          params.slopeA = TM::FALL; params.slopeB = TM::RISE;
          params.isFrequency = TRUE;
          params.cycleCompensation = 1 - dutyCycle;
      } else if (mode == "PER+") {
          params.slopeA = TM::FALL; params.slopeB = TM::RISE;
          params.isFrequency = FALSE;
          params.cycleCompensation = 1 - dutyCycle;
      } else if (mode == "FREQ-") {
          params.slopeA = TM::RISE; params.slopeB = TM::FALL;
          params.isFrequency = TRUE;
          params.cycleCompensation = dutyCycle;
      } else if (mode == "PER-") {
          params.slopeA = TM::RISE; params.slopeB = TM::FALL;
          params.isFrequency = FALSE;
          params.cycleCompensation = dutyCycle;
      } else {
          // If the specified mode is not supported in this function,
          // an exception is thrown.
          throw Error("PptiaFrequencyUtil::processParameters()",
                      "Illegal mode parameter.");
      }
  
      // Copy startMethod and determine # of measurements and delay time
      // If startMethod is "DIRECT", always measurements = 1 because
      // it's only possible to execute a single measurement and copy delayTime
      // In startMethod is "SEQ_PROG", always delayTime = 0 because it makes
      // no sense and copy measurements
      if (startMethod == "DIRECT") {
          params.delayTime_ms = delayTime_ms;
          params.measurements = 1;
      } else if (startMethod == "SEQ_PROG") {
          params.delayTime_ms = 0;
          params.measurements = measurements;
      } else {
          // If the specified startMethod is not supported in this function,
          // an exception is thrown.
          throw Error("PptiaFrequencyUtil::processParameters()",
                      "Illegal startMethod parameter.");
      }        
  
      // Copy other parameters
      params.pins = pins;
      params.mode = mode;
      params.threshold_mV = threshold_mV;
      params.dutCycles = dutCycles;
      params.startMethod = startMethod;
      params.toggleTIAMode = toggleTIAMode;
      params.dutyCycle = dutyCycle;
      params.ftstResult = ftstResult;
  }
  
  /*
   *----------------------------------------------------------------------*
   * Routine: PptiaFrequencyUtil::doMeasurement
   *
   * Purpose: Perform setup, execution and result retrieval
   *          for frequency/period measurement with per pin TIA
   *
   *----------------------------------------------------------------------*
   *
   * Description:
   *   const FrequencyParameter& params:
   *     Container to hold parameters for the measurement.
   *   PPTiaMeasurementResult& results:
   *     Container to store measurement results
   *     
   * Note:
   *
   *----------------------------------------------------------------------*
   */
  static void doMeasurement(const FrequencyParameter& params,
                            FrequencyResult& results)
  {
      // Measurement setup, execution and result retrieval are done
      // through task object
      PPTIA_TASK task;
  
      ON_FIRST_INVOCATION_BEGIN();
      
        /*
         * TIA measurement setup
         */
        // For eventA, event count is 0, and TM::EVENT is used
        // (i.e. no reference signal). Other parameters are given.
        task.pin(params.pins).eventA(params.slopeA, 0,
                                     params.threshold_mV mV, TM::EVENT);
        // For eventB, TM::EVENT is used (i.e. no reference signal).
        // Other parameters are given. eventBCount is equal to dutCycles
        task.pin(params.pins).eventB(params.slopeB, params.dutCycles,
                                     params.threshold_mV mV, TM::EVENT);
        // Arming method is always TM::EVENT_B
        task.pin(params.pins).armingMethod(TM::EVENT_B);
        // Only MEAN result is retrieved
        // If you'd like to get another type of results, add the type here
        task.pin(params.pins).resultType(TM::MEAN);
  
        // Setup non per-pin parameters 
        task.numberOfMeasurements(params.measurements);
        task.delay(params.delayTime_ms msec);
        task.execMode(params.startMethod);
        task.preAction(params.toggleTIAMode ? TM::SET_TIA_MODE : TM::TIA_NONE);
        task.functionalTestMode(params.ftstResult ? "GPF" : "NO_RESULT");
        // Enable a timeout flag so that the execution won't abort by timeout
        task.enableTimeoutFlag();
  
        /*
         * TIA measurement execution
         */
        task.execute();
  
      ON_FIRST_INVOCATION_END();
  
      /*
       * TIA measurement result retrieval
       */
      // Expand pinlist to get/store per-pin value results
      results.pinVector = params.pinVector;
      INT numberOfPins = results.pinVector.size();
  
      // Iterate all measurements
      for (INT i = 0; i < params.measurements; ++i) {
          // Iterate all pins in pinVector
          for (INT j = 0; j < numberOfPins; ++j) {
              const STRING& pinName = results.pinVector[j];
              FrequencyResult::PinResult& pinResult =
                  results.valueResult[pinName][i];

              // Check whether a timeout occurred on this pin
              // because there is no result available in case of a timeout
              if (task.getTimeoutFlag(pinName, i + 1)) {
                  // A timeout occured, so skip this pin
                  continue;
              }

              // Perform N-cycle averaging in case of frequency measurement.
              DOUBLE val = task.getValue(pinName, TM::MEAN, i + 1);
              val /= (params.dutCycles + params.cycleCompensation);
              if (params.isFrequency) {
                  val = (val != 0) ? (1 / val) : 0;
              }
  
              // Store the value result
              pinResult.mean = val;
          }
      }
  
      // Get the p/f result from functional test if specified.
      if (params.ftstResult) {
          results.funcTestResult = task.getFunctionalResult();
      }
  }
  
  /*
   *----------------------------------------------------------------------*
   * Routine: PptiaFrequencyUtil::judgeAndDatalog
   *
   * Purpose: Perform pass / fail judgement and datalogging
   *          for frequency/period measurement
   *
   *----------------------------------------------------------------------*
   * Description:
   *   const string& testname:
   *     limit name.
   *   PPTiaMeasurementResult& results:
   *     Container to store measurement results
   *   INT isFrequency:              {0 | 1}
   *     Flag to specify whether frequency or period test.
   *   INT ftstResult:               {0 | 1}
   *     Flag to specify whether taking functional test result into account
   *     for pass/fail judging and datalogging.
   *   
   * Note:
   *   judgeAndLog_ParametricTest() is called for results in the order of
   *   TM::MEAN, and then functional test results.
   *   Even if one of results is FAIL, test method is executed
   *   until all avaiable results are logged.
   *
   *----------------------------------------------------------------------*
   */
  static void judgeAndDatalog(const string& testname,
                              FrequencyResult& results,
                              INT isFrequency,
                              INT ftstResult)
  {
      static bool sIsLimitTableUsed = false;
      ON_FIRST_INVOCATION_BEGIN();
        //check whether limit table is used.
        TestTable* pLimitTable = TestTable::getDefaultInstance();
        pLimitTable->readCsvFile();
        sIsLimitTableUsed = pLimitTable->isTmLimitsCsvFile();
        if (sIsLimitTableUsed) {
          string testsuiteName;
          GET_TESTSUITE_NAME(testsuiteName);
          LIMIT limit;
          try{
              string key = testsuiteName + ":" + testname;
              V93kLimits::TMLimits::LimitInfo limitInfo = V93kLimits::tmLimits.getLimit(key);
              limit = limitInfo.TEST_API_LIMIT;
          }
          catch(Error& e){
              sIsLimitTableUsed = false;
              limit = GET_LIMIT_OBJECT(testname);
          }
        }
      ON_FIRST_INVOCATION_END();

      // Get the number of pins and if there is no pin contained in results,
      // just return
      INT numberOfPins = results.pinVector.size();
      if (numberOfPins < 1) {
          return;
      }
  
      // Get the number of measurements from size of valueResult[0].
      INT measurements = results.valueResult[results.pinVector[0]].size();
      if (measurements < 1) {
          return;
      }

      ARRAY_D resultArray(numberOfPins);
      if (sIsLimitTableUsed){
        // Iterate all available measurements
        for (INT i = 0; i < measurements; ++i) {
          // Iterate all pins in pinVector
          for (INT j = 0; j < numberOfPins; ++j) {
            const FrequencyResult::PinResult& pinResult =
                results.valueResult[results.pinVector[j]][i];

              if (pinResult.isValid()) {
                  resultArray[j] = pinResult.mean;
              } else {
                // No valid result is available
                resultArray[j] = NAN;
              }
          }
          // Judge and log the "meanValue" result
          TestSet.cont(TM::CONTINUE).
              judgeAndLog_ParametricTest(results.pinVector,
                                         testname,
                                         V93kLimits::tmLimits,
                                         resultArray);
        }
      }else{ 
        // Iterate all available measurements
        for (INT i = 0; i < measurements; ++i) {
          // Iterate all pins in pinVector
          for (INT j = 0; j < numberOfPins; ++j) {
            const FrequencyResult::PinResult& pinResult =
              results.valueResult[results.pinVector[j]][i];
  
            if (pinResult.isValid()) {
              resultArray[j] = pinResult.mean;
            } else {
                // No valid result is available
                resultArray[j] = NAN;
            }
          }
          // Judge and log the "meanValue" result
          TESTSET().cont(TM::CONTINUE).
            judgeAndLog_ParametricTest(results.pinVector,
                                       testname, resultArray);
        }
      }

      // Finally judge and log the functional test result if available
      if (ftstResult) {
          if (results.funcTestResult) {
              TESTSET().cont(TM::CONTINUE).
                  judgeAndLog_ParametricTest("", "", TM::Pass, 0);
          } else {
              TESTSET().cont(TM::CONTINUE).
                  judgeAndLog_ParametricTest("", "", TM::Fail, 0);
          }
      }
  }
  
  /*
   *----------------------------------------------------------------------*
   * Routine: PptiaFrequencyUtil::reportToUI
   *
   * Purpose: Output frequency/period measurement results to Report Window
   *
   *----------------------------------------------------------------------*
   * Description:
   *     const FrequencyResult& results:
   *     Container to store measurement results
   *   const STRING& output          {None | ReportUI}
   *     Flag to specify whether to output 
   *     "None" means no output and "ReportUI" means to do output
   *   INT isFrequency:              {0 | 1}
   *     Flag to specify whether frequency or period test.
   *   INT ftstResult:               {0 | 1}
   *     Flag to specify whether to output functional test result
   *
   * Note:
   *
   *----------------------------------------------------------------------*
   */
  static void reportToUI(FrequencyResult& results,
                         const STRING& output,
                         INT isFrequency,
                         INT ftstResult)
  {
      // If output parameter is different from "ReportUI", just retun
      if ( output != "ReportUI" ) {
          return;  
      }
  
      // Get the number of pins and if there is no pin contained in results,
      // just return
      INT numberOfPins = results.pinVector.size();
      if (numberOfPins < 1) {
          return;
      }
  
      // Get the number of measurements from size of valueResult[0].
      INT measurements = results.valueResult[results.pinVector[0]].size();
      if (measurements < 1) {
          return;
      }
  
      // Determine the unit to display results
      const char* unitString = isFrequency ? "MHz" : "nsec";
      const DOUBLE unitScale = isFrequency ? 1e6 : 1e-9;

      // Iterate all available measurements
      for (INT i = 0; i < measurements; ++i) {
          // Iterate all pins in pinVector
          for (INT j = 0; j < numberOfPins; ++j) {
          
              const FrequencyResult::PinResult& pinResult =
                  results.valueResult[results.pinVector[j]][i];
  
              // output the pin name and measurement index
              printf("Pin: [%s]   Measurement: [%d]\n",
                     results.pinVector[j].c_str(), i + 1);
              if (pinResult.isValid()) {
                  // output the "meanValue" result
                  printf("meanValue = %-10g   %s\n",
                         pinResult.mean / unitScale, unitString);
              } else {
                  // output the "meanValue" result with TIMEOUT
                  printf("meanValue = **********   %s\t*** TIMEOUT ***\n",
                         unitString);
              }
          }
      }
  
      // Finally output functional test result if available
      if (ftstResult) {
          printf("Functional Test:\n"
                 "%-16s\t%c\n", "@", results.funcTestResult ? 'P' : 'F');
      }
  
      fflush(stdout);
  }
};
#endif /*PPTIAFREQUENCY_H_*/
