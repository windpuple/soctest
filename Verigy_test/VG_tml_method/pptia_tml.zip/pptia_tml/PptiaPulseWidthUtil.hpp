#ifndef PPTIAPULSEWIDTH_H_
#define PPTIAPULSEWIDTH_H_

#include <float.h>
#include "CommonUtil.hpp"

class PptiaPulseWidthUtil
{
public:

  /*
   *----------------------------------------------------------------------*
   * Struct: PulseWidthParameter
   *
   * Purpose: Container to store pulse width measurement parameters
   *
   *----------------------------------------------------------------------*
   * Description:
   *   The members in this structure can be categorized into 3 groups
   *     1. specified by a user
   *     2. specified by a user, possibly modified by processParameters()
   *     3. set by processParameters()
   * 
   *   The following parameters belong to group 1.
   *
   *   STRING pins:                  {@ | pin and/or pin group list}
   *     Name of pin(s) and/or pin group(s) to be measured
   *     Valid pins: all digital pins.
   *   STRING mode:                  {PW+ | PW-}
   *     Measurement mode.
   *     PW+: pulse width (from rising edge to falling edge)
   *     PW-: pulse width (from falling edge to rising edge)
   *   DOUBLE threshold_mV:          {mV}
   *     Value of threshold voltage.
   *   INT sampleSize:               {}
   *     # of samples to be taken per measurement.
   *   DOUBLE randomizeRatio:        {}
   *     Value of sample randomization ratio. By specifying positve value
   *     (0 < randomizeRatio < 1), it's possible to move each sampling timing
   *     randomly. If 0 is specified, no randomization is performed.
   *   STRING startMethod:           {DIRECT | SEQ_PROG}
   *     How to start measurement.
   *     In case of DIRECT, measurement is performed immediately.
   *     In case of SEQ_PROG, measurement is performed at the point
   *     where TIAS is specified in sequencer program during functional test.
   *   INT toggleTIAMode:            {0 | 1}
   *     Flag to specify whether switching TIA mode on (and off)
   *     before (and after) measurement.
   *     For consecutive TIA measurements it's possible to skip this switching
   *     by setting TIA mode in advance, resetting it after all measurements.
   *   INT ftstResult:               {0 | 1}
   *     Flag to specify whether taking functional test result into account
   *     for pass/fail judging and datalogging.
   *
   *   The following parameters belong to group 2.
   *
   *   DOUBLE delayTime_ms:          {ms}
   *     Value of time to delay start of measurement.
   *     This is only effective when startMethod == DIRECT, otherwise
   *     it's set to 0 by processParameters()
   *   INT measurements:             {}
   *     # of measurements. This value is applicable when startMethod is
   *     SEQ_PROG and should be identical to # of TIAS in sequencer program.
   *     When startMethod == DIRECT, it's set to 1 by processParameters()
   *   
   *   The following parameters belong to group 3.
   *
   *   STRING_VECTOR pinVector:
   *     Contains all pins specified by pins as STRING_VECTOR
   *   TM::PPTIA_SLOPE slopeA:
   *     Event slope of event A. It's determined from the mode parameter
   *   TM::PPTIA_SLOPE slopeB:
   *     Event slope of event B. It's determined from the mode parameter
   *
   * Note:
   *   When you create an instance of this class, appropriate default values
   *   except pins are set to each variables in the class.
   *
   *----------------------------------------------------------------------*
   */
  struct PulseWidthParameter
  {
      // Parameters specified by a user
      STRING pins;
      STRING mode;
      DOUBLE threshold_mV;
      INT sampleSize;
      DOUBLE randomizeRatio;
      STRING startMethod;
      INT toggleTIAMode;
      INT ftstResult;

      // Parameters specified by a user, possibly modified by processParameters
      DOUBLE delayTime_ms;
      INT measurements;

      // Parameters set by processParameters()
      STRING_VECTOR pinVector;
      TM::PPTIA_SLOPE slopeA;
      TM::PPTIA_SLOPE slopeB;

      // Default constructor
      // all parameters are set to default values
      PulseWidthParameter()
      : pins(""),
        mode("PW+"),
        threshold_mV(0),
        sampleSize(1),
        randomizeRatio(0),
        startMethod("DIRECT"),
        toggleTIAMode(0),
        ftstResult(1),
        delayTime_ms(0),
        measurements(1),
        slopeA(TM::RISE),
        slopeB(TM::FALL) {}
  };
  
  /*
   *----------------------------------------------------------------------*
   * Struct: PPTiaMeasurementResult
   *
   * Purpose: Container to store pptia measurement results
   *
   *----------------------------------------------------------------------*
   * Description:
   *   map<STRING, map<INT, PinResult> > valueResult;
   *     Contains all results per pin and per measurement. Please see
   *     the note below how to access each result.
   *   STRING_VECTOR pinVector
   *     Contains all pins for which value results are available.
   *   Boolean funcTestResult;
   *     Global pass/fail results of functional test
   *   
   * Note:
   *   To access each result, e.g. a mean value result for pin pinVector[j]
   *   from i-th measurement, valueResult[pinVector[j]][i].mean.
   *
   *----------------------------------------------------------------------*
   */
  struct PulseWidthResult
  {
      struct PinResult {
          DOUBLE min;
          DOUBLE max;
          DOUBLE mean;

          // all values are initialized maximum value of DOUBLE
          PinResult() : min(DBL_MAX), max(DBL_MAX), mean(DBL_MAX) {}

          // function to return if the result is valid or not
          Boolean isValid() const {
              return min  != DBL_MAX ||
                     max  != DBL_MAX ||
                     mean != DBL_MAX;
          }
      };

      map<STRING, map<INT, PinResult> > valueResult;
      STRING_VECTOR pinVector;
      Boolean funcTestResult;

      // constructor
      PulseWidthResult() : funcTestResult(false) {}
  };
  
/*
 *----------------------------------------------------------------------*
 * Utility functions for Pulse Width measurements
 *----------------------------------------------------------------------*
 */

  /*
   *----------------------------------------------------------------------*
   * Routine: PptiaPulseWidthUtil::processParameters
   *
   * Purpose: Store given measurement parameters to the specified
   *          placeholder and determine addtional parameters
   *          which is necessary to execute measurement.
   *          Also performs some error checks on parameters.
   *
   *----------------------------------------------------------------------*
   * Description:
   *   const STRING& pins:
   *   const STRING& mode:           {PW+ | PW-}
   *   DOUBLE threshold_mV:
   *   INT sampleSize;
   *   DOUBLE randomizeRatio:
   *   const STRING& startMethod:    {DIRECT | SEQ_PROG}
   *   DOUBLE delayTime_ms:
   *   INT measurements:
   *   INT toggleTIAMode:            {0 | 1}
   *   INT ftstResult:               {0 | 1}
   *     Those are parameters for pulse width measurement.
   *     See the descriptions in PulseWidthParameter definition.
   *   PulseWidthParameter& params:
   *     Container to hold parameters for the measurement.
   *   
   * Note:
   *
   *----------------------------------------------------------------------*
   */
  static void processParameters(
                                  const STRING& pins,
                                  const STRING& mode,
                                  DOUBLE threshold_mV,
                                  INT sampleSize,
                                  DOUBLE randomizeRatio,
                                  const STRING& startMethod,
                                  DOUBLE delayTime_ms,
                                  INT measurements,
                                  INT toggleTIAMode,
                                  INT ftstResult,
                                  PulseWidthParameter& params)
  {
      // If no pin for pins is specified, an exception is thrown.
      if (pins.size() == 0) {
          throw Error("PptiaPulseWidthUtil::processParameters()",
                      "Empty pins parameter.");
      }
  
      // Expand the given comma-separated pinlist in STRING to STRING_VECTOR
      params.pinVector =
          PinUtility.expandDigitalPinNamesFromPinList(pins,
                                             TM::ALL_DIGITAL,
                                             TM::EXCEPTION_ON_MISSING_PIN_NAMES);
  
      // Determine which event slope (TM::RISE or TM::FALL) should be used
      // based on the given measurement mode.
      if (mode == "PW+") {
          params.slopeA = TM::RISE; params.slopeB = TM::FALL;
      } else if (mode == "PW-") {
          params.slopeA = TM::FALL; params.slopeB = TM::RISE;
      } else {
          // If the specified mode is not supported in this function,
          // an exception is thrown.
          throw Error("PptiaPulseWidthUtil::processParameters()",
                      "Illegal mode parameter.");
      }
  
      // Copy startMethod and determine # of measurements and delay time
      // If startMethod is "DIRECT", always measurements = 1 because
      // it's only possible to execute a single measurement and copy delayTime
      // In startMethod is "SEQ_PROG", always delayTime = 0 because it makes
      // no sense and copy measurements
      if (startMethod == "DIRECT") {
          params.delayTime_ms = delayTime_ms;
          params.measurements = 1;
      } else if (startMethod == "SEQ_PROG") {
          params.delayTime_ms = 0;
          params.measurements = measurements;
      } else {
          // If the specified startMethod is not supported in this function,
          // an exception is thrown.
          throw Error("PptiaPulseWidthUtil::processParameters()",
                      "Illegal startMethod parameter.");
      }        
  
      // Copy other parameters
      params.pins = pins;
      params.mode = mode;
      params.threshold_mV = threshold_mV;
      params.sampleSize = sampleSize;
      params.randomizeRatio = randomizeRatio;
      params.startMethod = startMethod;
      params.toggleTIAMode = toggleTIAMode;
      params.ftstResult = ftstResult;
  }
  
  /*
   *----------------------------------------------------------------------*
   * Routine: PptiaPulseWidthUtil::doMeasurement
   *
   * Purpose: Perform setup, execution and result retrieval
   *          for pulse width measurement with per pin TIA
   *
   *----------------------------------------------------------------------*
   *
   * Description:
   *   const PulseWidthParameter& params:
   *     Container to hold parameters for the measurement.
   *   PPTiaMeasurementResult& results:
   *     Container to store measurement results
   *     
   * Note:
   *   'static' variables are used in this function to keep some information
   *   which is refered in the execution for sites where ON_FIRST_INVOCATION 
   *   block is not executed.
   *
   *----------------------------------------------------------------------*
   */
  static void doMeasurement(
                                  const PulseWidthParameter& params,
                                  PulseWidthResult& results)
  {
      // Measurement setup, execution and result retrieval are done
      // through task object
      PPTIA_TASK task;
  
      ON_FIRST_INVOCATION_BEGIN();
      
        /*
         * TIA measurement setup
         */
        // For eventA and B, event count is 0, and TM::EVENT is used
        // (i.e. no reference signal). Other parameters are given.
        task.pin(params.pins).eventA(params.slopeA, 0,
                                     params.threshold_mV mV, TM::EVENT);
        task.pin(params.pins).eventB(params.slopeB, 0,
                                     params.threshold_mV mV, TM::EVENT);
        task.pin(params.pins).numberOfSamples(params.sampleSize);
        task.pin(params.pins).sampleRandomizeRatio(params.randomizeRatio);
        // Arming method is always TM::EVENT_B
        task.pin(params.pins).armingMethod(TM::EVENT_B);
        // MIN, MAX and MEAN results are retrieved
        // If you'd like to get another type of results, add the type here
        task.pin(params.pins).resultType(TM::MIN|TM::MAX|TM::MEAN);
  
        // Setup non per-pin parameters 
        task.numberOfMeasurements(params.measurements);
        task.delay(params.delayTime_ms msec);
        task.execMode(params.startMethod);
        task.preAction(params.toggleTIAMode ? TM::SET_TIA_MODE : TM::TIA_NONE);
        task.functionalTestMode(params.ftstResult ? "GPF" : "NO_RESULT");
        // Enable a timeout flag so that the execution won't abort by timeout
        task.enableTimeoutFlag();
  
        /*
         * TIA measurement execution
         */
        task.execute();
  
      ON_FIRST_INVOCATION_END();
  
      /*
       * TIA measurement result retrieval
       */
      // Expand pinlist to get/store per-pin value results
      results.pinVector = params.pinVector;
      INT numberOfPins = results.pinVector.size();
  
      // Iterate all measurements
      for (INT i = 0; i < params.measurements; ++i) {
          // Iterate all pins in pinVector
          for (INT j = 0; j < numberOfPins; ++j) {
              const STRING& pinName = results.pinVector[j];
              PulseWidthResult::PinResult& pinResult =
                  results.valueResult[pinName][i];

              // Check whether a timeout occurred on this pin
              // because there is no result available in case of a timeout
              if (task.getTimeoutFlag(pinName, i + 1)) {
                  // A timeout occured, so skip this pin
                  continue;
              }

              // Get and store the value results for specified result types
              // If you'd like to get another type of results,
              // add getValue() for the type
              pinResult.min = task.getValue(pinName, TM::MIN, i + 1);
              pinResult.max = task.getValue(pinName, TM::MAX, i + 1);
              pinResult.mean = task.getValue(pinName, TM::MEAN, i + 1);
          }
      }
  
      // Get the p/f result from functional test if specified.
      if (params.ftstResult) {
          results.funcTestResult = task.getFunctionalResult();
      }
  }
  
  /*
   *----------------------------------------------------------------------*
   * Routine: PptiaPulseWidthUtil::judgeAndDatalog
   *
   * Purpose: Perform pass / fail judgement and datalogging
   *          for pptia measurement
   *
   *----------------------------------------------------------------------*
   * Description:
   *   const string& testname:
   *     limit names.
   *   PulseWidthResult& results:
   *     Container to store measurement results
   *   INT ftstResult:               {0 | 1}
   *     Flag to specify whether taking functional test result into account
   *     for pass/fail judging and datalogging.
   *   
   * Note:
   *   judgeAndLog_ParametricTest() is called for results in the order of
   *   TM::MIN, TM::MAX, TM::MEAN, and finally functional test
   *   results. Even if one of results is FAIL, test method is executed
   *   until all avaiable results are logged.
   *
   *----------------------------------------------------------------------*
   */
  static void judgeAndDatalog(const string& testname,
                              PulseWidthResult& results,
                              INT ftstResult)
  {
      static bool sIsLimitTableUsed = false;
      static string minTestname;
      static string maxTestname;
      static string meanTestname;
      ON_FIRST_INVOCATION_BEGIN();
        string::size_type leadPos = testname.find("(");
        string::size_type postPos = testname.find(")");
        if (leadPos != string::npos && postPos != string::npos && leadPos < postPos) {
          string validName = testname.substr(leadPos+1,postPos-leadPos-1);
          vector<string> names;
          CommonUtil::splitStr(validName,',',names);
          if (names.size() != 3) {
            throw Error("PptiaPulseWidthUtil::judgeAndDatalog()",
                        "Invalid test name parameter.");
          }
          minTestname = names.at(0);
          maxTestname = names.at(1);
          meanTestname = names.at(2);
        } 
        
        //check whether limit table is used.
        string testsuiteName;
        GET_TESTSUITE_NAME(testsuiteName);
        TesttableLimitHelper ttlHelper(testsuiteName);

        LIMIT limitMin;
        LIMIT limitMax;
        LIMIT limitMean;
        if(ttlHelper.isLimitCsvFileLoad()) {
            ttlHelper.getLimit(minTestname,limitMin);
            ttlHelper.getLimit(maxTestname,limitMax);
            ttlHelper.getLimit(meanTestname,limitMean);
        }
        sIsLimitTableUsed = ttlHelper.isAllInTable();

        if(false == sIsLimitTableUsed)
        {
          limitMin = GET_LIMIT_OBJECT(minTestname);
          limitMax = GET_LIMIT_OBJECT(maxTestname);
          limitMean = GET_LIMIT_OBJECT(meanTestname);
        }
        
     ON_FIRST_INVOCATION_END(); 
     
      // Get the number of pins and if there is no pin contained in results,
      // just return
      INT numberOfPins = results.pinVector.size();
      if (numberOfPins < 1) {
          return;
      }
  
      // Get the number of measurements from size of valueResult[0].
      INT measurements = results.valueResult[results.pinVector[0]].size();
      if (measurements < 1) {
          return;
      }

      ARRAY_D resultArrayForMIN(numberOfPins);
      ARRAY_D resultArrayForMAX(numberOfPins);
      ARRAY_D resultArrayForMEAN(numberOfPins);
      if (sIsLimitTableUsed) {
        // Iterate all available measurements
        for (INT i = 0; i < measurements; ++i) {
          // Iterate all pins in pinVector
          for (INT j = 0; j < numberOfPins; ++j) {
          
            const PulseWidthResult::PinResult& pinResult =
                results.valueResult[results.pinVector[j]][i];
  
            if (pinResult.isValid()) {
              resultArrayForMIN[j] = pinResult.min;
              resultArrayForMAX[j] = pinResult.max;
              resultArrayForMEAN[j] = pinResult.mean;
            } else {
              // No valid result is available
              resultArrayForMIN[j] = NAN;
              resultArrayForMAX[j] = NAN;
              resultArrayForMEAN[j] = NAN;
            }
          }
          // Judge and log the "minimum" result
          TestSet.cont(TM::CONTINUE).
              judgeAndLog_ParametricTest(results.pinVector,
                                         minTestname,
                                         V93kLimits::tmLimits,
                                         resultArrayForMIN);
          // Judge and log the "maximum" result
          TestSet.cont(TM::CONTINUE).
              judgeAndLog_ParametricTest(results.pinVector,
                                         maxTestname,
                                         V93kLimits::tmLimits,
                                         resultArrayForMAX);
          // Judge and log the "meanValue" result
          TestSet.cont(TM::CONTINUE).
              judgeAndLog_ParametricTest(results.pinVector,
                                         meanTestname,
                                         V93kLimits::tmLimits,
                                         resultArrayForMEAN);
        }
      } else { 
        // Iterate all available measurements
        for (INT i = 0; i < measurements; ++i) {
          // Iterate all pins in pinVector
          for (INT j = 0; j < numberOfPins; ++j) {
          
              const PulseWidthResult::PinResult& pinResult =
                  results.valueResult[results.pinVector[j]][i];
  
              if (pinResult.isValid()) {
                  resultArrayForMIN[j] = pinResult.min;
                  resultArrayForMAX[j] = pinResult.max;
                  resultArrayForMEAN[j] = pinResult.mean;
              } else {
                  // No valid result is available
                  resultArrayForMIN[j] = NAN;
                  resultArrayForMAX[j] = NAN;
                  resultArrayForMEAN[j] = NAN;
            }
          }
          // Judge and log the "minValue" result
          TESTSET().cont(TM::CONTINUE).
              judgeAndLog_ParametricTest(results.pinVector,
                                         minTestname,
                                         resultArrayForMIN);
          // Judge and log the "maxValue" result
          TESTSET().cont(TM::CONTINUE).
              judgeAndLog_ParametricTest(results.pinVector,
                                         maxTestname,
                                         resultArrayForMAX);
          // Judge and log the "meanValue" result
          TESTSET().cont(TM::CONTINUE).
              judgeAndLog_ParametricTest(results.pinVector,
                                         meanTestname,
                                         resultArrayForMEAN);
        }
      }
  
      // Finally judge and log the functional test result if available
      if (ftstResult) {
          if (results.funcTestResult) {
              TESTSET().cont(TM::CONTINUE).
                  judgeAndLog_ParametricTest("", "", TM::Pass, 0);
          } else {
              TESTSET().cont(TM::CONTINUE).
                  judgeAndLog_ParametricTest("", "", TM::Fail, 0);
          }
      }
  }
  
  /*
   *----------------------------------------------------------------------*
   * Routine: PptiaPulseWidthUtil::reportToUI
   *
   * Purpose: Output pptia measurement results to Report Window
   *
   *----------------------------------------------------------------------*
   * Description:
   *   const PulseWidthResult& results:
   *     Container to store measurement results
   *   INT ftstResult:               {0 | 1}
   *     Flag to specify whether to output functional test result
   *   const STRING& output          {None | ReportUI}
   *     Flag to specify whether to output 
   *     "None" means no output and "ReportUI" means to do output
   *
   * Note:
   *
   *----------------------------------------------------------------------*
   */
  static void reportToUI(
                                 /* const*/ PulseWidthResult& results,
                                  const STRING& output,
                                  INT ftstResult)                  
  {
      // If output parameter is different from "ReportUI", just return
      if ( output != "ReportUI" ) {
          return;  
      }
  
      // Get the number of pins and if there is no pin contained in results,
      // just return
      INT numberOfPins = results.pinVector.size();
      if (numberOfPins < 1) {
          return;
      }
  
      // Get the number of measurements from size of valueResult[0].
      INT measurements = results.valueResult[results.pinVector[0]].size();
      if (measurements < 1) {
          return;
      }
  
      // Iterate all available measurements
      for (INT i = 0; i < measurements; ++i) {
          // Iterate all pins in pinVector
          for (INT j = 0; j < numberOfPins; ++j) {
          
              const PulseWidthResult::PinResult& pinResult =
                  results.valueResult[results.pinVector[j]][i];
  
              // output the pin name and measurement index
              printf("Pin: [%s]   Measurement: [%d]\n",
                     results.pinVector[j].c_str(), i + 1);
              if (pinResult.isValid()) {
                  // output the "minValue" result
                  printf(" minValue = %-10g   nsec\n", pinResult.min * 1e9);
                  // output the "maxValue" result
                  printf(" maxValue = %-10g   nsec\n", pinResult.max * 1e9);
                  // output the "meanValue" result
                  printf("meanValue = %-10g   nsec\n", pinResult.mean * 1e9);
              } else {
                  // output the "minValue" result with TIMEOUT
                  printf(" minValue = **********   nsec\t*** TIMEOUT ***\n");
                  // output the "maxValue" result with TIMEOUT
                  printf(" maxValue = **********   nsec\t*** TIMEOUT ***\n");
                  // output the "meanValue" result with TIMEOUT
                  printf("meanValue = **********   nsec\t*** TIMEOUT ***\n");
              }
          }
      }
  
      // Finally output functional test result if available
      if (ftstResult) {
          printf("Functional Test:\n"
                 "%-16s\t%c\n", "@", results.funcTestResult ? 'P' : 'F');
      }
  
      fflush(stdout);
  }

};
#endif /*PPTIAPULSEWIDTH_H_*/
