#include <iostream> 
#include "TestMethod.h"
#include "d2sFramework.h"
#include "PortChecker.h"
#include "PatternManager.h"


using namespace std;

d2sFramework::d2sFramework()
{
    currentExecutionMode = d2sExecutionModeType::FUNCTIONAL_TST;
    changeFrameworkMode(d2sFrameWorkModeType::DefaultMode);
}

d2sFramework::~d2sFramework()
{
}

string d2sFramework::getCurrentBurstName(){
    return  "d2s_" + currentIdentifier;
}

void d2sFramework::d2s_LABEL_BEGIN(std::string identifier, d2sFrameWorkModeType::Enum mode, d2sExecutionModeType::Enum execMode){
        
    //update registered TransactionPorts on block begin
    for(TransactionPortSetIter it = registeredTransactionPorts.begin(); it != registeredTransactionPorts.end(); it++){
        (*it)->setD2sBlockBegin();
    }
    currentIdentifier = identifier;
    currentExecutionMode = execMode;
    changeFrameworkMode(mode);
}

void d2sFramework::d2s_LABEL_END(){
    //inform TransactionPorts about preExec
    for(TransactionPortSetIter it = registeredTransactionPorts.begin(); it != registeredTransactionPorts.end(); it++){
        (*it)->preExec(getCurrentBurstName());
    }
    
    //execBurst
    if(currentFrameworkMode != d2sFrameWorkModeType::ProductionMode){
        //skip test in ProductionMode for Troughput
        if(!PatternManager::isPatternAvailable(getCurrentBurstName())){
            cerr << "Burst doesn't contain any port-labels. Cannot execute Burst for \"" << currentIdentifier << "\"" << endl;    
        }
        else setPrimariesAndExecuteStartLabel(getCurrentBurstName());
    }
    else setPrimariesAndExecuteStartLabel(getCurrentBurstName());
    
    //inform TransactionPorts about postExec
    for(TransactionPortSetIter it = registeredTransactionPorts.begin(); it != registeredTransactionPorts.end(); it++){
        (*it)->postExec(currentIdentifier);
    }
    
    //reset states
    currentIdentifier = "";  
    currentExecutionMode = d2sExecutionModeType::FUNCTIONAL_TST;
    changeFrameworkMode(d2sFrameWorkModeType::DefaultMode);
    
    //update registered TransactionPorts on block end
    for(TransactionPortSetIter it = registeredTransactionPorts.begin(); it != registeredTransactionPorts.end(); it++){
        (*it)->setD2sBlockEnd();
    }    
}

void d2sFramework::setPrimaries(){
    
}

void d2sFramework::changeFrameworkMode(d2sFrameWorkModeType::Enum newMode){
    currentFrameworkMode = newMode;
    
    //update registered TransactionPorts on mode change
    for(TransactionPortSetIter it = registeredTransactionPorts.begin(); it != registeredTransactionPorts.end(); it++){
        (*it)->setFrameworkMode(currentFrameworkMode);
    }
}

d2sFrameWorkModeType::Enum d2sFramework::getCurrentMode(){
    return currentFrameworkMode;
}

d2sExecutionModeType::Enum d2sFramework::getCurrentExecutionMode(){
    return currentExecutionMode;
}  

bool d2sFramework::registerTransactionPort(TransactionPort &portToAdd){
    PortChecker &portChecker = PortChecker::Instance();
    
    //add new Port
    string strPortToAdd = portToAdd.getPortName();
    pair<set<string>::iterator, bool>  ret = registeredPorts.insert(strPortToAdd);
    if(ret.second == false) {
    	cerr << "registerTransactionPort(): cannot register Port \"" << strPortToAdd << "\". Port with the same name already registered." << endl;
    	return false;
    }
    
    if(portChecker.arePortsIntersecting(registeredPorts)){
        cerr << "registerTransactionPort(): cannot register Port! Port has common pins with already registered ports and so they cannot be used together!" << endl;
        registeredPorts.erase(strPortToAdd);
        return false;
    }
    else{
        registeredTransactionPorts.insert(&portToAdd);
        return true;    
    }
}
   

void d2sFramework::setPrimariesAndExecuteStartLabel(std::string startLabel){
    //cerr << "setting start label: " << startLabel << endl;
    //cerr << "execMode = " << currentExecutionMode << endl;
    try{
		switch(currentExecutionMode){
      	 case d2sExecutionModeType::FUNCTIONAL_TST:
              setPrimaries();
              Primary.label(startLabel);
              FUNCTIONAL_TEST();
              break;
      	 case d2sExecutionModeType::EXECUTE_TST:
              setPrimaries();
              Primary.label(startLabel);
              EXECUTE_TEST();
              break;
      	 case d2sExecutionModeType::DIGITAL_CAPTURE_TST:
              setPrimaries();
              Primary.label(startLabel);
              DIGITAL_CAPTURE_TEST();
              break;
              /*            
      	 case d2sExecutionModeType::NONE:
              //don't execute anything. No need to set primaries either
              break;
              */
      	 default:
              cerr << "execMode not known. Please check your execMode!" << endl;
   	}
	 }
	 catch(...){
        string testSuiteName;
        GET_TESTSUITE_NAME(testSuiteName);
        cerr << "Setting and Executing label \"" << startLabel << "\" in test suite \"" << testSuiteName << "\" wasn't possible!" << endl;
        cerr << "Please check d2s-block: \"" << currentIdentifier << "\"" << endl; 	 
	 }
}
