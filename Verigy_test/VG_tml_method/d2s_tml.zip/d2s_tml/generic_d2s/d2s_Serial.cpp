#include "d2s_Serial.h"
#include "TestMethod.h"
#include "FW.h"
#include "assert.h"


d2s_Serial::d2s_Serial(string pName):DeviceRegisterTransactionPort(pName)
{  
    writeMapInitialized = false;
    readAndExpectValueMapInitialized = false;
}

d2s_Serial::~d2s_Serial()
{
}

int d2s_Serial::getAddressBits(){
    cerr << "Error in framework: getAddressBits() needs to be overridden!" << endl;
    bool notOverridden = false;
    assert(notOverridden);
    return 0;    
}
      
int d2s_Serial::getDataBits(){
    cerr << "Error in framework: getDataBits() needs to be overridden!" << endl;
    bool notOverridden = false;
    assert(notOverridden);    
    return 0;    
}

int d2s_Serial::getHighWaveformIndex(){
    cerr << "Error in framework: getHighWaveformIndex() needs to be overridden!" << endl;
    bool notOverridden = false;
    assert(notOverridden);    
    return -1;
}

int d2s_Serial::getLowWaveformIndex(){
    cerr << "Error in framework: getLowWaveformIndex() needs to be overridden!" << endl;
    bool notOverridden = false;
    assert(notOverridden);
    return -1;
}
       
int d2s_Serial::getHighStrobeWaveformIndex(){
    cerr << "Error in framework: getHighStrobeWaveformIndex() needs to be overridden!" << endl;
    bool notOverridden = false;
    assert(notOverridden);
    return -1;
}

int d2s_Serial::getLowStrobeWaveformIndex(){
    cerr << "Error in framework: getLowStrobeWaveformIndex() needs to be overridden!" << endl;
    bool notOverridden = false;
    assert(notOverridden);
    return -1;
}
    
int d2s_Serial::getMaskStrobeWaveformIndex(){
    cerr << "Error in framework: getMaskStrobeWaveformIndex() needs to be overridden!" << endl;
    bool notOverridden = false;
    assert(notOverridden);    
    return -1;
}        


    /*write parameters*/
std::string d2s_Serial::getWritePinName(){
    cerr << "Error in framework: getWritePinName() needs to be overridden!" << endl;
    bool notOverridden = false;
    assert(notOverridden);
    return "";
}
  
int d2s_Serial::getWriteAddressVectorNumberLSB(){
    cerr << "Error in framework: getWriteAddressVectorNumberLSB() needs to be overridden!" << endl;
    bool notOverridden = false;
    assert(notOverridden);
    return 0;
}
    
int d2s_Serial::getWriteAddressVectorNumberMSB(){
    cerr << "Error in framework: getWriteAddressVectorNumberMSB() needs to be overridden!" << endl;
    bool notOverridden = false;
    assert(notOverridden);
    return 0;
}
        
int d2s_Serial::getWriteDataVectorNumberLSB(){
    cerr << "Error in framework: getWriteDataVectorNumberLSB() needs to be overridden!" << endl;
    bool notOverridden = false;
    assert(notOverridden);
    return 0;
}
    

int d2s_Serial::getWriteDataVectorNumberMSB(){
    cerr << "Error in framework: getWriteDataVectorNumberMSB() needs to be overridden!" << endl;
    bool notOverridden = false;
    assert(notOverridden);
    return 0;
}

/*read parameters*/    
std::string d2s_Serial::getReadAddressPinName(){
    cerr << "Error in framework: getReadAddressPinName() needs to be overridden!" << endl;
    bool notOverridden = false;
    assert(notOverridden);
    return "";            
}
    
std::string d2s_Serial::getReadPinName(){
    cerr << "Error in framework: getReadPinName() needs to be overridden!" << endl;
    bool notOverridden = false;
    assert(notOverridden);
    return "";
}
    
 
int d2s_Serial::getReadAddressVectorNumberLSB(){
    cerr << "Error in framework: getReadAddressVectorNumberLSB() needs to be overridden!" << endl;
    bool notOverridden = false;
    assert(notOverridden);
    return 0;            
} 
           
int d2s_Serial::getReadAddressVectorNumberMSB(){
    cerr << "Error in framework: getReadAddressVectorNumberMSB() needs to be overridden!" << endl;
    bool notOverridden = false;
    assert(notOverridden);
    return 0;            
} 
       
int d2s_Serial::getReadDataCycleNumberLSB(){
    cerr << "Error in framework: getReadDataCycleNumberLSB() needs to be overridden!" << endl;
    bool notOverridden = false;
    assert(notOverridden);    
    return 0;            
}
          
int d2s_Serial::getReadDataCycleNumberMSB(){
    cerr << "Error in framework: getReadDataCycleNumberMSB() needs to be overridden!" << endl;
    bool notOverridden = false;
    assert(notOverridden);
    return 0;            
}  
    
int d2s_Serial::getReadDataVectorNumberLSB(){
    cerr << "Error in framework: getReadDataVectorNumberLSB() needs to be overridden!" << endl;
    bool notOverridden = false;
    assert(notOverridden);
    return 0;            
}
    
int d2s_Serial::getReadDataVectorNumberMSB(){
    cerr << "Error in framework: getReadDataVectorNumberMSB() needs to be overridden!" << endl;
    bool notOverridden = false;
    assert(notOverridden);
    return 0;            
}






int d2s_Serial::getPadding(){
    return 1;
}

void d2s_Serial::initWriteValueVectorMaps(){
    bool parametersValid = true;
    int addressVectors = abs(getWriteAddressVectorNumberMSB() - getWriteAddressVectorNumberLSB());
    if(addressVectors != ((getAddressBits()-1)*getPadding())){
        cerr << "Error: specified MSB and LSB vectors for address don't match amount of address bits specified!" << endl;
        parametersValid = false;  
    }
    int dataVectors = abs(getWriteDataVectorNumberMSB() - getWriteDataVectorNumberLSB());
    if(dataVectors != ((getDataBits()-1)*getPadding())){
        cerr << "Error: specified MSB and LSB vectors for data don't match amount of data bits specified!" << endl;
        parametersValid = false;
    }
    assert(parametersValid);
    
    //address
    unsigned long long mask = 1LL<<(getAddressBits()-1);
    int vector = getWriteAddressVectorNumberMSB();
    while(mask>0){
        writeAddressValueVectorMap[mask] = vector;
        if(getWriteAddressVectorNumberLSB() > getWriteAddressVectorNumberMSB()) vector += getPadding();
        else vector -= getPadding();
        mask = mask>>1;    
    }

    //data
    mask = 1LL<<(getDataBits()-1);
    vector = getWriteDataVectorNumberMSB();
    while(mask>0){
        writeDataValueVectorMap[mask] = vector;
        if(getWriteDataVectorNumberLSB() > getWriteDataVectorNumberMSB()) vector += getPadding();
        else vector -= getPadding();
        mask = mask>>1;    
    }
    
    writeMapInitialized = true;
}


void d2s_Serial::prepareDynamicWriteLabel(long long address, long long data, const std::string& patternName){
    if(!writeMapInitialized) initWriteValueVectorMaps();
    
    int HIGH_WFIndex = getHighWaveformIndex();
    int LOW_WFIndex = getLowWaveformIndex();  

    int totalBits = (getAddressBits()+getDataBits())*getPadding();
        
    VEC_LABEL_EDIT myLabel(patternName, getWritePinName());
    VECTOR_DATA *myVectorData = new VECTOR_DATA[totalBits]; 
    
    unsigned long long mask = 1LL; //0x01
    for(int i=0; i<getAddressBits(); i++){
        for(int padding=0; padding<getPadding(); padding++){
            myVectorData[i*getPadding()+padding].vectorNum = writeAddressValueVectorMap[mask]+padding;
            myVectorData[i*getPadding()+padding].phyWvfIndex = (address & mask)? HIGH_WFIndex:LOW_WFIndex; 
        }
        mask = mask<<1;
    }
    
    mask = 0x01;
    for(int i=0; i<getDataBits(); i++){
        for(int padding=0; padding<getPadding(); padding++){
            myVectorData[(i+getAddressBits())*getPadding()+padding].vectorNum = writeDataValueVectorMap[mask]+padding;
            myVectorData[(i+getAddressBits())*getPadding()+padding].phyWvfIndex = (data & mask)? HIGH_WFIndex:LOW_WFIndex;
        } 
        mask = mask<<1;
    }
    
    myLabel.downloadUserVectors(myVectorData, totalBits);
    delete[ ] myVectorData;
}


long long d2s_Serial::readFromErrorMap(int cycleOffset){
    int debug = 0;
    //ERMP? ERRM,9,16,,(do)
    int startCycle;
    if(getReadDataCycleNumberLSB() < getReadDataCycleNumberMSB()){
        startCycle = getReadDataCycleNumberLSB() + cycleOffset;
    }
    else{
        startCycle = getReadDataCycleNumberMSB() + cycleOffset;
    }
    int noOfCycles = getDataBits() * getPadding();
    fwout << "ERMP? ERRM," << startCycle << "," << noOfCycles << ",,(" << getReadPinName() << ")" << endl;
    long long readData = 0LL;
    unsigned long long maxBit = 1LL<<(getDataBits()-1);
    unsigned long long valueMask;
    if(getReadDataCycleNumberMSB() < getReadDataCycleNumberLSB()){
        if(debug)cerr << "from MSB to LSB: ";
        valueMask = 1LL<<(getDataBits()-1);
    }
    else{
        if(debug)cerr << "from LSB to MSB: ";
        valueMask = 1LL;        
    }
    
    int byteMask = 0x80;
    //adjust start byteMask since ERMP maps to the next mod8 boundary
    byteMask = byteMask>>(startCycle - fwresult[0].getIntParam(1));
    //cerr << "startByteMask = 0x" << hex << byteMask << endl;
    int counter = 0;
    for(unsigned int byte=0; byte<fwresult[0][5].size(); byte++){
        while(byteMask>0 && valueMask>0 && valueMask<=maxBit){
            if(counter % getPadding() == 0){
                //only on first cycle of padding
                if(fwresult[0][5][byte]&byteMask){
                    //bit set -->fail-->strobe for L --> so is HIGH
                    if(debug) cerr << "H";
                    readData = readData | valueMask; 
                }
                else{
                    //bit cleared --> cyle was pass --> strobe for L --> so is LOW
                    if(debug) cerr << "L"; 
                }
                
                if(getReadDataCycleNumberMSB() < getReadDataCycleNumberLSB()){
                    valueMask = valueMask>>1;
                }
                else{
                    valueMask = valueMask<<1; 
                }
            }
            counter++;    
            byteMask = byteMask>>1;
        }
        byteMask = 0x80;
    }
    if(debug) cerr << endl << "read value = 0x" << hex << readData << endl;

    return readData;   
}



void d2s_Serial::initReadAndExpectValueVectorMaps(){
    bool parametersValid = true;
    int addressVectors = abs(getReadAddressVectorNumberMSB() - getReadAddressVectorNumberLSB());
    if(addressVectors != ((getAddressBits()-1)*getPadding())){
        cerr << "Error: specified MSB and LSB vectors for address don't match amount of address bits specified!" << endl; 
        parametersValid = false;
    }
    int dataVectors = abs(getReadDataVectorNumberMSB() - getReadDataVectorNumberLSB());
    if(dataVectors != ((getDataBits()-1)*getPadding())){
        cerr << "Error: specified MSB and LSB vectors for data don't match amount of data bits specified!" << endl;  
        parametersValid = false;
    }
    assert(parametersValid);
    
    //address
    unsigned long long mask = 1LL<<(getAddressBits()-1);
    int vector = getReadAddressVectorNumberMSB();
    while(mask>0){
        readAndExpectAddressValueVectorMap[mask] = vector;
        if(getReadAddressVectorNumberLSB() > getReadAddressVectorNumberMSB()) vector += getPadding();
        else vector -= getPadding();
        mask = mask>>1;
    }

    //data
    mask = 1LL<<(getDataBits()-1);
    vector = getReadDataVectorNumberMSB();
    while(mask>0){
        readAndExpectDataValueVectorMap[mask] = vector;
        if(getReadDataVectorNumberLSB() > getReadDataVectorNumberMSB()) vector += getPadding();
        else vector -= getPadding();
        mask = mask>>1;    
    }
    
    readAndExpectValueMapInitialized = true;    
}


void d2s_Serial::prepareDynamicReadOrExpectValueLabel(long long address, const std::string& labelName,long long value, long long strobeMask){
    if(!readAndExpectValueMapInitialized) initReadAndExpectValueVectorMaps();
    
    int HIGH_WFIndex = getHighWaveformIndex();
    int LOW_WFIndex = getLowWaveformIndex(); 
    int highStrobeWfIndex = getHighStrobeWaveformIndex();
    int lowStrobeWfIndex = getLowStrobeWaveformIndex();
    int xStrobeWfIndex = getMaskStrobeWaveformIndex(); 

    int setPadding = getPadding();
    int totalAddressBits = getAddressBits()*setPadding;
    int totalDataBits = getDataBits()*setPadding;
    string readAddressPin = getReadAddressPinName();
    string readPinName = getReadPinName();
    
    VEC_LABEL_EDIT myLabelAddress(labelName, readAddressPin);
    VEC_LABEL_EDIT myLabelData(labelName, readPinName);
    VECTOR_DATA *myVectorAddress = new VECTOR_DATA[totalAddressBits]; 
    VECTOR_DATA *myVectorData = new VECTOR_DATA[totalDataBits]; 
    
    unsigned long long mask = 1LL; //0x01
    for(int i=0; i<getAddressBits(); i++){
        for(int padding=0; padding<setPadding; padding++){
            myVectorAddress[i*setPadding+padding].vectorNum = readAndExpectAddressValueVectorMap[mask]+padding;
            myVectorAddress[i*setPadding+padding].phyWvfIndex = (address & mask)? HIGH_WFIndex:LOW_WFIndex; 
        }
        mask = mask<<1;
    }
    
    mask = 0x01;
    for(int i=0; i<getDataBits(); i++){
        for(int padding=0; padding<getPadding(); padding++){
            myVectorData[i*setPadding+padding].vectorNum = readAndExpectDataValueVectorMap[mask]+padding;
            if(strobeMask & mask){
                //is a don't care bit
                myVectorData[i*setPadding+padding].phyWvfIndex = xStrobeWfIndex;
            }
            else{
                myVectorData[i*setPadding+padding].phyWvfIndex = (value & mask)? highStrobeWfIndex:lowStrobeWfIndex;
            }
        } 
        mask = mask<<1;
    }
    
    myLabelAddress.downloadUserVectors(myVectorAddress, totalAddressBits);
    myLabelData.downloadUserVectors(myVectorData, totalDataBits);
    delete[ ] myVectorAddress;
    delete[ ] myVectorData;
}

