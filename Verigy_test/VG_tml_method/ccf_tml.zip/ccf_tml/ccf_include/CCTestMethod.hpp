#ifndef CCTESTMETHOD_HPP_HEADER_INCLUDED_B42FF7F3
#define CCTESTMETHOD_HPP_HEADER_INCLUDED_B42FF7F3
/**
 * Copyright by Verigy Technologies, 2010
 *
 * @file    CCTestMethod.hpp
 *
 * @date    April 12, 2010
 */

#include "testmethod.hpp"
#include "mapi.hpp"
#include "internal/CCQ.hpp"
#include "internal/CCUtil.hpp"
#include "internal/CCExecutor.hpp"
#include "internal/CCVariables.hpp"

extern void SMC_CCT_TESTSUITE_PENDING(const STRING& testsuite);
extern void SMC_CCT_TESTSUITE_DONE(const STRING& testsuite);

#include <string>
#include <set>
#include <iostream>

namespace cct {

    /**
     * Mapping of MAPI and execution mode
     *  EXECUTE_TEST            EXM_EXECUTE_TEST
     *  FUNCTIONAL_TEST         EXM_FUNCTIONAL_TEST
     *  DIGITAL_CAPTURE_TEST    EXM_DIGITAL_CAPTURE_TEST    
     *  EXECUTE_GROUP           EXM_EXECUTE_GROUP
     *
     * EXM_NONE is used when no sequencer controlled test is required, 
     * for instance, static DC test. Framework will mainly execute the
     * preStart and postStart without triggering digital/analog sequencers.
     *
     * EXM_INVALID is the defalut execution mode which is not valid.
     *
     * EXM_EXECUTE_GROUP is for debugging purpose.
     * With this mode, postStart will be executed after EXECUTE_GROUP is done.
     *
     * Non-blocking API's execution mode are the same with corresponding
     * blocking ones. For instance, START_TEST's execution mode is same 
     * with EXECUTE_TEST, i.e., EXM_EXECUTE_TEST.
     *
     */
    typedef enum 
    {
        EXM_NONE                  = 0,
        EXM_EXECUTE_TEST          = (1<<0),
        EXM_FUNCTIONAL_TEST       = (1<<0), 
        EXM_DIGITAL_CAPTURE_TEST  = (1<<1|1<<0), 
        EXM_EXECUTE_GROUP         = (1<<2),   
        EXM_INVALID               = (1<<3)
    }EXEC_MODE;

    #define EXM_MAX  (1<<3)
    
    /**
     * SmartCalc support option
     * 
     * SMC_AUTO
     * 		Auto mode for hidden upload and calcualtion.
     * 		Framework will automatically request the hidden upload resources
     * 		and start the process() method in a seperate thread. User should put
     * 		hidden upload and calculation code in process method and ensure its
     * 		thread safety.
     * SMC_CONFIG_HIDDEN_UPLOAD
     * 		Mode for hidden upload and calculation configuration
     * 		Framework will request the hidden upload resources. Users need to
     * 		write his own upload and calculation code in SMC_backgroundProcessing()
     * 		method and start it manually in a seperate thread 
     * SMC_NONE
     * 	 	Mode for parallel/hidden calculation or none smart calc.
     *      Framework will do nothing specific for smart calc. User can write
     *      his own calculation code in SMC_backgroundProcessing() method and
     *      start it manually in a seperate thread, or handle result process
     *      without smart calc in regular way.
     */
    typedef enum
    {
    	SMC_AUTO				= 0,
    	SMC_CONFIG_HIDDEN_UPLOAD,
    	SMC_NONE
    }SMC_OPTION;

    // Level Setup struct
    typedef struct{
        int equationSet;
        int specSet;
        int levelSet;
    } LevelSet;

    // Timing Setup struct
    typedef struct{
        bool   isPortBased;
        string specName;
        map<string, int> portTimingSets; // <portName, timingSet> 
    } TimingSet;

    // Label setup struct
    typedef struct{
        bool   isPortBased;
        bool   isMpBurst;   // multiport burst
        string labelName;
    }Label;

    // Digital setup struct
    typedef struct{
        LevelSet  levelSet;
        TimingSet timingSet;
        Label     label;
    }DigitalSet;

    /**
     * Concurrent Framework (CCF) base class.
     * CCF testsuites except the CCF execution testsuite will inherit from this class
     */
    class CCTestMethod : public testmethod::TestMethod
    {
      protected:
        // predefined parameter are added here. don't inherit this class
        virtual void initialize()
        {
            addParameter(PARAM_AnalogRFSetName, "string", &mAnalogRFSetName);
            addParameters();
        }

        /**
         * Add testmethod parameters here
         * 
         * Example:
         * \code
         *   addParameter("param1", "double", &mVoltage)
         *   .setDefault("1.0")
         *   .setOptions("0.0:1.0");
         * \endcode
         * 
         * Note: Test Method API should not be used in this method.
         */
        virtual void addParameters() = 0;

        /**
         * Initialize/configure framework and user class members
         *
         * Example:
         * \code
         *   CCTsetResultArea("pin1,pin2", 1024);
         *   CCTsetExecMode(EXM_EXECUTE_TEST);
         *   CCTenableSMC(SMC_AUTO);
         *   CCTregisterDGT(digPin);
         * \endcode
         */
        virtual void init() = 0;

        /**
         * The setup method is a mandatory method for Analog tests. It contains
         * all Setup API code needed to create the Analog test.
         * 
         * For Digital and DC, as of now, this method is going to be empty.
         * @param setName Name of the analog set
         */
        virtual void createAnalogSetup(const string& setName) = 0;

        /**
         * The setup method is a mandatory method for RF tests. It contains all
         * Setup API code needed to create the RF test.
         * 
         * For Digital and DC, as of now, this method is going to be empty.
         * @param setName Name of the RF set/definition
         */
        virtual void createRFSetup(const string& setName) = 0;

        /**
         * The preStart() method of the testmethod classes is called for each
         * execution of the test suite. All necessary operations to happen
         * before the Execution of the test need to go here.
         */
        virtual void preStart() = 0;

        /**
         * The method is called after the execution (digital & analog sequencer) is
         * started. Tests that won't interfere other running sequencers can be 
         * called here.
         */
        virtual void postStart() = 0;

        /**
         * The process() method is called after the test execution, or rather
         * after the test execution start.
         * It spans all tasks for the result upload, calculation and data
         * logging / binning.
         * 
         * Normal sequence of actions.
         * - upload results
         * - do calculations / pass results to DSP routines
         * - test against the limits
         * - optional print out results
         * 
         * Best results are achieved by using the SmartCalc feature and API.
         *
         */
        virtual void process() = 0;

        /**
         * The cleanup() function finalizes the test and gets called after the
         * processing is done.
         * Common tasks for cleaning up after the test are
         * - Disable hardware triggers
         * - Disconnect instruments
         * - set Relays and DUT to a known good state / default state?         */
        virtual void cleanup() = 0;

        /**
         * Set the execution mode for CCT engine.
         * example: CCTsetExecMode(cct::EXECUTE_TEST);
         * 
         * @param execMode execution mode. Refer to EXEC_MODE definition. 
         * 
         * Mapping of MAPI and execution mode
         * \code 
         *   EXECUTE_TEST            EXM_EXECUTE_TEST
         *   FUNCTIONAL_TEST         EXM_FUNCTIONAL_TEST
         *   DIGITAL_CAPTURE_TEST    EXM_DIGITAL_CAPTURE_TEST    
         *   EXECUTE_GROUP           EXM_EXECUTE_GROUP 
         *        ---                EXM_NONE
         * \endcode
         */
        void CCTsetExecMode(EXEC_MODE execMode)
        {
            mExecMode = execMode;
        }

        /**
         * This method registers the analog digitizers so that data can be later
         * uploaded from these pins with correct upload id.
         *
         * Uploading data requires specifying a capture id, however the id may not
         * be hardcoded, because it is dependent on the order of tests in concurrent
         * execution. Instead, registering instructs the framework to maintain the
         * correct ids, and later on in the result upload routines the correct ids
         * can be queried from the framework.
         *
         * @param pinName pin name of the analog digitizer 
         * @return false means already registered; true means no register of the 
         * pin before
         */
        bool CCTregisterDGT(const string& pinName)
        {
            return mRegDgtPins.insert(pinName).second;
        }
 
        /**
         * This method registers the RF Tx so that data can be later uploaded
         * from these pins with current upload id.
         * Refer to CCTregisterDGT() for more descriptions.
         *
         * @param pinName pin name of the RF Tx
         * @return false means already registered; true means no register of the 
         * pin before
         */
        bool CCTregisterTx(const string& pinName)
        {
            return mRegTxPins.insert(pinName).second;
        }

        /**
         * This method config the SmartCalc support option
         * 
         * The framework has a simple wrapper for the SmartCalc, which will automatically
         * prepare and start the upload and calculation in a seperate thread. For complicated
         * cases, the framework allows users to handle the upload and/or calculation manually
         * in the original way of SmartCalc.
         * 
         * @param option SmartCalc support option in framework
         * 
         */
        void CCTenableSMC(SMC_OPTION option)
        {
        	mSmcOption = option;
        }

        /**
         * To configure the hidden digital capture upload, the user has to call this
         * method to create the required area for background upload 
         *
         * This method performs similar function as RESULT_AREA_CONFIG() which is
         * compatible with the framework.
         * 
         * @param pinList pin name list separated with comma (,). e.g. "pin1, pin2"
         * @param size size of the result area
         * 
         */
        void CCTsetResultArea(const string& pinList, const int size)
        {
            mResultAreaConf[pinList] = size;
        }


        /**
         * This method set the time to wait before start
         *
         * Some prestart actions require a short wait before the DUT gets into
         * expected status and ready for test. This method specifies how much
         * waiting time is needed before start.
         *
         * @param timInSec waiting time in second.
         */
        void CCTsetWaitTimeBeforeStart(const double timeInSec)
        {
            mWaitTimeBeforeStart = timeInSec; 
        }


        /**
         * This method gets the testsuite name where test code resides in.
         * 
         * In concurrent mode, API GET_TESTSUITE_ANME() will always return the
         * name of last CCF execution testsuite.
         */
        string CCTgetTestsuiteName()
        {
            return mTestsuiteName;
        }


        /**
         * This method returns the correct upload id of the registered DGT/RF Tx pin
         *
         * @param pinName pin name of the DGT/RF Tx
         * @return upload id 
         */
        int CCTgetUploadId(const string& pinName)
        {
            if(mUploadId.find(pinName) != mUploadId.end())
                return mUploadId[pinName];
            else
                return -1;
        }

        /**
         * This method returns the correct upload id of the registered RF pin
         *
         * @param pinName pin name of the RF
         * @return funcBlkId id
         */
        int CCTgetFuncBlkId()
        {
           return mFuncBlkId;
        }

        /**
         * Retrieve the result area name for hidden upload of digital capture
         * 
         * @return the global area id configured in framework.
         */
        string CCTgetResultArea()
        {
            return mAreaId;
        }

        /**
         * Retrieve the result handle name for hidden upload of analog waveform
         * 
         * @return the global result handle configured in framework.
         */
        string CCTgetResultHandle()
        {
            return mResultHandle;
        }


        /**
         * Get the actual analog and RF set name for current testsuite
         *
         * Analog set name might vary in concurrent mode or serial mode
         * This method returns the actual analog set/RF definition name
         * 
         * @return actual analog set/RF defintion name 
         */
        string CCTgetAnalogRFSetName()
        { 
            return mFinalAnalogRFSetName;
        }

        /**
         * Get the flag for time-out sites in execution.
         *
         * The flag maps to sites in binary format.
         * for instance, flag returns 13.
         * 13 = 1101(Bin), meaning sites 1, 3 and 4 are timed out in execution.
         *
         * @return flag for time-out sites
         *
         * Refer to API WAIT_TEST_DONE() in param timeout_site for more information.
         */
        int CCTgetTimeoutSite()
        {
            return mTimeoutSite;
        }

        /**
         * Get the flag for mistriggered sites in execution.
         *
         * The flag maps to sites in binary format.
         * for instance, flag returns 13.
         * 13 = 1101(Bin), meaning sites 1, 3 and 4 are mistriggered in execution.
         * @return flag for mistriggered sites
         *
         * Refer to API WAIT_TEST_DONE() in param mistriggered_site for more inforamtion.
         */
        int CCTgetMistriggeredSite()
        {
            return mMistriggeredSite;
        }

        /**
         * Get the current execution mode
         *
         * @return the execution mode
         */
        EXEC_MODE CCTgetExecMode()
        {
            return mExecMode;
        }        
        

        /**
         *@Description:
         *  it is just a wrapper of SMC_TEST and TESTSET.
         *  Inside of the API CCT_TEST When SMC is enabled,
         *  SMC_TEST is called to do the judge and datalog;
         *  when SMC is not enabled, TESTSET is called to do the judge and datalog.
         *
         */
         void CCT_TEST(
            string& pinlist,
            string& testName,
            V93kLimits::TMLimits& tmLimits,
            double value,
            bool isSMCEnabled,
            bool isContinue = true,
            TM::RELIABILITY reliability = TM::RELIABLE
            )

         {
            STRING_VECTOR splitPinlist;


            splitPinlist.clear();

            util::splitStr(pinlist,',',splitPinlist);

            STRING_VECTOR::const_iterator it = splitPinlist.begin();
            STRING_VECTOR::const_iterator it_end = splitPinlist.end();
            string testsuiteName = CCTgetTestsuiteName();

            if(isSMCEnabled){
                  for (;it != it_end; ++it)
                  {
s                     SMC_TEST(*it, testName, tmLimits, value, isContinue, reliability);
                  }
            }
            else{

                  for (;it != it_end; ++it)
                  {
                     V93kLimits::TMLimits::LimitInfo LimitInfo;

                     try{
                           LimitInfo = tmLimits.getLimit(testsuiteName, testName);
                     } catch (exception){
                           cout << "Cannont find parameter name " << testsuiteName << ":" <<
                              testName  << " So that the result will not be datalogged" << endl;

                           return;
                     }

                     LIMIT    limit = LimitInfo.TEST_API_LIMIT;
                     int testnumber = LimitInfo.TestNumber;
                     string softBinNum  = LimitInfo.BinsNumString;
                     int hardBinNum   = LimitInfo.BinhNum;
                     
                     bool pass = TESTSET().testsuite(testsuiteName).cont(isContinue).reliability(reliability)
                             .testnumber(testnumber)
                             .judgeAndLog_ParametricTest(*it, testName, limit, value);
                     
                     if( (false == mHasFirstFailed) && (false == pass) && (softBinNum.size() > 0) ){
						 
						 mHasFirstFailed = true;

                         SET_MULTIBIN(softBinNum, hardBinNum);
                     }
                  }
            }
         }



        /**
         * Constructor of CCTestMethod
         */
        CCTestMethod()
        :mExecMode(EXM_INVALID)
        ,mIsFirstExecution(true)
        ,mAnalogRFSetName("")
        ,mFinalAnalogRFSetName("")
        ,mCategory("")
        ,mConcurrent(false)
        ,mDevelopMode(1)
        ,mVerboseLevel(1)
        //,mTimingMergerNeeded(false)
        ,mSmcOption(SMC_NONE)
        ,mTestsuiteName("")
        ,mAreaId("")
        ,mResultHandle("")
        ,mWaitTimeBeforeStart(0)
        ,mTimeoutSite(0)
        ,mMistriggeredSite(0)
        ,mFuncBlkId(0)
        ,mExecutor(NULL)
		,mHasFirstFailed(false)
        {
            mExecutor = new CCExecutor();
        }

        virtual ~CCTestMethod()
        {
            if(mExecutor != NULL)
            {
                delete mExecutor;
                mExecutor = NULL;
            }
            // reference 'this' becomes invalid
            CCQ::getInstance()->pollute();
        }

        /**
         * The run() method adds its test to a set of tests for Concurrency,
         * but it does not start the test itself.
         * 
         * This method is NOT expected to be overwrote by end users.
         */
        virtual void run()
        {
            // push into queue and delay the execution in CCF engine.
            try 
            {
               ON_FIRST_INVOCATION_BEGIN();
                // only init and process queue on the first execution
                // queue info will be cached in executor
                if(mIsFirstExecution)
                {
                    initVariables();
                    if(CCQ::getInstance()->isMarked())
                        CCQ::getInstance()->clear();
                    CCQ::getInstance()->add(this);
                    mIsFirstExecution = false;
                }
               ON_FIRST_INVOCATION_END();

                if(!mConcurrent)
                {   
                    const bool enableChecker = (mDevelopMode != 0);
                    const bool enableTimingBuilder = false;//(mDevelopMode != 0) && mTimingMergerNeeded;
                    const bool enableLabelBuilder = (mDevelopMode != 0);
                    const bool enableAnalogBuilder = (mDevelopMode != 0);
                    mExecutor->init(mTimingSpecName,mBurstName, mAnalogRFSetName);
                    mExecutor->setup(enableChecker,enableTimingBuilder,enableLabelBuilder,enableAnalogBuilder);

                    mExecutor->preStart();
                    mExecutor->start();
                    mExecutor->postStart();
                    mExecutor->waitTestDone();

                    mExecutor->process(); 
                    mExecutor->cleanup(); 
                } else {
                    ON_LAST_INVOCATION_BEGIN();
                        SMC_CCT_TESTSUITE_PENDING(mTestsuiteName);
                    ON_LAST_INVOCATION_END();
                }
            }
            catch(CCError& e)
            {
                e.print();
                onError();
            }
            catch(ErrorInfo& e)
            {
                e.print();
                onError();
            }
            catch(...)
            {
                bool toUpper = true;
                onError(toUpper);
            }
        }

      public:
        // This method is dedicated for SMART_CALC, which starts it as a thread by SMC_ARM.
        virtual void SMC_backgroundProcessing()
        {
            process();
        }

      private:
        /**
         * Set default value for digital primary set structs
         */
        void initDigitalPrimary()
        {
            LevelSet& levSet = mDigitalPrimary.levelSet;
            levSet.equationSet = -1;
            levSet.specSet     = -1;
            levSet.levelSet    = -1;

            TimingSet& timSet = mDigitalPrimary.timingSet;
            timSet.isPortBased = false;
            timSet.portTimingSets.clear();

            Label& label = mDigitalPrimary.label;
            label.labelName.clear();
            label.isPortBased = false;
            label.isMpBurst = false;
        }

        /**
         * This method sets current digital primary set which can be latter "get"ed.
         * @param throwException this flag decides whether to throw exception on error.
         *                       true throw exception on error
         *                       false just prompt message on error 
         */
        void saveDigitalPrimary(bool throwException)
        {
          try{
            LevelSet& levSet = mDigitalPrimary.levelSet;               
            levSet.equationSet = Primary.getLevelSpec().getEquation();
            levSet.specSet     = Primary.getLevelSpec().getSpec();
            levSet.levelSet    = Primary.getLevel();

            TimingSet& timSet = mDigitalPrimary.timingSet;
            vector<string> ports;
            timSet.isPortBased = Primary.isTimingPortBased(&ports);
            if(timSet.isPortBased)
            {
                timSet.specName = Primary.getSpecification().getName();
                for(unsigned int p=0; p<ports.size(); p++)
                {
                    const string port = ports.at(p); 
                    (timSet.portTimingSets)[port] = Primary.getTiming(port);
                }
            }

            Label& label = mDigitalPrimary.label;
            label.labelName   = Primary.getLabel();
            label.isPortBased = Primary.isLabelPortBased();
            label.isMpBurst = true; 

            mBurstName = label.labelName;
          } // try
          catch(...)
          {
              // ignore the exceptions thrown in getting the primary
          }


          if(!mDigitalPrimary.timingSet.isPortBased && mConcurrent)
          {
              string message = "Timing is not port-based in testsuite "+ mTestsuiteName +".";
              if(throwException)
                  throw CCError(message);
              else
                  CCF_ERROR(message);

          }
          if((!mDigitalPrimary.label.isPortBased && mConcurrent) || (!mDigitalPrimary.label.isMpBurst))
          {
              string message = 
                  "Primary label \'"+mDigitalPrimary.label.labelName+"\' in testsuite \'"+ 
                  mTestsuiteName +"\' is not multi-port burst.";
              if(throwException)
                  throw CCError(message);
              else
                  CCF_ERROR(message);
          }

        }

        /**
         * this method set value for variables
         */
        void initVariables()
        {
            init();
            GET_TESTSUITE_NAME( mTestsuiteName );
            mFinalAnalogRFSetName = mAnalogRFSetName;

            mConcurrent = util::isConcurrentMode();
            mDevelopMode = util::getDevelopMode();
            mVerboseLevel = util::getVerboseLevel();
            //mTimingMergerNeeded = util::isTimingMergerNeeded();
            CCF_CONFIG_VERBOSE_LEVEL(mVerboseLevel);

            initDigitalPrimary();
            if(mExecMode != EXM_NONE)
                saveDigitalPrimary(false);
        }

      private:
        friend class CCQ;
        friend class CCExecutor;
        friend class LabelBuilder;
        friend class AnalogBuilder;
        friend class TimingBuilder;

        string getAnalogRFSetName() 
        {
            return mAnalogRFSetName;
        }

        set<string> getRegDGTPins()
        {
            return mRegDgtPins;
        }

        set<string> getRegTxPins()
        {
            return mRegTxPins;
        }

        void setFinalAnalogSetName(const string& setName) 
        { 
            mFinalAnalogRFSetName = setName;
        }

        bool setUploadId(const string& pinName, const int Id)
        {
            if(pinName.empty()) return false;
            mUploadId[pinName] = Id;
            return true;
        }

        bool setFuncBlkId(const int Id)
        {
            mFuncBlkId = Id;
            return true;
        }

        bool setResultAreaId(const string& areaId)
        {
            if(areaId.empty()) return false;
            mAreaId = areaId;
            return true;
        }

        bool setResultHandle(const string& resultHandle)
        {
            if(resultHandle.empty()) return false;
            mResultHandle= resultHandle;
            return true;
        }

        void setTimeoutSite(const int timeoutSite) 
        {
            mTimeoutSite = timeoutSite;
        }

        void setMistriggeredSite(const int mistriggeredSite)
        {
            mMistriggeredSite = mistriggeredSite;
        }

        DigitalSet & getDigitalPrimary()
        {
            return mDigitalPrimary;
        }

        void CCT_SMC_ARM()
        {
            SMC_ARM_OTHER_TS(mTestsuiteName.c_str());
        }

        void CCT_PROCESSING_DONE()
        {
            ON_LAST_INVOCATION_BEGIN();
                SMC_CCT_TESTSUITE_DONE(mTestsuiteName);
            ON_LAST_INVOCATION_END();
        }

        // return the pinlist vs size
        map<string, int> getResultAreaConfig()
        {
            return mResultAreaConf;
        }

        double getWaitTimeBeforeStart()
        {
            return mWaitTimeBeforeStart;
        }
        
        SMC_OPTION getSmcOption()
        {
        	return mSmcOption;
        }


        // error handler
        void onError(bool throwToUpper = false)
        {
            CCQ::getInstance()->mark(); // delay the clear
            if(mDevelopMode == 1)
            {
                // engineer mode 
                if(TM::isLast())
                    mExecutor->cleanup();
                if(throwToUpper)
                    throw;
                else
                    ERROR_EXIT(TM::RETURN_TO_FLOW); 
            }
            else
            {
                // prod mode etc
                if(TM::isLast())
                    mExecutor->cleanup();
                if(throwToUpper)
                    throw;
                else
                    ERROR_EXIT(TM::RETURN_TO_FLOW); 
            }
        }

      private:  
        EXEC_MODE  mExecMode;
        bool    mIsFirstExecution;
        string  mTimingSpecName;
        string  mBurstName;
        string  mAnalogRFSetName;
        string  mFinalAnalogRFSetName;
        string  mCategory;
        bool    mConcurrent;
        int     mDevelopMode;
        int     mVerboseLevel;
        //bool    mTimingMergerNeeded;
        SMC_OPTION mSmcOption;
        string  mTestsuiteName;
        string  mAreaId;
        string  mResultHandle;
        double  mWaitTimeBeforeStart;
        int     mTimeoutSite;
        int     mMistriggeredSite;
        int     mFuncBlkId;
        map<string, int> mUploadId;
        set<string> mRegDgtPins;
        set<string> mRegTxPins;
        map<string, int> mResultAreaConf;
        DigitalSet  mDigitalPrimary;
        CCExecutor* mExecutor;
		bool    mHasFirstFailed;
    };
} // namespace cct

#endif /* CCTESTMETHOD_HPP_HEADER_INCLUDED_B42FF7F3 */

