#ifndef __CCVARIABLES_HPP__
#define __CCVARIABLES_HPP__
/**
 * Copyright by Verigy Technologies, 2010
 *
 * @file    CCVariables.hpp
 *
 * @date    Oct 21, 2010
 */

#include <string>

namespace cct {
    using namespace std;

    // Version info. Format:  MAJOR_RELEASE.ENHANCE_RELEASE, FIX_BUG_RELEASE
    const string MAJOR_RELEASE = "2";
    const string ENHANCE_RELEASE = "1";
    const string FIX_BUG_RELEASE = "0";


    /// Test method parameter names

    /**
     * Analog baseband and RF set name
     * This variable sets the specified name of baseband and RF set for a concurrent group
     * It is available as testmethod parameter in property view of CCF testsuites and CCF execution testsuites.
     * If its value is empty in CCF testsuite, framework will skip calling to createAnalogSetup/createRFSetup method.
     * If its value is empty in CCF execution testsuite, default name is used as value of VAL_CCTAnaSetName.
     */
    const string PARAM_AnalogRFSetName = "CCF_AnalogRFSetName"; 

    /**
     * Digital timing spec name
     * This variable sets the specified name of timing spec for a concurrent group
     * It is available as testmethod parameter in property view of CCF execution testsuites.
     * If its value is empty, default name is set as value of VAL_CCTSpecName.
     */
    const string PARAM_TimingSpecName       = "CCF_TimingSpecSetName";
    /**
     * Digital burst name
     * This variable sets the specified name of burst for a concurrent group 
     * It is available as testmethod parameter in property view of CCF execution testsuites.
     * If its value is empty, default name is set as value of VAL_CCTBurstName.
     */
    const string PARAM_LabelName       = "CCF_LabelName"; 


    /// Testflow user flags as CCF control variables

    /**
     * User flag to control the concurrent mode
     * Value: 0 - serial mode; 1 - concurrent mode. Default: 0
     */
    const string VAR_ConcurrentMode   = "CCF_Concurrent"; 

    /**
     * User flag to control the develop mode
     * In development mode, more utilities will be open for debugging and development
     * In non-development/production mode, unnecessary utilities like checkers will be skipped
     * to achieve a better throughput.
     * Value: 0 - production mode; 1 - development mode. Default: 1
     */
    const string VAR_DevelopMode      = "CCF_DevelopMode";  

    /**
     * User flag to control the information level output by framework
     * Value: 0 - INFO disabled, WARN/ERROR enabled; 1 - INFO/WARN/ERROR enabled. Default: 1
     */
    const string VAR_VerboseLevel     = "CCF_VerboseLevel";  // flag to control the output info. 0 disables CCF_INFO.

    /**
     * User flag to control weather the timing merger is needed
     * Value: 0 - timing merger is not needed;
     *        1 - timing merger is needed.
     * Default: 0
     */
    //const string VAR_IsTimingMergerNeeded   = "CCF_TimingMerger";

    /**
     * User flag to control weather the label merger is needed
     * Value: 0 - label merger is not needed;
     *        1 - label merger is needed.
     * Default: 0
     */
    //const string VAR_IsLabelMergerNeeded   = "CCF_LabelMerger";

    // Name template
    const string TPL_CCTResultAreaID  = "CCF_ResultAreadId_XXXXXX"; // hidden upload result area ID 
    const string TPL_CCTResultHandle  = "CCF_ResultHandle_XXXXXX";  // hidden upload result handle


}
#endif // __CCVARIABLES_HPP__

