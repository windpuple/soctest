#ifndef CCUTIL_HPP_HEADER_INCLUDED_
#define CCUTIL_HPP_HEADER_INCLUDED_
/**
 * Copyright by Verigy Technologies, 2010
 *
 * @file    CCUtil.hpp
 *
 * @date    June 22, 2010
 */

#include <string>
#include <iostream>
#include <sstream>
#include <vector>

namespace cct {
using namespace std;

    /**
     * This class holds the error message for exception handling
     */
    class CCError
    {
      public:
        /**
         *  This method prints out the error message
         *  @param os ostream that the message outputs to. output to std::cerr by default. 
         */
        void print(std::ostream & os = std::cerr) const;
        
        /**
         * Constructor
         * @param origin where the error comes from
         * @param msg error message
         */
        CCError(const string& origin, const string& msg) :mOrigin(origin),mMessage(msg){};
        
        /**
         * Destructor
         */
        virtual ~CCError(){};

      private:
        string mOrigin;
        string mMessage;
    };

    #define  CCError(msg)  CCError(string(__FILE__)+": "+string(__FUNCTION__), msg)


    /**
     * This class provides information control for CCF
     */
    class CCInfo
    {
      public:
        /**
         * Set the verbose level
         *
         * Level  | Output
         * 0        warning, error
         * 1        text, information, warning, error
         *
         */
        static void verboseLevel(const int level);

        /**
         * Output information message to stdout
         * 
         * The output format is "INFO: [CCF] $msg"
         */
        static void info(const string& msg);

        /**
         * Output warning message to stderr
         * 
         * The output format is "WARNING: [CCF] $msg"
         */
        static void warn(const string& msg);

        /**
         * Output error message to stderr
         * 
         * The output format is "ERROR: [CCF] $msg"
         */
        static void error(const string& msg);

        /**
         * Output plain text directly to stdout
         * 
         * The output format is "$msg"
         */
        static void text(const string& msg);  // original text without prefix

        /**
         * Log the timer into EDL
         */
        static void startTimer(const string& id, const string& msg = "");
        static void stopTimer(const string& id, const string& msg = "");
      private:
        static void message(std::ostream& os, 
                            const string& type, 
                            const string& msg, 
                            const int verboseLev, 
                            const bool prefix = true);
      private:
        static int mVerboseLevel;
    };


    // Marcos for easy output of the message

    ///\def CCF_CONFIG_VERBOSE_LEVEL(level)
    /// Configurate the CCF verbose level
    #define CCF_CONFIG_VERBOSE_LEVEL(level) CCInfo::verboseLevel(level)

    ///\def CCF_INFO(msg)
    /// Output the msg as INFO to std::cout
    #define CCF_INFO(msg)  CCInfo::info(msg)

    ///\def CCF_WARN(msg)
    /// Output the msg as WARN to std::cerr
    #define CCF_WARN(msg)  CCInfo::warn(msg)

    ///\def CCF_ERROR(msg)
    /// Output the msg as ERROR to std::cerr
    #define CCF_ERROR(msg) CCInfo::error(msg)


    ///\def CCF_TEXT(msg)
    /// Output the msg as original text to std::cerr
    #define CCF_TEXT(msg) CCInfo::text(msg)


    #define CCF_START_TIMER(id) CCInfo::startTimer(id)
    #define CCF_STOP_TIMER(id)  CCInfo::stopTimer(id)

namespace util {
    // namespace cct::util;

    /**
     * Make a unique temporary name based on the nameTemplate
     * the last six characters of nameTemplate must be XXXXXX.
     * Refer to mkstemp.
     *
     * @param nameTemplate file name template ends with XXXXXX.
     * @return unique file name based on the template.
     */
    string makeTempName(const string& nameTemplate);
    
    /**
     * Check if the concurrent mode is on from user flag
     */
    bool isConcurrentMode();

    /**
     * Get the develop mode from user flag
     */
    int getDevelopMode();

    /**
     * Get the verbose level from user flag
     */
    int  getVerboseLevel();

    /**
     * Check if the timing merger is needed from user flag
     */
    //bool isTimingMergerNeeded();

    /**
     * Check if the label merger is needed from user flag
     */
    //bool isLabelMergerNeeded();

    /**
     * split a string into an vector by seperation CHAR sepCh
     */
    int splitStr (const string& origStr,
                  const char      sepCh,
                  vector<string>&  stringVector,
                  const bool bSupportBracket = true);

}// namespace util

} // namespace cct



#endif /* CCUTIL_HPP_HEADER_INCLUDED_ */

