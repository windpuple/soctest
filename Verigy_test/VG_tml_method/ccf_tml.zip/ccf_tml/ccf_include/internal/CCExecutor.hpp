#ifndef CCEXECUTOR_HPP_HEADER_INCLUDED_B42FA8E7
#define CCEXECUTOR_HPP_HEADER_INCLUDED_B42FA8E7
/**
 * Copyright by Verigy Technologies, 2010
 *
 * @file    CCExecutor.hpp
 *
 * @date    April 12, 2010
 */
#include <string>
#include <vector>
#include <set>
#include "CCUtil.hpp"

namespace cct {

    using namespace std;
    class CCTestMethod;

    using std::string;
    using std::vector;
    using std::set;


    /**
     * Class to build the setup, execute test, handle the post process and cleanup
     * 
     * Thread safety: unsafe. 
     */
    class CCExecutor
    {
      public:
        /**
         * Call this method to initialize the executor
         * @param specName  final spec name after merge
         * @param burstName final burst name after merge
         * @param analogSetName final analog set name after merge
         */ 
        void init(const string& specName = "",
                  const string& burstName = "",
                  const string & analogSetName = "");

        /**
         * Analog and RF tests get created through setup API. The framework
         * uses the information contained in the createSetup() methods of the
         * individual tests.
         * If more than one Analog or RF test is in the queue, a merging
         * algorithm transforms the individual tests into one new Analog Set.
         * 
         * @param check perform the condition check or not before building the setup.
         * @param enableTimingBuilder perform timing building
         * @param enableLabelBuilder perform burst building
         * @param enableAnalogBuilder perform analog building
         */
        void setup(const bool check = false, 
                   const bool enableTimingBuilder = true,
                   const bool enableLabelBuilder = true, 
                   const bool enableAnalogBuilder = true);

        /**
         * Perform actions that before the digital and analog sequencer start.
         * Framework activates the primaries, e.g. the Analog Primary.
         * After that it does a simple looping over all items in the queue and
         * calls each preStart() method. 
         */
        void preStart();

        /**
         * This method triggers the start of the execution on the execution
         * mode.
         * 
         * Each test preciously defines an execution mode.  e.g., 
         * execMode = EXM_EXECUTE_TEST, or
         * execMode = EXM_DIGITAL_CAPTURE_TEST
         *
         */
        void start();

        /**
         * Perform actions that after the digital and analog sequencer start.
         * Simply loop over all the item in the queue and calls postStart() method
         */
        void postStart();

        /**
         * Wait the test execution done.
         * Digital sequencer, Digitizer's completion will be waited.
         */
        void waitTestDone();

        /**
         * In essence here the process() methods of all queue items are
         * called. 
         * Using SmartCalc functionality, the uploading, calculation and data
         * logging is done while other tests might still be running, and in
         * parallel.
         * At the end, the Fail Bin of the first failing test in the queue
         * determines the Bin to be used.
         * All failures are logged though.
         */
        void process();

        /**
         * Simple looping over all cleanup() methods.
         */
        void cleanup();


        /**
         * Get the time-out site in latest execution
         */
        int getTimeoutSite() 
        {
            return mTimeoutSite;
        }

        /**
         * Get the mistriggered site in latest execution
         */
        int getMistriggeredSite() 
        {
            return mMistriggeredSite;
        }

        //Constructor
        CCExecutor();

        // Destructor
        virtual ~CCExecutor();

      private:
        friend class CCTestMethod;
        friend class CCExecution;

        void   setTestsuiteName();
        string getTestsuiteName(){return mTestsuiteName;};
        int  sumExecMode();
        void checkExecMode() throw (CCError);
        void initRegPins();
        void initSmcOption();
        void configResultArea();
        void releaseResultArea();
        void requestResultHandle();
        void releaseResultHandle();
        void saveTimingLevelSets(const bool throwException = false);
        void restoreTimingLevelSets();
        void setTimingPrimary();

      private:
        vector<CCTestMethod* > mQList;
        vector<CCTestMethod* > mAutoAsyncList;
        vector<CCTestMethod* > mManualAsyncList;
        vector<CCTestMethod* > mSyncList;
        bool        mIsInited;
        int         mQLen;
        int         mGlobalExecMode;
        double      mWaitTimeBeforeStart;
        bool        mSmcHiddenUpload;
        string      mTestsuiteName;
        string      mResultAreaId;
        string      mResultHandle;
        set<string> mRegPins;
        bool        mIsFirstTfExec; // first testflow execution in loop or testprogram execution
        bool        mSMCconfiged; 
        bool        mTimingSpecAvailable;
        bool        mBurstAvailable;
        bool        mAnalogSetAvailable;
        // primary 
        string      mTimSpecificationName;
        typedef map<string, int>    MPtimingSet;
        MPtimingSet mMutiportTimingSet;
        // primary level
        int         mLevelSet;
        int         mLevelEquation;
        int         mLevelSpec;
        // primary timing
        string      mTimingSpecName;
        string      mTimingSet;
        // primary label
        string      mBurstName;
        // primary analog set
        string      mAnalogSetName;

        // execution info
        int         mTimeoutSite;
        int         mMistriggeredSite;

        RESULT_AREA_CONFIG* mpResultAreaConfig;
       
    };


} // namespace cct



#endif /* CCEXECUTOR_HPP_HEADER_INCLUDED_B42FA8E7 */

