#ifndef CCQ_HPP_HEADER_INCLUDED_B42FA60A
#define CCQ_HPP_HEADER_INCLUDED_B42FA60A
/**
 * Copyright by Verigy Technologies, 2010
 *
 * @file    CCQ.hpp
 *
 * @date    April 12, 2010
 */

#include <vector>

namespace cct {

using std::vector;
class CCTestMethod;

    /**
     * Queue the reference to CCTestMethod objects in Concurrent Framework group.
     * 
     * Thread safety: unsafe
     */
    class CCQ
    {
      public:
        /**
         * Add the testmethod object reference into queue
         */
        void add(CCTestMethod *testmethod);
        
        /**
         * The queue holds some invalid references to testmethod object. A clear is required.
         */
        bool isDirty();
        
        /**
         * The queue is marked as an indication like being executed already.
         */
        bool isMarked();

        /**
         * clear the testmethod object references in queue
         */
        void clear();

        /**
         * Return the queue list
         * If containing any invalid reference, the queue will be cleared and returns empty.
         *
         * @return queue list
         */
        vector<cct::CCTestMethod *>& getTestList();
        
        /**
         * Get the instance of the CCQ. If the instance is existed, return it directly; 
         * otherwise create a new one.
         * 
         * @return the pointer to CCQ object
         */
        static CCQ* getInstance();
        
        /**
         * release the instance of the CCQ;
         */
        static void releaseInstance();

      private:
        friend class CCTestMethod;
        friend class CCExecution;
        friend class CCExecutor;
        /**
         * mark the queue
         */
        void mark();
      
        /**
         * wipe the mark 
         */
        void wipe(); 

        /**
         * Set the pollute flag to indicate some invalid references are hold in queue.
         */
        void pollute(); 

        /**
         * Reset the pollute flag as clean 
         */
        void clean();
      
      private:
        CCQ();
        virtual ~CCQ();
        vector<cct::CCTestMethod* > mQueue;
        bool mMarked;
        bool mDirty;
        
        static CCQ* mpInstance;
    };
    

    // helper to destroy the CCQ on exit/restart
    class DestroyHelper
    {
      public:
        DestroyHelper(){};
        ~DestroyHelper() {
            CCQ::releaseInstance();
        }
    };
} // namespace cct



#endif /* CCQ_HPP_HEADER_INCLUDED_B42FA60A */

