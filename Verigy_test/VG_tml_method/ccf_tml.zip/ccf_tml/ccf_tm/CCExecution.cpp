/**
 * Copyright by Verigy Technologies, 2010
 *
 * @file    CCExecution.cpp
 *
 * @date    April 12, 2010
 *
 * Modification History:
 *
 */

#include <iostream>
#include "CCExecution.hpp"
#include "../ccf_include/internal/CCExecutor.hpp"
#include "../ccf_include/internal/CCQ.hpp"
#include "../ccf_include/internal/CCUtil.hpp"
#include "../ccf_include/internal/CCVariables.hpp"

namespace cct {
    /**
     * Add the testmethod parameters
     * Burst name and analog set name are supposed to be specified for
     * the name of final merged burst and analog set. They must be given
     * if multiple concurrent test groups exist in one testflow.
     */
    void CCExecution::initialize()
    {
        addParameter(PARAM_TimingSpecName, "string", &mTimingSpecName);
        addParameter(PARAM_LabelName, "string", &mBurstName);
        addParameter(PARAM_AnalogRFSetName, "string", &mAnalogSetName);
    }

    /**
     * This method merges the setup, executes the test concurrently and 
     * handles the results for cached tests in queue.
     */
    void CCExecution::run()
    {
        try
        {
            ON_FIRST_INVOCATION_BEGIN();
            initVariables();
            ON_FIRST_INVOCATION_END();
            if(mConcurrent)
            {
                const bool enableChecker = (mDevelopMode != 0);
                const bool enableTimingBuilder = (mDevelopMode != 0 && mDevelopMode != (-1)); //&& mIsTimingMergerNeeded;
                const bool enableLabelBuilder = (mDevelopMode != 0 && mDevelopMode != (-1)); //&& mIsLabelMergerNeeded;
		const bool enableAnalogBuilder = (mDevelopMode != 0);

                mExecutor->init(mTimingSpecName,mBurstName, mAnalogSetName);
                // setup building. Skip the setup checker in production.
                mExecutor->setup(enableChecker,
                        enableTimingBuilder,
                        enableLabelBuilder,
                        enableAnalogBuilder);

                mExecutor->preStart();
                mExecutor->start();
                mExecutor->postStart();
                mExecutor->waitTestDone();

                mExecutor->process();
                mExecutor->cleanup();
            }
        }
        catch(CCError& e)
        {
            e.print();
            onError();
        }
        catch(ErrorInfo& e)
        {
            e.print();
            onError();
        }
        catch(...)
        {
            bool toUpper = true;
            onError(toUpper);
        }
    }

    /**
     * Initilize the class data members
     */
    void CCExecution::initVariables()
    {
        if(mIsInited) return;

        // get value from the testflow user flags
        mConcurrent = util::isConcurrentMode();
        mDevelopMode = util::getDevelopMode();
        mVerboseLevel = util::getVerboseLevel();
        //mIsTimingMergerNeeded = util::isTimingMergerNeeded();
        //mIsLabelMergerNeeded = util::isLabelMergerNeeded();

        CCF_CONFIG_VERBOSE_LEVEL(mVerboseLevel);
        mIsInited = true;
    }


    /**
     * Error handler for exceptions
     */
    void CCExecution::onError(bool throwToUpper)
    {
        // mark the queue for clear later
        CCQ::getInstance()->mark(); 
        if(mDevelopMode == 1)
        {
            // error handling in engineer mode
            if(TM::isLast())
                mExecutor->cleanup(); 
            if(throwToUpper) {
                throw;
            }
            else {
                ERROR_EXIT(TM::RETURN_TO_FLOW); 
            }
        }
        else
        {
            // error handling in prod mode etc
            if(TM::isLast())
                mExecutor->cleanup(); 
            if(throwToUpper) {
                throw;
            }
            else {
                ERROR_EXIT(TM::RETURN_TO_FLOW); 
            }
        }
    }


    CCExecution::CCExecution()
        :mExecutor(NULL)
        ,mBurstName("")
        ,mAnalogSetName("")
        ,mConcurrent(false)
        ,mDevelopMode(1)
        ,mVerboseLevel(0)
        ,mIsInited(false)
    {
        mExecutor = new CCExecutor();
    }


    CCExecution::~CCExecution()
    {
        delete mExecutor;
        mExecutor = NULL;
    }

    REGISTER_TESTMETHOD("CCExecution", CCExecution);
} // namespace cct
