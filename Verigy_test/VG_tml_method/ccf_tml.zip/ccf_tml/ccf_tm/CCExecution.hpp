#ifndef CCEXECUTION_HPP_HEADER_INCLUDED_B42FFA26
#define CCEXECUTION_HPP_HEADER_INCLUDED_B42FFA26
/**
 * Copyright by Verigy Technologies, 2010
 *
 * @file    CCExecution.hpp
 *
 * @date    April 12, 2010 
 */

#include <string>
#include "testmethod.hpp"
#include "mapi.hpp"

namespace cct {

using std::string;

class CCExecutor;

    /**
     * This class is used as an pre-implemented testmethod in last test
     * suite of the concurrent test block.
     *
     * The last Test Suite of a Concurrent Test Block does not define a test
     * by itself, but is the vehicle to tell the Framework that the block is
     * finished and waiting to execute. 
     * 
     */
    class CCExecution : public testmethod::TestMethod
    {
      public:
        virtual void initialize();
        virtual void run();
        CCExecution();
        virtual ~CCExecution();

      private:
          void initVariables();
          void onError(bool throwToUpper = false);
      private:
        CCExecutor* mExecutor;
        string mTimingSpecName;
        string mBurstName;
        string mAnalogSetName;
        bool mConcurrent;
        int  mDevelopMode;
        int  mVerboseLevel;
        //bool mIsTimingMergerNeeded;
        //bool mIsLabelMergerNeeded;
        bool mIsInited;
    };
    
} // namespace cct

#endif /* CCEXECUTION_HPP_HEADER_INCLUDED_B42FFA26 */
