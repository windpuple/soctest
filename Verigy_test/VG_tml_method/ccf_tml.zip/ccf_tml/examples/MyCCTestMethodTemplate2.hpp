#ifndef MyCCTestMethodTemplate2_HPP_
#define MyCCTestMethodTemplate2_HPP_

/**
 * Copyright by Verigy Technologies, 2010
 *
 * @file  MyCCTestMethodTemplate2.hpp  
 *
 * @brief  Test method class for Concurrent Test Framework.
 *
 *         Similiar to regualr test method class, for each testsuite
 *         using this test method, one object of the class is created.
 *
 * @author  __Author__
 * @date    __Date__
 */

#include "CCTestMethod.hpp"

using namespace cct;

    class MyCCTestMethodTemplate2 : public cct::CCTestMethod
    {
    protected:
    //  Add class data member
    protected:
        /**
         * Add testmethod parameters here
         * 
         *  addParameter("myParam", "double", &myParam)
         *  .setDefault("1.0")
         *  .setOptions("0.0:1.0");
         *
         * Note: Test Method API should not be used in this method.
         */
        virtual void addParameters();

        /**
         * Initialize/configure framework and user class members
         *
         * Example:
         * \code
         *   CCTsetResultArea("pin1,pin2", 1024);
         *   CCTsetExecMode(EXM_EXECUTE_TEST);
         *   CCTenableSMC(SMC_AUTO);
         *   CCTregisterDGT(digPin);
         * \endcode
         */
        virtual void init();

        /**
         * The setup method is a mandatory method for Analog tests. It contains
         * all Setup API code needed to create the Analog test.
         * 
         * For Digital and DC, as of now, this method is going to be empty.
         * @param setName Name of the analog set
         */
        virtual void createAnalogSetup(const string& analogSetName);

        /**
         * The setup method is a mandatory method for RF tests. It contains all
         * Setup API code needed to create the RF test.
         * 
         * For Digital and DC, as of now, this method is going to be empty.
         * @param setName Name of the RF set/definition
         */
        virtual void createRFSetup(const string& RFSetName);

        /**
         * The preStart() method of the testmethod classes is called for each
         * execution of the test suite. All necessary operations to happen
         * before the execution of the test need to go here.
         *
         * NOTE: ON_FIRST_INVOCATION block should be used in this method to run it
         * only the first time for all sites in multi-site test.
         */
        virtual void preStart();

        /**
         * The method is called after the execution (digital & analog sequencer) is
         * started. Tests that won't interfere other running sequencers can be 
         * called here.
         *
         * NOTE: ON_FIRST_INVOCATION block should be used in this method to run it
         * only the first time for all sites in multi-site test.
         */
        virtual void postStart();

        /**
         * The process() method is called after the test execution, or rather
         * after the test execution start.
         * It spans all tasks for the result upload, calculation and data
         * logging / binning.
         * 
         * Normal sequence of actions.
         * - upload results
         * - do calculations / pass results to DSP routines
         * - test against the limits
         * - optional print out results
         * 
         * Best results are achieved by using the SmartCalc feature and API.
         */
        virtual void process();

        /**
         * The cleanup() function finalizes the test and gets called after the
         * processing is done.
         * Common tasks for cleaning up after the test are
         * - Disable hardware triggers
         * - Disconnect instruments
         * - set Relays and DUT to a known good state / default state
         *
         * NOTE: ON_LAST_INVOCATION block should be used in this method to run it
         * only in last site in multi-site test.
         */
        virtual void cleanup();

        /**
        * This function will be invoked once the specified parameter's value is changed.
        * @param parameterIdentifier
        *
        * Note: Test Method API should not be used in this method.
        */
        virtual void postParameterChange(const std::string& parameterIdentifier);

    };

#endif // MyCCTestMethodTemplate2_HPP_
