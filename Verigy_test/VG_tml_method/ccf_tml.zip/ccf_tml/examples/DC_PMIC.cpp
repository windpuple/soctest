/**
 * Copyright by Verigy Technologies, 2010
 *
 * @file    DC_PMIC.cpp.template
 *
 * @date    Aug 26, 2010
 */

#include "CCTestMethod.hpp"
#include "TMLimits.h"

using namespace cct;
using V93kLimits::tmLimits;
#define TOTAL_SITE  2

    class DC_PMIC : public cct::CCTestMethod
    {
    protected:
        // pins
        STRING ISINK0_CH;
        STRING ISINK1_CH;
        STRING ISINK2_CH;
        STRING ISINK3_CH;
        STRING ISINK4_CH;
        // results
        double ISINK0[TOTAL_SITE][2];
        double ISINK1[TOTAL_SITE][2];
        double ISINK2[TOTAL_SITE][2];
        double ISINK3[TOTAL_SITE][2];
        double ISINK4[TOTAL_SITE][2];
    protected:
        /**
         * Add testmethod parameters here
         * 
         *  addParameter("myParam", "double", &myParam)
         *  .setDefault("1.0")
         *  .setOptions("0.0:1.0");
         *
         * Note: Test Method API should not be used in this method.
         */
        virtual void addParameters()
        {
            // no testmethod parameter
        }

        /**
         * Initialize/configure framework and user class members
         */
        virtual void init()
        {
            CCTsetExecMode(EXM_NONE);

            ISINK0_CH ="CSDPS_22904";
            ISINK1_CH ="CSDPS_42916";
            ISINK2_CH ="CSDPS_42908";
            ISINK3_CH ="CSDPS_22903";
            ISINK4_CH ="CSDPS_22907";
        }

        /**
         * The setup method is a mandatory method for Analog tests. It contains
         * all Setup API code needed to create the Analog test.
         * 
         * For Digital and DC, as of now, this method is going to be empty.
         * @param setName Name of the analog set
         */
        virtual void createAnalogSetup(const string& analogSetName)
        {
            //Add your code
        }

        /**
         * The setup method is a mandatory method for RF tests. It contains all
         * Setup API code needed to create the RF test.
         * 
         * For Digital and DC, as of now, this method is going to be empty.
         * @param setName Name of the RF set/definition
         */
        virtual void createRFSetup(const string& RFSetName)
        {
            //Add your code
        }

        /**
         * The preStart() method of the testmethod classes is called for each
         * execution of the test suite. All necessary operations to happen
         * before the execution of the test need to go here.
         */
        virtual void preStart()
        {
            //Add your code
        }

        /**
         * The method is called after the execution (digital & analog sequencer) is
         * started. Tests that won't interfere other running sequencers can be 
         * called here.
         */
        virtual void postStart()
        {
          SPMU_TASK   SPMU_VFIM_ALL_task;

          ON_FIRST_INVOCATION_BEGIN();

          float dly = 20e-3;
          SPMU_VFIM_ALL_task.pin(ISINK0_CH).settling(dly).relay("NT").clamp(0.05).max(0.05).min(-0.05).vForce(0.3 V).mode("VFIM");
          SPMU_VFIM_ALL_task.pin(ISINK1_CH).settling(dly).relay("NT").clamp(0.05).max(0.05).min(-0.05).vForce(0.3 V).mode("VFIM");
          SPMU_VFIM_ALL_task.pin(ISINK2_CH).settling(dly).relay("NT").clamp(0.05).max(0.05).min(-0.05).vForce(0.3 V).mode("VFIM");
          SPMU_VFIM_ALL_task.pin(ISINK3_CH).settling(dly).relay("NT").clamp(0.05).max(0.05).min(-0.05).vForce(0.3 V).mode("VFIM");
          SPMU_VFIM_ALL_task.pin(ISINK4_CH).settling(dly).relay("NT").clamp(0.05).max(0.05).min(-0.05).vForce(0.3 V).mode("VFIM");

          // Execute 
          SPMU_VFIM_ALL_task.execMode("PVAL").preAction("NPRM").execute();

          // Get Results 
          FOR_EACH_SITE_BEGIN();
          INT nSite = CURRENT_SITE_NUMBER();
          ISINK0[nSite-1][0] = SPMU_VFIM_ALL_task.getValue(ISINK0_CH);
          ISINK1[nSite-1][0] = SPMU_VFIM_ALL_task.getValue(ISINK1_CH);
          ISINK2[nSite-1][0] = SPMU_VFIM_ALL_task.getValue(ISINK2_CH);
          ISINK3[nSite-1][0] = SPMU_VFIM_ALL_task.getValue(ISINK3_CH);
          ISINK4[nSite-1][0] = SPMU_VFIM_ALL_task.getValue(ISINK4_CH);
          FOR_EACH_SITE_END();

          // Setup 2 - Change Voltage 
          SPMU_VFIM_ALL_task.pin(ISINK0_CH).vForce(0.25 V);
          SPMU_VFIM_ALL_task.pin(ISINK1_CH).vForce(0.25 V);
          SPMU_VFIM_ALL_task.pin(ISINK2_CH).vForce(0.25 V);
          SPMU_VFIM_ALL_task.pin(ISINK3_CH).vForce(0.25 V);
          SPMU_VFIM_ALL_task.pin(ISINK4_CH).vForce(0.25 V);

          // Execute
          SPMU_VFIM_ALL_task.execute();      // excute and get value

          // Get Results 
          FOR_EACH_SITE_BEGIN();
          INT nSite = CURRENT_SITE_NUMBER();
          ISINK0[nSite-1][1] = SPMU_VFIM_ALL_task.getValue(ISINK0_CH);
          ISINK1[nSite-1][1] = SPMU_VFIM_ALL_task.getValue(ISINK1_CH);
          ISINK2[nSite-1][1] = SPMU_VFIM_ALL_task.getValue(ISINK2_CH);    
          ISINK3[nSite-1][1] = SPMU_VFIM_ALL_task.getValue(ISINK3_CH);    
          ISINK4[nSite-1][1] = SPMU_VFIM_ALL_task.getValue(ISINK4_CH);    
          FOR_EACH_SITE_END();
          ON_FIRST_INVOCATION_END();
        }

        /**
         * The process() method is called after the test execution, or rather
         * after the test execution start.
         * It spans all tasks for the result upload, calculation and data
         * logging / binning.
         * 
         * Normal sequence of actions.
         * - upload results
         * - do calculations / pass results to DSP routines
         * - test against the limits
         * - optional print out results
         * 
         * Best results are achieved by using the SmartCalc feature and API.
         */
        virtual void process()
        {
          double Idiff[TOTAL_SITE][5];
          INT nSite = CURRENT_SITE_NUMBER();

          Idiff[nSite-1][0] = 100*(ISINK0[nSite-1][0] - ISINK0[nSite-1][1])/ISINK0[nSite-1][0];
          Idiff[nSite-1][1] = 100*(ISINK1[nSite-1][0] - ISINK1[nSite-1][1])/ISINK1[nSite-1][0];
          Idiff[nSite-1][2] = 100*(ISINK2[nSite-1][0] - ISINK2[nSite-1][1])/ISINK2[nSite-1][0];
          Idiff[nSite-1][3] = 100*(ISINK3[nSite-1][0] - ISINK3[nSite-1][1])/ISINK3[nSite-1][0];
          Idiff[nSite-1][4] = 100*(ISINK4[nSite-1][0] - ISINK4[nSite-1][1])/ISINK4[nSite-1][0];

          string tsName=CCTgetTestsuiteName();
          cout << "INFO: tsname: " << tsName << endl;
          bool pass = true;

          pass |= TEST("","ISINKS_CH0_STEP_1",tmLimits.getLimit(tsName, "ISINKS_CH0_STEP_1").TEST_API_LIMIT,ISINK0[nSite-1][0], true);
          pass |= TEST("","ISINKS_CH1_STEP_1",tmLimits.getLimit(tsName, "ISINKS_CH1_STEP_1").TEST_API_LIMIT,ISINK1[nSite-1][0], true);
          pass |= TEST("","ISINKS_CH2_STEP_1",tmLimits.getLimit(tsName, "ISINKS_CH2_STEP_1").TEST_API_LIMIT,ISINK2[nSite-1][0], true);
          pass |= TEST("","ISINKS_CH3_STEP_1",tmLimits.getLimit(tsName, "ISINKS_CH3_STEP_1").TEST_API_LIMIT,ISINK3[nSite-1][0], true);
          pass |= TEST("","ISINKS_CH4_STEP_1",tmLimits.getLimit(tsName, "ISINKS_CH4_STEP_1").TEST_API_LIMIT,ISINK4[nSite-1][0], true);

          pass |= TEST("","ISINKS_CH0_STEP_1_E",tmLimits.getLimit(tsName, "ISINKS_CH0_STEP_1_E").TEST_API_LIMIT,ISINK0[nSite-1][1], true);
          pass |= TEST("","ISINKS_CH1_STEP_1_E",tmLimits.getLimit(tsName, "ISINKS_CH1_STEP_1_E").TEST_API_LIMIT,ISINK1[nSite-1][1], true);
          pass |= TEST("","ISINKS_CH2_STEP_1_E",tmLimits.getLimit(tsName, "ISINKS_CH2_STEP_1_E").TEST_API_LIMIT,ISINK2[nSite-1][1], true);
          pass |= TEST("","ISINKS_CH3_STEP_1_E",tmLimits.getLimit(tsName, "ISINKS_CH3_STEP_1_E").TEST_API_LIMIT,ISINK3[nSite-1][1], true);
          pass |= TEST("","ISINKS_CH4_STEP_1_E",tmLimits.getLimit(tsName, "ISINKS_CH4_STEP_1_E").TEST_API_LIMIT,ISINK4[nSite-1][1], true);

          // Get software bin name and hard bin number from tmLimit
          string softbinName = tmLimits.getLimit(tsName, "ISINKS_CH0_STEP_1").BinsName; 
          int hardNum        = tmLimits.getLimit(tsName, "ISINKS_CH0_STEP_1").BinhNum;

          // Set multibin accoring to result
          if(!pass)
            SET_MULTIBIN(softbinName, hardNum);
        }

        /**
         * The cleanup() function finalizes the test and gets called after the
         * processing is done.
         * Common tasks for cleaning up after the test are
         * - Disable hardware triggers
         * - Disconnect instruments
         * - set Relays and DUT to a known good state / default state
         */
        virtual void cleanup()
        {
        }

        /**
        * This function will be invoked once the specified parameter's value is changed.
        * @param parameterIdentifier
        *
        * Note: Test Method API should not be used in this method.
        */
        virtual void postParameterChange(const std::string& parameterIdentifier)
        {
        }

    };
REGISTER_TESTMETHOD("DC_PMIC", DC_PMIC);

