/**
 * Copyright by Verigy Technologies, 2010
 *
 * @file    RF_Power_SMC.cpp
 *
 * @date    Aug 17, 2010
 */

#include "CCTestMethod.hpp"
#include "mapi.hpp"
using namespace std;
using namespace cct;
using namespace V93kLimits;

class RF_Power_SMC : public cct::CCTestMethod
{
    protected:
        string TxPin;
        INT    numCaptures;
        INT    enable_SMC;
    protected:
        /**
         * Add testmethod parameters here
         * 
         * Note: Test Method API should not be used in this method.
         */
        virtual void addParameters()
        {
          addParameter("TxPin", "string", &TxPin);
          
          addParameter("enable_SMC", "int", &enable_SMC)
          .setOptions("0:1")
          .setDefault("0")
          .setComment("Enable/disable SmartCalc");
        }

        /**
         * Initialize/configure framework and user class members
         */
        virtual void init()
        {
          CCTregisterTx(TxPin);
          CCTsetExecMode(EXM_EXECUTE_TEST); //or EXM_EXECUTE_GROUP for debug
          if(enable_SMC)
            CCTenableSMC(SMC_AUTO);
        }

        /**
         * The setup method is a mandatory method for Analog tests. It contains
         * all Setup API code needed to create the Analog test.
         * 
         * For Digital and DC, as of now, this method is going to be empty.
         * @param setName Name of the analog set
         */
        virtual void createAnalogSetup(const string& analogSetName)
        {
            // No baseband setup
        }

        /**
         * The setup method is a mandatory method for RF tests. It contains all
         * Setup API code needed to create the RF test.
         * 
         * For Digital and DC, as of now, this method is going to be empty.
         * @param setName Name of the RF set/definition
         */
        virtual void createRFSetup(const string& RFSetName)
        {
            STRING measName = RFSetName;
            STRING stimName = measName + "_s1";


            /********************************************************************
             * Beginning of Scalar Measurement "Power_in_Meas" Settings
            ********************************************************************/

            //---------------------------------------------------------------
            // Property Setting of "Power_in_Meas"
            //---------------------------------------------------------------
            RF_DATA_LIST freq_points("freq_points", "step(1e9,3e9,500e6)", TM::FREQ_LIST);

            // Constructor
            RF_STIM_CW Stim_cw_stim(stimName, TxPin, "freq_points");
            RF_MEAS_CW_IN Meas_Power_in_Meas(RFSetName, TxPin, "freq_points"); // loop back

            // Stimulus Configuration
            Stim_cw_stim.rfBlanking(false);
            Stim_cw_stim.imdNoiseRatio(0 dB);

            // Measurement Configuration
            Meas_Power_in_Meas.clock(500e6 Hz);

            // Resource Allocation
            Stim_cw_stim.minPower(-20 dBm);
            Stim_cw_stim.maxPower(-20 dBm);
            Stim_cw_stim.stimPath(TM::RF_STIM_PATH_BRIDGE);

            // Resource Allocation
            Meas_Power_in_Meas.useWith(stimName);

            //---------------------------------------------------------------
            // Sequence Setting of "Power_in_Meas"
            //---------------------------------------------------------------
            Meas_Power_in_Meas.appendFBlock();
            Meas_Power_in_Meas.appendFBlock();
            Meas_Power_in_Meas.appendFBlock();
            Meas_Power_in_Meas.appendFBlock();

            //++++++++++ cw_stim ++++++++++
            // Functional Block 1: Initial Settings
            SEQ_SETTINGS::RF_STIM_CW seqParam_Power_in_Meas_cw_stim_0;
            seqParam_Power_in_Meas_cw_stim_0.state = TM::RF_STIM_STATE_ON;
            seqParam_Power_in_Meas_cw_stim_0.freqIndex = 1;
            seqParam_Power_in_Meas_cw_stim_0.power = -20 dBm;
            Meas_Power_in_Meas.sequenceParam(1, stimName, seqParam_Power_in_Meas_cw_stim_0);
            // Functional Block 3: Sequence Step 1
            SEQ_SETTINGS::RF_STIM_CW seqParam_Power_in_Meas_cw_stim_1;
            seqParam_Power_in_Meas_cw_stim_1.freqIndex = 3;
            seqParam_Power_in_Meas_cw_stim_1.power = -30 dBm;
            Meas_Power_in_Meas.sequenceParam(3, stimName, seqParam_Power_in_Meas_cw_stim_1);
            // Functional Block 5: Sequence Step 2
            SEQ_SETTINGS::RF_STIM_CW seqParam_Power_in_Meas_cw_stim_2;
            seqParam_Power_in_Meas_cw_stim_2.freqIndex = 0;
            seqParam_Power_in_Meas_cw_stim_2.power = -30 dBm;
            Meas_Power_in_Meas.sequenceParam(5, stimName, seqParam_Power_in_Meas_cw_stim_2);

            //++++++++++ Power_in_Meas ++++++++++
            // Functional Block 2: Capture 1
            SEQ_SETTINGS::RF_MEAS_CW_IN seqParam_Power_in_Meas_1;
            seqParam_Power_in_Meas_1.freqIndex = 1;
            seqParam_Power_in_Meas_1.measBandwidth = 1e6 Hz;
            seqParam_Power_in_Meas_1.numOfAvg = 1;
            seqParam_Power_in_Meas_1.maxPower = -20 dBm;
            seqParam_Power_in_Meas_1.loAboveSignal = true;
            seqParam_Power_in_Meas_1.measFreqOffset = 0 Hz;
            seqParam_Power_in_Meas_1.overrideSamplingParam = false;
            Meas_Power_in_Meas.sequenceParam(2, RFSetName, seqParam_Power_in_Meas_1);
            // Functional Block 4: Capture 2
            SEQ_SETTINGS::RF_MEAS_CW_IN seqParam_Power_in_Meas_2;
            seqParam_Power_in_Meas_2.freqIndex = 3;
            seqParam_Power_in_Meas_2.measFreqOffset = 0 Hz;
            seqParam_Power_in_Meas_2.overrideSamplingParam = false;
            Meas_Power_in_Meas.sequenceParam(4, RFSetName, seqParam_Power_in_Meas_2);
            // Functional Block 6: Capture 3
            SEQ_SETTINGS::RF_MEAS_CW_IN seqParam_Power_in_Meas_3;
            seqParam_Power_in_Meas_3.freqIndex = 0;
            seqParam_Power_in_Meas_3.measFreqOffset = 0 Hz;
            seqParam_Power_in_Meas_3.overrideSamplingParam = false;
            Meas_Power_in_Meas.sequenceParam(6, RFSetName, seqParam_Power_in_Meas_3);

            numCaptures = 3; // number of capture blocks
            //---------------------------------------------------------------
            // Calibration status of "cw_stim"
            //---------------------------------------------------------------

            Stim_cw_stim.calState(TM::RF_CAL_OFF);

            //---------------------------------------------------------------
            // Calibration status of "Power_in_Meas"
            //---------------------------------------------------------------
            Meas_Power_in_Meas.calState(TM::RF_CAL_OFF);
            FLUSH();
        }

        /**
         * The preStart() method of the testmethod classes is called for each
         * execution of the test suite. All necessary operations to happen
         * before the execution of the test need to go here.
         */
        virtual void preStart()
        {
            ON_FIRST_INVOCATION_BEGIN();
            const STRING measName = CCTgetAnalogRFSetName();
            MEAS_DEF(measName).disableAll().connectAll();
            ON_FIRST_INVOCATION_END();
        }

        /**
         * The method is called after the execution (digital & analog sequencer) is
         * started. Tests that won't interfere other running sequencers can be 
         * called here.
         */
        virtual void postStart()
        {
            // No post actions
        }

        /**
         * The process() method is called after the test execution, or rather
         * after the test execution start.
         * It spans all tasks for the result upload, calculation and data
         * logging / binning.
         * 
         * Normal sequence of actions.
         * - upload results
         * - do calculations / pass results to DSP routines
         * - test against the limits
         * - optional print out results
         * 
         * Best results are achieved by using the SmartCalc feature and API.
         */
        virtual void process()
        {
            const STRING measName = CCTgetAnalogRFSetName();
            // ---------------------------------------------------------------------------
            //  Fetch the DSP parameters (and cal data) from the MEAS_DEF object.
            //    - If you are looping over multipule captures, you will need to
            //      pack the data into a single ARRAY_D for use with the HW DSP.
            //    - use getParameters(capId, freqIdx)
            //        capId   - the capture order used by the digitizer (DGT)
            //        freqIdx - the index in the freq List used by the capture
            // -------------------------------------------------------
            INT startCaptureId = CCTgetUploadId(TxPin);
            ARRAY_D measParams = MEAS_DEF(measName).getParameters(startCaptureId,0);

            INT sizeOfOne = measParams.size();

            ARRAY_D packedMeasParams(sizeOfOne*numCaptures);
            for(INT i= 0; i < numCaptures; i++)
            {
                measParams = MEAS_DEF(measName).getParameters(startCaptureId+i, 0);
                DSP_EXTRACT(measParams, packedMeasParams, 0, i*sizeOfOne, sizeOfOne);
            }

            // ---------------------------------------------------------------------------
            //  Run the DSP on the captured data by execting the static DSP function
            // -------------------------------------------------------
            ARRAY_D measuredPowers(numCaptures);
            sizeOfOne = measParams.size();
            INT numCaptures = measuredPowers.size();

            // Loop over the captures and process
            INT startCapNum = CCTgetUploadId(TxPin);
            for(INT capNum = startCapNum; capNum <= numCaptures; capNum++)
            {
                // Extract each set of Measurement parameters in turn.
                DSP_EXTRACT(packedMeasParams, measParams, (capNum-1)*sizeOfOne, 0, sizeOfOne);

                // Perform the actual DSP work
                //  1 - Get the captured waveform(s) from the DGT(s)
                //  2 - Send waveform(s) to the mod power DSP
                ARRAY_COMPLEX cData;
                if(enable_SMC)
                {
                    // hidden upload
                    cData = SMC_GET_COMPLEX_WAVEFORM(MEAS_DEF(measName).getDgtPinName(),CCTgetResultHandle(), capNum);
                }
                else
                {
                    cData = MEAS_DEF(measName).getComplexWaveform(capNum);
                }
                DSP_RF_CW_POWER(cData, measParams, SMC_SITE_NUMBER(), &measuredPowers[capNum-1]);
            }
            
            // ---------------------------------------------------------------------------
            //  (Optional)  Print results to ui.Report window
            // -------------------------------------------------------
            string tsName=CCTgetTestsuiteName();
            cout << "INFO: testsuite name: " << tsName << endl;

            cout << "For site " << CURRENT_SITE_NUMBER()    << endl;
            for(INT capNum=0; capNum < numCaptures; capNum++)
            {
                cout << "\t Capture Num = "  << capNum + 1
                     << ", Measured Power = " << measuredPowers[capNum] << "  dBm" << endl;
         
                if(enable_SMC)
                {
                    SMC_TEST(TxPin,
                            "Power_out",
                            tmLimits.getLimit(tsName, "Power_out").TEST_API_LIMIT, 
                            measuredPowers[capNum],
                            true);
                }
                else
                {
                    TEST(TxPin,
                        "Power_out",
                        tmLimits.getLimit(tsName, "Power_out").TEST_API_LIMIT, 
                        measuredPowers[capNum],
                        true);
                }
            }
        }

        /**
         * The cleanup() function finalizes the test and gets called after the
         * processing is done.
         * Common tasks for cleaning up after the test are
         * - Disable hardware triggers
         * - Disconnect instruments
         * - set Relays and DUT to a known good state / default state
         */
        virtual void cleanup()
        {
            ON_LAST_INVOCATION_BEGIN();
            // ---------------------------------------------------------------------------
            //  To prevent warnings and errors you should disconnect DGTs and AWGs
            //  that will no longer be in use.  The method below will disconnect
            //  everything.  If you just want to disconnect select pins (for example
            //  only the digitizer) you can also use the following sample code:
            //    - Routing.pin(MEAS_DEF(measName).getPinName()).disconnect();
            // -------------------------------------------------------
            MEAS_DEF(CCTgetAnalogRFSetName()).disconnectAll();
            ON_LAST_INVOCATION_END();
        }

        /**
         * This function will be invoked once the specified parameter's value is changed.
         * @param parameterIdentifier
         *
         * Note: Test Method API should not be used in this method.
         */
        virtual void postParameterChange(const std::string& parameterIdentifier)
        {
            //Add your code
        }

};
REGISTER_TESTMETHOD("RF_Power_SMC", RF_Power_SMC);

