/**
 * Copyright by Verigy Technologies, 2010
 *
 * @file    DAC_Distortion_SMC.cpp
 *
 * @date    Aug 25, 2010
 */

#include "CCTestMethod.hpp"

using namespace cct;
using V93kLimits::tmLimits;

class DAC_Distortion_SMC : public cct::CCTestMethod
{
    protected:
        string   dac_out;
        INT      num_cycle_DAC;
        THDtype  thd_result;
        ARRAY_D  dgtz_waveform;
        ARRAY_D  spect_waveform;
        INT      enable_SMC;

    protected:
        /**
         * Add testmethod parameters here
         * 
         * Note: Test Method API should not be used in this method.
         */
        virtual void addParameters()
        {
            addParameter("dac_out",
                         "string",
                         &dac_out)
            .setOptions("DAC_WDE:DAC.VOUT.MCA:DAC.VOUT.MCB")
            .setComment("DAC sequence 2");

            addParameter("num_cycle_DAC",
                         "int",
                         &num_cycle_DAC)
            .setDefault("25");

            addParameter("enable_SMC", "int", &enable_SMC)
            .setOptions("0:1")
            .setDefault("0")
            .setComment("Enable/disable SmartCalc");
        }

        /**
         * Initialize/configure framework and user class members
         */
        virtual void init()
        {
            CCTsetExecMode(EXM_EXECUTE_TEST);
            CCTregisterDGT(dac_out);
            if(enable_SMC)
                CCTenableSMC(SMC_AUTO);
        }

        /**
         * The setup method is a mandatory method for Analog tests. It contains
         * all Setup API code needed to create the Analog test.
         * 
         * For Digital and DC, as of now, this method is going to be empty.
         * @param setName Name of the analog set
         */
        virtual void createAnalogSetup(const string& analogSetName)
        {
            ANALOG_SET Analog_Set_11(analogSetName);
            Analog_Set_11.comment("dac_dis_MCB");

            Analog_Set_11.DGT(dac_out).coreFunction(TM::LF);
            // Sequencer Programs
            ANALOG_SEQUENCER Seq_DAC_sine_4096("DAC_sine_4096");
            // Commands,Trigger,Size,Disc,Core
            Seq_DAC_sine_4096.add(TM::HALT,TM::POST,4096,1,TM::ONE);

            // Hardware Settings
            Analog_Set_11.DGT(dac_out)
                    .sequencerProgram(Seq_DAC_sine_4096).vOffset(2.0000);

            // Master Clock Settings
            Analog_Set_11.CLOCK_DOMAIN(2,TM::ANALOG).clock(TM::MCLK_AUTO);

            // Conversion Clock Settings
            Analog_Set_11.DGT(dac_out).clockDomain(2).rule(TM::AUTOFS).frequency(0.1e+06);

            FLUSH();
        }

        /**
         * The setup method is a mandatory method for RF tests. It contains all
         * Setup API code needed to create the RF test.
         * 
         * For Digital and DC, as of now, this method is going to be empty.
         * @param setName Name of the RF set/definition
         */
        virtual void createRFSetup(const string& RFSetName)
        {
            // No RF setup. Leave it empty
        }

        /**
         * The preStart() method of the testmethod classes is called for each
         * execution of the test suite. All necessary operations to happen
         * before the execution of the test need to go here.
         */
        virtual void preStart()
        {
            ON_FIRST_INVOCATION_BEGIN();
            // CONNECT(); // insert a connect testsuite before CCF group 
            Routing.pin(dac_out).connect(TM::SINGLE);
            Analog.DGT(dac_out).enable();
            ON_FIRST_INVOCATION_END();
        }

        /**
         * The method is called after the execution (digital & analog sequencer) is
         * started. Tests that won't interfere other running sequencers can be 
         * called here.
         */
        virtual void postStart()
        {
            // No postStart actions.
        }

        /**
         * The process() method is called after the test execution, or rather
         * after the test execution start.
         * It spans all tasks for the result upload, calculation and data
         * logging / binning.
         * 
         * Normal sequence of actions.
         * - upload results
         * - do calculations / pass results to DSP routines
         * - test against the limits
         * - optional print out results
         * 
         * Best results are achieved by using the SmartCalc feature and API.
         */
        virtual void process()
        {
            INT    num_harmonics_DAC = 5;
            DOUBLE ref_level_DAC = 0.0;

            if(CCTgetMistriggeredSite() != 0)
            {
            	cout << "DAC Not triggered!!!" << endl;
            }

            // Get Digitized Waveform Data
            // hidden upload
            dgtz_waveform = SMC_GET_WAVEFORM(dac_out, CCTgetResultHandle(), CCTgetUploadId(dac_out));

            // Link to MX Signal Tool for debug
            //PUT_DEBUG(dac_out, "Source(captured)", dgtz_waveform);

            // Data Processing
            INT num_pts = dgtz_waveform.size();
            spect_waveform.resize(num_pts/2);
            DSP_SPECTRUM(dgtz_waveform, spect_waveform, DB, ref_level_DAC, RECT, 0);

            // Link to MX Signal Tool for debug
            //PUT_DEBUG(dac_out, "Spectrum", spect_waveform);

            // Result Evaluation
            DSP_THD(dgtz_waveform, &thd_result, num_cycle_DAC, num_harmonics_DAC, DB, 0);

            // Pass/Fail Evaluation & Datalog
            string tsName = CCTgetTestsuiteName(); // Get the original testsutie name
            cout << "INFO: testsuite name: " << tsName << endl;
            cout << thd_result.snr << " -> DAC_SNR" << endl;
            cout << thd_result.thd << " -> DAC_THD" << endl;

            // Get the soft bin name and hard bin number from tm limit file
            // the test limit file (.csv) should be specified in testflow setup
            // NOTE: use tmLimits.getLimit(testsuiteName, testName) 
            // testsuiteName is got by CCTgetTestsuiteName().
            string softBinName_1    = tmLimits.getLimit(tsName, "DAC_SNR").BinsName; 
            int hardBinNum_1        = tmLimits.getLimit(tsName, "DAC_SNR").BinhNum;
            string softBinName_2    = tmLimits.getLimit(tsName, "DAC_THD").BinsName; 
            int hardBinNum_2        = tmLimits.getLimit(tsName, "DAC_THD").BinhNum;
            string softBinName_3    = tmLimits.getLimit(tsName, "DAC_SNR_THD").BinsName; 
            int hardBinNum_3        = tmLimits.getLimit(tsName, "DAC_SNR_THD").BinhNum;
            
            // Test agaist limit and datalog
            if(enable_SMC)
            {
                SMC_TEST(dac_out,
                        "DAC_SNR",
                        tmLimits.getLimit(tsName, "DAC_SNR").TEST_API_LIMIT, 
                        thd_result.snr,
                        true,
                        100,
                        softBinName_1,
                        hardBinNum_1);
                SMC_TEST(dac_out,
                        "DAC_THD",
                        tmLimits.getLimit(tsName, "DAC_THD").TEST_API_LIMIT, 
                        thd_result.thd,
                        true,
                        101,
                        softBinName_2,
                        hardBinNum_2);
            }
            else
            {
                bool pass_1 = TEST(dac_out,
                                    "DAC_SNR",
                                    tmLimits.getLimit(tsName, "DAC_SNR").TEST_API_LIMIT, 
                                    thd_result.snr,
                                    true);
                bool pass_2 = TEST(dac_out,
                                    "DAC_THD",
                                    tmLimits.getLimit(tsName, "DAC_THD").TEST_API_LIMIT, 
                                    thd_result.thd,
                                    true);
                // Multibin is used for binning.
                // Set multibin according to different result branch
                if(!pass_1&&pass_2) SET_MULTIBIN(softBinName_1, hardBinNum_1);
                if(pass_1&&!pass_2) SET_MULTIBIN(softBinName_2, hardBinNum_2);
                if(!pass_1&&!pass_2) SET_MULTIBIN(softBinName_3, hardBinNum_3);
            }
        }

        /**
         * The cleanup() function finalizes the test and gets called after the
         * processing is done.
         * Common tasks for cleaning up after the test are
         * - Disable hardware triggers
         * - Disconnect instruments
         * - set Relays and DUT to a known good state / default state
         */
        virtual void cleanup()
        {
            ON_LAST_INVOCATION_BEGIN();
            DGT(dac_out).disable();
            Routing.pin(dac_out).disconnect();
            ON_LAST_INVOCATION_END();
        }

        /**
         * This function will be invoked once the specified parameter's value is changed.
         * @param parameterIdentifier
         *
         * Note: Test Method API should not be used in this method.
         */
        virtual void postParameterChange(const std::string& parameterIdentifier)
        {
            //Add your code
        }

};
REGISTER_TESTMETHOD("DAC_Distortion_SMC", DAC_Distortion_SMC);

