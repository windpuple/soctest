#include "CCTestMethod.hpp"

/**
 * Copyright by Verigy Technologies, 2010
 *
 * @file    ADC_Lineary.cpp
 *
 * @date    Sep 13, 2010
 */
using namespace V93kLimits;
using namespace cct;

    class ADC_LINEARITY : public cct::CCTestMethod
    {
    protected:
        string  adc_in;
        string  adc_capture_pin;
        string  capture_data;
        string  ADC_flag;

    protected:
          /**
           * Add testmethod parameters here
           * 
           * Note: Test Method API should not be used in this method.
           */
        virtual void addParameters()
        {
            addParameter("adc_in",
                         "string",
                         &adc_in)
              .setOptions("ADC.VIN:ADC.VIN.MCA:ADC.VIN.MCB")
              .setComment("ADC analog input ");
            addParameter("capture_data",
                         "string",
                         &capture_data)
              .setDefault("ADC.vector_var")
              .setOptions("ADC.vector_var")
              .setComment("digital capture");
            addParameter("ADC_flag",
                         "string",
                         &ADC_flag)
              .setDefault("ADC")
              .setOptions("ADC")
              .setComment("ADC_Port results");

            addParameter("adc_capture_pin",
                         "string",
                         &adc_capture_pin)
              .setDefault("ADC.data_out")
              .setOptions("ADC.data_out");
        }
        
        /**
         * Initialize/configure framework and user class members
         */
        virtual void init()
        {
            CCTsetResultArea(adc_capture_pin,1024);
            CCTsetExecMode(EXM_DIGITAL_CAPTURE_TEST);
        }

        /**
         * The setup method is a mandatory method for Analog tests. It contains
         * all Setup API code needed to create the Analog test.
         * 
         * For Digital and DC, as of now, this method is going to be empty.
         * @param setName Name of the analog set
         */
        virtual void createAnalogSetup(const string& analogSetName)
        {
            ANALOG_SET Analog_Set(analogSetName);
            Analog_Set.comment("adc_lin_MCB");

            // Waveforms
            ANALOG_WAVEFORM Wave_adc_ramp8192(analogSetName+"_adc_ramp8192");
            Wave_adc_ramp8192.definition(TM::ASCII,"../waveform/Wave_adc_ramp8192.txt");

            // Sequencer Programs
            ANALOG_SEQUENCER Seq_adc_ramp_8192(analogSetName+"_adc_ramp_8192");
            Seq_adc_ramp_8192.add(TM::RPTI,Wave_adc_ramp8192);
            Seq_adc_ramp_8192.add(TM::HALT,Wave_adc_ramp8192);

            // Hardware Settings
            Analog_Set.AWG(adc_in).coreFunction(TM::LF).sequencerProgram(Seq_adc_ramp_8192)
                        .attn(6.0200).vOffset(1.5000);
            
            // Master Clock Settings
            Analog_Set.CLOCK_DOMAIN(2,TM::ANALOG).clock(TM::MCLK_AUTO);

            // Conversion Clock Settings
            Analog_Set.AWG(adc_in).clockDomain(2).rule(TM::AUTOFS).frequency(0.1e+06);

            FLUSH();
        }

        /**
         * The setup method is a mandatory method for RF tests. It contains all
         * Setup API code needed to create the RF test.
         * 
         * For Digital and DC, as of now, this method is going to be empty.
         * @param setName Name of the RF set/definition
         */
        virtual void createRFSetup(const string& RFSetName)
        {
            
        }

        /**
         * The preStart() method of the testmethod classes is called for each
         * execution of the test suite. All necessary operations to happen
         * before the execution of the test need to go here.
         */
        virtual void preStart()
        {
          ON_FIRST_INVOCATION_BEGIN();
            
            //CONNECT();// insert a "connect" testsuite before CCF group
            // Connect the DAC and ADC pins and enable the Analog Instruments
            Routing.pin(adc_in).connect();
            Analog.AWG(adc_in).enable();    
          ON_FIRST_INVOCATION_END();

        }

        /**
         * The method is called after the execution (digital & analog sequencer) is
         * started. Tests that won't interfere other running sequencers can be 
         * called here.
         */
        virtual void postStart()
        {
            //Add your code;
        }
        
        /**
         * The process() method is called after the test execution, or rather
         * after the test execution start.
         * It spans all tasks for the result upload, calculation and data
         * logging / binning.
         * 
         * Normal sequence of actions.
         * - upload results
         * - do calculations / pass results to DSP routines
         * - test against the limits
         * - optional print out results
         * 
         * Best results are achieved by using the SmartCalc feature and API.
         */
        virtual void process()
        {
            ARRAY_I ADC_captured_wave;
            ADC_captured_wave = VECTOR(capture_data).getVectors();

            // Perform waveform calculations for ADC test
            INT miss_number(0), min_code_size(1);
            INT miss_code[10000];
            ARRAY_D ADC_dle, ADC_ile;
            ARRAY_I ADC_histogram;
            LINEARtype ADC_lin_result;

            DSP_ADC_HISTOGRAM(ADC_captured_wave, &ADC_lin_result, ADC_dle, ADC_ile, &miss_number, miss_code, END_PT, min_code_size);

            string tsName=CCTgetTestsuiteName();
            cout << "INFO: testsuite name: " << tsName << endl;
            cout << "miss number = " << miss_number << endl;
            cout << "DNL MAX = " << ADC_lin_result.damax << endl;
            cout << "INL MAX = " << ADC_lin_result.iamax << endl;

            // Test for Pass/Fail Results and datalog
 
            string softBinName_1 = tmLimits.getLimit(tsName, "ADC_dnl").BinsName; 
            int hardBinNum_1 = tmLimits.getLimit(tsName, "ADC_dnl").BinhNum;
            string softBinName_2 = tmLimits.getLimit(tsName, "ADC_inl").BinsName; 
            int hardBinNum_2 = tmLimits.getLimit(tsName, "ADC_inl").BinhNum;
            string softBinName_3 = tmLimits.getLimit(tsName, "ADC_dnl_inl").BinsName; 
            int hardBinNum_3 = tmLimits.getLimit(tsName, "ADC_dnl_inl").BinhNum;

            Boolean ADC_result_dnl = TEST(adc_in,"ADC_dnl",tmLimits.getLimit(tsName, "ADC_dnl").TEST_API_LIMIT, ADC_lin_result.damax, true);
            Boolean ADC_result_inl = TEST(adc_in,"ADC_inl",tmLimits.getLimit(tsName, "ADC_inl").TEST_API_LIMIT, ADC_lin_result.iamax, true);

            if(!ADC_result_dnl&&ADC_result_inl) SET_MULTIBIN(softBinName_1, hardBinNum_1);
            if(ADC_result_dnl&&!ADC_result_inl) SET_MULTIBIN(softBinName_2, hardBinNum_2);
            if(!ADC_result_dnl&&!ADC_result_inl) SET_MULTIBIN(softBinName_3, hardBinNum_3);

            // Send waveforms to Mixed Signal Tool
            // PUT_DEBUG(adc_in, "ADC output from ADC.data_out", ADC_captured_wave);
            // PUT_DEBUG(adc_in, "ADC ILE Waveform", ADC_ile);
            // PUT_DEBUG(adc_in, "ADC DLE Waveform", ADC_dle);

        }

        /**
         * The cleanup() function finalizes the test and gets called after the
         * processing is done.
         * Common tasks for cleaning up after the test are
         * - Disable hardware triggers
         * - Disconnect instruments
         * - set Relays and DUT to a known good state / default state
         */
        virtual void cleanup()
        {
          ON_LAST_INVOCATION_BEGIN();
            // Disconnect the  ADC pins and disable the Analog Instruments
            Analog.AWG(adc_in).disable();
            Routing.pin(adc_in).disconnect();
          ON_LAST_INVOCATION_END(); 
        }

         /**
          * This function will be invoked once the specified parameter's value is changed.
          * @param parameterIdentifier
          *
          * Note: Test Method API should not be used in this method.
          */
        virtual void postParameterChange(const std::string& parameterIdentifier)
        {
            
        }

    };
REGISTER_TESTMETHOD("ADC_LINEARITY", ADC_LINEARITY);

