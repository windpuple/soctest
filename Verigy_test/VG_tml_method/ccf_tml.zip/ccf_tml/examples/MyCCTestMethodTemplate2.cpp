/**
 * Copyright by Verigy Technologies, 2010
 *
 * @file    MyCCTestMethodTemplate2.cpp
 *
 * @author  __Author__
 * @date    __Date__
 */

#include "MyCCTestMethodTemplate2.hpp"

void MyCCTestMethodTemplate2::addParameters()
{
    //Add your code
}


void MyCCTestMethodTemplate2::init()
{
    CCTsetExecMode(EXM_EXECUTE_TEST);
}


void MyCCTestMethodTemplate2::createAnalogSetup(const string& analogSetName)
{
    //Add your code
}


void MyCCTestMethodTemplate2::createRFSetup(const string& RFSetName)
{
    //Add your code
}


void MyCCTestMethodTemplate2::preStart()
{
    //Add your code
}


void MyCCTestMethodTemplate2::postStart()
{
    //Add your code
}


void MyCCTestMethodTemplate2::process()
{
    //Add your code
}


void MyCCTestMethodTemplate2::cleanup()
{
    //Add your code
}


void MyCCTestMethodTemplate2::postParameterChange(const std::string& parameterIdentifier)
{
    //Add your code
}

REGISTER_TESTMETHOD("MyCCTestMethodTemplate2", MyCCTestMethodTemplate2);

