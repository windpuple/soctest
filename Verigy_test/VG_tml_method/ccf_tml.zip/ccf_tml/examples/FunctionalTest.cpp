/**
 * Copyright by Verigy Technologies, 2010
 *
 * @file    FunctionalTest.cpp
 *
 * @date    Aug 25, 2010
 */

#include "CCTestMethod.hpp"

using namespace cct;

    class FunctionalTest : public cct::CCTestMethod
    {
      protected:
        /**
         * Add testmethod parameters here
         * 
         * Note: Test Method API should not be used in this method.
         */
        virtual void addParameters()
        {
            //Add your code
        }

        /**
         * Initialize/configure framework and user class members
         */
        virtual void init()
        {
            CCTsetExecMode(EXM_FUNCTIONAL_TEST);
        }

        /**
         * The setup method is a mandatory method for Analog tests. It contains
         * all Setup API code needed to create the Analog test.
         * 
         * For Digital and DC, as of now, this method is going to be empty.
         * @param setName Name of the analog set
         */
        virtual void createAnalogSetup(const string& analogSetName)
        {
            // no analog setup
        }

        /**
         * The setup method is a mandatory method for RF tests. It contains all
         * Setup API code needed to create the RF test.
         * 
         * For Digital and DC, as of now, this method is going to be empty.
         * @param setName Name of the RF set/definition
         */
        virtual void createRFSetup(const string& RFSetName)
        {
            // no RF setup
        }

        /**
         * The preStart() method of the testmethod classes is called for each
         * execution of the test suite. All necessary operations to happen
         * before the execution of the test need to go here.
         */
        virtual void preStart()
        {
            //ON_FIRST_INVOCATION_BEGIN();
            //CONNECT(); // insert a connect testsuite before CCF group
            //ON_FIRST_INVOCATION_END();
        }

        /**
         * The method is called after the execution (digital & analog sequencer) is
         * started. Tests that won't interfere other running sequencers can be 
         * called here.
         */
        virtual void postStart()
        {
            // no post start
        }

        /**
         * The process() method is called after the test execution, or rather
         * after the test execution start.
         * It spans all tasks for the result upload, calculation and data
         * logging / binning.
         * 
         * Normal sequence of actions.
         * - upload results
         * - do calculations / pass results to DSP routines
         * - test against the limits
         * - optional print out results
         * 
         * Best results are achieved by using the SmartCalc feature and API.
         */
        virtual void process()
        {
            string tsName=CCTgetTestsuiteName();
            cout << "INFO: testsuite name: " << tsName << endl;

            Boolean pass = TEST("SH1_Port", TRUE);
            // Or GET_FUNCTIONAL_RESULT (does NOT log data)
            // Boolean pass = GET_FUNCTIONAL_RESULT("SH1_Port");

            if ( pass ) 
              cout << "SH1_Port Passes!!" << endl;
            else 
              cout << "SH1_Port Fails..." << endl;
        }

        /**
         * The cleanup() function finalizes the test and gets called after the
         * processing is done.
         * Common tasks for cleaning up after the test are
         * - Disable hardware triggers
         * - Disconnect instruments
         * - set Relays and DUT to a known good state / default state
         */
        virtual void cleanup()
        {
        }

        /**
        * This function will be invoked once the specified parameter's value is changed.
        * @param parameterIdentifier
        *
        * Note: Test Method API should not be used in this method.
        */
        virtual void postParameterChange(const std::string& parameterIdentifier)
        {
            //Add your code
        }

    };
REGISTER_TESTMETHOD("FunctionalTest", FunctionalTest);

