#ifndef SETUPLEVEL0SETUTIL_HPP_
#define SETUPLEVEL0SETUTIL_HPP_
#include "CommonUtil.hpp"

class SetupLevelSet0Util
{
private:
  vector<string> mPinVector;
  vector<string> mClampModeVector;
  vector<string> mClampHighVector_mV; //in [mV]
  vector<string> mClampLowVector_mV;  //in [mV]
  vector<string> mActiveLoadModeVector;
  vector<string> mVtVector_mV;  //in [mV]
  vector<string> mIolVector_uA; //in [uA]
  vector<string> mIohVector_uA; //in [uA]

public:
  ~SetupLevelSet0Util()
  {
  }
  SetupLevelSet0Util()
  {
  }

  /*
   *processParameter:
   *  - split string value into vector with separated setup group
   *  - validate values
   *  - validate the parameters consistency against pins
   *
   *@note: this must be called inside ON_FIRST_INVOCATIN block
   */
  void
  processParameter(const string& pins,
                   const string& clampMode,
                   const string& clampVoltageLow,
                   const string& clampVoltageHigh,
                   const string& activeLoadMode,
                   const string& activeLoadCommVoltage, 
                   const string& activeLoadSourceCurrent,
                   const string& activeLoadSinkCurrent)
  {
    setPins(pins);
    for(vector<string>::const_iterator it = mPinVector.begin();
        it != mPinVector.end();
        ++it)
    {
      if ((*it).empty())
      {
    	throw Error("SetupLevelSet0Util::processParameter()",
                "pin is empty",
                "SetupLevelSet0Util::processParameter()");  
      }
      PinUtility.getDigitalPinNamesFromPinList(*it,
        TM::IO_PIN|TM::I_PIN|TM::O_PIN,true,true);
    }
    
    if (!setClampMode(clampMode))
    {
      throw Error("SetupLevelSet0Util::processParameter()",
                  "valid clamp mode should be: ON,OFF.",
                  "SetupLevelSet0Util::processParameter()");
    }

    setClampHigh(clampVoltageHigh);
    setClampLow(clampVoltageLow);

    if (!setActiveLoadMode(activeLoadMode))
    {
      throw Error("SetupLevelSet0Util::processParameter()",
                  "valid active load mode should be: ON,OFF.",
                  "SetupLevelSet0Util::processParameter()");
    }
    setActiveLoadCommVoltage(activeLoadCommVoltage);
    setActiveLoadSinkCurrent(activeLoadSinkCurrent);
    setActiveLoadSourceCurrent(activeLoadSourceCurrent);

    validateArrayParameters();
  }

  /**
   * doMeasurement() to implement the following things:
   *  - DISCONNCET()
   *  - use CLMP to set up clamp settings.
   *  - use TERM to set up active load vt,iol,ioh settings.
   *  - use SQST BRK;SQST OFF; to activate this setting.
   *  - download command through FW_TASK() API.
   *
   *@note: this must be called inside ON_FIRST_INVOCATIN block
   */
  void 
  doMeasurement()
  {
    string cmdString;
    for (vector<string>::size_type i = 0; i < mPinVector.size(); ++i)
    {
      //set up clamp	
      cmdString += "CLMP 0";
      if (mClampModeVector[i] == "ON")
      {
        cmdString += ",ON";
        cmdString += ","+mClampLowVector_mV[i];
        cmdString += ","+mClampHighVector_mV[i];
      }
      else //OFF
      {
        cmdString += ",OFF,,";
      }
      cmdString += ",("+mPinVector[i]+")\n";

      //set up active load only if mode is ON,OFF
      if (mActiveLoadModeVector[i] == "ON")
      {
        //format: TERM 0,A,vt,iol,ioh,,,(pin)	  
        cmdString += "TERM 0,A";
        cmdString += ","+mVtVector_mV[i];
        cmdString += ","+mIolVector_uA[i];
        cmdString += ","+mIohVector_uA[i];
        cmdString += ",,,("+mPinVector[i]+")\n";
      }
      else //OFF
      {
        cmdString += "TERM 0,OFF,,,,,,("+mPinVector[i]+")\n";
      }
    }
    if (!cmdString.empty())
    {
      DISCONNECT();
      cmdString += "SQST BRK;SQST OFF\n";
      FW_TASK(cmdString);
    }
  } 

 /*
  *setPins: split pin-group string into vector as separated group.
  *
  *@note: this function can NOT call any MAPI api because
  * it is invoked in postParameterChanged().
  */
  bool 
  setPins(const string& pins)
  {
    splitStringToStringVector(pins,";",mPinVector);
    return true;
  }

  const vector<string>& 
  getPinVector() const
  {
    return mPinVector;
  }

 /*
  *setClampMode: split mode-group string into vector as separated group,
  *  and validate the mode value.
  *@param: clampMode - clamp mode
  *@return: true - success, false - invalid value detected
  *
  *@note: this function can NOT call any MAPI api because
  * it is invoked in postParameterChanged().
  */
  bool 
  setClampMode(const string& clampMode)
  {
    string clampModeString;
    for (string::size_type i = 0; i < clampMode.size(); ++i)
    {
      clampModeString += toupper(clampMode[i]);   
    }
    splitStringToStringVector(clampModeString,";",mClampModeVector);
    for (vector<string>::const_iterator it = mClampModeVector.begin(); 
        it != mClampModeVector.end();
        ++it)
    {
      if (*it == "OFF" || *it == "ON")
      {
        continue; 
      }
      else
      {
        return false;
      }     
    }
    return true;
  }

  const vector<string>& 
  getClampModeVector() const
  {
    return mClampModeVector;
  }

  /**
   *@purose: split string into vector.   
   *@param: clampHigh - clamp voltage high value in one string. unit is [V]  
   *@return: true - success, false - invalid value detected
   *
   *@note: this function can NOT call any MAPI api because
   * it is invoked in postParameterChanged().
   */
  bool 
  setClampHigh(const string& clampHigh)
  {
    vector<double> valueVector;
    mClampHighVector_mV.clear();
    try
    {
      splitStringToDoubleVector(clampHigh,";",valueVector);
      for (vector<double>::iterator it = valueVector.begin();
          it != valueVector.end();
          ++it)
      {
        (*it) *= 1e3; //[V] -> [mV];
        mClampHighVector_mV.push_back(CommonUtil::double2String(*it));
      }
    }
    catch (Error& e)
    {
      return false; 
    }
    return true;
  }

  const vector<string>& 
  getClampHighVector() const
  {
    return mClampHighVector_mV;
  }

  /**
   *@purose: split string into vector.   
   *@param: clampLow - clamp voltage low value in one string. unit is [V]  
   *@return: true - success, false - invalid value detected
   *
   *@note: this function can NOT call any MAPI api because
   * it is invoked in postParameterChanged().
   */  
  bool 
  setClampLow(const string& clampLow)
  {
    vector<double> valueVector;
    mClampLowVector_mV.clear();
    try
    {
      splitStringToDoubleVector(clampLow,";",valueVector);
      for (vector<double>::iterator it = valueVector.begin();
          it != valueVector.end();
          ++it)
      {
        (*it) *= 1e3; //[V] -> [mV];
        mClampLowVector_mV.push_back(CommonUtil::double2String(*it));
      }
    }
    catch (Error& e)
    {
      return false; 
    }
    return true;
  }

  const vector<string>& 
  getClampLowVector() const
  {
    return mClampLowVector_mV;
  }  

  /**
   *setActiveLoadMode: split string into vector.   
   *@param: activeLoadMode - active load mode  
   *@return: true - success, false - invalid mode detected
   *
   *@note: this function can NOT call any MAPI api because
   * it is invoked in postParameterChanged().
   */
  bool 
  setActiveLoadMode(const string& activeLoadMode)
  {
    string modeString;
    for (string::size_type i = 0; i < activeLoadMode.size(); ++i)
    {
      modeString += toupper(activeLoadMode[i]);   
    }
    splitStringToStringVector(modeString,";",mActiveLoadModeVector);
    for (vector<string>::const_iterator it = mActiveLoadModeVector.begin(); 
        it != mActiveLoadModeVector.end();
        ++it)
    {
      if (*it == "ON" || *it == "OFF")
      {
        continue; 
      }
      else
      {
        return false;
      }     
    }
    return true;
  }

  const vector<string>& 
  getActiveLoadModeVector() const
  {
    return mActiveLoadModeVector;
  }

  /**
   *@purose: split string into vector.   
   *@param: communVoltage - active load commutation voltage  
   *@return: true - success, false - invalid value detected
   *
   *@note: this function can NOT call any MAPI api because
   * it is invoked in postParameterChanged().
   */  
  bool 
  setActiveLoadCommVoltage(const string& communVoltage)
  {
    vector<double> valueVector;
    mVtVector_mV.clear();
    try
    {
      splitStringToDoubleVector(communVoltage,";",valueVector);
      for (vector<double>::iterator it = valueVector.begin();
          it != valueVector.end();
          ++it)
      {
        (*it) *= 1e3; //[V] -> [mV];
        mVtVector_mV.push_back(CommonUtil::double2String(*it));
      }
    }
    catch (Error& e)
    {
      return false; 
    }
    return true;
  }

  const vector<string>& 
  getActiveLoadCommVoltageVector() const
  {
    return mVtVector_mV;
  }

  /**
   *@purose: split string into vector.   
   *@param: sinkCurrent - active load IOL current value in one string.  
   *@return: true - success, false - invalid value detected
   *
   *@note: this function can NOT call any MAPI api because
   * it is invoked in postParameterChanged().
   */  
  bool 
  setActiveLoadSinkCurrent(const string& sinkCurrent)
  {
    vector<double> valueVector;
    mIolVector_uA.clear();
    try
    {
      splitStringToDoubleVector(sinkCurrent,";",valueVector);
      for (vector<double>::iterator it = valueVector.begin();
          it != valueVector.end();
          ++it)
      {
        (*it) *= 1e6; //[A] -> [uA];
        mIolVector_uA.push_back(CommonUtil::double2String(*it));
      }
    }
    catch (Error& e)
    {
      cerr<<"Error in setActiveLoadSinkCurrent()."<<endl;   
      return false; 
    }
    return true;
  }

  const vector<string>& 
  getActiveLoadSinkCurrentVector() const
  {
    return mIolVector_uA;
  }

  /**
   *@purose: split string into vector.   
   *@param: sourceCurrent - active load IOH current value in one string.  
   *@return: true - success, false - invalid value detected
   *
   *@note: this function can NOT call any MAPI api because
   * it is invoked in postParameterChanged().
   */   
  bool 
  setActiveLoadSourceCurrent(const string& sourceCurrent)
  {
    vector<double> valueVector;
    mIohVector_uA.clear();
    try
    {
      splitStringToDoubleVector(sourceCurrent,";",valueVector);
      for (vector<double>::iterator it = valueVector.begin();
          it != valueVector.end();
          ++it)
      {
        (*it) *= 1e6; //[A] -> [uA];
        mIohVector_uA.push_back(CommonUtil::double2String(*it));
      }
    }
    catch (Error& e)
    {
      cerr<<"Error in setActiveLoadSourceCurrent()."<<endl; 
      return false; 
    }
    return true;
  }

  const vector<string>& 
  getActiveLoadSourceCurrentVector() const
  {
    return mIohVector_uA;
  }

  /**
   *make sure that size of arraries are same for all input parameters. 
   **/
  bool 
  validateArrayParameters()
  {
    string checkError;
    if (mClampModeVector.size() != mPinVector.size())
    {
      checkError = "clamp mode array size doesn't match with pin arrary.";  
    }
    else if (mClampHighVector_mV.size() != mPinVector.size())
    {
      checkError = "clamp high voltage array size doesn't match with pin arrary.";  
    }
    else if (mClampLowVector_mV.size() != mPinVector.size())
    {
      checkError = "clamp low voltage array size doesn't match with pin arrary."; 
    }
    else if (mActiveLoadModeVector.size() != mPinVector.size())
    {
      checkError = "active load mode array size doesn't match with pin arrary."; 
    }
    else if (mVtVector_mV.size() != mPinVector.size())
    {
      checkError = "active load commnutation voltage array size doesn't match with pin arrary.";  
    }
    else if (mIohVector_uA.size() != mPinVector.size())
    {
      checkError = "active load source current array size doesn't match with pin arrary.";  
    }
    else if (mIolVector_uA.size() != mPinVector.size())
    {
      checkError = "active load sink current array size doesn't match with pin arrary.";  
    }

    if (!checkError.empty())
    {
      throw Error("SetupLevelSet0Util::validateArrayParameters()",
                  checkError,
                  "SetupLevelSet0Util::validateArrayParameters()");  
    }
    return true;
  }

private:
  static void 
  splitStringToStringVector(const string& origString, 
    const string& delimiter, vector<string>& outVector)
  {
    outVector.clear();
    string::size_type posBegin = 0;
    string::size_type posEnd = 0;
    string element;
    while ((posEnd = origString.find(delimiter,posBegin)) != string::npos)
    {
      element = origString.substr(posBegin,posEnd-posBegin);
      element = CommonUtil::trim(element);
      outVector.push_back(element);
      posBegin = posEnd+delimiter.size();
    }

    if (posBegin < origString.size())
    {
      element = origString.substr(posBegin,origString.size()-posBegin);
      element = CommonUtil::trim(element);
      outVector.push_back(element);
    }
  }

  static void 
  splitStringToDoubleVector(const string& origStr, 
    const string& delimiter, vector<double>& outVector)
  {
    vector<string> vectorString;
    outVector.clear();
    splitStringToStringVector(origStr,delimiter,vectorString);
    for (vector<string>::const_iterator it = vectorString.begin();
        it != vectorString.end();
        ++it)
    {
      double valDouble = CommonUtil::string2Double(*it,*it);
      outVector.push_back(valDouble);
    }
  }
};
#endif /*SETUPLEVEL0SETUTIL_HPP_*/
