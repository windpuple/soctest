/**
 * (c) Copyright 2011, Verigy Technologies, all rights reserved.
 *
 * Modification History:
 *
 *
 */

//for testmethod framework interfaces
#include "testmethod.hpp"

//for testmethod API interfaces
#include "mapi.hpp"

#include "CommonUtil.hpp"

using namespace std;

/**
 * Testmethod class.
 *
 * For each testsuite using this testmethod, one object of this
 * class is created.
 */
class FwEscape: public testmethod::TestMethod {
protected:
  string  setupCommand;
  string  executionCommand;
  string  testerState;
  string  output;
protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   *
   *Note: TestMethod API should not be used in this method.
   */
  virtual void initialize()
  {
    //Add your initialization code here
    addParameter("setupCommand",
                 "string",
                 &setupCommand,
                 testmethod::TM_PARAMETER_INPUT);
    addParameter("executionCommand",
                 "string",
                 &executionCommand,
                 testmethod::TM_PARAMETER_INPUT);
    addParameter("testerState",
                 "string",
                 &testerState,
                 testmethod::TM_PARAMETER_INPUT)
      .setDefault("UNCHANGED")
      .setOptions("UNCHANGED:CONNECTED:DISCONNECTED")
      .setComment("set system state before execution commands");
    addParameter("output",
                 "string",
                 &output)
      .setDefault("ReportUI")
      .setOptions("ReportUI:None")
      .setComment("display result or not");
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
    ON_FIRST_INVOCATION_BEGIN();
      // process parameter
      string setupCommandString = CommonUtil::trim(setupCommand) + "\n";
      string executionCommandString = CommonUtil::trim(executionCommand) + "\n";
      string setupCommandAnswer,executionCommandAnswer;
      string status = CommonUtil::trim(testerState);
      if(status != "CONNECTED"    &&
         status != "DISCONNECTED" &&
         status != "UNCHANGED")
      {
        throw Error("FwEscape::run()",
                    "status must be one of: CONNECTED DISCONNECTED UNCHANGED",
                     "FwEscape::run()");
      }
      
      // do measurement
      if(FW_PASSED != FW_TASK(setupCommandString,setupCommandAnswer))
      {
        throw Error("FwEscape::run()","setup command: " + setupCommandString
                    + "execution is not successful",
                    "FwEscape::run()");
      }
      if(status == "CONNECTED")
      {
        CONNECT();  
      }
      else if(status == "DISCONNECTED")
      {
        DISCONNECT();
      }
      if(FW_PASSED != FW_TASK(executionCommandString,executionCommandAnswer))	  
      {
        throw Error("FwEscape::run()","execution command: " 
                    + executionCommandString + "execution is not successful",
                    "FwEscape::run()");
      }

      // report to UI
      if(output == "ReportUI")
      {
        if(!setupCommandAnswer.empty())
        {
          cout << "setup command answer is: " << setupCommandAnswer <<endl;
        }
        if(!executionCommandAnswer.empty())
        {
          cout << "execution command answer is: " << executionCommandAnswer <<endl;
        }
      }
    ON_FIRST_INVOCATION_END();
    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   *
   *Note: TestMethod API should not be used in this method.
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string  getComment() const
  {
     static string comment = _TML_VERSION;
     return comment;
  }
};
REGISTER_TESTMETHOD("OtherTest.FwEscape", FwEscape);
