/**
 * (c) Copyright 2011, Verigy Technologies, all rights reserved.
 *
 * Modification History:
 *
 *
 */

//for testmethod framework interfaces
#include "testmethod.hpp"

//for testmethod API interfaces
#include "mapi.hpp"

#include "CommonUtil.hpp"

using namespace std;

namespace {
  bool checkUtilityLines(const STRING& utilityLines)
  {
    if(  (utilityLines.find(" ") != STRING::npos)
      && (utilityLines.find(" ") != (utilityLines.find(", ") + 1))  )
    {
      return false;
    }
    return true;
  }
}

#define CHECK_UTILITYLINES_PARAM(id) \
if(parameterIdentifier == #id) \
{ \
  if (!checkUtilityLines(id)) \
  { \
    getParameter(#id).setValid(false); \
    getParameter(#id).setMessage("all utility lines must be separated by comma's"); \
  } \
  else \
  { \
    getParameter(#id).setValid(true); \
  } \
}

/**
 * Testmethod class.
 *
 * For each testsuite using this testmethod, one object of this
 * class is created.
 */
class SetUtilityLines: public testmethod::TestMethod {
protected:
  string  type;
  string  utilityLineChannelOn;
  string  utilityLineChannelOff;
  string  utilityLineNameOn;
  string  utilityLineNameOff;
  string  utilityPurpose;
  double  waittime;

protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   *
   *Note: TestMethod API should not be used in this method.
   */
  virtual void initialize()
  {
    //Add your initialization code here
    addParameter("type",
                 "string",
                 &type,
                 testmethod::TM_PARAMETER_INPUT)
      .setDefault("UtilityLineName")
      .setOptions("UtilityLineName:UtilityLineChannel")
      .setComment("UtilityLineName and UtilityPurpose defined in pin configuration; UtilityLineChannel formated as UTI101");
    addParameter("utilityLineNameOn",
                 "string",
                 &utilityLineNameOn,
                 testmethod::TM_PARAMETER_INPUT);
    addParameter("utilityLineNameOff",
                 "string",
                 &utilityLineNameOff,
                 testmethod::TM_PARAMETER_INPUT);
    addParameter("utilityPurpose",
                 "string",
                 &utilityPurpose,
                 testmethod::TM_PARAMETER_INPUT);
    addParameter("utilityLineChannelOn",
                 "string",
                 &utilityLineChannelOn,
                 testmethod::TM_PARAMETER_INPUT);
    addParameter("utilityLineChannelOff",
                 "string",
                 &utilityLineChannelOff,
                 testmethod::TM_PARAMETER_INPUT);
    addParameter("waittime",
                 "double",
                 &waittime,
                 testmethod::TM_PARAMETER_INPUT)
      .setDefault("0.0")
      .setComment("the unit is second");
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
    FLEX_RELAY flexRelay;
    ON_FIRST_INVOCATION_BEGIN();
      // process and check parameter
      string typeString = CommonUtil::trim(type);
      if(typeString != "UtilityLineName" && typeString != "UtilityLineChannel")
      {
        throw Error("SetUtilityLines::run()",
                    "we just support types:UtilityLineName UtilityLineChannel",
                    "SetUtilityLines::run()");
      }
      
      utilityLineNameOn = CommonUtil::trim(utilityLineNameOn);
      utilityLineNameOff = CommonUtil::trim(utilityLineNameOff);
      utilityPurpose = CommonUtil::trim(utilityPurpose);
      utilityLineChannelOn = CommonUtil::trim(utilityLineChannelOn);
      utilityLineChannelOff = CommonUtil::trim(utilityLineChannelOff);
      
      if(waittime < 0)
      {
        throw Error("SetUtilityLines::run()",
                    "waittime can not be negative."
                    "SetUtilityLines::run()");  
      }

      if(typeString == "UtilityLineName")
      {
        if(utilityLineNameOn != "")
        {
          flexRelay.util(utilityLineNameOn).on();
        }
        if(utilityLineNameOff != "")
        {
          flexRelay.util(utilityLineNameOff).off();
        }
        if(utilityPurpose != "")
        {
          flexRelay.util_purpose(utilityPurpose).set();
        }
      }
      else 
      {
        if(utilityLineChannelOn != "")
        {
          flexRelay.util_channelRes(utilityLineChannelOn).on();
        }
        if(utilityLineChannelOff != "")
        {
          flexRelay.util_channelRes(utilityLineChannelOff).off();
        }
      }

      flexRelay.wait(waittime);
      flexRelay.execute();
    ON_FIRST_INVOCATION_END();
	  
    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   *
   *Note: TestMethod API should not be used in this method.
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    if(parameterIdentifier == "type")
    {
      if(CommonUtil::trim(type) == "UtilityLineName")
      {
        getParameter("utilityLineChannelOn").setEnabled(false);
        getParameter("utilityLineChannelOff").setEnabled(false);
        getParameter("utilityLineNameOn").setEnabled(true);
        getParameter("utilityLineNameOff").setEnabled(true);
        getParameter("utilityPurpose").setEnabled(true);
      }
      else if(CommonUtil::trim(type) == "UtilityLineChannel")
      {
        getParameter("utilityLineNameOn").setEnabled(false);
        getParameter("utilityLineNameOff").setEnabled(false);
        getParameter("utilityPurpose").setEnabled(false);
        getParameter("utilityLineChannelOn").setEnabled(true);
        getParameter("utilityLineChannelOff").setEnabled(true);
      }
      else
      {
        getParameter("type").setValid(false);
        getParameter("type").setMessage("current only support: UtilityLineName and UtilityLineChannel");
      }
    }
    CHECK_UTILITYLINES_PARAM(utilityLineNameOn);
    CHECK_UTILITYLINES_PARAM(utilityLineNameOff);
    CHECK_UTILITYLINES_PARAM(utilityLineChannelOn);
    CHECK_UTILITYLINES_PARAM(utilityLineChannelOff);
    if(waittime < 0)
    {
      getParameter("waittime").setValid(false);
      getParameter("waittime").setMessage("waittime can not be negative");
    }
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string  getComment() const
  {
     static string comment = _TML_VERSION;
     return comment;
  }
};
REGISTER_TESTMETHOD("OtherTest.SetUtilityLines", SetUtilityLines);
