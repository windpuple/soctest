/**
 * (c) Copyright 2011, Verigy Technologies, all rights reserved.
 *
 * Modification History:
 *
 *
 */

//for testmethod framework interfaces
#include "testmethod.hpp"

//for testmethod API interfaces
#include "mapi.hpp"

#include "CommonUtil.hpp"
using namespace std;

/**
 * Testmethod class.
 *
 * For each testsuite using this testmethod, one object of this
 * class is created.
 */
class TestheadTemperature: public testmethod::TestMethod {
protected:
  string  boardType;
  int  boardID;
  string  unit;

protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   *
   *Note: TestMethod API should not be used in this method.
   */
  virtual void initialize()
  {
    //Add your initialization code here
    addParameter("boardType",
                 "string",
                 &boardType,
                 testmethod::TM_PARAMETER_INPUT)
      .setDefault("ALL")
      .setOptions("ALL:DIGIO:PDPS:CLK")
      .setComment("ALL: get the hightest temperature of all of these types\n"
                  "DIGIO: DPS board(GP-DPS,HV-DPS,HC-DPS,MS-DPS)\n"
                  "PDPS: Digital IO board(including DC Scale channel boards)\n"
                  "CLK: Clock board");
    addParameter("boardID",
                 "int",
                 &boardID,
                 testmethod::TM_PARAMETER_INPUT)
      .setDefault("0")
      .setComment("the board number of the logical channel board\n"
                  "0 means all the same type board");
    addParameter("unit",
                 "string",
                 &unit,
                 testmethod::TM_PARAMETER_INPUT)
      .setDefault("F")
      .setOptions("F:K:C")
      .setComment("K for degrees Kelvin; C for degrees Celsius; F for degrees Fahrenheit");
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
    //Add your test code here.
    ON_FIRST_INVOCATION_BEGIN();
      DOUBLE kelvinValue = 0.0;
      string boardTypeString = CommonUtil::trim(boardType);
      string unitString = CommonUtil::trim(unit);
      // check parameter
      if(boardTypeString != "ALL"   &&
         boardTypeString != "DIGIO" &&
         boardTypeString != "PDPS"  &&
         boardTypeString != "CLK")
      {
        throw Error("TestheadTemperature::run()",
                    "board type can only be: ALL  DIGIO  PDPS  CLK.",
                    "TestheadTemperature::run()");
      }
      if(unitString != "K" && unitString != "C" && unitString != "F")
      {
        throw Error("TestheadTemperature::run()",
                    "unit can only be : K  C  F.",
                    "TestheadTemperature::run()");
      }
      if(boardID < 0)
      {
        throw Error("TestheadTemperature::run()",
                    "board id can't be negative!",
                    "TestheadTemperature::run()");
      }

      if(boardID != 0)
      {
        kelvinValue = GET_TESTHEAD_TEMPERATURE(boardTypeString,boardID);
      }
      else
      {
        kelvinValue = GET_TESTHEAD_TEMPERATURE(boardTypeString);
      }

      if(unitString == "F")
      {
        cout <<"The Fahrenheit temperature value is: "
             << (9.0/5.0) *(kelvinValue - 273) + 32.0
             <<endl;
      }
      else if(unitString == "C")
      {
        cout <<"The Celsius temperature value is: "
             <<kelvinValue - 273
             <<endl;
      }
      else
      {
        cout <<"The Kelvin temperature value is: "
             <<kelvinValue
             <<endl;
      }
    ON_FIRST_INVOCATION_END();
    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   *
   *Note: TestMethod API should not be used in this method.
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    if(parameterIdentifier == "boardType")
    {
      boardType = CommonUtil::trim(boardType);
      if(boardType != "ALL" && boardType != "DIGIO" &&
         boardType != "PDPS" && boardType != "CLK")
      {
        getParameter("boardType").setValid(false);
        getParameter("boardType").setMessage("board type can only be: ALL  DIGIO  PDPS  CLK");
      }
    }
    else if(parameterIdentifier == "boardID")
    {
      if(boardID < 0)
      {
        getParameter("boardID").setValid(false);
        getParameter("boardID").setMessage("board id can't be negative!");
      }
    }
    else
    {
      unit = CommonUtil::trim(unit);
      if(unit != "F" && unit != "K" && unit != "C")
      {
        getParameter("unit").setValid(false);
        getParameter("unit").setMessage("unit can only be : K  C  F.");
      }
    }
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string  getComment() const
  {
     static string comment = _TML_VERSION;
     return comment;
  }
};
REGISTER_TESTMETHOD("OtherTest.TestheadTemperature", TestheadTemperature);
