/**
 * (c) Copyright 2011, Verigy Technologies, all rights reserved.
 *
 * Modification History:
 *
 *
 */

//for testmethod framework interfaces
#include "testmethod.hpp"

//for testmethod API interfaces
#include "mapi.hpp"

#include "CommonUtil.hpp"

using namespace std;

/**
 * Testmethod class.
 *
 * For each testsuite using this testmethod, one object of this
 * class is created.
 */
class ExecuteLinuxCommand: public testmethod::TestMethod {
protected:
  string  command;
  int  timeout_s;
  int  ret;

protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   *
   *Note: TestMethod API should not be used in this method.
   */
  virtual void initialize()
  {
    //Add your initialization code here
    addParameter("command",
                 "string",
                 &command,
                 testmethod::TM_PARAMETER_INPUT)
      .setComment("the linux shell command to be executed");
    addParameter("timeout_s",
                 "int",
                 &timeout_s,
                 testmethod::TM_PARAMETER_INPUT)
      .setComment("during this time interval the shell command should be executed");
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
    ON_FIRST_INVOCATION_BEGIN();
      if(timeout_s < 0)
      {
        throw Error("ExecuteLinuxCommand::run()",
                    "timeout_s can not be negative.",
                    "ExecuteLinuxCommand::run()");    	  
      }
      ret = ExecuteShellCommand(command,timeout_s);
    ON_FIRST_INVOCATION_END();
    if(ret == 0)
    {
      TEST(" "," ",TM::Pass,0.0);
    }
    else
    {
      TEST(" "," ",TM::Fail,0.0);
    }
    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   *
   *Note: TestMethod API should not be used in this method.
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    if(parameterIdentifier == "timeout_s")
    {
      if(timeout_s < 0)
      {
        getParameter("timeout_s").setValid(false);
        getParameter("timeout_s").setMessage("timeout_s can not be negative.");
      }
    }
  
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string  getComment() const
  {
     static string comment = _TML_VERSION;
     return comment;
  }
};
REGISTER_TESTMETHOD("OtherTest.ExecuteLinuxCommand", ExecuteLinuxCommand);
