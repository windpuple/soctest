/**
 * (c) Copyright 2011, Verigy Technologies, all rights reserved.
 *
 * Modification History:
 *
 *
 */

//for testmethod framework interfaces
#include "testmethod.hpp"

//for testmethod API interfaces
#include "mapi.hpp"

#include "CommonUtil.hpp"

using namespace std;

/**
 * Testmethod class.
 *
 * For each testsuite using this testmethod, one object of this
 * class is created.
 */
class GetUtilityLines: public testmethod::TestMethod {
protected:
  int blockId;

protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   *
   *Note: TestMethod API should not be used in this method.
   */
  virtual void initialize()
  {
    //Add your initialization code here
    addParameter("blockId",
                 "int",
                 &blockId,
                 testmethod::TM_PARAMETER_INPUT)
      .setDefault("0")
      .setComment("specified block number, 0 means all utility line blocks.");    
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
    ON_FIRST_INVOCATION_BEGIN();
      if(blockId < 0 || blockId > 8)
      {
        throw Error("GetUtilityLines::run()",
                    "block id's range is [0,8).",
                    "GetUtilityLines::run()");
      }
      STRING_VECTOR utilitylinesStatus = GET_UTILITY_LINES_STATUS(blockId);
      if(blockId == 0)
      {
        for(unsigned int block = 0; block < utilitylinesStatus.size(); block ++)
        {
           cout << "get utility block " << block + 1 
                << "         =" << utilitylinesStatus[block] <<endl;
        }
      }
      else
      {
        cout << "get utility block " << blockId 
             << "        =" << utilitylinesStatus[0] <<endl;
      }
    ON_FIRST_INVOCATION_END();
    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   *
   *Note: TestMethod API should not be used in this method.
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    //Add your code
    if(blockId < 0 || blockId >8)
    {
      getParameter("blockId").setValid(false);
    }

    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string  getComment() const
  {
     static string comment = _TML_VERSION;
     return comment;
  }
};
REGISTER_TESTMETHOD("OtherTest.GetUtilityLines", GetUtilityLines);
