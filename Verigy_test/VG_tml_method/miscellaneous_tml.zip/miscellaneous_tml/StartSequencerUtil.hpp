#ifndef INCLUDE_STARTSEQUENCERUTIL_H
#define INCLUDE_STARTSEQUENCERUTIL_H
#include "CommonUtil.hpp"

const static unsigned long HP_DELAY_CYCLES_MIN = 1;
//max. 2G cycles for 32-bits OS; for 64-bits OS, we should change this limits.
const static unsigned long HP_DELAY_CYCLES_MAX = 2147483647;   

static unsigned long get_SQGB_delay()
{
  unsigned long  delayCounter;
  string answer;
  int iPosition = 0;
       
  if(FW_PASSED != FW_TASK("SQGB?\n", answer))
  {
    throw Error("get_SQGB_delay()",
                "the execution firmware \"SQGB?\n\" is not successful",
                "get_SQGB_delay()");
  }
  // the return answer of "SQGB?\n" like:
  // SQGB {mode},[analyze_delay][,(port)]
  iPosition = answer.find_first_of(',');
  delayCounter = CommonUtil::string2Long(
                              answer.substr(iPosition+1),
                              "currentCounter");
  return delayCounter;
}
class StartSequencerTest
{
public:
  struct StartSequencerParam
  {
    string endlessMode;
    string stopOnErrorMode;
    string stopByDelayCounter;
    unsigned long cycleNumber;
    string output;   
 
    void init()
    {
      endlessMode = "OFF";
      stopOnErrorMode = "OFF";
      stopByDelayCounter = "OFF";
      cycleNumber = 0;
      output = "ReportUI";
    }
    
    StartSequencerParam()
    {
      init();
    }
  };	
  
  static void processParameter(const string& endlessMode,
                               const string& stopOnErrorMode,
                               const string& stopByDelayCounter,
                               const string& cycleNumber,
                               StartSequencerParam& param)
  {
    param.endlessMode = CommonUtil::trim(endlessMode);
    param.stopOnErrorMode = CommonUtil::trim(stopOnErrorMode);
    param.stopByDelayCounter = CommonUtil::trim(stopByDelayCounter);
    //check parameter
    if(param.endlessMode != "OFF" && param.endlessMode != "ON")
    {
      throw Error("StartSequencerTest::processParameter()",
                  "endless mode can only be ON or OFF!",
                  "StartSequencerTest::processParameter()");
    }
    if(param.stopOnErrorMode != "OFF" && param.stopOnErrorMode != "ON")
    {
      throw Error("StartSequencerTest::processParameter()",
                  "stop on error mode can only be ON or OFF!",
                  "StartSequencerTest::processParameter()");
    }
    if(param.stopByDelayCounter != "OFF" && param.stopByDelayCounter != "ON")
    {
      throw Error("StartSequencerTest::processParameter()",
                  "stop on error mode can only be ON or OFF!",
                  "StartSequencerTest::processParameter()");
    }
    
    if(param.stopByDelayCounter == "ON")
    {  
      string delayCounterNumber = CommonUtil::trim(cycleNumber);
      if(delayCounterNumber == "current_value" ||
         delayCounterNumber.empty())
      {
        param.cycleNumber = get_SQGB_delay();
      }
      else
      {
        string first = delayCounterNumber.substr(0,1);
     
        if(first == "+" || first == "-")
        {
          param.cycleNumber = CommonUtil::string2Long(
                                            delayCounterNumber.substr(1),
                                            "delaycycleNumber");
          if(first == "+")
          {
            param.cycleNumber = get_SQGB_delay() + param.cycleNumber;
          }
          else
          {
            param.cycleNumber = get_SQGB_delay() - param.cycleNumber;
          }
        }
        else
        {
          param.cycleNumber = CommonUtil::string2Long(
                                            delayCounterNumber.substr(0),
                                            "delayCounterNumber");
        }
      }
      
      // check paramter stopByDelayCounter
      if(param.cycleNumber < HP_DELAY_CYCLES_MIN ||
         param.cycleNumber > HP_DELAY_CYCLES_MAX)
      {
        cerr << " ERROR: " <<endl
             << " Stop by delay counter cycle must be in range: " <<"["
             << HP_DELAY_CYCLES_MIN << "," <<HP_DELAY_CYCLES_MAX <<"]" <<endl;
        cerr << "Executing complete test in cycle oriented mode." <<endl;
      }
    }
  }
  static void doMeasurement(const StartSequencerParam& param)
  {
    if(param.endlessMode == "ON" && param.stopOnErrorMode == "ON")
    {
      Sequencer.run(TM::STOPONERROR_LOOP);
    }
    else if(param.endlessMode == "ON")
    {
      Sequencer.run(TM::ENDLESS_LOOP);
    }
    else if(param.stopOnErrorMode == "ON")
    {
      Sequencer.run(TM::STOPONERROR);
    }
    else if(param.stopByDelayCounter == "ON" && param.cycleNumber > 0)
    {
      //because this member function will add 1 at current number
      Sequencer.stopCycle(param.cycleNumber - 1).run();
    }
    else
    {
      FW_TASK("SQGB EMPS,;SQST RUN\n");
      cerr << "WARNING:" <<endl
           << "Executing complete test in cycle oriented mode."<<endl;
    }
  }
  
  static void reportToUI(const StartSequencerParam& param)
  {
    if(param.output == "ReportUI")
    {
      if(param.endlessMode == "ON" && param.stopOnErrorMode == "ON")
      {
        cout <<"Sequencer is running in stop on error loop mode." <<endl;
      }
      else if(param.endlessMode == "ON")
      {
        cout <<"Sequencer is running in endless mode." <<endl;
      }	
      else if(param.stopOnErrorMode == "ON")
      {
        cout <<"Sequencer is running in stop on error mode." <<endl;
      }
      else if(param.stopByDelayCounter == "ON")
      {
        cout <<"Sequencer is running in stop by delay counter mode." <<endl;
        cout <<"the delay counter is:" << param.cycleNumber -1 <<endl;
      }
    } 
  }
};
#endif
