/**
 * (c) Copyright 2011, Verigy Technologies, all rights reserved.
 *
 * Modification History:
 *
 *
 */

//for testmethod framework interfaces
#include "testmethod.hpp"
//for test method API interfaces
#include "mapi.hpp"

#include "SetupLevelSet0Util.hpp"

using namespace std;

/**
 * Test method class.
 *
 * For each testsuite using this test method, one object of this
 * class is created.
 */
class SetupLevelSet0: public testmethod::TestMethod {
protected:
  string  mPins;
  string  mClampMode;
  string  mClampVoltageHigh;
  string  mClampVoltageLow;
  string  mActiveLoadMode;
  string  mActiveLoadCommutationVoltage;
  string  mActiveLoadSourceCurrent;
  string  mActiveLoadSinkCurrent;
  SetupLevelSet0Util mSetupUtility;
  bool mIsParameterChanged;
protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   *
   *Note: Test Method API should not be used in this method.
   */
  virtual void initialize()
  {
    mIsParameterChanged = true;

    addParameter("Pins[]",
                 "string",
                 &mPins,
                 testmethod::TM_PARAMETER_INPUT)
      .setComment("pins array. separator is ';' for different setup per pins\n"
         "e.g. \"DataIn;DataOut\" with different level set 0 configuration\n"
         "only I/O/IO digital pins are supported");

    addParameter("ClampVoltage.Mode[]",
                 "string",
                 &mClampMode,
                 testmethod::TM_PARAMETER_INPUT)
      .setComment("array of clamp mode. "
         "element could be : 'ON' or 'OFF'\n"
         "separator is ';' for different setup per pins");

    addParameter("ClampVoltage.Low_V[]",
                 "string",
                 &mClampVoltageLow,
                 testmethod::TM_PARAMETER_INPUT)
      .setComment("array of clamp voltage low. "
         "element is voltage value in string, unit is [V]\n"
         "separator is ';' for different setup per pins");

    addParameter("ClampVoltage.High_V[]",
                 "string",
                 &mClampVoltageHigh,
                 testmethod::TM_PARAMETER_INPUT)
      .setComment("array of clamp voltage high. "
         "element is voltage value in string, unit is [V]\n"
         "separator is ';' for different setup per pins");

    addParameter("ActiveLoad.Mode[]",
                 "string",
                 &mActiveLoadMode,
                 testmethod::TM_PARAMETER_INPUT)
      .setComment("array of active load mode. "
         "element could be : 'ON','OFF'\n"
         "ON:   setup active load setting: Vt,Iol,Ioh\n"
         "OFF:  turn off active load setting\n"
         "separator is ';' for different setup per pins");

    addParameter("ActiveLoad.CommutationVoltage_V[]",
                 "string",
                 &mActiveLoadCommutationVoltage,
                 testmethod::TM_PARAMETER_INPUT)
      .setComment("arrary of commutation voltage(Vt)."
         "element is voltage value in string, unit is [V]\n"
         "separator is ';' for different setup per pins");

    addParameter("ActiveLoad.SourceCurrent_A[]",
                 "string",
                 &mActiveLoadSourceCurrent,
                 testmethod::TM_PARAMETER_INPUT)
      .setComment("arrary of source current (IOH)."
         "element is crrent value in string, unit is [A]\n"
         "separator is ';' for different setup per pins");

    addParameter("ActiveLoad.SinkCurrent_A[]",
                 "string",
                 &mActiveLoadSinkCurrent,
                 testmethod::TM_PARAMETER_INPUT)
      .setComment("arrary of sink current (IOL)."
         "element is crrent value in string, unit is [A]\n"
         "separator is ';' for different setup per pins");
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
    static bool sIsFirstRun = true;

    //only run this setup once OR there are some parameters changed
    if (sIsFirstRun || mIsParameterChanged)
    {
      ON_FIRST_INVOCATION_BEGIN();
        if(CommonUtil::getCurrentSmarTestVersion() < CommonUtil::SmarTestVersion(6,3,6))
        {
          throw Error("SetupLevelSet0", 
            "SmarTest version is older than 6.3.6, Level Set0 testmethod is not supported.",
            "SetupLevelSet0");
        }
        else
        {     
          mSetupUtility.processParameter(
            mPins,
            mClampMode,
            mClampVoltageLow,
            mClampVoltageHigh,
            mActiveLoadMode,
            mActiveLoadCommutationVoltage,
            mActiveLoadSourceCurrent,
            mActiveLoadSinkCurrent);
	      
          mIsParameterChanged = false;
	      
          mSetupUtility.doMeasurement();
        }
      ON_FIRST_INVOCATION_END();
	  
      sIsFirstRun = false;
    }
    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   *
   *Note: Test Method API should not be used in this method.
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    #define ARRAY_SIZE_MISMATCH_ERROR_MSG(idString) \
      ("array size of "+(idString)+" should be equal to Pins[].")

    mIsParameterChanged = true;
    if (parameterIdentifier == "Pins[]")
    {
      mSetupUtility.setPins(mPins);
    }
    else if (parameterIdentifier == "ClampVoltage.Mode[]")
    {
      testmethod::TestMethodParameterProxy paramProxy = getParameter(parameterIdentifier); 
      if (!mSetupUtility.setClampMode(mClampMode))
      {
    	paramProxy.setValid(false);
    	paramProxy.setMessage("element value of "+parameterIdentifier+" should be: ON,OFF.");
      }
      else if(mSetupUtility.getClampModeVector().size() != 
        mSetupUtility.getPinVector().size())
      {
    	paramProxy.setValid(false);
    	paramProxy.setMessage(ARRAY_SIZE_MISMATCH_ERROR_MSG(parameterIdentifier));
      }
      else
      {
        paramProxy.setValid(true);
        paramProxy.setMessage("");
      }
    }
    else if (parameterIdentifier == "ClampVoltage.Low_V[]")
    {
      testmethod::TestMethodParameterProxy paramProxy = getParameter(parameterIdentifier); 
      if (!mSetupUtility.setClampLow(mClampVoltageLow))
      {
    	paramProxy.setValid(false);
    	paramProxy.setMessage("value of "+parameterIdentifier+" is invalid.");
      }
      else if(mSetupUtility.getClampLowVector().size() != 
        mSetupUtility.getPinVector().size())
      {
    	paramProxy.setValid(false);
    	paramProxy.setMessage(ARRAY_SIZE_MISMATCH_ERROR_MSG(parameterIdentifier));
      }
      else
      {
        paramProxy.setValid(true);
        paramProxy.setMessage("");
      }
    }	
    else if (parameterIdentifier == "ClampVoltage.High_V[]")
    {
      testmethod::TestMethodParameterProxy paramProxy = getParameter(parameterIdentifier); 
      if (!mSetupUtility.setClampHigh(mClampVoltageHigh))
      {
    	paramProxy.setValid(false);
    	paramProxy.setMessage("value of "+parameterIdentifier+" is invalid.");
      }
      else if(mSetupUtility.getClampHighVector().size() != 
        mSetupUtility.getPinVector().size())
      {
    	paramProxy.setValid(false);
    	paramProxy.setMessage(ARRAY_SIZE_MISMATCH_ERROR_MSG(parameterIdentifier));
      }
      else
      {
        paramProxy.setValid(true);
        paramProxy.setMessage("");
      }
    }
    else if (parameterIdentifier == "ActiveLoad.Mode[]")
    {
      testmethod::TestMethodParameterProxy paramProxy = getParameter(parameterIdentifier); 
      if (!mSetupUtility.setActiveLoadMode(mActiveLoadMode))
      {
    	paramProxy.setValid(false);
    	paramProxy.setMessage("element value of "+parameterIdentifier+" should be: ON,OFF");
      }
      else if(mSetupUtility.getActiveLoadModeVector().size() != 
        mSetupUtility.getPinVector().size())
      {
    	paramProxy.setValid(false);
    	paramProxy.setMessage(ARRAY_SIZE_MISMATCH_ERROR_MSG(parameterIdentifier));
      }
      else
      {
        paramProxy.setValid(true);
        paramProxy.setMessage("");
      }
    }
    else if (parameterIdentifier == "ActiveLoad.CommutationVoltage_V[]")
    {
      testmethod::TestMethodParameterProxy paramProxy = getParameter(parameterIdentifier); 
      if (!mSetupUtility.setActiveLoadCommVoltage(mActiveLoadCommutationVoltage))
      {
    	paramProxy.setValid(false);
    	paramProxy.setMessage("value of "+parameterIdentifier+" is invalid.");
      }
      else if(mSetupUtility.getActiveLoadCommVoltageVector().size() != 
        mSetupUtility.getPinVector().size())
      {
    	paramProxy.setValid(false);
    	paramProxy.setMessage(ARRAY_SIZE_MISMATCH_ERROR_MSG(parameterIdentifier));
      }
      else
      {
        paramProxy.setValid(true);
        paramProxy.setMessage("");
      }
    }
    else if (parameterIdentifier == "ActiveLoad.SourceCurrent_A[]")
    {
      testmethod::TestMethodParameterProxy paramProxy = getParameter(parameterIdentifier); 
      if (!mSetupUtility.setActiveLoadSourceCurrent(mActiveLoadSourceCurrent))
      {
    	paramProxy.setValid(false);
    	paramProxy.setMessage("value of "+parameterIdentifier+" is invalid!.");
      }
      else if(mSetupUtility.getActiveLoadSourceCurrentVector().size() != 
        mSetupUtility.getPinVector().size())
      {
    	paramProxy.setValid(false);
    	paramProxy.setMessage(ARRAY_SIZE_MISMATCH_ERROR_MSG(parameterIdentifier));
      }
      else
      {
        paramProxy.setValid(true);
        paramProxy.setMessage("");
      }
    }
    else if (parameterIdentifier == "ActiveLoad.SinkCurrent_A[]")
    {
      testmethod::TestMethodParameterProxy paramProxy = getParameter(parameterIdentifier); 
      if (!mSetupUtility.setActiveLoadSinkCurrent(mActiveLoadSinkCurrent))
      {
    	paramProxy.setValid(false);
    	paramProxy.setMessage("value of "+parameterIdentifier+" is invalid!.");
      }
      else if(mSetupUtility.getActiveLoadSinkCurrentVector().size() != 
        mSetupUtility.getPinVector().size())
      {
    	paramProxy.setValid(false);
    	paramProxy.setMessage(ARRAY_SIZE_MISMATCH_ERROR_MSG(parameterIdentifier));
      }
      else
      {
        paramProxy.setValid(true);
        paramProxy.setMessage("");
      }
    }	
    #undef ARRAY_SIZE_MISMATCH_ERROR_MSG
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string  getComment() const
  {
     static string comment = _TML_VERSION;
     return comment;
  }
};
REGISTER_TESTMETHOD("TestControl.SetupLevelSet0", SetupLevelSet0);
