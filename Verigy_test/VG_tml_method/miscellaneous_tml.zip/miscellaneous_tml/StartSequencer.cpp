/**
 * (c) Copyright 2011, Verigy Technologies, all rights reserved.
 *
 * Modification History:
 *
 *
 */

//for testmethod framework interfaces
#include "testmethod.hpp"
//for testmethod API interfaces
#include "mapi.hpp"

#include "StartSequencerUtil.hpp"

using namespace std;

/**
 * Testmethod class.
 *
 * For each testsuite using this testmethod, one object of this
 * class is created.
 */
class StartSequencer: public testmethod::TestMethod {
protected:
  string  endless;
  string  stopOnError;
  string  stopByDelayCounter;
  string  cycleNumber;
  string  output;

protected:
  /**
   *Initialize the parameter interface to the testflow.
   *This method is called just once after a testsuite is created.
   *
   *Note: TestMethod API should not be used in this method.
   */
  virtual void initialize()
  {
    //Add your initialization code here
    addParameter("endless",
                 "string",
                 &endless,
                 testmethod::TM_PARAMETER_INPUT)
      .setDefault("OFF")
      .setOptions("OFF:ON")
      .setComment("whether the sequencer run in endless");
    addParameter("stopOnError",
                 "string",
                 &stopOnError,
                 testmethod::TM_PARAMETER_INPUT)
      .setDefault("OFF")
      .setOptions("OFF:ON")
      .setComment("whether stop execution of pattern if a vector failure occurs.");
    addParameter("stopByDelayCounter",
                 "string",
                 &stopByDelayCounter,
                 testmethod::TM_PARAMETER_INPUT)
      .setDefault("OFF")
      .setOptions("OFF:ON")
      .setComment("this parameter can only enable when endless  and stopOnError are \"OFF\"");
    addParameter("stopByDelayCounter.cycleNumber",
                 "string",
                 &cycleNumber,
                 testmethod::TM_PARAMETER_INPUT)
      .setOptions("current_value")
      .setComment("stop execution of the pattern after the specified delay counter test system cycles\n"
                  "this parameter only takes effect when stopByDelayCounter is \"ON\"\n"
                  "current_value or blank: to use current setting to run sequencer\n"
                  " +/-number:  to +/- number of cycles of current setting\n"
                  " number:     to delay number of cycles");
    addParameter("output",
                 "string",
                 &output)
      .setDefault("None")
      .setOptions("ReportUI:None")
      .setComment("display result or not");
  }

  /**
   *This test is invoked per site.
   */
  virtual void run()
  {
    //Add your test code here.
    static StartSequencerTest::StartSequencerParam param;
    ON_FIRST_INVOCATION_BEGIN();
      StartSequencerTest::processParameter(endless,
                                           stopOnError,
                                           stopByDelayCounter,
                                           cycleNumber,
                                           param);
      StartSequencerTest::doMeasurement(param);
      StartSequencerTest::reportToUI(param);
    ON_FIRST_INVOCATION_END();
    return;
  }

  /**
   *This function will be invoked once the specified parameter's value is changed.
   *@param parameterIdentifier
   *
   *Note: TestMethod API should not be used in this method.
   */
  virtual void postParameterChange(const string& parameterIdentifier)
  {
    if(parameterIdentifier == "stopByDelayCounter")
    {
      if(CommonUtil::trim(endless) == "ON" || 
         CommonUtil::trim(stopOnError) == "ON")
      {
        getParameter("stopByDelayCounter").setEnabled(false);
      }
      else
      {
        getParameter("stopByDelayCounter").setEnabled(true);
      }
	  
      if(CommonUtil::trim(stopByDelayCounter) == "ON")
      {
        endless = "OFF";
        stopOnError = "OFF";
        getParameter("endless").setEnabled(false);
        getParameter("stopOnError").setEnabled(false);
        getParameter("stopByDelayCounter.cycleNumber").setEnabled(true);
      }
      else
      {
        getParameter("endless").setEnabled(true);  
        getParameter("stopOnError").setEnabled(true);     
        getParameter("stopByDelayCounter.cycleNumber").setEnabled(false);
      }		  
    }
	
    return;
  }

  /**
   *This function will be invoked once the Select Test Method Dialog is opened.
   */
  virtual const string  getComment() const
  {
     static string comment = _TML_VERSION;
     return comment;
  }
};
REGISTER_TESTMETHOD("SequencerControl.StartSequencer", StartSequencer);
