// ClassScanTest.cpp


//for testmethod framework interfaces
#include "testmethod.hpp"
//for testmethod API interfaces
#include "mapi.hpp"

using namespace std;

const static string _TML_VERSION = "version: tml_7.1.2_2.1.3";

/**
 *Testmethod class.
 *
 *For each testsuite using this testmethod, one object of this
 *class is created.
 */
class ScanTest: public testmethod::TestMethod
{
protected:
  string  scanPins;
  int  maxFailsPerPin;
  int  cycleBased;
  int  includeExpectedData;
  int  testerCycleMode;
  string mTestName;
  int mTestNumber;
  bool mIsLimitTableUsed;
  string mSoftBinNumberString;
  int   mHardBinNumber;
protected:
/**
 *Initialize the parameter interface to the testflow.
 *This method is called just once after a testsuite is created.
 *
 *Note: TestMethod API should not be used in this method.
 */
virtual void initialize()
{
  mTestNumber = 0;
  mIsLimitTableUsed = false;
  mSoftBinNumberString = "";
  mHardBinNumber = -1;

  addParameter("scanPins",
               "string",
               &scanPins)
    .setDefault("@");
  addParameter("maxFailsPerPin",
               "int",
               &maxFailsPerPin)
    .setDefault("-1");
  addParameter("cycleBased",
               "int",
               &cycleBased)
    .setDefault("1");
  addParameter("includeExpectedData",
               "int",
               &includeExpectedData)
    .setDefault("0");
  addParameter("testerCycleMode",
               "int",
               &testerCycleMode)
    .setDefault("1");
  addParameter("testName",
               "string",
               &mTestName)
    .setDefault("ScanTest")
    .setComment("test limit's name, default is \"ScanTest\"\n"
       "if test table is used, the limit is defined in file\n"
       "if predefined limit is used, the limit name must be as same as default.");

  addLimit("ScanTest"); 
}

/**
 *This test is invoked per site.
 */
virtual void run()
{
  ERROR_MAP_TEST emap(testerCycleMode ? TM::TESTER_CYCLES : TM::XMODE_CYCLES);
  
  SCAN_TEST_RESULT log(cycleBased ? TM::CYCLE_BASED_LOGGING : TM::PATTERN_BASED_LOGGING);
  
  ON_FIRST_INVOCATION_BEGIN();
    /* Prepare limit information from limit table */
    TestTable* pLimitTable = TestTable::getDefaultInstance();
    pLimitTable->readCsvFile();
    mIsLimitTableUsed = pLimitTable->isTmLimitsCsvFile();
	if (mIsLimitTableUsed)
	{
		try{
			string testsuiteName;
			GET_TESTSUITE_NAME(testsuiteName);
			string key = testsuiteName + ":" + mTestName;
			V93kLimits::TMLimits::LimitInfo limitInfo = V93kLimits::tmLimits.getLimit(key);
			mTestNumber = limitInfo.TestNumber;
			mSoftBinNumberString = limitInfo.BinsNumString;
			mHardBinNumber = limitInfo.BinhNum;
		}
		catch (Error e)
		{
			mIsLimitTableUsed = false;
		}
	}

    /* Setup the error map */
    emap.pin(scanPins).setLocation(TM::RAM)
      .setRecordingMode(TM::PF)
      .setStartCycle(0);

    /* Execute functional test */
    CONNECT();
    FUNCTIONAL_TEST();
  ON_FIRST_INVOCATION_END();
  
  /* If functional test has passed, no further processing has to be done */
  if(GET_FUNCTIONAL_RESULT()) {
    return;
  }
  
  /* Retrieve the overall failures for this site */
  log.totalFailures(emap.getErrorCount());  
  log.totalCyclesExecuted(emap.getLastCycleExecuted());
  
  STRING_VECTOR pins =
    PIN_UTILITY::getDigitalPinNamesFromPinList(scanPins, TM::O_PIN | TM::IO_PIN);
  

  /* Retrieve the failing cycles per pin for this site */
  for(STRING_VECTOR::size_type i=0; i<pins.size(); i++) {
    INT failsToUpload = 1;
    INT failsForPin = emap.pin(pins[i]).getErrorCount();

    if(-1 == maxFailsPerPin) {
      /* -1 means upload all fails for this pin */
      failsToUpload = failsForPin;
    }
    else {
      /* upload not more than maxFailsPerPin */
      failsToUpload = min(maxFailsPerPin, failsForPin);
    }

    if(0 == failsToUpload) {
      /* no failures on this pin, skip to the next one */
      continue;
    }
    
    ARRAY_LL cycles;
    emap.pin(pins[i]).getFirstFailingCycles(0, failsToUpload, cycles); 
    log.pin(pins[i]).failingCycles(cycles);
    
    if(includeExpectedData) {
      ARRAY_CHAR expected;
      emap.pin(pins[i]).getExpectedDataForCycles(cycles, expected);
      log.pin(pins[i]).expectedData(expected);
    }
  }
  
  /* Push the failures to datalog */
  if (mIsLimitTableUsed)
  {
    bool isPass = TESTSET().testnumber(mTestNumber)
                           .testname(mTestName)
                           .judgeAndLog_ScanTest(log);
    if(!isPass && !mSoftBinNumberString.empty())
    {
      SET_MULTIBIN(mSoftBinNumberString,mHardBinNumber);
    }
  }
  else
  {
    TESTSET().testnumber(mTestName,true).judgeAndLog_ScanTest(log);
  }
  return;
}

/**
 *This function will be invoked once the specified parameter's value is changed.
 *@param parameterIdentifier
 *
 *Note: TestMethod API should not be used in this method.
 */
virtual void postParameterChange(const string& parameterIdentifier)
{
  //add your code
}

/**
 *This function will be invoked once the Select Test Method Dialog is opened.
 */
virtual const string  getComment() const
{
   static string comment = _TML_VERSION;
   return comment;
}
};

REGISTER_TESTMETHOD("ScanTest.ScanTest",ScanTest);

